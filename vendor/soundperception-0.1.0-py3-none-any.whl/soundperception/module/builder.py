"""Fluent API builder for creating pipelines.

This module provides PipelineBuilder for a more expressive
way to construct pipelines using method chaining.
"""

from __future__ import annotations


from .base import ModuleProtocol
from .pipeline import Pipeline


class PipelineBuilder:
    """Fluent builder for constructing Pipeline instances.

    Provides a more readable API for building pipelines with
    method chaining and implicit connection inference.

    Example:
        >>> pipeline = (
        ...     PipelineBuilder("AudioAnalysis")
        ...     .with_module("extractor", GlobalExtractor(config))
        ...     .with_module("categorizer", Categorizer(config))
        ...     .connect("extractor.mean", "categorizer.image")
        ...     .input("signal", "extractor.signal")
        ...     .output("categories", "categorizer.categories")
        ...     .build()
        ... )

    Alternative flow-based API:
        >>> pipeline = (
        ...     PipelineBuilder("AudioAnalysis")
        ...     .source("signal")
        ...     .then("extractor", GlobalExtractor(config), input_port="signal")
        ...     .then("categorizer", Categorizer(config), input_port="image", from_port="mean")
        ...     .output("categories", "categorizer.categories")
        ...     .build()
        ... )
    """

    def __init__(self, name: str, description: str = "") -> None:
        """Initialize the builder.

        Args:
            name: Pipeline name.
            description: Optional description.
        """
        self._pipeline = Pipeline(name, description)
        self._last_module: str | None = None
        self._pending_source: str | None = None

    def with_module(self, name: str, module: ModuleProtocol) -> "PipelineBuilder":
        """Add a module to the pipeline.

        Args:
            name: Unique module name.
            module: Module instance.

        Returns:
            Self for method chaining.
        """
        self._pipeline.add(name, module)
        self._last_module = name
        return self

    def connect(self, source: str, target: str) -> "PipelineBuilder":
        """Connect two module ports.

        Args:
            source: Source in "module.port" format.
            target: Target in "module.port" format.

        Returns:
            Self for method chaining.
        """
        self._pipeline.connect(source, target)
        return self

    def input(self, name: str, target: str) -> "PipelineBuilder":
        """Define a pipeline input.

        Args:
            name: External input name.
            target: Target in "module.port" format.

        Returns:
            Self for method chaining.
        """
        self._pipeline.set_input(name, target)
        return self

    def output(self, name: str, source: str) -> "PipelineBuilder":
        """Define a pipeline output.

        Args:
            name: External output name.
            source: Source in "module.port" format.

        Returns:
            Self for method chaining.
        """
        self._pipeline.set_output(name, source)
        return self

    def source(self, input_name: str) -> "PipelineBuilder":
        """Start a flow from a pipeline input.

        Args:
            input_name: Name of the pipeline input.

        Returns:
            Self for method chaining.
        """
        self._pending_source = input_name
        return self

    def then(
        self,
        module_name: str,
        module: ModuleProtocol,
        input_port: str | None = None,
        from_port: str | None = None,
    ) -> "PipelineBuilder":
        """Add the next module in the flow.

        If there's a pending source (from source()), connects it.
        If there's a previous module, connects from it.

        Args:
            module_name: Name for this module.
            module: Module instance.
            input_port: Target input port name (uses first if not specified).
            from_port: Source output port name (uses first if not specified).

        Returns:
            Self for method chaining.
        """
        self._pipeline.add(module_name, module)

        if input_port is None:
            inputs = module.inputs
            if inputs:
                input_port = next(iter(inputs.keys()))
            else:
                input_port = "input"

        if self._pending_source is not None:
            self._pipeline.set_input(self._pending_source, f"{module_name}.{input_port}")
            self._pending_source = None

        elif self._last_module is not None:
            last_mod = self._pipeline._modules[self._last_module]
            if from_port is None:
                outputs = last_mod.outputs
                if outputs:
                    from_port = next(iter(outputs.keys()))
                else:
                    from_port = "output"

            self._pipeline.connect(
                f"{self._last_module}.{from_port}",
                f"{module_name}.{input_port}",
            )

        self._last_module = module_name
        return self

    def branch(
        self,
        module_name: str,
        module: ModuleProtocol,
        from_module: str,
        from_port: str,
        input_port: str | None = None,
    ) -> "PipelineBuilder":
        """Create a branch from an existing module.

        This allows creating parallel paths in the pipeline.

        Args:
            module_name: Name for this module.
            module: Module instance.
            from_module: Source module name.
            from_port: Source output port name.
            input_port: Target input port name (uses first if not specified).

        Returns:
            Self for method chaining.
        """
        self._pipeline.add(module_name, module)

        if input_port is None:
            inputs = module.inputs
            if inputs:
                input_port = next(iter(inputs.keys()))
            else:
                input_port = "input"

        self._pipeline.connect(f"{from_module}.{from_port}", f"{module_name}.{input_port}")

        self._last_module = module_name
        return self

    def merge(
        self,
        module_name: str,
        module: ModuleProtocol,
        connections: dict[str, str],
    ) -> "PipelineBuilder":
        """Merge multiple outputs into a single module.

        Args:
            module_name: Name for this module.
            module: Module instance.
            connections: Dict mapping "module.port" sources to input port names.

        Returns:
            Self for method chaining.

        Example:
            >>> builder.merge(
            ...     "combiner",
            ...     CombinerModule(config),
            ...     connections={
            ...         "extractor.mean": "input_a",
            ...         "extractor.std": "input_b",
            ...     }
            ... )
        """
        self._pipeline.add(module_name, module)

        for source, input_port in connections.items():
            self._pipeline.connect(source, f"{module_name}.{input_port}")

        self._last_module = module_name
        return self

    def build(self) -> Pipeline:
        """Build and return the pipeline.

        Returns:
            Configured Pipeline instance.
        """
        return self._pipeline


def pipeline(name: str, description: str = "") -> PipelineBuilder:
    """Create a new pipeline builder.

    Convenience function for starting a pipeline definition.

    Args:
        name: Pipeline name.
        description: Optional description.

    Returns:
        PipelineBuilder instance.

    Example:
        >>> p = (
        ...     pipeline("MyPipeline")
        ...     .with_module("a", ModuleA())
        ...     .with_module("b", ModuleB())
        ...     .connect("a.out", "b.in")
        ...     .build()
        ... )
    """
    return PipelineBuilder(name, description)
