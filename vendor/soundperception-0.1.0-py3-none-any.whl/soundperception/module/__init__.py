"""Unified module system for soundperception.

This package provides a framework for defining, composing, and executing
processing modules with well-defined inputs, outputs, and parameters.

Key Components:
    - Specifications (specs.py): TensorShape, InputSpec, OutputSpec, ParameterSpec
    - Base Classes (base.py): ModuleProtocol, ModuleBase
    - Adapter (adapter.py): @module decorator for adapting existing classes
    - Pipeline (pipeline.py): Pipeline for composing modules
    - Builder (builder.py): Fluent API for building pipelines

Example Usage:
    >>> from soundperception.module import (
    ...     module, InputSpec, OutputSpec, Pipeline, pipeline
    ... )
    >>> import numpy as np
    >>>
    >>> @module(
    ...     inputs={"signal": InputSpec("signal", np.ndarray, "Input signal")},
    ...     outputs={"result": OutputSpec("result", np.ndarray, "Processed result")},
    ...     method="process",
    ... )
    ... class MyProcessor:
    ...     def __init__(self, config=None):
    ...         self.config = config
    ...
    ...     def process(self, signal):
    ...         return {"result": signal * 2}
    >>>
    >>> # Create and use directly
    >>> processor = MyProcessor()
    >>> result = processor(signal=np.array([1, 2, 3]))
    >>>
    >>> # Or compose in a pipeline
    >>> p = (
    ...     pipeline("Example")
    ...     .with_module("proc", processor)
    ...     .input("data", "proc.signal")
    ...     .output("output", "proc.result")
    ...     .build()
    ... )
    >>> result = p(data=np.array([1, 2, 3]))
"""

from .adapter import ModuleWrapper, adapt_existing, is_module, module
from .base import ModuleBase, ModuleProtocol
from .builder import PipelineBuilder, pipeline
from .pipeline import Connection, Pipeline, PipelineInput, PipelineOutput
from .specs import InputSpec, ModuleSchema, OutputSpec, ParameterSpec, TensorShape

__all__ = [
    # Specifications
    "TensorShape",
    "InputSpec",
    "OutputSpec",
    "ParameterSpec",
    "ModuleSchema",
    # Protocol and Base
    "ModuleProtocol",
    "ModuleBase",
    # Adapter
    "module",
    "adapt_existing",
    "is_module",
    "ModuleWrapper",
    # Pipeline
    "Pipeline",
    "Connection",
    "PipelineInput",
    "PipelineOutput",
    # Builder
    "PipelineBuilder",
    "pipeline",
]
