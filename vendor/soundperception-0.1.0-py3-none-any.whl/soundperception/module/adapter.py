"""Adapter decorator for wrapping existing classes as modules.

This module provides the @module decorator that wraps existing classes
to implement the ModuleProtocol without modifying the original code.
"""

from __future__ import annotations

from dataclasses import fields, is_dataclass
from functools import wraps
from typing import Any, Callable, Generic, TypeVar

from .base import ModuleProtocol
from .specs import InputSpec, ModuleSchema, OutputSpec, ParameterSpec

T = TypeVar("T")


def module(
    inputs: dict[str, InputSpec],
    outputs: dict[str, OutputSpec],
    method: str = "__call__",
    name: str | None = None,
    description: str | None = None,
) -> Callable[[type[T]], type[T]]:
    """Decorator to adapt an existing class to the ModuleProtocol.

    This decorator wraps an existing class to provide:
    - inputs, outputs, parameters properties
    - __call__ method that delegates to the specified method
    - schema() method for introspection

    The original class methods remain available and unchanged.

    Args:
        inputs: Dictionary mapping input names to InputSpec.
        outputs: Dictionary mapping output names to OutputSpec.
        method: Name of the method to call via __call__ (default "__call__").
        name: Optional module name (defaults to class name).
        description: Optional description (defaults to class docstring).

    Returns:
        Class decorator function.

    Example:
        >>> @module(
        ...     inputs={"signal": InputSpec("signal", np.ndarray, "Input signal")},
        ...     outputs={"result": OutputSpec("result", np.ndarray, "Processed result")},
        ...     method="extract",
        ... )
        ... class MyExtractor:
        ...     def __init__(self, config):
        ...         self.config = config
        ...
        ...     def extract(self, signal):
        ...         return {"result": signal * 2}
    """

    def decorator(cls: type[T]) -> type[T]:
        original_init = cls.__init__ if hasattr(cls, "__init__") else None

        @wraps(original_init or (lambda self: None))
        def new_init(self: Any, *args: Any, **kwargs: Any) -> None:
            if original_init:
                original_init(self, *args, **kwargs)
            self._module_inputs = inputs
            self._module_outputs = outputs
            self._module_method = method
            self._module_name = name or cls.__name__
            self._module_description = description or cls.__doc__ or f"{cls.__name__}"
            self._module_parameters: dict[str, ParameterSpec] | None = None

        cls.__init__ = new_init

        @property
        def inputs_property(self: Any) -> dict[str, InputSpec]:
            return self._module_inputs.copy()

        cls.inputs = inputs_property  # type: ignore[attr-defined]

        @property
        def outputs_property(self: Any) -> dict[str, OutputSpec]:
            return self._module_outputs.copy()

        cls.outputs = outputs_property  # type: ignore[attr-defined]

        @property
        def parameters_property(self: Any) -> dict[str, ParameterSpec]:
            if self._module_parameters is not None:
                return self._module_parameters.copy()
            self._module_parameters = _extract_parameters(self)
            return self._module_parameters.copy()

        cls.parameters = parameters_property  # type: ignore[attr-defined]

        def schema_method(self: Any) -> ModuleSchema:
            return ModuleSchema(
                name=self._module_name,
                description=self._module_description,
                inputs=self.inputs,
                outputs=self.outputs,
                parameters=self.parameters,
            )

        cls.schema = schema_method  # type: ignore[attr-defined]

        if method != "__call__":
            original_call = getattr(cls, "__call__", None)

            def call_method(self: Any, **kwargs: Any) -> dict[str, Any]:
                target_method = getattr(self, self._module_method)
                return target_method(**kwargs)

            if original_call:
                cls._original_call = original_call  # type: ignore[attr-defined]

            cls.__call__ = call_method  # type: ignore[method-assign]

        cls._is_module = True  # type: ignore[attr-defined]

        return cls

    return decorator


def _extract_parameters(instance: Any) -> dict[str, ParameterSpec]:
    """Extract parameter specifications from instance config.

    Args:
        instance: Module instance with potential config attribute.

    Returns:
        Dictionary of parameter specifications.
    """
    config = getattr(instance, "config", None)

    if config is None:
        return {}

    if not is_dataclass(config):
        return {}

    params = {}
    for f in fields(config):
        default_value = getattr(config, f.name)
        dtype = f.type if isinstance(f.type, type) else type(default_value)
        if dtype is type(None):
            dtype = object

        params[f.name] = ParameterSpec(
            name=f.name,
            dtype=dtype,
            description=f"Config parameter: {f.name}",
            default=default_value,
            constraints=None,
        )

    return params


def is_module(obj: Any) -> bool:
    """Check if an object implements the ModuleProtocol.

    Checks for the decorator marker first, then falls back to protocol compliance.

    Args:
        obj: Object to check.

    Returns:
        True if the object is a module.
    """
    if hasattr(obj, "_is_module"):
        return True
    return isinstance(obj, ModuleProtocol)


class ModuleWrapper(Generic[T]):
    """Wrapper that makes an existing instance implement ModuleProtocol.

    This wrapper class delegates attribute access to the wrapped instance
    while providing the module protocol interface including __call__.
    """

    def __init__(
        self,
        instance: T,
        inputs: dict[str, InputSpec],
        outputs: dict[str, OutputSpec],
        method: str,
        name: str,
        description: str,
    ) -> None:
        """Initialize wrapper around an existing instance."""
        self._wrapped = instance
        self._module_inputs = inputs
        self._module_outputs = outputs
        self._module_method = method
        self._module_name = name
        self._module_description = description
        self._module_parameters: dict[str, ParameterSpec] | None = None
        self._is_module = True

    @property
    def inputs(self) -> dict[str, InputSpec]:
        """Return copy of input specifications."""
        return self._module_inputs.copy()

    @property
    def outputs(self) -> dict[str, OutputSpec]:
        """Return copy of output specifications."""
        return self._module_outputs.copy()

    @property
    def parameters(self) -> dict[str, ParameterSpec]:
        """Return copy of parameter specifications."""
        if self._module_parameters is not None:
            return self._module_parameters.copy()
        self._module_parameters = _extract_parameters(self._wrapped)
        return self._module_parameters.copy()

    def schema(self) -> ModuleSchema:
        """Return module schema describing the interface."""
        return ModuleSchema(
            name=self._module_name,
            description=self._module_description,
            inputs=self.inputs,
            outputs=self.outputs,
            parameters=self.parameters,
        )

    def __call__(self, **kwargs: Any) -> dict[str, Any]:
        """Delegate call to the wrapped instance method."""
        target = getattr(self._wrapped, self._module_method)
        return target(**kwargs)

    def __getattr__(self, name: str) -> Any:
        """Proxy attribute access to wrapped instance."""
        return getattr(self._wrapped, name)

    def __repr__(self) -> str:
        """Return string representation of the wrapper."""
        return f"ModuleWrapper({self._wrapped!r})"


def adapt_existing(
    instance: T,
    inputs: dict[str, InputSpec],
    outputs: dict[str, OutputSpec],
    method: str = "__call__",
    name: str | None = None,
    description: str | None = None,
) -> ModuleWrapper[T]:
    """Adapt an existing instance to the ModuleProtocol at runtime.

    This is useful when you can't modify the class definition but need
    to use an existing instance as a module.

    Args:
        instance: Existing object instance.
        inputs: Dictionary mapping input names to InputSpec.
        outputs: Dictionary mapping output names to OutputSpec.
        method: Name of the method to call via __call__.
        name: Optional module name.
        description: Optional description.

    Returns:
        A ModuleWrapper wrapping the instance with module protocol methods.

    Example:
        >>> extractor = SomeLibraryExtractor(config)
        >>> extractor = adapt_existing(
        ...     extractor,
        ...     inputs={"signal": InputSpec(...)},
        ...     outputs={"features": OutputSpec(...)},
        ...     method="process",
        ... )
        >>> result = extractor(signal=audio)
    """
    return ModuleWrapper(
        instance=instance,
        inputs=inputs,
        outputs=outputs,
        method=method,
        name=name or instance.__class__.__name__,
        description=description or instance.__class__.__doc__ or "",
    )
