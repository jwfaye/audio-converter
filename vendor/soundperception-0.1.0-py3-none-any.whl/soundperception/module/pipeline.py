"""Pipeline for composing and executing modules.

This module provides:
- Connection: Represents a connection between module ports
- Pipeline: Manages module composition and execution
- Mermaid visualization support
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .adapter import is_module
from .base import ModuleProtocol
from .specs import ModuleSchema


@dataclass
class Connection:
    """Represents a connection between two module ports.

    Attributes:
        source_module: Name of the source module.
        source_port: Name of the output port on the source module.
        target_module: Name of the target module.
        target_port: Name of the input port on the target module.
    """

    source_module: str
    source_port: str
    target_module: str
    target_port: str

    def __str__(self) -> str:
        """Return human-readable connection string."""
        return f"{self.source_module}.{self.source_port} -> {self.target_module}.{self.target_port}"

    @classmethod
    def parse(cls, source: str, target: str) -> "Connection":
        """Parse connection from dot-notation strings.

        Args:
            source: Source in "module.port" format.
            target: Target in "module.port" format.

        Returns:
            Connection instance.

        Raises:
            ValueError: If format is invalid.
        """
        if "." not in source:
            raise ValueError(f"Invalid source format: {source}. Expected 'module.port'")
        if "." not in target:
            raise ValueError(f"Invalid target format: {target}. Expected 'module.port'")

        src_module, src_port = source.rsplit(".", 1)
        tgt_module, tgt_port = target.rsplit(".", 1)

        return cls(src_module, src_port, tgt_module, tgt_port)


@dataclass
class PipelineInput:
    """Represents a pipeline-level input mapping.

    Attributes:
        name: External input name.
        target_module: Internal module name.
        target_port: Module input port name.
    """

    name: str
    target_module: str
    target_port: str


@dataclass
class PipelineOutput:
    """Represents a pipeline-level output mapping.

    Attributes:
        name: External output name.
        source_module: Internal module name.
        source_port: Module output port name.
    """

    name: str
    source_module: str
    source_port: str


class Pipeline:
    """Pipeline for composing and executing modules.

    A Pipeline connects multiple modules together, routing outputs
    from one module to inputs of another. It provides:
    - Module registration and connection
    - Topological execution order
    - Input/output mapping
    - Mermaid visualization

    Attributes:
        name: Pipeline name.

    Example:
        >>> pipeline = Pipeline("AudioAnalysis")
        >>> pipeline.add("extractor", GlobalExtractor(config))
        >>> pipeline.add("categorizer", Categorizer(config))
        >>> pipeline.connect("extractor.mean", "categorizer.image")
        >>> pipeline.set_input("signal", "extractor.signal")
        >>> pipeline.set_output("categories", "categorizer.categories")
        >>> result = pipeline(signal=audio)
    """

    def __init__(self, name: str, description: str = "") -> None:
        """Initialize pipeline.

        Args:
            name: Pipeline name.
            description: Optional description.
        """
        self.name = name
        self.description = description

        self._modules: dict[str, ModuleProtocol] = {}
        self._connections: list[Connection] = []
        self._inputs: dict[str, PipelineInput] = {}
        self._outputs: dict[str, PipelineOutput] = {}
        self._execution_order: list[str] | None = None

    def add(self, name: str, module: ModuleProtocol) -> "Pipeline":
        """Add a module to the pipeline.

        Args:
            name: Unique name for this module instance.
            module: Module instance implementing ModuleProtocol.

        Returns:
            Self for method chaining.

        Raises:
            ValueError: If name already exists or module is invalid.
        """
        if name in self._modules:
            raise ValueError(f"Module '{name}' already exists in pipeline")

        if not is_module(module):
            raise ValueError(
                f"Object '{name}' does not implement ModuleProtocol. "
                "Use @module decorator or adapt_existing()."
            )

        self._modules[name] = module
        self._execution_order = None
        return self

    def connect(self, source: str, target: str) -> "Pipeline":
        """Connect an output port to an input port.

        Args:
            source: Source in "module.port" format.
            target: Target in "module.port" format.

        Returns:
            Self for method chaining.

        Raises:
            ValueError: If modules or ports don't exist.
        """
        conn = Connection.parse(source, target)

        if conn.source_module not in self._modules:
            raise ValueError(f"Source module '{conn.source_module}' not found")
        src_mod = self._modules[conn.source_module]
        if conn.source_port not in src_mod.outputs:
            raise ValueError(
                f"Output port '{conn.source_port}' not found in module '{conn.source_module}'. "
                f"Available: {list(src_mod.outputs.keys())}"
            )

        if conn.target_module not in self._modules:
            raise ValueError(f"Target module '{conn.target_module}' not found")
        tgt_mod = self._modules[conn.target_module]
        if conn.target_port not in tgt_mod.inputs:
            raise ValueError(
                f"Input port '{conn.target_port}' not found in module '{conn.target_module}'. "
                f"Available: {list(tgt_mod.inputs.keys())}"
            )

        self._connections.append(conn)
        self._execution_order = None
        return self

    def set_input(self, name: str, target: str) -> "Pipeline":
        """Map a pipeline input to a module input.

        Args:
            name: External input name.
            target: Target in "module.port" format.

        Returns:
            Self for method chaining.

        Raises:
            ValueError: If target module or port doesn't exist.
        """
        if "." not in target:
            raise ValueError(f"Invalid target format: {target}. Expected 'module.port'")

        module_name, port_name = target.rsplit(".", 1)

        if module_name not in self._modules:
            raise ValueError(f"Target module '{module_name}' not found")

        mod = self._modules[module_name]
        if port_name not in mod.inputs:
            raise ValueError(
                f"Input port '{port_name}' not found in module '{module_name}'. "
                f"Available: {list(mod.inputs.keys())}"
            )

        self._inputs[name] = PipelineInput(name, module_name, port_name)
        return self

    def set_output(self, name: str, source: str) -> "Pipeline":
        """Map a module output to a pipeline output.

        Args:
            name: External output name.
            source: Source in "module.port" format.

        Returns:
            Self for method chaining.

        Raises:
            ValueError: If source module or port doesn't exist.
        """
        if "." not in source:
            raise ValueError(f"Invalid source format: {source}. Expected 'module.port'")

        module_name, port_name = source.rsplit(".", 1)

        if module_name not in self._modules:
            raise ValueError(f"Source module '{module_name}' not found")

        mod = self._modules[module_name]
        if port_name not in mod.outputs:
            raise ValueError(
                f"Output port '{port_name}' not found in module '{module_name}'. "
                f"Available: {list(mod.outputs.keys())}"
            )

        self._outputs[name] = PipelineOutput(name, module_name, port_name)
        return self

    def _compute_execution_order(self) -> list[str]:
        """Compute topological execution order based on connections.

        Returns:
            List of module names in execution order.

        Raises:
            ValueError: If there's a cycle in the graph.
        """
        dependencies: dict[str, set[str]] = {name: set() for name in self._modules}

        for conn in self._connections:
            dependencies[conn.target_module].add(conn.source_module)

        order = []
        no_deps = [name for name, deps in dependencies.items() if not deps]

        while no_deps:
            node = no_deps.pop(0)
            order.append(node)

            for name, deps in dependencies.items():
                if node in deps:
                    deps.remove(node)
                    if not deps and name not in order and name not in no_deps:
                        no_deps.append(name)

        if len(order) != len(self._modules):
            remaining = set(self._modules.keys()) - set(order)
            raise ValueError(f"Cycle detected involving modules: {remaining}")

        return order

    def __call__(self, **kwargs: Any) -> dict[str, Any]:
        """Execute the pipeline.

        Args:
            **kwargs: Input values matching pipeline input mappings.

        Returns:
            Dictionary of pipeline outputs.

        Raises:
            ValueError: If required inputs are missing.
        """
        for input_name, mapping in self._inputs.items():
            if input_name not in kwargs:
                raise ValueError(f"Missing required pipeline input: {input_name}")

        if self._execution_order is None:
            self._execution_order = self._compute_execution_order()

        module_inputs: dict[str, dict[str, Any]] = {name: {} for name in self._modules}

        for input_name, mapping in self._inputs.items():
            module_inputs[mapping.target_module][mapping.target_port] = kwargs[input_name]

        module_outputs: dict[str, dict[str, Any]] = {}

        for module_name in self._execution_order:
            module = self._modules[module_name]
            inputs = module_inputs[module_name]

            outputs = module(**inputs)
            module_outputs[module_name] = outputs

            for conn in self._connections:
                if conn.source_module == module_name:
                    value = outputs[conn.source_port]
                    module_inputs[conn.target_module][conn.target_port] = value

        result = {}
        for output_name, mapping in self._outputs.items():
            result[output_name] = module_outputs[mapping.source_module][mapping.source_port]

        return result

    def schema(self) -> ModuleSchema:
        """Generate schema for the pipeline as a module.

        Returns:
            ModuleSchema representing the pipeline interface.
        """
        from .specs import InputSpec, OutputSpec

        inputs = {}
        for name, mapping in self._inputs.items():
            mod = self._modules[mapping.target_module]
            spec = mod.inputs[mapping.target_port]
            inputs[name] = InputSpec(
                name=name,
                dtype=spec.dtype,
                description=f"Pipeline input -> {mapping.target_module}.{mapping.target_port}",
                shape=spec.shape,
                required=spec.required,
                default=spec.default,
            )

        outputs = {}
        for name, mapping in self._outputs.items():
            mod = self._modules[mapping.source_module]
            spec = mod.outputs[mapping.source_port]
            outputs[name] = OutputSpec(
                name=name,
                dtype=spec.dtype,
                description=f"Pipeline output <- {mapping.source_module}.{mapping.source_port}",
                shape=spec.shape,
                intermediate=spec.intermediate,
            )

        return ModuleSchema(
            name=self.name,
            description=self.description or f"Pipeline: {self.name}",
            inputs=inputs,
            outputs=outputs,
            parameters={},
        )

    def visualize(self, format: str = "mermaid") -> str:
        """Generate a visualization of the pipeline.

        Args:
            format: Output format ("mermaid" supported).

        Returns:
            Visualization string.

        Raises:
            ValueError: If format is not supported.
        """
        if format != "mermaid":
            raise ValueError(f"Unsupported format: {format}. Use 'mermaid'.")

        return self._to_mermaid()

    def _to_mermaid(self) -> str:
        """Generate Mermaid flowchart diagram.

        Returns:
            Mermaid diagram string.
        """
        lines = [
            "```mermaid",
            "flowchart LR",
            f"    subgraph {self.name}",
        ]

        for name, module in self._modules.items():
            schema = module.schema()
            input_list = ", ".join(schema.inputs.keys()) if schema.inputs else "-"
            output_list = ", ".join(schema.outputs.keys()) if schema.outputs else "-"
            label = f"{schema.name}\\n[{input_list}]\\n[{output_list}]"
            lines.append(f'        {name}["{label}"]')

        lines.append("    end")

        for input_name, mapping in self._inputs.items():
            input_id = f"in_{input_name}"
            lines.append(f'    {input_id}(("{input_name}"))')
            lines.append(f"    {input_id} --> {mapping.target_module}")

        for conn in self._connections:
            label = f"{conn.source_port}"
            lines.append(f"    {conn.source_module} -->|{label}| {conn.target_module}")

        for output_name, mapping in self._outputs.items():
            output_id = f"out_{output_name}"
            lines.append(f'    {output_id}(("{output_name}"))')
            lines.append(f"    {mapping.source_module} --> {output_id}")

        lines.append("```")

        return "\n".join(lines)

    def __repr__(self) -> str:
        """Return repr with pipeline name, modules, and connection count."""
        return (
            f"Pipeline(name={self.name!r}, "
            f"modules={list(self._modules.keys())}, "
            f"connections={len(self._connections)})"
        )

    def __str__(self) -> str:
        """Return detailed pipeline description."""
        lines = [f"Pipeline: {self.name}"]

        if self.description:
            lines.append(f"  {self.description}")

        lines.append("")
        lines.append("  Modules:")
        for name, module in self._modules.items():
            lines.append(f"    - {name}: {module.schema().name}")

        if self._inputs:
            lines.append("")
            lines.append("  Inputs:")
            for name, mapping in self._inputs.items():
                lines.append(f"    - {name} -> {mapping.target_module}.{mapping.target_port}")

        if self._connections:
            lines.append("")
            lines.append("  Connections:")
            for conn in self._connections:
                lines.append(f"    - {conn}")

        if self._outputs:
            lines.append("")
            lines.append("  Outputs:")
            for name, mapping in self._outputs.items():
                lines.append(f"    - {name} <- {mapping.source_module}.{mapping.source_port}")

        return "\n".join(lines)
