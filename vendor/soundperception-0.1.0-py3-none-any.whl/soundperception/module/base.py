"""Base classes and protocols for the module system.

This module provides:
- ModuleProtocol: Runtime-checkable protocol for modules
- ModuleBase: Abstract base class with automatic schema generation
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import fields, is_dataclass
from typing import Any, Generic, Protocol, TypeVar, runtime_checkable

from .specs import InputSpec, ModuleSchema, OutputSpec, ParameterSpec

ConfigT = TypeVar("ConfigT")


@runtime_checkable
class ModuleProtocol(Protocol):
    """Protocol defining the interface all modules must implement.

    This is a runtime-checkable protocol, allowing isinstance() checks.

    Required properties:
        inputs: Dictionary mapping input names to InputSpec.
        outputs: Dictionary mapping output names to OutputSpec.
        parameters: Dictionary mapping parameter names to ParameterSpec.

    Required methods:
        __call__: Process inputs and return outputs as a dictionary.
        schema: Return the complete ModuleSchema.
    """

    @property
    def inputs(self) -> dict[str, InputSpec]:
        """Return input specifications."""
        ...

    @property
    def outputs(self) -> dict[str, OutputSpec]:
        """Return output specifications."""
        ...

    @property
    def parameters(self) -> dict[str, ParameterSpec]:
        """Return parameter specifications."""
        ...

    def __call__(self, **kwargs: Any) -> dict[str, Any]:
        """Process inputs and return outputs.

        Args:
            **kwargs: Input values matching the input specifications.

        Returns:
            Dictionary mapping output names to values.
        """
        ...

    def schema(self) -> ModuleSchema:
        """Return the complete module schema.

        Returns:
            ModuleSchema describing inputs, outputs, and parameters.
        """
        ...


class ModuleBase(ABC, Generic[ConfigT]):
    """Abstract base class for modules with automatic schema generation.

    This class provides:
    - Automatic parameter extraction from Config dataclasses
    - Default schema() implementation
    - Validation helpers

    Subclasses must:
    - Define _inputs and _outputs class attributes
    - Implement _process() method
    - Optionally override _get_module_name() and _get_module_description()

    Type Parameters:
        ConfigT: The configuration dataclass type.

    Attributes:
        config: The module's configuration object.

    Example:
        >>> class MyModule(ModuleBase[MyConfig]):
        ...     _inputs = {"signal": InputSpec(...)}
        ...     _outputs = {"result": OutputSpec(...)}
        ...
        ...     def _process(self, signal):
        ...         return {"result": signal * 2}
    """

    _inputs: dict[str, InputSpec] = {}
    _outputs: dict[str, OutputSpec] = {}

    def __init__(self, config: ConfigT | None = None) -> None:
        """Initialize the module with optional configuration.

        Args:
            config: Configuration object. If None, uses default config
                    if a default() classmethod exists on the config class.
        """
        self.config = config
        self._parameters: dict[str, ParameterSpec] | None = None

    @property
    def inputs(self) -> dict[str, InputSpec]:
        """Return input specifications."""
        return self._inputs.copy()

    @property
    def outputs(self) -> dict[str, OutputSpec]:
        """Return output specifications."""
        return self._outputs.copy()

    @property
    def parameters(self) -> dict[str, ParameterSpec]:
        """Return parameter specifications extracted from config.

        Parameters are automatically extracted from the Config dataclass
        fields if the config is a dataclass.
        """
        if self._parameters is not None:
            return self._parameters.copy()

        self._parameters = self._extract_parameters_from_config()
        return self._parameters.copy()

    def _extract_parameters_from_config(self) -> dict[str, ParameterSpec]:
        """Extract parameter specifications from config dataclass.

        Returns:
            Dictionary of parameter specifications.
        """
        if self.config is None:
            return {}

        if not is_dataclass(self.config):
            return {}

        params = {}
        for f in fields(self.config):
            default_value = getattr(self.config, f.name)
            dtype = f.type if isinstance(f.type, type) else type(default_value)
            if dtype is type(None):
                dtype = object

            params[f.name] = ParameterSpec(
                name=f.name,
                dtype=dtype,
                description=f"Config parameter: {f.name}",
                default=default_value,
                constraints=None,
            )

        return params

    def _get_module_name(self) -> str:
        """Return the module name for schema.

        Override to provide a custom name.
        """
        return self.__class__.__name__

    def _get_module_description(self) -> str:
        """Return the module description for schema.

        Override to provide a custom description.
        """
        return self.__class__.__doc__ or f"{self.__class__.__name__} module"

    def schema(self) -> ModuleSchema:
        """Generate the complete module schema.

        Returns:
            ModuleSchema with inputs, outputs, and parameters.
        """
        return ModuleSchema(
            name=self._get_module_name(),
            description=self._get_module_description(),
            inputs=self.inputs,
            outputs=self.outputs,
            parameters=self.parameters,
        )

    @abstractmethod
    def _process(self, **kwargs: Any) -> dict[str, Any]:
        """Process inputs and return outputs.

        This is the main processing method that subclasses must implement.

        Args:
            **kwargs: Input values matching the input specifications.

        Returns:
            Dictionary mapping output names to values.
        """
        ...

    def __call__(self, **kwargs: Any) -> dict[str, Any]:
        """Process inputs and return outputs.

        This method validates inputs, calls _process(), and validates outputs.

        Args:
            **kwargs: Input values matching the input specifications.

        Returns:
            Dictionary mapping output names to values.

        Raises:
            TypeError: If required inputs are missing.
            ValueError: If input validation fails.
        """
        self._validate_inputs(kwargs)
        result = self._process(**kwargs)
        self._validate_outputs(result)
        return result

    def _validate_inputs(self, kwargs: dict[str, Any]) -> None:
        """Validate input arguments against specifications.

        Args:
            kwargs: Input keyword arguments.

        Raises:
            TypeError: If required inputs are missing.
        """
        for name, spec in self._inputs.items():
            if spec.required and name not in kwargs:
                raise TypeError(f"Missing required input '{name}' for {self._get_module_name()}")

    def _validate_outputs(self, result: dict[str, Any]) -> None:
        """Validate output dictionary against specifications.

        Args:
            result: Output dictionary from _process().

        Raises:
            ValueError: If required outputs are missing.
        """
        for name, spec in self._outputs.items():
            if not spec.intermediate and name not in result:
                raise ValueError(f"Missing required output '{name}' from {self._get_module_name()}")
