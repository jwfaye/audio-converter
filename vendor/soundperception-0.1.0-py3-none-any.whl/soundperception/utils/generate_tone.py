"""Tone generation utilities for audio synthesis."""

from dataclasses import dataclass

import numpy as np


@dataclass
class ToneConfig:
    """Configuration for tone generation.

    Attributes:
        sample_rate: Sampling rate in Hz.
        silence_duration: Initial silence duration in seconds.
        sound_duration: Sound duration in seconds.
        fundamental_freq: Fundamental frequency in Hz.
        harmonics: List of (multiple, amplitude) tuples for harmonics.
        bit_range: Bit depth for output.
    """

    sample_rate: int
    silence_duration: float
    sound_duration: float
    fundamental_freq: float
    harmonics: list[tuple[float, float]]
    bit_range: int = 16


def generate_tone(config: ToneConfig) -> np.ndarray:
    """Generate a tone with specified harmonics.

    Creates a signal starting with silence followed by a tone composed of
    the fundamental frequency plus specified harmonics. Each harmonic is
    defined by (frequency_multiple, amplitude).

    Args:
        config: Tone generation configuration.

    Returns:
        Generated signal as int16 numpy array.
    """
    silence_samples = int(config.sample_rate * config.silence_duration)
    sound_samples = int(config.sample_rate * config.sound_duration)
    silence = np.zeros(silence_samples)

    t = np.linspace(0, config.sound_duration, sound_samples, endpoint=False)
    sound = np.sin(2 * np.pi * config.fundamental_freq * t)

    for multiple, amplitude in config.harmonics:
        sound += amplitude * np.sin(2 * np.pi * config.fundamental_freq * multiple * t)

    signal = np.concatenate((silence, sound))

    fundamental_gain = pow(2, config.bit_range - 1) - 1
    signal = signal * fundamental_gain
    return signal.astype(np.int16)
