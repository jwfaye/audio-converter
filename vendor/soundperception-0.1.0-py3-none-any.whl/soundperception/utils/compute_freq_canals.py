"""Frequency canal computation utilities for ERB scale."""

import numpy as np
import pandas as pd


def hz_to_erb(f):
    """Convert frequency to ERB scale.

    Args:
        f: Frequency in Hz

    Returns:
        ERB value
    """
    return 21.4 * np.log10(4.37e-3 * f + 1)


def erb_to_hz(erb):
    """Convert ERB value to frequency in Hz.

    Args:
        erb: ERB value

    Returns:
        Frequency in Hz
    """
    return (10 ** (erb / 21.4) - 1) / 4.37e-3


def compute_freq_canals(nb_canals, f_min, f_max):
    """Calculate central frequencies for canals spaced linearly in ERB scale.

    Args:
        nb_canals: Number of canals
        f_min: Minimum frequency in Hz
        f_max: Maximum frequency in Hz

    Returns:
        Array of central frequencies in Hz
    """
    erb_min = hz_to_erb(f_min)
    erb_max = hz_to_erb(f_max)
    erb_points = np.linspace(erb_min, erb_max, nb_canals)
    center_freqs = erb_to_hz(erb_points)
    return center_freqs


def save_to_csv(center_freqs):
    """Save central frequencies to CSV file.

    Args:
        center_freqs: Central frequencies array from compute_freq_canals
    """
    df = pd.DataFrame({"Channel": np.arange(1, len(center_freqs) + 1), "Fc (Hz)": center_freqs})
    df.to_csv(f"gammatone_fc_{len(center_freqs)}_channels.csv", index=False)
