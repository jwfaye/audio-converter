"""Unified peak detection for the sound perception pipeline.

Single function for detecting local maxima in 1D or 2D arrays,
used throughout the pipeline (cochlear peaks, histogram analysis,
formant detection, segmentation).
"""

import numpy as np
from scipy.ndimage import maximum_filter, minimum_filter


def find_peaks(
    data: np.ndarray,
    size: int | tuple[int, ...] = 3,
    min_ratio: float = 0.0,
    min_value: float = 0.0,
) -> np.ndarray:
    """Detect local maxima in a 1D or N-D array.

    A value is a peak if it equals the maximum in its local neighborhood,
    exceeds both threshold criteria, and shows growth before and decay
    after (rejects monotonic slopes and edge artifacts).

    Args:
        data: Input array (1D or N-D).
        size: Neighborhood size for local max detection.
            Int for uniform, tuple for anisotropic (e.g. (1, 5) for
            per-row detection along columns).
        min_ratio: Minimum peak height as fraction of global max (0-1).
        min_value: Minimum absolute peak value.

    Returns:
        1D input: array of peak indices, sorted by position.
        N-D input: array of coordinates (N, ndim), sorted by
            descending peak value.

    Examples:
        >>> profile = np.array([0, 3, 1, 0, 5, 2, 0, 4, 1])
        >>> find_peaks(profile, size=3, min_ratio=0.1)
        array([1, 4, 7])

        >>> # Monotonic decrease → no peaks
        >>> find_peaks(np.array([10, 8, 6, 4, 2]), size=3)
        array([], dtype=int64)

        >>> image = np.zeros((5, 5)); image[1, 1] = 10; image[3, 3] = 8
        >>> find_peaks(image, size=3, min_value=1.0)
        array([[1, 1], [3, 3]])
    """
    data = np.asarray(data, dtype=np.float64)

    if data.size == 0:
        if data.ndim == 1:
            return np.array([], dtype=np.intp)
        return np.empty((0, data.ndim), dtype=np.intp)

    global_max = data.max()
    threshold = max(min_value, global_max * min_ratio) if global_max > 0 else min_value

    cval = 0.0 if data.ndim == 1 else -np.inf
    max_filtered = maximum_filter(data, size=size, mode="constant", cval=cval)

    is_peak = (data == max_filtered) & (data >= threshold)

    if data.ndim == 1:
        peak_indices = np.where(is_peak)[0]
        if len(peak_indices) == 0:
            return peak_indices

        # Growth/decay filter: a true peak (or plateau) must have a
        # strictly lower value somewhere before AND after the plateau.
        # This rejects peaks on monotonic slopes and at signal edges.
        n = len(data)
        valid = np.ones(len(peak_indices), dtype=bool)
        for k, idx in enumerate(peak_indices):
            val = data[idx]
            # Find left edge of plateau (consecutive equal values)
            left_edge = idx
            while left_edge > 0 and data[left_edge - 1] == val:
                left_edge -= 1
            # Find right edge of plateau
            right_edge = idx
            while right_edge < n - 1 and data[right_edge + 1] == val:
                right_edge += 1
            # Growth: strictly lower value before the plateau
            has_growth = left_edge > 0 and np.any(data[:left_edge] < val)
            # Decay: strictly lower value after the plateau
            has_decay = right_edge < n - 1 and np.any(data[right_edge + 1 :] < val)
            # Accept edge peaks if they have growth (left) or decay (right)
            at_left_edge = left_edge == 0
            at_right_edge = right_edge == n - 1
            if at_left_edge and at_right_edge:
                pass  # single plateau spanning entire array
            elif at_left_edge:
                if not has_decay:
                    valid[k] = False
            elif at_right_edge:
                if not has_growth:
                    valid[k] = False
            else:
                if not (has_growth and has_decay):
                    valid[k] = False
        return peak_indices[valid]

    # N-D: require at least one strictly lower immediate neighbor.
    min_near = minimum_filter(data, size=3, mode="constant", cval=np.inf)
    is_peak &= min_near < data

    coords = np.argwhere(is_peak)
    if len(coords) == 0:
        return coords

    values = data[tuple(coords.T)]
    order = np.argsort(-values)
    return coords[order]
