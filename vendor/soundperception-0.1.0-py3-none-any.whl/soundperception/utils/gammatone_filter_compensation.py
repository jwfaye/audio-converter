"""Gammatone filter delay compensation generation utilities."""

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from soundperception.core.sounddetector import (
    extract_peaks_optim,
    pos_erb_filter,
)
from soundperception.utils.compute_freq_canals import compute_freq_canals
from soundperception.utils.generate_tone import ToneConfig, generate_tone


@dataclass
class CompensationConfig:
    """Configuration for compensation generation.

    Attributes:
        f_min: Minimum frequency in Hz.
        f_max: Maximum frequency in Hz.
        num_filters: Number of canals.
        sample_rate: Sampling rate in Hz.
        silence_duration: Initial silence duration in seconds.
        sound_duration: Post-silence sound duration in seconds.
        harmonics: Harmonics to use.
    """

    f_min: int = 40
    f_max: int = 6500
    num_filters: int = 65
    sample_rate: int = 16000
    silence_duration: float = 0.01
    sound_duration: float = 0.99
    harmonics: list[tuple[float, float]] = field(default_factory=lambda: [(1, 100)])


def create_freq_tone(freq: float, config: CompensationConfig) -> np.ndarray:
    """Create signal at specified frequency.

    Args:
        freq: Frequency of signal in Hz.
        config: Compensation configuration.

    Returns:
        Signal array with specified frequency.
    """
    tone_config = ToneConfig(
        sample_rate=config.sample_rate,
        silence_duration=config.silence_duration,
        sound_duration=config.sound_duration,
        fundamental_freq=freq,
        harmonics=config.harmonics,
    )
    return generate_tone(tone_config)


def gross_filtering(
    signal: np.ndarray,
    sample_rate: int = 16000,
    num_filters: int = 65,
    f_min: int = 40,
    f_max: int = 6500,
) -> np.ndarray:
    """Apply ERB filtering to signal.

    Args:
        signal: Input signal array.
        sample_rate: Sampling rate in Hz.
        num_filters: Number of canals.
        f_min: Minimum frequency in Hz.
        f_max: Maximum frequency in Hz.

    Returns:
        ERB filtered signal array.
    """
    return pos_erb_filter(signal, sample_rate, num_filters, f_min, f_max)


def search_previous_ma(canal: int, peaks: np.ndarray) -> tuple[int, int, float]:
    """Find peak in upper canal (canal+1) preceding peak in current canal.

    Searches backward from the peak in the current canal to find the
    peak in the upper canal (canal+1) using threshold of ma_max - 6 dB.

    Args:
        canal: Canal ID.
        peaks: Signal filtered on peaks.

    Returns:
        Tuple of (upper_canal, peak_tick, peak_value).
    """
    ma_max = np.max(peaks)
    tick = np.argmax(peaks[canal])
    wave = peaks[canal + 1]
    for t in range(tick, 0, -1):
        if wave[t] > ma_max - 6:
            return canal + 1, t, wave[t]
    return canal + 1, 0, 0


def generate_compensations(config: CompensationConfig | None = None) -> pd.DataFrame:
    """Generate compensation delays for all canals.

    Generates pure tones at each ERB frequency, measures group delays
    between adjacent canals, and cumulates delays from high to low frequencies
    to compute compensation values.

    Args:
        config: Compensation configuration. If None, uses defaults.

    Returns:
        DataFrame with compensation delays for all canals.
    """
    if config is None:
        config = CompensationConfig()

    freq_canals = compute_freq_canals(config.num_filters, config.f_min, config.f_max)
    cumulated_gaps = [0]

    for canal, freq in enumerate(freq_canals[:-1]):
        signal = create_freq_tone(freq, config)
        erb_signal = pos_erb_filter(
            signal, config.sample_rate, config.num_filters, config.f_min, config.f_max
        )
        peaks = extract_peaks_optim(erb_signal)

        tick = np.argmax(peaks[canal])
        _can, t, _previous_ma = search_previous_ma(canal, peaks)
        gap = tick - t
        cumulated_gaps.append(gap + cumulated_gaps[-1])

    gaps = np.max(cumulated_gaps) - cumulated_gaps
    df = pd.DataFrame({"Freq": freq_canals, "Cumulated gaps": cumulated_gaps, "Gaps": gaps})
    df.to_csv("gammatone_filters_compensation.csv", index=False)
    return df


if __name__ == "__main__":
    config = CompensationConfig(f_min=40, f_max=6500, num_filters=65)
    generate_compensations(config)
