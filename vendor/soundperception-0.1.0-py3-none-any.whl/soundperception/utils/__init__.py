"""Utility functions for calibration, ERB scale conversion, and tone generation."""

from soundperception.utils.compute_freq_canals import (
    compute_freq_canals,
    erb_to_hz,
    hz_to_erb,
)

__all__ = [
    "hz_to_erb",
    "erb_to_hz",
    "compute_freq_canals",
]
