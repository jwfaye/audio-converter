"""French vowel frequency patterns.

Builds empirical patterns by passing sinusoids (F, F +/- 50 Hz) through the
full cochlear pipeline (periphery -> integration -> global extractor ->
structural extractor -> stability). Stores raw MA x CK matrices of stable
pixels and rectangular masks.
"""

import csv
import logging
from pathlib import Path

import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
import openpyxl

from soundperception.audition import (
    AuditoryPeriphery,
    AuditoryPeripheryConfig,
    TemporalIntegrationConfig,
    TemporalIntegrator,
)
from soundperception.core.global_extractor import GlobalExtractor, GlobalExtractorConfig
from soundperception.histograms import (
    auto_grid_categorize_histogram,
    build_joint_histogram,
)
from soundperception.histograms.structural_extractor import (
    StructuralExtractor,
    StructuralExtractorConfig,
)

logger = logging.getLogger(__name__)

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
OUTPUT_DIR = Path(__file__).resolve().parent.parent / "output"
VOYELLES_DIR = OUTPUT_DIR / "voyelles"
CSV_PATH = VOYELLES_DIR / "formants_reference.csv"
PATRONS_DIR = DATA_DIR / "vowels" / "patrons"
NPY_PATH = PATRONS_DIR / "patrons_voyelles.npy"
PNG_PATH = PATRONS_DIR / "patrons_voyelles.png"
XLSX_PATH = PATRONS_DIR / "patrons_voyelles.xlsx"
MASKS_PNG_PATH = PATRONS_DIR / "patrons_masques.png"

SR = 16000
DURATION = 0.5
DELTA = 50
MA_NORM = 45.0


def _full_pipeline(signal_int16, periphery, integrator, global_ext, struct_ext):
    """Run the full pipeline and return stable (ma, ck) points.

    Pipeline: periphery -> integration -> global extractor (std 3x3)
    -> stability categorization -> extract stable pixels.
    """
    stages = periphery.process(signal_int16, return_intermediate=True)
    integrated = integrator.process(stages["memo_ma"], stages["memo_ck"])
    memo_ma = integrated["memo_ma"]
    memo_ck = integrated["memo_ck"]
    presence = memo_ma >= 0

    memo_ma_clean = np.where(presence, memo_ma, 0.0)
    memo_ck_clean = np.where(presence, memo_ck, 0.0)
    global_ma = global_ext.process(memo_ma_clean)
    global_ck = global_ext.process(memo_ck_clean)
    for out in (global_ma, global_ck):
        for k in out:
            out[k] = np.where(presence, out[k], -1)

    std_ma = global_ma["std"]
    std_ck = global_ck["std"]
    valid_ma = std_ma[presence]
    valid_ck = std_ck[presence]

    if len(valid_ma) == 0 or valid_ma.max() == 0 or valid_ck.max() == 0:
        return np.array([]), np.array([])

    bins_ma_range = np.arange(0, int(valid_ma.max()) + 2, dtype=np.float64)
    bins_ck_range = np.arange(0, int(valid_ck.max()) + 2, dtype=np.float64)
    hist_std, bins_ma, bins_ck = build_joint_histogram(
        std_ma, std_ck, mask=presence, bins=[bins_ma_range, bins_ck_range]
    )
    labels_std = auto_grid_categorize_histogram(hist_std)
    stable_cat = labels_std[0, 0]

    std_ma_vals = np.where(presence, std_ma, 0)
    std_ck_vals = np.where(presence, std_ck, 0)
    ma_idx = np.clip(
        np.searchsorted(bins_ma, std_ma_vals.ravel(), side="right") - 1,
        0,
        hist_std.shape[1] - 1,
    )
    ck_idx = np.clip(
        np.searchsorted(bins_ck, std_ck_vals.ravel(), side="right") - 1,
        0,
        hist_std.shape[0] - 1,
    )
    pixel_cats = labels_std[ck_idx, ma_idx].reshape(std_ma.shape)
    pixel_stability = np.full_like(memo_ma, -1.0)
    pixel_stability[presence] = np.where(pixel_cats[presence] == stable_cat, 1.0, 2.0)

    stable_mask = pixel_stability == 1
    ma_vals = memo_ma[stable_mask]
    ck_vals = memo_ck[stable_mask]
    valid = (ma_vals >= 0) & (ck_vals > 0)
    return ma_vals[valid], ck_vals[valid]


def _formant_to_stable(freq, periphery, integrator, global_ext, struct_ext):
    """Pass sin(F) + sin(F +/- 50) through full pipeline, return stable points."""
    t = np.arange(int(SR * DURATION)) / SR
    sig = (
        np.sin(2 * np.pi * freq * t)
        + np.sin(2 * np.pi * (freq - DELTA) * t)
        + np.sin(2 * np.pi * (freq + DELTA) * t)
    )
    sig = sig / np.abs(sig).max()
    signal_int16 = (sig * 32767).astype(np.int16)
    return _full_pipeline(signal_int16, periphery, integrator, global_ext, struct_ext)


# -- Rectangular masks --------------------------------------------------------


def _bbox(ma, ck):
    """Bounding box (ma_min, ma_max, ck_min, ck_max) of a point set."""
    return float(ma.min()), float(ma.max()), float(ck.min()), float(ck.max())


def masks_formants(pattern):
    """Ground-truth masks: one rectangle per formant."""
    rects = []
    for fname in ("F1", "F2", "F3"):
        ma = pattern[f"ma_{fname}"]
        ck = pattern[f"ck_{fname}"]
        if len(ma) > 0:
            rects.append({"formant": fname, "bbox": _bbox(ma / MA_NORM, ck)})
    return rects


def _threshold_groups(marg_n, min_ratio=0.25, max_gap=3, gap_floor=0.03):
    """Threshold + consecutive grouping with short non-zero gap merging.

    1. Select bins where normalized marginal >= min_ratio.
    2. Group consecutive bins into intervals.
    3. Merge two adjacent groups if the gap between them has <= max_gap bins
       and all gap values are > gap_floor (non-negligible continuity).
    """
    above = np.where(marg_n >= min_ratio)[0]
    if len(above) == 0:
        return []

    groups = []
    lo = above[0]
    hi = above[0]
    for b in above[1:]:
        if b == hi + 1:
            hi = b
        else:
            groups.append((lo, hi))
            lo = hi = b
    groups.append((lo, hi))

    if len(groups) > 1:
        merged = [groups[0]]
        for g_lo, g_hi in groups[1:]:
            prev_lo, prev_hi = merged[-1]
            gap = marg_n[prev_hi + 1 : g_lo]
            if len(gap) <= max_gap and len(gap) > 0 and np.all(gap > gap_floor):
                merged[-1] = (prev_lo, g_hi)
            else:
                merged.append((g_lo, g_hi))
        groups = merged
    return groups


def masks_autogrid(pattern, min_ratio=0.25):
    """Build rectangular masks from threshold groups on normalized marginals.

    Computes 2D histogram MA x CK, normalizes marginals, finds groups on each
    axis via _threshold_groups, then returns the cartesian product of MA and CK
    intervals as rectangles (only those containing data).
    """
    ma_norm = pattern["ma"] / MA_NORM
    ck = pattern["ck"]
    if len(ma_norm) == 0:
        return []

    ma_bins = np.linspace(0, 1, 50)
    ck_max = int(np.ceil(ck.max())) + 1
    ck_bins = np.arange(0, ck_max + 1)
    hist2d, ma_edges, ck_edges = np.histogram2d(ma_norm, ck, bins=[ma_bins, ck_bins])

    marg_ma = hist2d.sum(axis=1)
    marg_ck = hist2d.sum(axis=0)
    marg_ma_n = marg_ma / marg_ma.max() if marg_ma.max() > 0 else marg_ma
    marg_ck_n = marg_ck / marg_ck.max() if marg_ck.max() > 0 else marg_ck

    ma_intervals = _threshold_groups(marg_ma_n, min_ratio)
    ck_intervals = _threshold_groups(marg_ck_n, min_ratio)

    if not ma_intervals:
        ma_intervals = [(0, len(ma_bins) - 2)]
    if not ck_intervals:
        ck_intervals = [(0, len(ck_bins) - 2)]

    rects = []
    for ma_lo_idx, ma_hi_idx in ma_intervals:
        for ck_lo_idx, ck_hi_idx in ck_intervals:
            cell = hist2d[ma_lo_idx : ma_hi_idx + 1, ck_lo_idx : ck_hi_idx + 1]
            if cell.sum() > 0:
                ma_lo = ma_edges[ma_lo_idx]
                ma_hi = ma_edges[min(ma_hi_idx + 1, len(ma_edges) - 1)]
                ck_lo = ck_edges[ck_lo_idx]
                ck_hi = ck_edges[min(ck_hi_idx + 1, len(ck_edges) - 1)]
                rects.append({"bbox": (ma_lo, ma_hi, ck_lo, ck_hi), "count": int(cell.sum())})

    return rects


# -- Build / Load -------------------------------------------------------------


def build_patterns():
    """Build vowel patterns through the full pipeline, keeping only stable pixels."""
    periphery = AuditoryPeriphery(AuditoryPeripheryConfig.default())
    integrator = TemporalIntegrator(TemporalIntegrationConfig.default())
    global_ext = GlobalExtractor(GlobalExtractorConfig.default())
    struct_ext = StructuralExtractor(StructuralExtractorConfig.default())
    patterns = {}

    with open(CSV_PATH) as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["dossier"].strip()
            f1_raw = row["F1_Homme"].strip()
            f2_raw = row["F2_Homme"].strip()
            f3_raw = row["F3_Homme"].strip()

            if not f1_raw or not f2_raw or not f3_raw:
                continue

            formants_ref = {
                "F1": float(f1_raw),
                "F2": float(f2_raw),
                "F3": float(f3_raw),
            }

            all_ma = []
            all_ck = []
            per_formant = {}
            for fname, freq in formants_ref.items():
                ma, ck = _formant_to_stable(freq, periphery, integrator, global_ext, struct_ext)
                all_ma.append(ma)
                all_ck.append(ck)
                per_formant[fname] = (ma, ck)

            patterns[name] = {
                "ipa": row["IPA"].strip(),
                "type": row["type"].strip(),
                "formants_ref": formants_ref,
                "ma": np.concatenate(all_ma),
                "ck": np.concatenate(all_ck),
                "ma_F1": per_formant["F1"][0],
                "ck_F1": per_formant["F1"][1],
                "ma_F2": per_formant["F2"][0],
                "ck_F2": per_formant["F2"][1],
                "ma_F3": per_formant["F3"][0],
                "ck_F3": per_formant["F3"][1],
            }
            logger.info("  %s %s  %d stable points", name, row["IPA"], len(patterns[name]["ma"]))

    PATRONS_DIR.mkdir(parents=True, exist_ok=True)
    np.save(NPY_PATH, patterns, allow_pickle=True)
    logger.info("Saved %d patterns -> %s", len(patterns), NPY_PATH)
    return patterns


def load_patterns():
    """Load patterns from .npy file. Rebuilds if missing."""
    if not NPY_PATH.exists():
        return build_patterns()
    return np.load(NPY_PATH, allow_pickle=True).item()


# -- Visualization ------------------------------------------------------------


def _draw_rects(ax, rects, colors, labels=None):
    """Draw rectangles on a matplotlib axes."""
    for i, r in enumerate(rects):
        ma_lo, ma_hi, ck_lo, ck_hi = r["bbox"]
        color = colors[i % len(colors)]
        label = labels[i] if labels else None
        rect = mpatches.FancyBboxPatch(
            (ma_lo, ck_lo),
            ma_hi - ma_lo,
            ck_hi - ck_lo,
            boxstyle="round,pad=0",
            linewidth=1.5,
            edgecolor=color,
            facecolor=color,
            alpha=0.2,
            label=label,
        )
        ax.add_patch(rect)
        ax.plot(
            [ma_lo, ma_hi, ma_hi, ma_lo, ma_lo],
            [ck_lo, ck_lo, ck_hi, ck_hi, ck_lo],
            color=color,
            linewidth=1.5,
        )


def plot_patterns(patterns):
    """Generate pattern image: scatter MA(x) x CK(y) with marginals."""
    names = list(patterns.keys())
    n = len(names)
    ncols = 4
    nrows = (n + ncols - 1) // ncols

    fig = plt.figure(figsize=(5 * ncols, 5 * nrows), facecolor="#1a1a2e")
    fig.suptitle(
        "Vowel patterns - MA x CK maps (stable pixels, separated formants)",
        color="white",
        fontsize=14,
        y=0.995,
    )

    for idx, name in enumerate(names):
        p = patterns[name]
        ma_norm = p["ma"] / MA_NORM
        ck = p["ck"]
        formants = p["formants_ref"]

        if len(ma_norm) == 0:
            continue

        gs = fig.add_gridspec(
            2,
            2,
            left=(idx % ncols) / ncols + 0.02,
            right=(idx % ncols + 1) / ncols - 0.02,
            bottom=1 - (idx // ncols + 1) / nrows + 0.04,
            top=1 - (idx // ncols) / nrows - 0.02,
            width_ratios=[4, 1],
            height_ratios=[1, 4],
            wspace=0.05,
            hspace=0.05,
        )

        ax_main = fig.add_subplot(gs[1, 0], facecolor="#1a1a2e")
        ax_ma = fig.add_subplot(gs[0, 0], facecolor="#1a1a2e", sharex=ax_main)
        ax_ck = fig.add_subplot(gs[1, 1], facecolor="#1a1a2e", sharey=ax_main)

        ax_main.scatter(ma_norm, ck, s=1, c=ma_norm, cmap="inferno", alpha=0.5)
        ax_main.set_xlabel("MA (norm)", color="white", fontsize=7)
        ax_main.set_ylabel("bin CK", color="white", fontsize=7)
        ax_main.tick_params(colors="white", labelsize=6)

        for _fname, freq in formants.items():
            ck_val = 10 * np.log(SR / freq)
            ax_main.axhline(ck_val, color="red", ls="--", lw=0.8, alpha=0.7)
            ax_ck.axhline(ck_val, color="red", ls="--", lw=0.8, alpha=0.7)

        ma_bins = np.linspace(0, 1, 50)
        ax_ma.hist(ma_norm, bins=ma_bins, color="goldenrod", alpha=0.8)
        ax_ma.set_title(f"{name} {p['ipa']}", color="white", fontsize=9)
        ax_ma.tick_params(colors="white", labelsize=6)
        plt.setp(ax_ma.get_xticklabels(), visible=False)

        ck_max = int(np.ceil(ck.max())) + 1
        ck_bins_hist = np.arange(0, ck_max + 1)
        ax_ck.hist(ck, bins=ck_bins_hist, orientation="horizontal", color="cyan", alpha=0.8)
        ax_ck.tick_params(colors="white", labelsize=6)
        plt.setp(ax_ck.get_yticklabels(), visible=False)

        for ax in [ax_main, ax_ma, ax_ck]:
            for spine in ax.spines.values():
                spine.set_color("#333")

    plt.savefig(PNG_PATH, dpi=150, bbox_inches="tight", facecolor="#1a1a2e")
    plt.close()
    logger.info("Image saved -> %s", PNG_PATH)


def plot_masks(patterns, min_ratio=0.25):
    """Generate mask image: scatter MA x CK + normalized marginals + groups + rectangles."""
    names = list(patterns.keys())
    n = len(names)
    ncols = 4
    nrows = (n + ncols - 1) // ncols

    fig = plt.figure(figsize=(6 * ncols, 5 * nrows), facecolor="#1a1a2e")
    fig.suptitle(
        f"Pattern masks - threshold {int(min_ratio * 100)}%",
        color="white",
        fontsize=14,
        y=0.995,
    )

    rect_colors = ["#e74c3c", "#2ecc71", "#3498db", "#e8a838", "#9b59b6", "#1abc9c"]

    for idx, name in enumerate(names):
        p = patterns[name]
        ma_norm = p["ma"] / MA_NORM
        ck = p["ck"]
        if len(ma_norm) == 0:
            continue

        ma_bins = np.linspace(0, 1, 50)
        ck_max = int(np.ceil(ck.max())) + 1
        ck_bins = np.arange(0, ck_max + 1)
        hist2d, ma_edges, ck_edges = np.histogram2d(ma_norm, ck, bins=[ma_bins, ck_bins])

        ma_centers = (ma_edges[:-1] + ma_edges[1:]) / 2
        ck_centers = (ck_edges[:-1] + ck_edges[1:]) / 2

        marg_ma = hist2d.sum(axis=1)
        marg_ck = hist2d.sum(axis=0)
        marg_ma_n = marg_ma / marg_ma.max() if marg_ma.max() > 0 else marg_ma
        marg_ck_n = marg_ck / marg_ck.max() if marg_ck.max() > 0 else marg_ck

        ma_groups = _threshold_groups(marg_ma_n, min_ratio)
        ck_groups = _threshold_groups(marg_ck_n, min_ratio)

        gs = fig.add_gridspec(
            2,
            2,
            left=(idx % ncols) / ncols + 0.02,
            right=(idx % ncols + 1) / ncols - 0.02,
            bottom=1 - (idx // ncols + 1) / nrows + 0.04,
            top=1 - (idx // ncols) / nrows - 0.02,
            width_ratios=[4, 1],
            height_ratios=[1, 4],
            wspace=0.05,
            hspace=0.05,
        )

        ax_main = fig.add_subplot(gs[1, 0], facecolor="black")
        ax_marg_top = fig.add_subplot(gs[0, 0], facecolor="#1a1a2e", sharex=ax_main)
        ax_marg_right = fig.add_subplot(gs[1, 1], facecolor="#1a1a2e", sharey=ax_main)

        ax_main.scatter(ma_norm, ck, s=1, c=ma_norm, cmap="inferno", alpha=0.5)
        ax_main.set_xlabel("MA (norm)", color="white", fontsize=7)
        ax_main.set_ylabel("bin CK", color="white", fontsize=7)
        ax_main.tick_params(colors="white", labelsize=6)

        rects = masks_autogrid(p, min_ratio)
        for i, r in enumerate(rects):
            ma_lo, ma_hi, ck_lo, ck_hi = r["bbox"]
            color = rect_colors[i % len(rect_colors)]
            rect = mpatches.FancyBboxPatch(
                (ma_lo, ck_lo),
                ma_hi - ma_lo,
                ck_hi - ck_lo,
                boxstyle="round,pad=0",
                linewidth=1.5,
                edgecolor=color,
                facecolor=color,
                alpha=0.2,
            )
            ax_main.add_patch(rect)
            ax_main.plot(
                [ma_lo, ma_hi, ma_hi, ma_lo, ma_lo],
                [ck_lo, ck_lo, ck_hi, ck_hi, ck_lo],
                color=color,
                linewidth=1.5,
            )

        ax_marg_top.bar(
            ma_centers,
            marg_ma_n,
            width=ma_centers[1] - ma_centers[0],
            color="goldenrod",
            alpha=0.8,
        )
        ax_marg_top.axhline(min_ratio, color="red", ls="--", lw=0.8, alpha=0.7)
        for gi, (lo, hi) in enumerate(ma_groups):
            color = rect_colors[gi % len(rect_colors)]
            ax_marg_top.axvspan(ma_edges[lo], ma_edges[hi + 1], color=color, alpha=0.2)
        n_ma = len(ma_groups)
        n_ck = len(ck_groups)
        ax_marg_top.set_title(
            f"{name} {p['ipa']}  -  {n_ma} MA x {n_ck} CK = {len(rects)} rect",
            color="white",
            fontsize=8,
        )
        ax_marg_top.tick_params(colors="white", labelsize=5)
        plt.setp(ax_marg_top.get_xticklabels(), visible=False)

        ax_marg_right.barh(
            ck_centers,
            marg_ck_n,
            height=ck_centers[1] - ck_centers[0] if len(ck_centers) > 1 else 1,
            color="cyan",
            alpha=0.8,
        )
        ax_marg_right.axvline(min_ratio, color="red", ls="--", lw=0.8, alpha=0.7)
        for gi, (lo, hi) in enumerate(ck_groups):
            color = rect_colors[gi % len(rect_colors)]
            ax_marg_right.axhspan(ck_edges[lo], ck_edges[hi + 1], color=color, alpha=0.2)
        ax_marg_right.tick_params(colors="white", labelsize=5)
        plt.setp(ax_marg_right.get_yticklabels(), visible=False)

        for ax in [ax_main, ax_marg_top, ax_marg_right]:
            for spine in ax.spines.values():
                spine.set_color("#333")

    plt.savefig(MASKS_PNG_PATH, dpi=150, bbox_inches="tight", facecolor="#1a1a2e")
    plt.close()
    logger.info("Masks image saved -> %s", MASKS_PNG_PATH)


def export_excel(patterns):
    """Export patterns to Excel: one sheet per vowel with MA x CK matrix + marginals."""
    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    for name, p in patterns.items():
        ma_norm = p["ma"] / MA_NORM
        ck = p["ck"]

        if len(ma_norm) == 0:
            continue

        ma_bins = np.linspace(0, 1, 50)
        ck_max = int(np.ceil(ck.max())) + 1
        ck_bins = np.arange(0, ck_max + 1)

        hist2d, ma_edges, ck_edges = np.histogram2d(ma_norm, ck, bins=[ma_bins, ck_bins])
        ma_marginal = hist2d.sum(axis=1)
        ck_marginal = hist2d.sum(axis=0)

        ma_labels = [f"{(ma_edges[i] + ma_edges[i + 1]) / 2:.3f}" for i in range(len(ma_edges) - 1)]
        ck_labels = [f"CK={int(ck_edges[i])}" for i in range(len(ck_edges) - 1)]

        sheet_name = f"{name} {p['ipa'].replace('/', '')}"[:31]
        ws = wb.create_sheet(title=sheet_name)

        ws.cell(row=1, column=1, value="CK \\ MA")
        for j, ml in enumerate(ma_labels):
            ws.cell(row=1, column=j + 2, value=ml)
        ws.cell(row=1, column=len(ma_labels) + 2, value="marg_CK")

        for i, cl in enumerate(ck_labels):
            ws.cell(row=i + 2, column=1, value=cl)
            for j in range(len(ma_labels)):
                val = hist2d[j, i]
                if val > 0:
                    ws.cell(row=i + 2, column=j + 2, value=int(val))
            ws.cell(row=i + 2, column=len(ma_labels) + 2, value=int(ck_marginal[i]))

        row_marg = len(ck_labels) + 2
        ws.cell(row=row_marg, column=1, value="marg_MA")
        for j in range(len(ma_labels)):
            ws.cell(row=row_marg, column=j + 2, value=int(ma_marginal[j]))

    wb.save(XLSX_PATH)
    logger.info("Excel saved -> %s", XLSX_PATH)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    patterns = build_patterns()
    plot_patterns(patterns)
    plot_masks(patterns)
    export_excel(patterns)
    for name, p in patterns.items():
        rects_f = masks_formants(p)
        rects_g = masks_autogrid(p)
        logger.info(
            "  %s %s  %d pts  formants: %d rect  auto-grid: %d rect",
            name,
            p["ipa"],
            len(p["ma"]),
            len(rects_f),
            len(rects_g),
        )
