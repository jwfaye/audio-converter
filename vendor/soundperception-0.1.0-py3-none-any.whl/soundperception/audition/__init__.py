"""Audition - Bio-inspired auditory periphery simulation.

This package provides a simulation of the human auditory periphery,
from acoustic input to frequency-invariant representations.

Stages implemented:
- Stage 1: Outer ear (not implemented)
- Stage 2: Middle ear filtering (optional)
- Stage 3: Cochlear filtering (Gammatone filterbank)
- Stage 3b: Group delay compensation
- Stage 4: Inner hair cell simulation (peak extraction)
- Stage 5: Auditory nerve discrete temporal encoding
- Stage 5.5: Temporal integration and decimation
- Stage 6: Fundamental frequency (F0) detection
- Stage 7: Frequency invariance extraction

Example:
    >>> from soundperception.audition import (
    ...     AuditoryPeriphery, TemporalIntegrator, F0Detector, FrequencyInvarianceExtractor
    ... )
    >>> from soundperception.audition import (
    ...     AuditoryPeripheryConfig, TemporalIntegrationConfig,
    ...     F0DetectionConfig, FrequencyInvarianceConfig
    ... )
    >>> import numpy as np
    >>>
    >>> # Generate test signal (1 second at 16 kHz)
    >>> audio = np.random.randn(16000)
    >>>
    >>> # Stage 1-5: Auditory periphery
    >>> periphery = AuditoryPeriphery(AuditoryPeripheryConfig.default())
    >>> result = periphery.process(audio)
    >>>
    >>> # Stage 5.5: Temporal integration
    >>> integrator = TemporalIntegrator(TemporalIntegrationConfig.default())
    >>> integrated = integrator.process(result['memo_ma'], result['memo_ck'])
    >>>
    >>> # Stage 6: F0 detection
    >>> detector = F0Detector(F0DetectionConfig.default())
    >>> f0_result = detector.process(integrated['memo_ma'], integrated['memo_ck'])
    >>>
    >>> # Stage 7: Frequency invariance
    >>> extractor = FrequencyInvarianceExtractor(FrequencyInvarianceConfig.default())
    >>> inv_result = extractor.process(f0_result, integrated['memo_ma'])

References:
    Osses, A., Varnet, L., Carney, L. H., et al. (2022). A comparative study
    of eight human auditory models of monaural processing. Acta Acustica.
"""

from soundperception.audition.config import (
    AuditoryNerveConfig,
    AuditoryPeripheryConfig,
    CochlearFilterConfig,
    DelayCompensationConfig,
    F0DetectionConfig,
    FrequencyInvarianceConfig,
    MiddleEarConfig,
    PeakExtractionConfig,
    TemporalIntegrationConfig,
)
from soundperception.audition.core.f0_detection import F0Detector
from soundperception.audition.core.frequency_invariance import FrequencyInvarianceExtractor
from soundperception.audition.core.integration import TemporalIntegrator, integrate_temporal
from soundperception.audition.core.periphery import AuditoryPeriphery
from soundperception.audition.utils.audio_io import (
    get_audio_info,
    load_audio,
    resample_audio,
    save_audio,
)

__version__ = "0.2.0"

__all__ = [
    "AuditoryPeriphery",
    "TemporalIntegrator",
    "F0Detector",
    "FrequencyInvarianceExtractor",
    "AuditoryPeripheryConfig",
    "TemporalIntegrationConfig",
    "F0DetectionConfig",
    "FrequencyInvarianceConfig",
    "MiddleEarConfig",
    "CochlearFilterConfig",
    "DelayCompensationConfig",
    "PeakExtractionConfig",
    "AuditoryNerveConfig",
    "load_audio",
    "save_audio",
    "resample_audio",
    "get_audio_info",
    "integrate_temporal",
]
