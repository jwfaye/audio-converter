"""Fundamental frequency (F0) detection module (Stage 6).

F0 detection algorithm:
1. Adaptive peak extraction with spatial filtering
2. Cumulative persistence tracking
3. Harmonic group segmentation
4. Temporal continuity filtering

Processes pre-integrated and decimated auditory signals (from TemporalIntegrator).
Extracts fundamental frequency by identifying lowest active channel with temporal stability.

Note: Temporal integration and decimation handled by TemporalIntegrator module (Stage 5.5).
"""

import numpy as np

from soundperception.audition.config import F0DetectionConfig
from soundperception.module import InputSpec, OutputSpec, TensorShape, module

FIRST_ENERGY_PEAK = 1
SECOND_ENERGY_PEAK = 2


def extract_peaks_adaptive(
    signal_ma: np.ndarray,
    signal_ck: np.ndarray,
    window_size: int = 7,
    amp_threshold: float = 5.0,
    ck_threshold: float = 220.0,
) -> np.ndarray:
    """Extract peaks using spatial filtering along frequency axis with zero padding.

    Args:
        signal_ma: Amplitude memory of shape (n_channels, n_frames)
        signal_ck: Temporal memory of shape (n_channels, n_frames)
        window_size: Window size for spatial peak detection (default: 7 channels)
        amp_threshold: Minimum amplitude threshold (default: 5.0)
        ck_threshold: Maximum memo_ck threshold (default: 220.0)

    Returns:
        Peaks array of same shape as input, with peak values where detected, 0 elsewhere

    Example:
        import numpy as np
        signal_ma = np.random.rand(20, 50) * 20  # 20 channels, 50 frames
        signal_ck = np.random.rand(20, 50) * 100
        peaks = extract_peaks_adaptive(signal_ma, signal_ck, window_size=7)
        # peaks[c, t] > 0 only where channel c is a local maximum at frame t
    """
    from soundperception.utils.peak_detection import find_peaks

    peak_coords = find_peaks(signal_ma, size=(window_size, 1), min_value=amp_threshold)
    peaks = np.zeros_like(signal_ma)
    if len(peak_coords) > 0:
        rows, cols = peak_coords[:, 0], peak_coords[:, 1]
        ck_ok = signal_ck[rows, cols] < ck_threshold
        peaks[rows[ck_ok], cols[ck_ok]] = signal_ma[rows[ck_ok], cols[ck_ok]]

    return peaks


def track_cumulative_persistence(peaks: np.ndarray, window_half_size: int = 3) -> np.ndarray:
    """Track harmonics over time and count persistence.

    Args:
        peaks: Detected peaks of shape (n_channels, n_frames), 0 where no peak
        window_half_size: Half-size of vertical search window (default: 3 channels)

    Returns:
        Persistence counter of shape (n_channels, n_frames)
        - 0: no peak
        - 1: harmonic appeared
        - >1: persistent harmonic

    Example:
        import numpy as np
        # Binary peak array: 5 channels, 4 frames
        peaks = np.array([
            [0, 10, 12, 11],
            [0,  0,  0,  0],
            [5,  6,  7,  8],
            [0,  0,  0,  0],
            [0,  0,  0,  0],
        ], dtype=float)
        counter = track_cumulative_persistence(peaks, window_half_size=1)
        # counter[2, :] will be [1, 2, 3, 4] (persistent harmonic)
    """
    counter = np.zeros_like(peaks, dtype=int)
    n_channels, n_frames = peaks.shape

    for c in range(n_channels):
        if peaks[c, 0] > 0:
            counter[c, 0] = 1

    for t in range(1, n_frames):
        for c in range(n_channels):
            if peaks[c, t] == 0:
                continue

            c_min = max(0, c - window_half_size)
            c_max = min(n_channels, c + window_half_size + 1)

            prev_window = counter[c_min:c_max, t - 1]

            max_prev = np.max(prev_window)
            if max_prev > 0:
                counter[c, t] = max_prev + 1
            else:
                counter[c, t] = 1

    return counter


def segment_harmonic_groups(active_channels: np.ndarray) -> np.ndarray:
    """Segment spectrum into harmonic groups by counting transitions.

    Args:
        active_channels: Channel numbers where active, 0 otherwise (n_channels, n_frames)

    Returns:
        Group counter of shape (n_channels, n_frames)
        - Group 0: inactive regions
        - Group 1: lowest frequency group (fundamental)
        - Group 2: next harmonic
        - Group 3+: higher harmonics

    Example:
        import numpy as np
        # Active channels: groups separated by gaps
        active = np.array([
            [1, 0],
            [2, 0],
            [0, 0],  # gap separates groups
            [4, 0],
            [5, 0],
        ])
        groups = segment_harmonic_groups(active)
        # groups[:, 0] will be [1, 1, 0, 2, 2]
    """
    n_channels, n_frames = active_channels.shape
    group_counter = np.zeros_like(active_channels, dtype=int)

    for frame in range(n_frames):
        counter = 0

        for channel in range(n_channels):
            current_active = active_channels[channel, frame] > 0

            if channel > 0:
                prev_active = active_channels[channel - 1, frame] > 0

                if not prev_active and current_active:
                    counter += 1
            elif current_active:
                counter = 1

            group_counter[channel, frame] = counter

    return group_counter


def _extract_f0_from_tracked_counter(
    tracked_counter: np.ndarray,
    rounded_ma: np.ndarray,
    rounded_ck: np.ndarray,
) -> dict[str, np.ndarray]:
    """Extract F0 (lowest active channel) from tracked counter.

    Args:
        tracked_counter: Filtered counter array (n_channels, n_frames)
        rounded_ma: Amplitude memory array (n_channels, n_frames)
        rounded_ck: Temporal memory array (n_channels, n_frames)

    Returns:
        Dictionary with F0 extraction results:
            - 'f0_frames': Frame indices with F0 detection
            - 'f0_channels': Channel indices (lowest active per frame)
            - 'f0_memo_ma': memo_ma values at F0 positions
            - 'f0_memo_ck': memo_ck values at F0 positions
            - 'f0_counter': Counter values at F0 positions
    """
    _, n_frames = tracked_counter.shape
    f0_frames = []
    f0_channels = []
    f0_memo_ma = []
    f0_memo_ck = []
    f0_counter = []

    for frame in range(n_frames):
        active_channels = np.where(tracked_counter[:, frame] > 0)[0]

        if len(active_channels) > 0:
            selected_channel = np.min(active_channels)

            f0_frames.append(frame)
            f0_channels.append(selected_channel)
            f0_memo_ma.append(rounded_ma[selected_channel, frame])
            f0_memo_ck.append(rounded_ck[selected_channel, frame])
            f0_counter.append(tracked_counter[selected_channel, frame])

    return {
        "f0_frames": np.array(f0_frames),
        "f0_channels": np.array(f0_channels),
        "f0_memo_ma": np.array(f0_memo_ma),
        "f0_memo_ck": np.array(f0_memo_ck),
        "f0_counter": np.array(f0_counter),
    }


def track_temporal_continuity(  # noqa: PLR0913, PLR0912
    persistence_counter: np.ndarray,
    peak_groups: np.ndarray,
    mode: str = "limited",
    extract_f0: bool = False,
    rounded_ma: np.ndarray | None = None,
    rounded_ck: np.ndarray | None = None,
) -> np.ndarray | dict[str, np.ndarray]:
    """Filter detections by temporal continuity of counter progression.

    Args:
        persistence_counter: Persistence counter values (n_channels, n_frames)
        peak_groups: Group assignment for each peak (n_channels, n_frames)
        mode: "limited" (groups 1-2 only) or "all_groups" (all groups tracked)
              Default: "limited"
        extract_f0: If True, extract fundamental frequency (lowest active channel)
                    Default: False
        rounded_ma: Required if extract_f0=True (n_channels, n_frames)
        rounded_ck: Required if extract_f0=True (n_channels, n_frames)

    Returns:
        If extract_f0=False:
            tracked_counter: (n_channels, n_frames) - filtered counter (0 where rejected)

        If extract_f0=True:
            dict with keys:
                - 'tracked_counter': (n_channels, n_frames) - filtered counter
                - 'f0_frames': array of frame indices with F0 detection
                - 'f0_channels': array of channel indices (lowest active per frame)
                - 'f0_memo_ma': array of memo_ma values at F0 positions
                - 'f0_memo_ck': array of memo_ck values at F0 positions
                - 'f0_counter': array of counter values at F0 positions

    Modes:
        - "limited": Group 1 can start/continue, Group 2 must continue, Groups 3+ rejected

        - "all_groups": Group 1 can start/continue, Groups 2+ must continue

    Raises:
        ValueError: If mode is not "limited" or "all_groups"
        ValueError: If extract_f0=True but rounded_ma or rounded_ck is None

    Example:
        import numpy as np
        n_ch, n_fr = 10, 20
        persistence = np.random.randint(0, 5, (n_ch, n_fr))
        groups = np.random.randint(0, 3, (n_ch, n_fr))
        tracked = track_temporal_continuity(persistence, groups, mode="limited")
        # tracked has same shape, with rejected detections set to 0
    """
    if mode not in ["limited", "all_groups"]:
        raise ValueError(f"mode must be 'limited' or 'all_groups', got '{mode}'")

    if extract_f0 and (rounded_ma is None or rounded_ck is None):
        raise ValueError("extract_f0=True requires rounded_ma and rounded_ck parameters")

    n_channels, n_frames = persistence_counter.shape
    tracked_counter = np.zeros_like(persistence_counter, dtype=int)

    for c in range(n_channels):
        if peak_groups[c, 0] == FIRST_ENERGY_PEAK:
            tracked_counter[c, 0] = persistence_counter[c, 0]

    for t in range(1, n_frames):
        max_prev = np.max(tracked_counter[:, t - 1])

        for c in range(n_channels):
            group = peak_groups[c, t]
            counter = persistence_counter[c, t]

            if group == 0:
                continue

            if group == FIRST_ENERGY_PEAK:
                if max_prev == 0 or counter == max_prev + 1:
                    tracked_counter[c, t] = counter

            elif group >= SECOND_ENERGY_PEAK:
                if mode == "limited" and group > SECOND_ENERGY_PEAK:
                    continue

                if counter == max_prev + 1:
                    tracked_counter[c, t] = counter

    if extract_f0:
        f0_result = _extract_f0_from_tracked_counter(tracked_counter, rounded_ma, rounded_ck)
        return {
            "tracked_counter": tracked_counter,
            **f0_result,
        }

    return tracked_counter


def convert_memo_ck_to_frequency(
    memo_ck_values: np.ndarray, sample_rate: int = 16000
) -> dict[str, np.ndarray]:
    """Convert memo_ck logarithmic encoding to period and frequency.

    Args:
        memo_ck_values: Array of memo_ck values (logarithmic encoding)
        sample_rate: Sample rate in Hz (default: 16000)

    Returns:
        Dictionary with:
            - 'period_samples': period in samples
            - 'frequency_hz': frequency in Hz

    Example:
        import numpy as np
        memo_ck = np.array([30.0, 40.0, 50.0])
        result = convert_memo_ck_to_frequency(memo_ck, sample_rate=16000)
        print(result["frequency_hz"])  # frequencies in Hz
    """
    period_samples = np.exp(memo_ck_values / 10)
    frequency_hz = sample_rate / period_samples

    return {"period_samples": period_samples, "frequency_hz": frequency_hz}


@module(
    inputs={
        "memo_ma_integrated": InputSpec(
            name="memo_ma_integrated",
            dtype=np.ndarray,
            description="Integrated/decimated amplitude memory (n_channels, n_decimated_frames)",
            shape=TensorShape(("n_channels", "n_decimated_frames")),
        ),
        "memo_ck_integrated": InputSpec(
            name="memo_ck_integrated",
            dtype=np.ndarray,
            description="Integrated/decimated temporal memory (n_channels, n_decimated_frames)",
            shape=TensorShape(("n_channels", "n_decimated_frames")),
        ),
    },
    outputs={
        "f0_frames": OutputSpec(
            name="f0_frames",
            dtype=np.ndarray,
            description="Frame indices with F0 detection",
        ),
        "f0_channels": OutputSpec(
            name="f0_channels",
            dtype=np.ndarray,
            description="Channel indices (lowest active per frame)",
        ),
        "f0_frequency_hz": OutputSpec(
            name="f0_frequency_hz",
            dtype=np.ndarray,
            description="F0 frequency in Hz",
        ),
        "f0_period_samples": OutputSpec(
            name="f0_period_samples",
            dtype=np.ndarray,
            description="F0 period in samples",
        ),
        "f0_memo_ma": OutputSpec(
            name="f0_memo_ma",
            dtype=np.ndarray,
            description="memo_ma values at F0 positions",
        ),
        "f0_memo_ck": OutputSpec(
            name="f0_memo_ck",
            dtype=np.ndarray,
            description="memo_ck values at F0 positions",
        ),
        "f0_counter": OutputSpec(
            name="f0_counter",
            dtype=np.ndarray,
            description="Counter values at F0 positions",
        ),
    },
    method="process",
    description="Detect fundamental frequency from integrated/decimated auditory signals.",
)
class F0Detector:
    """Fundamental frequency detector using persistence tracking and harmonic analysis.

    F0 detection pipeline:
    1. Peak extraction (spatial filtering)
    2. Cumulative persistence tracking
    3. Harmonic group segmentation
    4. Temporal continuity filtering
    5. F0 extraction (lowest active channel)

    Input signals must be pre-integrated and decimated using TemporalIntegrator.

    Example:
        >>> from soundperception.audition import AuditoryPeriphery, TemporalIntegrator, F0Detector
        >>> from soundperception.audition import (
        ...     AuditoryPeripheryConfig, TemporalIntegrationConfig, F0DetectionConfig
        ... )
        >>>
        >>> periphery = AuditoryPeriphery(AuditoryPeripheryConfig.default())
        >>> result = periphery.process(audio_signal)
        >>>
        >>> # Apply temporal integration and decimation
        >>> integrator = TemporalIntegrator(TemporalIntegrationConfig.default())
        >>> integrated = integrator.process(result['memo_ma'], result['memo_ck'])
        >>>
        >>> # Detect F0
        >>> detector = F0Detector(F0DetectionConfig.default())
        >>> f0_result = detector.process(integrated['memo_ma'], integrated['memo_ck'])
        >>>
        >>> # Access results
        >>> print(f"F0 frequency range: {f0_result['f0_frequency_hz'].min():.1f} - "
        ...       f"{f0_result['f0_frequency_hz'].max():.1f} Hz")
    """

    def __init__(self, config: F0DetectionConfig | None = None):
        """Initialize F0 detector with configuration.

        Args:
            config: F0 detection configuration. If None, uses default configuration.
        """
        self.config = config or F0DetectionConfig()

    def process(
        self,
        memo_ma_integrated: np.ndarray,
        memo_ck_integrated: np.ndarray,
        return_intermediate: bool = False,
    ) -> dict[str, np.ndarray]:
        """Detect fundamental frequency from integrated/decimated auditory signals.

        Args:
            memo_ma_integrated: Integrated/decimated amplitude memory from TemporalIntegrator
                               (n_channels, n_decimated_frames)
            memo_ck_integrated: Integrated/decimated temporal memory from TemporalIntegrator
                               (n_channels, n_decimated_frames)
            return_intermediate: If True, return all intermediate stages (default: False)

        Returns:
            Dictionary with F0 detection results:
                - 'f0_frames': Frame indices with F0 detection
                - 'f0_channels': Channel indices (lowest active per frame)
                - 'f0_frequency_hz': F0 frequency in Hz
                - 'f0_period_samples': F0 period in samples
                - 'f0_memo_ma': memo_ma values at F0 positions
                - 'f0_memo_ck': memo_ck values at F0 positions
                - 'f0_counter': Counter values at F0 positions

            If return_intermediate=True, also includes:
                - 'low_freq_ma': After low frequency channel extraction
                - 'low_freq_ck': After low frequency channel extraction
                - 'peaks': Detected peaks
                - 'persistence_counter': Persistence counter
                - 'peak_groups': Harmonic group assignments
                - 'tracked_counter': After temporal continuity filtering
        """
        cfg = self.config

        low_freq_ma = memo_ma_integrated[: cfg.num_low_channels, :]
        low_freq_ck = memo_ck_integrated[: cfg.num_low_channels, :]

        peaks = extract_peaks_adaptive(
            low_freq_ma,
            low_freq_ck,
            window_size=cfg.peak_window_size,
            amp_threshold=cfg.peak_amp_threshold,
            ck_threshold=cfg.peak_ck_threshold,
        )

        persistence_counter = track_cumulative_persistence(
            peaks, window_half_size=cfg.persistence_window_half_size
        )

        channel_numbers = np.arange(cfg.num_low_channels)[:, np.newaxis]
        active_channels = np.where(persistence_counter > 0, channel_numbers, 0)
        peak_groups = segment_harmonic_groups(active_channels)
        peak_groups = np.where(peaks > 0, peak_groups, 0)

        result = track_temporal_continuity(
            persistence_counter,
            peak_groups,
            mode=cfg.continuity_mode,
            extract_f0=True,
            rounded_ma=low_freq_ma,
            rounded_ck=low_freq_ck,
        )

        conversion = convert_memo_ck_to_frequency(result["f0_memo_ck"], sample_rate=cfg.sample_rate)

        f0_frames = result["f0_frames"]
        f0_channels = result["f0_channels"]
        f0_frequency_hz = conversion["frequency_hz"]
        f0_period_samples = conversion["period_samples"]
        f0_memo_ma = result["f0_memo_ma"]
        f0_memo_ck = result["f0_memo_ck"]
        f0_counter = result["f0_counter"]

        if cfg.boundary_filter_frames > 0:
            total_frames = memo_ma_integrated.shape[1]
            boundary_mask = (f0_frames >= cfg.boundary_filter_frames) & (
                f0_frames < (total_frames - cfg.boundary_filter_frames)
            )

            f0_frames = f0_frames[boundary_mask]
            f0_channels = f0_channels[boundary_mask]
            f0_frequency_hz = f0_frequency_hz[boundary_mask]
            f0_period_samples = f0_period_samples[boundary_mask]
            f0_memo_ma = f0_memo_ma[boundary_mask]
            f0_memo_ck = f0_memo_ck[boundary_mask]
            f0_counter = f0_counter[boundary_mask]

        output = {
            "f0_frames": f0_frames,
            "f0_channels": f0_channels,
            "f0_frequency_hz": f0_frequency_hz,
            "f0_period_samples": f0_period_samples,
            "f0_memo_ma": f0_memo_ma,
            "f0_memo_ck": f0_memo_ck,
            "f0_counter": f0_counter,
        }

        if return_intermediate:
            output.update(
                {
                    "low_freq_ma": low_freq_ma,
                    "low_freq_ck": low_freq_ck,
                    "peaks": peaks,
                    "persistence_counter": persistence_counter,
                    "peak_groups": peak_groups,
                    "tracked_counter": result["tracked_counter"],
                }
            )

        return output
