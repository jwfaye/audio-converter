"""Frequency invariance extraction module (Stage 7).

Stage 7 of auditory model: extraction of frequency-invariant representations
from temporal memory (memo_ck). Identifies harmonic relationships and computes
amplitude invariances across different fundamental frequencies.

Extraction steps:
1. Fundamental selection: Extract F0 from temporal memory at decimated frames
2. Frequency table computation: Calculate harmonic distances for all channels
3. Minima detection: Identify channels corresponding to harmonics
4. Amplitude extraction: Get memo_ma values at harmonic positions
5. Invariance computation: Calculate relative amplitudes wrt fundamental

Captures spectral envelope independently of fundamental frequency.
"""

import logging

import numpy as np
import pandas as pd

from soundperception.audition.config import FrequencyInvarianceConfig
from soundperception.module import InputSpec, OutputSpec, TensorShape, module

logger = logging.getLogger(__name__)


@module(
    inputs={
        "f0_result": InputSpec(
            name="f0_result",
            dtype=dict,
            description="Dictionary from F0Detector with f0_frames, f0_channels, f0_period_samples",
        ),
        "memo_ma_integrated": InputSpec(
            name="memo_ma_integrated",
            dtype=np.ndarray,
            description="Integrated/decimated amplitude memory (n_channels, n_decimated_frames)",
            shape=TensorShape(("n_channels", "n_decimated_frames")),
        ),
    },
    outputs={
        "invariance_table": OutputSpec(
            name="invariance_table",
            dtype=np.ndarray,
            description="2D array of spectral envelopes (n_harmonics, n_frames)",
            shape=TensorShape(("n_harmonics", "n_frames")),
        ),
        "ma_values": OutputSpec(
            name="ma_values",
            dtype=np.ndarray,
            description="Amplitude values at fundamental",
        ),
        "nbck_values": OutputSpec(
            name="nbck_values",
            dtype=np.ndarray,
            description="Period values",
        ),
        "frame_indices": OutputSpec(
            name="frame_indices",
            dtype=list,
            description="Analyzed frame indices",
        ),
    },
    method="process",
    description="Extract frequency-invariant spectral envelopes from F0 detection results.",
)
class FrequencyInvarianceExtractor:
    """Extracts frequency-invariant representations from auditory outputs.

    Processes temporal memory (memo_ck) and amplitude memory (memo_ma)
    to extract spectral envelopes independent of fundamental frequency.

    Harmonic analysis steps:
    - Select frames with detected temporal activity
    - Compute frequency tables for harmonic relationships
    - Identify harmonic positions via local minima
    - Extract amplitude values at those positions
    - Compute invariances (relative to fundamental amplitude)

    Attributes:
        nb_harmonics: Number of harmonics to analyze (default: 30)
        min_invariance: Minimum invariance value for clipping (default: -30)
        freq_calibration: Frequency calibration table (numpy array)

    Example:
        >>> from soundperception.audition import (
        ...     AuditoryPeriphery, TemporalIntegrator, F0Detector,
        ...     FrequencyInvarianceExtractor
        ... )
        >>> from soundperception.audition import (
        ...     AuditoryPeripheryConfig, TemporalIntegrationConfig,
        ...     F0DetectionConfig, FrequencyInvarianceConfig
        ... )
        >>>
        >>> # Process through pipeline
        >>> periphery = AuditoryPeriphery(AuditoryPeripheryConfig.default())
        >>> result = periphery.process(audio_signal)
        >>>
        >>> integrator = TemporalIntegrator(TemporalIntegrationConfig.default())
        >>> integrated = integrator.process(result['memo_ma'], result['memo_ck'])
        >>>
        >>> detector = F0Detector(F0DetectionConfig.default())
        >>> f0_result = detector.process(integrated['memo_ma'], integrated['memo_ck'])
        >>>
        >>> extractor = FrequencyInvarianceExtractor(FrequencyInvarianceConfig.default())
        >>> inv_result = extractor.process(f0_result, integrated['memo_ma'])
        >>> print(inv_result['invariance_table'].shape)
    """

    def __init__(
        self,
        config: FrequencyInvarianceConfig | None = None,
        freq_table_path: str | None = None,
    ):
        """Initialize the frequency invariance extractor.

        Args:
            config: Configuration object. If None, uses default configuration.
            freq_table_path: Path to frequency calibration CSV file.
                If None, uses path from config.

        Note:
            CSV file has high-to-low frequency order (iloc[0]=6500Hz to iloc[64]=40Hz).
            Flipped to match memo_ma order (channel[0]=40Hz to channel[64]=6174Hz).
        """
        self.config = config or FrequencyInvarianceConfig()
        self.nb_harmonics = self.config.nb_harmonics
        self.min_invariance = self.config.min_invariance
        self.num_channels = self.config.num_channels

        calibration_path = freq_table_path or self.config.calibration_table_path

        self.freq_calibration = None
        if calibration_path:
            try:
                df = pd.read_csv(calibration_path, sep=",")
                n_channels = len(df)
                self.freq_calibration = np.flipud(df["calibrage"].values)
                del df
                logger.info(
                    "Loaded frequency calibration table: %d channels "
                    "(flipped to match memo_ma order)",
                    n_channels,
                )
            except (
                FileNotFoundError,
                pd.errors.EmptyDataError,
                pd.errors.ParserError,
                ValueError,
            ) as e:
                logger.warning("Failed to load frequency table from %s: %s", calibration_path, e)

        logger.info(
            "Initialized FrequencyInvarianceExtractor (nb_harmonics=%d, min_invariance=%d)",
            self.nb_harmonics,
            self.min_invariance,
        )

    def process(
        self,
        f0_result: dict,
        memo_ma_integrated: np.ndarray,
        return_intermediate: bool = False,
        fill_missing_frames: bool = True,
    ) -> dict:
        """Extract frequency-invariant representations using F0 detection results.

        Args:
            f0_result: Dictionary returned by F0Detector.detect(), containing:
                - 'f0_frames': Frame indices where F0 was detected
                - 'f0_channels': Channel indices of detected F0
                - 'f0_period_samples': Period values in samples
            memo_ma_integrated: Integrated/decimated amplitude memory from TemporalIntegrator,
                shape (n_channels, n_decimated_frames). Must use same TemporalIntegrator
                output as for F0 detection.
            return_intermediate: If True, returns dict with all intermediate stages.
            fill_missing_frames: If True, fills frames without F0 detection with
                min_invariance value for temporal alignment with input signals.
                Default: True.

        Returns:
            Dictionary with keys:
            - 'invariance_table': 2D array (n_harmonics, n_total_frames) if
                fill_missing_frames=True, or (n_harmonics, n_valid_frames) if False
            - 'ma_values': Array of amplitude values at fundamental
            - 'nbck_values': Array of period values
            - 'frame_indices': List of analyzed frame indices
            If return_intermediate=True, includes:
            - 'frequency_tables': List of frequency tables per frame
            - 'harmonic_positions': List of harmonic channel positions per frame

        Example:
            extractor = FrequencyInvarianceExtractor(
                FrequencyInvarianceConfig.default()
            )
            result = extractor.process(f0_result, memo_ma_integrated)
            inv_table = result["invariance_table"]  # (n_harmonics, n_frames)
            print(f"Harmonics: {inv_table.shape[0]}, Frames: {inv_table.shape[1]}")
        """
        if self.freq_calibration is None:
            raise ValueError("Frequency calibration table not loaded. Provide freq_table_path.")

        f0_frames = f0_result["f0_frames"]
        f0_channels = f0_result["f0_channels"]
        f0_period_samples = f0_result["f0_period_samples"]

        total_frames = memo_ma_integrated.shape[1]

        invariances = []
        ma_values = []
        nbck_values = []
        frame_indices = []
        frequency_tables = [] if return_intermediate else None
        harmonic_positions = [] if return_intermediate else None

        for _, (frame, channel, period) in enumerate(
            zip(f0_frames, f0_channels, f0_period_samples, strict=False)
        ):
            nbck_fundamental = period
            ma_fundamental = memo_ma_integrated[channel, frame]

            freq_table = self._compute_frequency_table(nbck_fundamental)
            if return_intermediate:
                frequency_tables.append(freq_table)
            harmonic_ranks = self._find_harmonic_positions(freq_table)
            harmonic_ranks[0] = channel
            if return_intermediate:
                harmonic_positions.append(harmonic_ranks)
            harmonic_amplitudes = self._extract_harmonic_amplitudes(
                harmonic_ranks, memo_ma_integrated[:, frame]
            )

            if len(harmonic_amplitudes) > 0:
                invariance = self._compute_invariance(harmonic_amplitudes)

                invariances.append(invariance)
                ma_values.append(ma_fundamental)
                nbck_values.append(nbck_fundamental)
                frame_indices.append(frame)

        if len(invariances) > 0:
            inv_table = self._build_invariance_table(invariances)
            inv_table = np.where(inv_table < self.min_invariance, self.min_invariance, inv_table)
        else:
            inv_table = np.array([]).reshape(0, 0)

        if fill_missing_frames and len(invariances) > 0:
            inv_table_full, ma_values_full, nbck_values_full = self._fill_missing_frames(
                inv_table, ma_values, nbck_values, frame_indices, total_frames
            )

            result = {
                "invariance_table": inv_table_full,
                "ma_values": ma_values_full,
                "nbck_values": nbck_values_full,
                "frame_indices": list(range(total_frames)),
            }

            logger.debug(
                "Extracted invariances: %d/%d frames filled, %d harmonics",
                len(invariances),
                total_frames,
                inv_table_full.shape[0],
            )
        else:
            result = {
                "invariance_table": inv_table,
                "ma_values": ma_values,
                "nbck_values": nbck_values,
                "frame_indices": frame_indices,
            }

            logger.debug(
                "Extracted invariances: %d frames, %d harmonics",
                len(frame_indices),
                inv_table.shape[0] if len(invariances) > 0 else 0,
            )

        if return_intermediate:
            result["frequency_tables"] = frequency_tables
            result["harmonic_positions"] = harmonic_positions

        return result

    def _compute_frequency_table(self, nbck_fundamental: float) -> np.ndarray:
        """Compute frequency table for harmonic analysis.

        For each channel and each harmonic, computes the distance:
        distance = |log(nbck_fundamental) - log(harmonic_number) - log(channel_calibration)|

        Args:
            nbck_fundamental: Fundamental period value

        Returns:
            Frequency table, shape (n_channels, nb_harmonics)
        """
        n_channels = len(self.freq_calibration)
        freq_table = np.zeros((n_channels, self.nb_harmonics))

        for i in range(n_channels):
            for h in range(self.nb_harmonics):
                harmonic_number = h + 1
                channel_calib = self.freq_calibration[i]

                freq_table[i, h] = abs(
                    np.log(nbck_fundamental) - np.log(harmonic_number) - np.log(channel_calib)
                )

        return freq_table

    def _find_harmonic_positions(self, freq_table: np.ndarray) -> list:
        """Find harmonic positions by detecting local minima in frequency table.

        Args:
            freq_table: Frequency distance table, shape (n_channels, nb_harmonics)

        Returns:
            List of channel indices (0-indexed) for each harmonic, length = nb_harmonics
            harmonic_channels[0] = channel for H1 (fundamental)
            harmonic_channels[1] = channel for H2
            ...
        """
        harmonic_channels = []

        for h in range(self.nb_harmonics):
            column = freq_table[:, h]

            best_channel = None
            min_value = float("inf")

            for i, value in enumerate(column):
                neighbors = []
                if i > 0:
                    neighbors.append(column[i - 1])
                if i < len(column) - 1:
                    neighbors.append(column[i + 1])

                if len(neighbors) > 0 and value < min(neighbors):
                    if value < min_value:
                        min_value = value
                        best_channel = i

            if best_channel is None:
                best_channel = np.argmin(column)

            harmonic_channels.append(best_channel)

        return harmonic_channels

    def _extract_harmonic_amplitudes(
        self, harmonic_channels: list, memo_ma_frame: np.ndarray
    ) -> list:
        """Extract amplitude values at harmonic positions.

        Args:
            harmonic_channels: List of channel indices (0-indexed) for each harmonic
            memo_ma_frame: Amplitude values for one frame (n_channels,)

        Returns:
            List of amplitude values at harmonic positions
            amplitudes[0] = amplitude of H1 (fundamental)
            amplitudes[1] = amplitude of H2
            ...
        """
        amplitudes = []
        for channel_idx in harmonic_channels:
            if 0 <= channel_idx < len(memo_ma_frame):
                amplitudes.append(memo_ma_frame[channel_idx])
            else:
                amplitudes.append(self.min_invariance)

        return amplitudes

    def _compute_invariance(self, harmonic_amplitudes: list) -> list:
        """Compute amplitude invariances relative to fundamental.

        Args:
            harmonic_amplitudes: List of amplitude values (first is fundamental)

        Returns:
            List of invariance values (differences from fundamental)
        """
        if len(harmonic_amplitudes) == 0:
            return []

        fundamental_amplitude = harmonic_amplitudes[0]
        invariances = [amp - fundamental_amplitude for amp in harmonic_amplitudes]

        return invariances

    def _build_invariance_table(self, invariances: list) -> np.ndarray:
        """Convert list of invariances to 2D table.

        Args:
            invariances: List of invariance lists (one per frame)

        Returns:
            2D array, shape (max_harmonics, n_frames)
        """
        max_harmonics = max(len(inv) for inv in invariances)

        table = []
        for inv in invariances:
            padded = list(inv) + [0] * (max_harmonics - len(inv))
            table.append(padded)

        table = np.array(table).T

        return table

    def _fill_missing_frames(
        self,
        inv_table: np.ndarray,
        ma_values: list,
        nbck_values: list,
        frame_indices: list,
        total_frames: int,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Fill missing frames with min_invariance value for temporal alignment.

        Args:
            inv_table: Invariance table with detected frames only (n_harmonics, n_detected_frames)
            ma_values: List of MA values for detected frames
            nbck_values: List of NBCK values for detected frames
            frame_indices: List of detected frame indices
            total_frames: Total number of frames in the signal

        Returns:
            Tuple of (inv_table_full, ma_values_full, nbck_values_full) with all frames
        """
        n_harmonics = inv_table.shape[0]

        inv_table_full = np.full((n_harmonics, total_frames), self.min_invariance, dtype=float)
        ma_values_full = np.full(total_frames, self.min_invariance, dtype=float)
        nbck_values_full = np.zeros(total_frames, dtype=float)

        for i, frame_idx in enumerate(frame_indices):
            inv_table_full[:, frame_idx] = inv_table[:, i]
            ma_values_full[frame_idx] = ma_values[i]
            nbck_values_full[frame_idx] = nbck_values[i]

        logger.debug(
            "Filled missing frames: %d detected / %d total (%.1f%% coverage)",
            len(frame_indices),
            total_frames,
            100 * len(frame_indices) / total_frames,
        )

        return inv_table_full, ma_values_full, nbck_values_full
