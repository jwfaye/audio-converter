"""Auditory periphery model with auditory nerve encoding.

This module implements the auditory periphery stages, based on models
compared in Osses et al. (2022).

Stages implemented:
- Stage 1: Outer ear (not implemented)
- Stage 2: Middle ear filtering (optional)
- Stage 3: Cochlear filtering (Gammatone filterbank)
- Stage 3b: Group delay compensation
- Stage 4: Inner hair cell simulation (peak extraction -> neural spikes)
- Stage 5: Auditory nerve (AN) discrete temporal encoding

Stage 5 uses discrete memory mechanisms that capture spike timing and amplitude.

References:
    Osses, A., Varnet, L., Carney, L. H., et al. (2022). A comparative study
    of eight human auditory models of monaural processing. Acta Acustica.
"""

import logging
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pandas as pd
from gammatone.filters import centre_freqs, erb_space, make_erb_filters
from scipy import signal as sgn
from scipy.signal import butter, sosfilt

from soundperception.audition.config import (
    AuditoryPeripheryConfig,
)
from soundperception.audition.core._kernels import (
    NUMBA_AVAILABLE,
    extract_clock_counter_numba,
    extract_clock_counter_numpy,
    extract_memo_ck_numba,
    extract_memo_ck_numpy,
    extract_peaks_numba,
    extract_peaks_numpy,
)
from soundperception.module import InputSpec, OutputSpec, TensorShape, module

logger = logging.getLogger(__name__)


@module(
    inputs={
        "signal": InputSpec(
            name="signal",
            dtype=np.ndarray,
            description="Input audio signal (n_samples,)",
            shape=TensorShape(("n_samples",)),
        ),
    },
    outputs={
        "peaks": OutputSpec(
            name="peaks",
            dtype=np.ndarray,
            description="Peak-extracted signal (n_channels, n_samples)",
            shape=TensorShape(("n_channels", "n_samples")),
        ),
        "cpt_ck": OutputSpec(
            name="cpt_ck",
            dtype=np.ndarray,
            description="Clock counter (n_channels, n_samples)",
            shape=TensorShape(("n_channels", "n_samples")),
        ),
        "memo_ma": OutputSpec(
            name="memo_ma",
            dtype=np.ndarray,
            description="Amplitude memory (n_channels, n_samples)",
            shape=TensorShape(("n_channels", "n_samples")),
        ),
        "memo_ck": OutputSpec(
            name="memo_ck",
            dtype=np.ndarray,
            description="Temporal memory (n_channels, n_samples)",
            shape=TensorShape(("n_channels", "n_samples")),
        ),
    },
    method="process",
    description=(
        "Auditory periphery model processing audio through cochlear filtering"
        " and auditory nerve encoding."
    ),
)
class AuditoryPeriphery:
    """Auditory periphery model (Stages 1-5).

    Processes acoustic input through auditory nerve encoding. Outputs peaks
    and discrete temporal representations (clock counter, amplitude/temporal memory).

    Attributes:
        config: Configuration for all processing stages
        center_frequencies: Center frequencies of cochlear channels (Hz)

    Example:
        >>> from soundperception.audition import AuditoryPeriphery, AuditoryPeripheryConfig
        >>> config = AuditoryPeripheryConfig.default()
        >>> model = AuditoryPeriphery(config)
        >>> result = model.process(audio_signal)
        >>> peaks = result['peaks']
        >>> memo_ma = result['memo_ma']
    """

    def __init__(
        self,
        config: AuditoryPeripheryConfig | None = None,
        use_numba: bool = True,
        n_threads: int = 8,
    ):
        """Initialize auditory periphery model.

        Args:
            config: Configuration object. If None, uses default configuration.
            use_numba: Use Numba-optimized kernels (default: True, ~50x faster).
            n_threads: Number of threads for parallel gammatone filtering (default: 8).
        """
        self.config = config or AuditoryPeripheryConfig.default()
        self.use_numba = use_numba and NUMBA_AVAILABLE
        self.n_threads = n_threads
        self.center_frequencies = self._compute_center_frequencies()

        self._calibration_cache: np.ndarray | None = None
        self._limits_cache: np.ndarray | None = None
        self._delay_gaps_cache: np.ndarray | None = None

        self._gammatone_coefs: np.ndarray | None = None
        self._gammatone_gain: np.ndarray | None = None
        self._gammatone_As: tuple | None = None
        self._gammatone_Bs: np.ndarray | None = None

        logger.info(
            "Initialized AuditoryPeriphery with %d channels (%g-%g Hz), numba=%s, threads=%d",
            self.config.cochlear.num_filters,
            self.config.cochlear.f_min,
            self.config.cochlear.f_max,
            self.use_numba,
            n_threads,
        )

    def _compute_center_frequencies(self) -> np.ndarray:
        """Compute center frequencies for cochlear channels.

        Returns:
            Array of center frequencies in Hz, shape (num_filters,)
        """
        cfg = self.config.cochlear
        return centre_freqs(cfg.sample_rate, cfg.num_filters, cfg.f_min, cfg.f_max)

    def process(self, signal: np.ndarray, return_intermediate: bool = False) -> np.ndarray | dict:
        """Process audio signal through auditory periphery stages.

        Args:
            signal: Input audio signal, shape (n_samples,)
            return_intermediate: If True, returns dict with all intermediate stages

        Returns:
            If return_intermediate=False:
                If auditory_nerve is disabled:
                    Peaks array, shape (num_filters, n_samples)
                If auditory_nerve is enabled:
                    Dictionary with 'peaks', 'cpt_ck', 'memo_ma', 'memo_ck'
            If return_intermediate=True:
                Dictionary with keys:
                - 'middle_ear': Signal after middle ear filtering
                - 'cochlear': Signal after cochlear filtering
                - 'compensated': Signal after delay compensation
                - 'peaks': Peak-extracted signal (Stage 4)
                - 'cpt_ck': Clock counter (Stage 5a, if enabled)
                - 'memo_ma': Amplitude memory (Stage 5b, if enabled)
                - 'memo_ck': Temporal memory (Stage 5c, if enabled)

        Example:
            >>> signal = np.random.randn(16000)  # 1 second at 16 kHz
            >>> result = model.process(signal)
            >>> result['peaks'].shape
            (65, 16000)
        """
        stages = {}

        if self.config.middle_ear.enabled:
            signal = self._apply_middle_ear(signal)
            stages["middle_ear"] = signal

        cochlear_output = self._apply_cochlear_filtering(signal)
        stages["cochlear"] = cochlear_output

        peaks = self._extract_peaks(cochlear_output)

        if self.config.delay_compensation.enabled:
            peaks = self._apply_delay_compensation(peaks)
            stages["compensated"] = peaks

        stages["peaks"] = peaks

        # Stage 4b: Presence mask — global 25% then per-channel 25%
        max_energy = np.max(peaks)
        if max_energy > 0:
            mask = peaks >= 0.25 * max_energy
        else:
            mask = peaks > 0
        ch_max = np.max(peaks * mask, axis=1, keepdims=True)
        mask = mask & (peaks >= 0.25 * ch_max)
        peaks = np.where(mask, peaks, 0.0)

        if self.config.auditory_nerve.enabled:
            cpt_ck = self._extract_clock_counter(peaks)
            memo_ma = self._extract_memo_ma(peaks, cpt_ck)
            memo_ck = self._extract_memo_ck(peaks, cpt_ck)

            stages["cpt_ck"] = cpt_ck
            stages["memo_ma"] = memo_ma
            stages["memo_ck"] = memo_ck

        if return_intermediate:
            return stages

        if self.config.auditory_nerve.enabled:
            return {
                "peaks": stages["peaks"],
                "cpt_ck": stages["cpt_ck"],
                "memo_ma": stages["memo_ma"],
                "memo_ck": stages["memo_ck"],
            }
        return peaks

    def _apply_middle_ear(self, signal: np.ndarray) -> np.ndarray:
        """Apply middle ear filtering (Stage 2).

        Bandpass filter implementation, present in 6/8 models from Osses et al. (2022).

        Args:
            signal: Input signal, shape (n_samples,)

        Returns:
            Filtered signal, shape (n_samples,)
        """
        cfg = self.config.middle_ear

        if cfg.filter_type == "butterworth":
            sos = butter(
                cfg.order,
                [cfg.lowcut, cfg.highcut],
                btype="band",
                fs=self.config.cochlear.sample_rate,
                output="sos",
            )
            return sosfilt(sos, signal)
        if cfg.filter_type == "none":
            return signal
        raise ValueError(f"Unknown middle ear filter type: {cfg.filter_type}")

    def _apply_cochlear_filtering(self, signal: np.ndarray) -> np.ndarray:
        """Apply cochlear filtering using Gammatone filterbank (Stage 3).

        Linear Gammatone filtering implementation, used in dau1997 and osses2021
        models from Osses et al. (2022).

        Uses parallel filtering with ThreadPoolExecutor for ~2x speedup.

        Args:
            signal: Input signal, shape (n_samples,)

        Returns:
            Filtered signal, shape (num_filters, n_samples)

        References:
            - Hohmann (2002): Frequency analysis and synthesis using a
              Gammatone filterbank
            - Osses et al. (2022), Table II: dau1997 and osses2021 use
              linear Gammatone filters
        """
        cfg = self.config.cochlear

        if self._gammatone_coefs is None:
            cfs = self.center_frequencies
            coefs = np.flipud(make_erb_filters(cfg.sample_rate, cfs))
            self._gammatone_coefs = coefs
            self._gammatone_gain = coefs[:, 9]
            self._gammatone_As = (
                coefs[:, (0, 1, 5)],
                coefs[:, (0, 2, 5)],
                coefs[:, (0, 3, 5)],
                coefs[:, (0, 4, 5)],
            )
            self._gammatone_Bs = coefs[:, 6:9]

        n_filters = cfg.num_filters
        gain = self._gammatone_gain
        as1, as2, as3, as4 = self._gammatone_As
        bs = self._gammatone_Bs

        def filter_channel(idx: int) -> np.ndarray:
            y1 = sgn.lfilter(as1[idx], bs[idx], signal)
            y2 = sgn.lfilter(as2[idx], bs[idx], y1)
            y3 = sgn.lfilter(as3[idx], bs[idx], y2)
            y4 = sgn.lfilter(as4[idx], bs[idx], y3)
            return y4 / gain[idx]

        if self.n_threads > 1:
            with ThreadPoolExecutor(max_workers=self.n_threads) as executor:
                results = list(executor.map(filter_channel, range(n_filters)))
            xf = np.array(results)
        else:
            xf = np.zeros((n_filters, len(signal)))
            for idx in range(n_filters):
                xf[idx] = filter_channel(idx)

        xe = np.where(xf > 0, xf, 0)

        return xe

    def _apply_delay_compensation(self, signal: np.ndarray) -> np.ndarray:
        """Apply group delay compensation (Stage 3b).

        Compensates for differential group delay across frequency channels
        introduced by the Gammatone filterbank.

        Args:
            signal: Cochlear-filtered signal, shape (num_filters, n_samples)

        Returns:
            Delay-compensated signal, shape (num_filters, n_samples)

        References:
            - Osses et al. (2022), p.3: "osses2021 includes [...] a fixed
              group-delay compensation"
        """
        cfg = self.config.delay_compensation

        try:
            delay_df = pd.read_csv(cfg.compensation_file)
        except FileNotFoundError:
            logger.warning(
                "Delay compensation file not found: %s. Skipping delay compensation.",
                cfg.compensation_file,
            )
            return signal

        if cfg.apply_threshold:
            max_peak = np.max(signal)
            threshold = max_peak - cfg.threshold_db
            signal = np.where(signal > threshold, signal, 0)
            logger.debug(
                "Applied %g dB threshold: max=%.2f, threshold=%.2f",
                cfg.threshold_db,
                max_peak,
                threshold,
            )

        compensated = np.zeros_like(signal)
        num_channels = min(signal.shape[0], len(delay_df))

        for canal in range(num_channels):
            gap = int(delay_df["Gaps"].iloc[canal])
            if gap > 0:
                compensated[canal, :-gap] = signal[canal, gap:]
            else:
                compensated[canal, :] = signal[canal, :]

        return compensated

    def _extract_peaks(self, signal: np.ndarray) -> np.ndarray:
        """Extract local peaks (Stage 4 - IHC approximation).

        Approximates Inner Hair Cell processing. Extracts local maxima in a sliding window.

        Uses Numba-optimized kernel when use_numba=True (~23x faster).

        Args:
            signal: Input signal, shape (num_filters, n_samples)

        Returns:
            Peak-extracted signal, shape (num_filters, n_samples)

        Note:
            Other models in Osses et al. (2022) use different approaches:
            - dau1997/osses2021: Half-wave rect + 1000 Hz lowpass
            - zilany2014/bruce2018: Nonlinearity + 966 Hz lowpass cascade
            - verhulst2018: Hodgkin-Huxley 3-channel model
        """
        cfg = self.config.peak_extraction

        if self.use_numba:
            return extract_peaks_numba(
                signal.astype(np.float64),
                cfg.window_size,
                cfg.min_peak_value,
                cfg.log_transform,
            )

        return extract_peaks_numpy(
            signal.astype(np.float64),
            cfg.window_size,
            cfg.min_peak_value,
            cfg.log_transform,
        )

    def _extract_clock_counter(self, peaks: np.ndarray) -> np.ndarray:
        """Extract clock counter from peaks (Stage 5a - Auditory Nerve).

        For each row (channel) j and column i:
        - If peaks[j,i] > 0, set cpt_ck[j,i] = 1
        - Otherwise, if cpt_ck[j,i-1] > 0 and cpt_ck[j,i-1] < limit[j],
          set cpt_ck[j,i] = cpt_ck[j,i-1] + 1
        - Elsewhere, cpt_ck[j,i] = 0

        Where limit[j] = lim_coef * calibrage[j] (period in samples for channel j)

        Uses Numba-optimized kernel when use_numba=True (~50x faster).

        Args:
            peaks: Peak-extracted signal, shape (num_filters, n_samples)

        Returns:
            Clock counter array, shape (num_filters, n_samples)

        Note:
            Captures inter-spike intervals for temporal pitch perception.
            Each channel has its own limit based on its characteristic period.
        """
        cfg = self.config.auditory_nerve

        if self._limits_cache is None:
            calibration = pd.read_csv(cfg.calibration_table_path)
            calibrage = calibration["calibrage"].values[::-1]
            self._limits_cache = (cfg.lim_coef * calibrage).astype(np.float64)

        limits = self._limits_cache

        if self.use_numba:
            return extract_clock_counter_numba(
                peaks.astype(np.float64),
                limits,
            )

        return extract_clock_counter_numpy(peaks.astype(np.float64), limits)

    def _extract_memo_ma(self, peaks: np.ndarray, cpt_ck: np.ndarray) -> np.ndarray:
        """Extract amplitude memory (Stage 5b - Auditory Nerve).

        For each column j and row i:
        - If peaks[j,i] > 0, memo_ma[j,i] = peaks[j,i]
        - Otherwise, if cpt_ck[j,i-1] > 0, memo_ma[j,i] = memo_ma[j,i-1]
        - Elsewhere, memo_ma[j,i] = 0

        Args:
            peaks: Peak-extracted signal, shape (num_filters, n_samples)
            cpt_ck: Clock counter array, shape (num_filters, n_samples)

        Returns:
            Amplitude memory array, shape (num_filters, n_samples)

        Note:
            Maintains the amplitude of the last spike.
        """
        n_rows, n_cols = peaks.shape
        peaks_bin = peaks > 0

        col_idx = np.arange(n_cols)
        pos = peaks_bin * col_idx[None, :]
        last_peak_idx = np.maximum.accumulate(pos, axis=1)
        peak_vals = peaks[np.arange(n_rows)[:, None], last_peak_idx]
        prev_ck = np.concatenate([np.zeros((n_rows, 1), dtype=bool), cpt_ck[:, :-1] > 0], axis=1)
        _valid = peaks_bin | prev_ck

        memo_ma = np.where(_valid, peak_vals, 0.0)

        return memo_ma

    def _extract_memo_ck(self, peaks: np.ndarray, cpt_ck: np.ndarray) -> np.ndarray:
        """Extract temporal memory (Stage 5c - Auditory Nerve).

        For each row j and column i:
        - If (peaks[j,i] > 0) and (cpt_ck[j,i-1] > 0),
          memo_ck[j,i] = 10*log(cpt_ck[j,i-1])
        - Otherwise if cpt_ck[j,i] > 0,
          memo_ck[j,i] = memo_ck[j,i-1]

        Uses Numba-optimized kernel when use_numba=True (~50x faster).

        Args:
            peaks: Peak-extracted signal, shape (num_filters, n_samples)
            cpt_ck: Clock counter array, shape (num_filters, n_samples)

        Returns:
            Temporal memory array, shape (num_filters, n_samples)

        Note:
            Encodes inter-spike intervals on a logarithmic scale.
        """
        if self.use_numba:
            return extract_memo_ck_numba(
                peaks.astype(np.float64),
                cpt_ck.astype(np.float64),
            )

        return extract_memo_ck_numpy(peaks.astype(np.float64), cpt_ck.astype(np.float64))

    def apply_cochlear_filtering(self, signal: np.ndarray) -> np.ndarray:
        """Public wrapper for cochlear filtering (for backward compatibility).

        Args:
            signal: Input signal, shape (n_samples,)

        Returns:
            Filtered signal, shape (num_filters, n_samples)

        Example:
            import numpy as np
            model = AuditoryPeriphery(AuditoryPeripheryConfig.default())
            signal = np.random.randn(16000)
            filtered = model.apply_cochlear_filtering(signal)
            # filtered.shape == (65, 16000)
        """
        return self._apply_cochlear_filtering(signal)

    def apply_delay_compensation(self, signal: np.ndarray) -> np.ndarray:
        """Public wrapper for delay compensation (for backward compatibility).

        Args:
            signal: Cochlear-filtered signal, shape (num_filters, n_samples)

        Returns:
            Delay-compensated signal, shape (num_filters, n_samples)

        Example:
            filtered = model.apply_cochlear_filtering(signal)
            compensated = model.apply_delay_compensation(filtered)
            # compensated.shape == filtered.shape
        """
        return self._apply_delay_compensation(signal)

    def get_channel_info(self) -> pd.DataFrame:
        """Get information about cochlear channels.

        Returns:
            DataFrame with columns:
            - channel: Channel index (0-based)
            - center_freq_hz: Center frequency in Hz
            - erb: Equivalent Rectangular Bandwidth in Hz

        Example:
            >>> info = model.get_channel_info()
            >>> print(info.head())
               channel  center_freq_hz       erb
            0        0           40.12      8.67
            1        1           45.23      9.12
            ...
        """
        cfg = self.config.cochlear
        erbs = erb_space(cfg.f_min, cfg.f_max, cfg.num_filters)

        return pd.DataFrame(
            {
                "channel": np.arange(cfg.num_filters),
                "center_freq_hz": self.center_frequencies,
                "erb_hz": erbs,
            }
        )
