"""Temporal integration and decimation module (Stage 5.5).

Signal preprocessing between auditory periphery (Stage 5) and downstream analysis:

1. Temporal integration: Smooths signals over time using first-order differential equation
2. Decimation: Reduces temporal resolution
3. Rounding: Quantizes values for numerical stability
"""

import numpy as np

from soundperception.audition.config import TemporalIntegrationConfig
from soundperception.module import InputSpec, OutputSpec, TensorShape, module

__all__ = ["TemporalIntegrationConfig", "integrate_temporal", "TemporalIntegrator"]


def integrate_temporal(signal: np.ndarray, tau: int = 50) -> np.ndarray:
    """Apply temporal integration using first-order differential equation.

    Smooths the signal over time using:
        y[n] = y[n-1] + (x[n] - y[n-1]) / tau

    Args:
        signal: Input signal of shape (n_channels, n_frames)
        tau: Time constant controlling integration (default: 50)

    Returns:
        Integrated signal of same shape as input

    Example:
        import numpy as np
        # 10 channels, 1000 frames of noisy signal
        signal = np.random.rand(10, 1000)
        smoothed = integrate_temporal(signal, tau=50)
        # smoothed has same shape; rapid fluctuations are attenuated
    """
    result = np.zeros_like(signal, dtype=float)
    result[:, 0] = signal[:, 0]

    for i in range(1, signal.shape[1]):
        result[:, i] = result[:, i - 1] + (signal[:, i] - result[:, i - 1]) / tau

    return result


@module(
    inputs={
        "memo_ma": InputSpec(
            name="memo_ma",
            dtype=np.ndarray,
            description="Amplitude memory from auditory periphery (n_channels, n_frames)",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
        "memo_ck": InputSpec(
            name="memo_ck",
            dtype=np.ndarray,
            description="Temporal memory from auditory periphery (n_channels, n_frames)",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
    },
    outputs={
        "memo_ma": OutputSpec(
            name="memo_ma",
            dtype=np.ndarray,
            description="Integrated, decimated, rounded amplitude memory",
            shape=TensorShape(("n_channels", "n_decimated_frames")),
        ),
        "memo_ck": OutputSpec(
            name="memo_ck",
            dtype=np.ndarray,
            description="Integrated, decimated, rounded temporal memory",
            shape=TensorShape(("n_channels", "n_decimated_frames")),
        ),
    },
    method="process",
    description="Temporal integration, decimation and rounding of auditory signals.",
)
class TemporalIntegrator:
    """Temporal integration and decimation processor.

    Stage 5.5 of auditory pipeline. Preprocesses signals between auditory periphery
    outputs and downstream analysis stages.

    Integration smooths rapid fluctuations while preserving temporal structure.
    Decimation reduces computational load. Rounding ensures numerical stability.

    Example:
        >>> from soundperception.audition import AuditoryPeriphery, TemporalIntegrator
        >>> from soundperception.audition import AuditoryPeripheryConfig, TemporalIntegrationConfig
        >>>
        >>> # Process audio through auditory periphery
        >>> periphery_config = AuditoryPeripheryConfig.default()
        >>> periphery = AuditoryPeriphery(periphery_config)
        >>> result = periphery.process(audio_signal)
        >>>
        >>> # Apply temporal integration and decimation
        >>> integration_config = TemporalIntegrationConfig.default()
        >>> integrator = TemporalIntegrator(integration_config)
        >>> integrated = integrator.process(result['memo_ma'], result['memo_ck'])
        >>>
        >>> # Processed signals ready for downstream use
        >>> memo_ma_processed = integrated['memo_ma']
        >>> memo_ck_processed = integrated['memo_ck']
    """

    def __init__(self, config: TemporalIntegrationConfig):
        """Initialize temporal integrator with configuration.

        Args:
            config: Temporal integration configuration
        """
        self.config = config

    def process(
        self,
        memo_ma: np.ndarray,
        memo_ck: np.ndarray,
        return_intermediate: bool = False,
    ) -> dict[str, np.ndarray]:
        """Apply temporal integration, decimation, and rounding to auditory signals.

        Args:
            memo_ma: Amplitude memory from auditory periphery (n_channels, n_frames)
            memo_ck: Temporal memory from auditory periphery (n_channels, n_frames)
            return_intermediate: If True, return intermediate stages (default: False)

        Returns:
            Dictionary with processed signals:
                - 'memo_ma': Integrated, decimated, rounded amplitude memory
                - 'memo_ck': Integrated, decimated, rounded temporal memory

            If return_intermediate=True, also includes:
                - 'integrated_ma': After temporal integration (before decimation)
                - 'integrated_ck': After temporal integration (before decimation)
                - 'decimated_ma': After decimation (before rounding)
                - 'decimated_ck': After decimation (before rounding)

        Example:
            import numpy as np
            integrator = TemporalIntegrator(TemporalIntegrationConfig.default())
            memo_ma = np.random.rand(65, 16000)
            memo_ck = np.random.rand(65, 16000)
            result = integrator.process(memo_ma, memo_ck)
            # result['memo_ma'].shape == (65, 160)  # decimated by 100
        """
        cfg = self.config

        integrated_ma = integrate_temporal(memo_ma, tau=cfg.tau)
        integrated_ck = integrate_temporal(memo_ck, tau=cfg.tau)

        decimated_ma = integrated_ma[:, :: cfg.decimation_factor]
        decimated_ck = integrated_ck[:, :: cfg.decimation_factor]

        rounded_ma = np.round(decimated_ma, cfg.rounding_decimals)
        rounded_ck = np.round(decimated_ck, cfg.rounding_decimals)

        # Presence mask from memo_ma — global then per-channel
        max_val = np.max(rounded_ma)
        if max_val > 0:
            mask = rounded_ma >= 0.25 * max_val
        else:
            mask = rounded_ma > 0
        ch_max = np.max(rounded_ma * mask, axis=1, keepdims=True)
        mask = mask & (rounded_ma >= 0.25 * ch_max)

        rounded_ma = np.where(mask, rounded_ma, -1.0)
        rounded_ck = np.where(mask, rounded_ck, -1.0)

        output = {
            "memo_ma": rounded_ma,
            "memo_ck": rounded_ck,
        }

        if return_intermediate:
            output.update(
                {
                    "integrated_ma": integrated_ma,
                    "integrated_ck": integrated_ck,
                    "decimated_ma": decimated_ma,
                    "decimated_ck": decimated_ck,
                }
            )

        return output
