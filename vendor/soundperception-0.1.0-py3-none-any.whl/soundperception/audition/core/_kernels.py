"""Numba-optimized kernels for auditory periphery processing.

These functions provide speedups for Stage 4-5 processing:
- extract_peaks_numba: ~23x faster (Stage 4)
- extract_clock_counter_numba: ~200x faster (Stage 5a)
- extract_memo_ck_numba: ~180x faster (Stage 5c)

If Numba is not installed, the functions are replaced with pure NumPy fallbacks.
"""

import numpy as np

try:
    from numba import jit, prange

    NUMBA_AVAILABLE = True
except ImportError:
    NUMBA_AVAILABLE = False

    def jit(*args, **kwargs):  # noqa: ARG001
        def decorator(func):
            return func

        return decorator

    def prange(n):
        return range(n)


@jit(nopython=True, cache=True, parallel=True, fastmath=True)
def extract_peaks_numba(
    signal: np.ndarray,
    window_size: int,
    min_peak_value: float,
    log_transform: bool,
) -> np.ndarray:
    """Extract local peaks from signal (Stage 4 - IHC approximation).

    Numba-optimized version with parallel processing and optional log transform.

    For each channel and sample, checks if the value is:
    1. Above min_peak_value threshold
    2. A local maximum within the window

    Args:
        signal: Input signal, shape (num_filters, n_samples)
        window_size: Size of the sliding window for local max detection
        min_peak_value: Minimum value to consider as a peak
        log_transform: If True, apply 10*log10 transform to peaks

    Returns:
        Peak-extracted signal, shape (num_filters, n_samples)
    """
    n_rows, n_cols = signal.shape
    half = window_size // 2
    peaks = np.zeros((n_rows, n_cols), dtype=np.float64)

    for j in prange(n_rows):
        for i in range(half, n_cols - half):
            val = signal[j, i]
            if val <= min_peak_value:
                continue

            is_max = True
            for k in range(-half, half + 1):
                if signal[j, i + k] > val:
                    is_max = False
                    break

            if is_max:
                if log_transform:
                    peaks[j, i] = round(10.0 * np.log10(val))
                else:
                    peaks[j, i] = val

    return peaks


@jit(nopython=True, cache=True, parallel=True)
def extract_clock_counter_numba(
    peaks: np.ndarray,
    limits: np.ndarray,
) -> np.ndarray:
    """Extract clock counter from peaks (Stage 5a).

    Numba-optimized version with parallel processing across channels.

    For each channel j and sample i:
    - If peaks[j,i] > 0, set cpt_ck[j,i] = 1
    - Otherwise, if cpt_ck[j,i-1] > 0 and cpt_ck[j,i-1] < limit[j],
      set cpt_ck[j,i] = cpt_ck[j,i-1] + 1

    Args:
        peaks: Peak-extracted signal, shape (num_filters, n_samples)
        limits: Per-channel limits, shape (num_filters,)

    Returns:
        Clock counter array, shape (num_filters, n_samples)
    """
    n_rows, n_cols = peaks.shape
    cpt_ck = np.zeros((n_rows, n_cols), dtype=np.float64)

    for j in prange(n_rows):
        limit_j = limits[j]
        for i in range(n_cols):
            if peaks[j, i] > 0:
                cpt_ck[j, i] = 1.0
            elif i > 0 and cpt_ck[j, i - 1] > 0 and cpt_ck[j, i - 1] < limit_j:
                cpt_ck[j, i] = cpt_ck[j, i - 1] + 1.0

    return cpt_ck


@jit(nopython=True, cache=True, parallel=True)
def extract_memo_ck_numba(
    peaks: np.ndarray,
    cpt_ck: np.ndarray,
) -> np.ndarray:
    """Extract temporal memory (Stage 5c).

    Numba-optimized version with parallel processing across channels.

    For each channel j and sample i:
    - If peaks[j,i] > 0 and cpt_ck[j,i-1] > 0:
      memo_ck[j,i] = 10 * log(cpt_ck[j,i-1])
    - Otherwise if cpt_ck[j,i] > 0:
      memo_ck[j,i] = memo_ck[j,i-1]

    Args:
        peaks: Peak-extracted signal, shape (num_filters, n_samples)
        cpt_ck: Clock counter array, shape (num_filters, n_samples)

    Returns:
        Temporal memory array, shape (num_filters, n_samples)
    """
    n_rows, n_cols = cpt_ck.shape
    memo_ck = np.zeros((n_rows, n_cols), dtype=np.float64)

    for j in prange(n_rows):
        for i in range(1, n_cols):
            if peaks[j, i] > 0 and cpt_ck[j, i - 1] > 0:
                memo_ck[j, i] = int(10.0 * np.log(cpt_ck[j, i - 1]))
            elif cpt_ck[j, i] > 0:
                memo_ck[j, i] = memo_ck[j, i - 1]

    return memo_ck


def extract_peaks_numpy(
    signal: np.ndarray,
    window_size: int,
    min_peak_value: float,
    log_transform: bool,
) -> np.ndarray:
    """NumPy fallback for peak extraction."""
    from soundperception.utils.peak_detection import find_peaks

    peak_coords = find_peaks(signal, size=(1, window_size), min_value=min_peak_value)
    peaks = np.zeros_like(signal)
    if len(peak_coords) > 0:
        rows, cols = peak_coords[:, 0], peak_coords[:, 1]
        peaks[rows, cols] = signal[rows, cols]

    if log_transform:
        peaks = np.where(peaks > min_peak_value, np.round(10 * np.log10(peaks), 0), 0)

    return peaks


def extract_clock_counter_numpy(
    peaks: np.ndarray,
    limits: np.ndarray,
) -> np.ndarray:
    """NumPy fallback for clock counter extraction."""
    n_rows, n_cols = peaks.shape
    cpt_ck = np.zeros_like(peaks, dtype=float)

    for j in range(n_rows):
        limit_j = limits[j]
        for i in range(n_cols):
            if peaks[j, i] > 0:
                cpt_ck[j, i] = 1
            elif i > 0 and cpt_ck[j, i - 1] > 0 and cpt_ck[j, i - 1] < limit_j:
                cpt_ck[j, i] = cpt_ck[j, i - 1] + 1

    return cpt_ck


def extract_memo_ck_numpy(
    peaks: np.ndarray,
    cpt_ck: np.ndarray,
) -> np.ndarray:
    """NumPy fallback for temporal memory extraction."""
    memo_ck = np.zeros(cpt_ck.shape)
    for j in range(cpt_ck.shape[0]):
        for i in range(1, cpt_ck.shape[1]):
            if (peaks[j][i] > 0) and (cpt_ck[j][i - 1] > 0):
                memo_ck[j][i] = int(10 * np.log(cpt_ck[j][i - 1]))
            elif cpt_ck[j][i] > 0:
                memo_ck[j][i] = memo_ck[j][i - 1]
    return memo_ck
