"""Core auditory processing algorithms.

This module contains the main processing pipeline:
- AuditoryPeriphery: Stages 1-5 (cochlear filtering, neural encoding)
- TemporalIntegrator: Stage 5.5 (integration and decimation)
- F0Detector: Stage 6 (fundamental frequency detection)
- FrequencyInvarianceExtractor: Stage 7 (harmonic invariance extraction)
"""

from soundperception.audition.core.f0_detection import F0Detector
from soundperception.audition.core.frequency_invariance import FrequencyInvarianceExtractor
from soundperception.audition.core.integration import TemporalIntegrator, integrate_temporal
from soundperception.audition.core.periphery import AuditoryPeriphery

__all__ = [
    "AuditoryPeriphery",
    "TemporalIntegrator",
    "F0Detector",
    "FrequencyInvarianceExtractor",
    "integrate_temporal",
]
