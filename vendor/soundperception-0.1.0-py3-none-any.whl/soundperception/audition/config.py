"""Configuration for auditory periphery model.

This module provides configuration dataclasses for the auditory periphery stages,
inspired by Osses et al. (2022) comparison of auditory models.
"""

from dataclasses import dataclass, field
from pathlib import Path

_PACKAGE_DIR = Path(__file__).parent
DEFAULT_COMPENSATION_FILE = str(_PACKAGE_DIR / "calibration" / "gammatone_filters_compensation.csv")
DEFAULT_CALIBRATION_TABLE = str(_PACKAGE_DIR / "calibration" / "table_frq_can.csv")


@dataclass
class MiddleEarConfig:
    """Configuration for middle ear filtering stage.

    Bandpass filter configuration. Present in 6/8 models from Osses et al. (2022).

    Attributes:
        enabled: Whether to apply middle ear filtering
        filter_type: Type of filter ('butterworth', 'custom', 'none')
        lowcut: Lower cutoff frequency in Hz
        highcut: Upper cutoff frequency in Hz
        order: Filter order for butterworth filters

    Example:
        cfg = MiddleEarConfig(enabled=True, lowcut=500.0, highcut=6000.0)
        # Disable middle ear filtering
        cfg_off = MiddleEarConfig(enabled=False)
    """

    enabled: bool = False
    filter_type: str = "butterworth"
    lowcut: float = 500.0
    highcut: float = 6000.0
    order: int = 4


@dataclass
class CochlearFilterConfig:
    """Configuration for cochlear filtering stage (Stage 3 in Osses et al.).

    Gammatone filterbank configuration.

    Attributes:
        num_filters: Number of frequency channels (31-401 in paper)
        f_min: Minimum center frequency in Hz
        f_max: Maximum center frequency in Hz
        sample_rate: Sampling rate in Hz

    References:
        - Osses et al. (2022), Table II: dau1997 uses 31 channels

    Example:
        cfg = CochlearFilterConfig(num_filters=65, f_min=40.0, f_max=6500.0)
        # Use fewer channels for faster processing
        cfg_fast = CochlearFilterConfig(num_filters=31, sample_rate=16000)
    """

    num_filters: int = 65
    f_min: float = 40.0
    f_max: float = 6500.0
    sample_rate: int = 16000


@dataclass
class DelayCompensationConfig:
    """Configuration for group delay compensation.

    Compensates for differential group delay across frequency channels
    introduced by the Gammatone filterbank.

    Attributes:
        enabled: Whether to apply delay compensation
        compensation_file: Path to CSV file with delay values per channel
        threshold_db: Threshold in dB below max to suppress weak components
        apply_threshold: Whether to apply amplitude thresholding

    References:
        - Osses et al. (2022), p.3: "osses2021 includes [...] a fixed
          group-delay compensation"

    Example:
        cfg = DelayCompensationConfig(enabled=True, threshold_db=60.0)
        # Disable amplitude thresholding
        cfg_no_thresh = DelayCompensationConfig(apply_threshold=False)
    """

    enabled: bool = True
    compensation_file: str = DEFAULT_COMPENSATION_FILE
    threshold_db: float = 60.0
    apply_threshold: bool = True


@dataclass
class PeakExtractionConfig:
    """Configuration for peak extraction (IHC stage approximation).

    Extracts local maxima from filtered signal. Approximation of Inner Hair Cell processing.

    Attributes:
        window_size: Size of sliding window for local maxima detection
        log_transform: Whether to apply 10*log10 transformation
        min_peak_value: Minimum value to consider as a peak (linear scale)

    Note:
        Other models in Osses et al. (2022) use different approaches:
        - Half-wave rectification + lowpass filter (dau1997, osses2021)
        - Nonlinear transformation + LP cascade (zilany2014, bruce2018)

    Example:
        cfg = PeakExtractionConfig(window_size=5, log_transform=True)
        # Larger window for coarser peak detection
        cfg_wide = PeakExtractionConfig(window_size=11, min_peak_value=2.0)
    """

    window_size: int = 5
    log_transform: bool = True
    min_peak_value: float = 1.0


@dataclass
class AuditoryNerveConfig:
    """Configuration for auditory nerve (AN) discrete temporal encoding (Stage 5).

    Discrete memory mechanisms that capture spike timing and amplitude:
    - Inter-spike intervals (clock counter)
    - Last spike amplitude (memo MA)
    - Temporal memory (memo CK)

    Attributes:
        enabled: Whether to apply auditory nerve encoding
        lim_coef: Limit coefficient for clock counter (default: 1.5)
                 The limit per channel is: lim_coef * calibrage[channel]
                 where calibrage is the period in samples for each channel
        calibration_table_path: Path to the calibration table CSV file
                               containing 'Canal' and 'calibrage' columns

    Example:
        cfg = AuditoryNerveConfig(enabled=True, lim_coef=1.5)
        # Increase limit coefficient for wider temporal window
        cfg_wide = AuditoryNerveConfig(lim_coef=2.0)
    """

    enabled: bool = True
    lim_coef: float = 1.5
    calibration_table_path: str = DEFAULT_CALIBRATION_TABLE


@dataclass
class TemporalIntegrationConfig:
    """Configuration for temporal integration and decimation (Stage 5.5).

    Controls signal preprocessing between auditory periphery (Stage 5) and
    downstream analysis stages.

    Attributes:
        tau: Time constant for temporal integration
        decimation_factor: Temporal downsampling factor
        rounding_decimals: Number of decimal places for rounding
    Example:
        cfg = TemporalIntegrationConfig(tau=50, decimation_factor=100)
        # Higher temporal resolution with less decimation
        cfg_fine = TemporalIntegrationConfig(tau=25, decimation_factor=50)
    """

    tau: int = 50
    decimation_factor: int = 100
    rounding_decimals: int = 1

    @classmethod
    def default(cls) -> "TemporalIntegrationConfig":
        """Create default configuration."""
        return cls(tau=50, decimation_factor=100, rounding_decimals=1)


@dataclass
class F0DetectionConfig:
    """Configuration for fundamental frequency (F0) detection (Stage 6).

    Controls F0 detection algorithm:
    1. Adaptive peak extraction (spatial filtering)
    2. Cumulative persistence tracking
    3. Harmonic group segmentation
    4. Temporal continuity filtering

    Attributes:
        num_low_channels: Number of low-frequency channels to analyze (default: 20).
        peak_window_size: Window size for spatial peak detection (default: 7 channels).
        peak_amp_threshold: Minimum amplitude for peak detection (default: 10.0).
        peak_ck_threshold: Maximum memo_ck for peak detection (default: 220.0).
        persistence_window_half_size: Half-size of vertical window for persistence
            tracking (default: 3 channels). Allows ±3 channel drift.
        continuity_mode: Temporal continuity mode (default: "limited").
            - "limited": Groups 1-2 only
            - "all_groups": All groups tracked
        boundary_filter_frames: Number of frames to filter at start/end (default: 0).
            Set to 0 to disable.
        sample_rate: Sample rate in Hz (default: 16000).

    Example:
        >>> config = F0DetectionConfig.default()
    """

    num_low_channels: int = 20
    peak_window_size: int = 7
    peak_amp_threshold: float = 10.0
    peak_ck_threshold: float = 220.0
    persistence_window_half_size: int = 3
    continuity_mode: str = "limited"
    boundary_filter_frames: int = 0
    sample_rate: int = 16000

    @classmethod
    def default(cls) -> "F0DetectionConfig":
        """Create default configuration."""
        return cls(
            num_low_channels=20,
            peak_window_size=7,
            peak_amp_threshold=10.0,
            peak_ck_threshold=220.0,
            persistence_window_half_size=3,
            continuity_mode="limited",
            boundary_filter_frames=0,
            sample_rate=16000,
        )


@dataclass
class FrequencyInvarianceConfig:
    """Configuration for frequency invariance extraction (Stage 7).

    Extracts frequency-invariant representations by analyzing harmonic relationships.
    Captures spectral envelope information independent of fundamental frequency.

    Attributes:
        nb_harmonics: Number of harmonics to analyze (default: 30).
        min_invariance: Minimum invariance value for clipping (default: -30).
        num_channels: Number of frequency channels (default: 65).
            Must match the auditory periphery configuration.
        calibration_table_path: Path to frequency calibration CSV file.

    Example:
        >>> config = FrequencyInvarianceConfig.default()
    """

    nb_harmonics: int = 30
    min_invariance: int = -30
    num_channels: int = 65
    calibration_table_path: str = DEFAULT_CALIBRATION_TABLE

    @classmethod
    def default(cls) -> "FrequencyInvarianceConfig":
        """Create default configuration."""
        return cls(
            nb_harmonics=30,
            min_invariance=-30,
            num_channels=65,
            calibration_table_path=DEFAULT_CALIBRATION_TABLE,
        )


@dataclass
class AuditoryPeripheryConfig:
    """Configuration for auditory periphery model.

    Combines all stages from acoustic input to auditory nerve encoding:
    - Stage 1: Outer ear (not implemented)
    - Stage 2: Middle ear (optional)
    - Stage 3: Cochlear filtering
    - Stage 4: Inner hair cell (peak extraction -> neural spikes)
    - Stage 5: Auditory nerve (AN) discrete temporal encoding

    Attributes:
        middle_ear: Middle ear configuration
        cochlear: Cochlear filtering configuration
        delay_compensation: Delay compensation configuration
        peak_extraction: Peak extraction configuration
        auditory_nerve: Auditory nerve encoding configuration

    Example:
        # Use default configuration
        cfg = AuditoryPeripheryConfig.default()
        # Customize cochlear filtering
        cfg = AuditoryPeripheryConfig(
            cochlear=CochlearFilterConfig(num_filters=31, f_min=80.0),
            auditory_nerve=AuditoryNerveConfig(enabled=True),
        )
    """

    middle_ear: MiddleEarConfig = field(default_factory=MiddleEarConfig)
    cochlear: CochlearFilterConfig = field(default_factory=CochlearFilterConfig)
    delay_compensation: DelayCompensationConfig = field(default_factory=DelayCompensationConfig)
    peak_extraction: PeakExtractionConfig = field(default_factory=PeakExtractionConfig)
    auditory_nerve: AuditoryNerveConfig = field(default_factory=AuditoryNerveConfig)

    @classmethod
    def default(cls) -> "AuditoryPeripheryConfig":
        """Create default configuration.

        Returns:
            Configuration with:
            - Gammatone filtering: 65 channels, 40-6500 Hz, 16 kHz sample rate
            - Peak extraction: window_size=5, min_peak_value=1, log_transform=True
            - Delay compensation: threshold_db=60
            - Auditory nerve: enabled, lim_coef=1.5
        """
        return cls(
            middle_ear=MiddleEarConfig(enabled=False),
            cochlear=CochlearFilterConfig(
                num_filters=65, f_min=40.0, f_max=6500.0, sample_rate=16000
            ),
            delay_compensation=DelayCompensationConfig(
                enabled=True,
                compensation_file=DEFAULT_COMPENSATION_FILE,
                threshold_db=60.0,
                apply_threshold=True,
            ),
            peak_extraction=PeakExtractionConfig(
                window_size=5, log_transform=True, min_peak_value=1.0
            ),
            auditory_nerve=AuditoryNerveConfig(
                enabled=True,
                lim_coef=1.5,
                calibration_table_path=DEFAULT_CALIBRATION_TABLE,
            ),
        )
