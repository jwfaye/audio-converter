"""Audio I/O operations using soundfile with libsndfile backend."""

from pathlib import Path

import numpy as np
import soundfile as sf
from scipy import signal as scipy_signal


def load_audio(
    file_path: str | Path,
    target_sample_rate: int | None = None,
    mono: bool = True,
    normalize: bool = False,
) -> tuple[np.ndarray, int]:
    """Load audio file with optional resampling and mono conversion.

    Args:
        file_path: Path to audio file (str or Path)
        target_sample_rate: Target sample rate (Hz). If None, use original.
        mono: If True, convert to mono by averaging channels.
        normalize: If True, keep float32 [-1, 1]. If False, convert to int16.

    Returns:
        tuple: (audio_data, sample_rate)
            - audio_data: numpy array of shape (n_samples,)
              - If normalize=False: int16 values
              - If normalize=True: float32 values in range [-1, 1]
            - sample_rate: Sample rate in Hz

    Example:
        >>> audio, sr = load_audio('file.wav', target_sample_rate=16000)
        >>> audio, sr = load_audio('file.wav', target_sample_rate=16000, normalize=True)

    Notes:
        - Supports WAV, FLAC, OGG, AIFF formats natively
        - Default behavior (normalize=False) returns int16 values
        - Resampling via scipy.signal.resample
    """
    audio_data, original_sr = sf.read(str(file_path), always_2d=False)

    if mono and audio_data.ndim > 1:
        audio_data = np.mean(audio_data, axis=1)

    if target_sample_rate is not None and original_sr != target_sample_rate:
        audio_data = resample_audio(audio_data, original_sr, target_sample_rate)
        sample_rate = target_sample_rate
    else:
        sample_rate = original_sr

    if not normalize:
        audio_data = (audio_data * 32767).astype(np.int16)

    return audio_data, sample_rate


def resample_audio(
    audio_data: np.ndarray,
    original_sr: int,
    target_sr: int,
) -> np.ndarray:
    """Resample audio to target sample rate.

    Args:
        audio_data: numpy array of audio samples (float32 in range [-1, 1])
        original_sr: Original sample rate (Hz)
        target_sr: Target sample rate (Hz)

    Returns:
        numpy array: Resampled audio (float32 in range [-1, 1])

    Example:
        import numpy as np
        audio = np.random.randn(44100).astype(np.float32)  # 1s at 44.1 kHz
        resampled = resample_audio(audio, original_sr=44100, target_sr=16000)
        # resampled has ~16000 samples

    Notes:
        - Uses scipy.signal.resample
    """
    if original_sr == target_sr:
        return audio_data

    num_samples = int(len(audio_data) * target_sr / original_sr)

    resampled = scipy_signal.resample(audio_data, num_samples)

    return resampled


def save_audio(
    file_path: str | Path,
    audio_data: np.ndarray,
    sample_rate: int,
    subtype: str = "PCM_16",
) -> None:
    """Save audio to file.

    Args:
        file_path: Output file path (str or Path)
        audio_data: numpy array of audio samples
            - Can be int16, float32, or float64
            - If int16: converted to float32 [-1, 1] for saving
            - If float32/float64: must be in range [-1, 1]
        sample_rate: Sample rate in Hz
        subtype: Audio format subtype
            Options: 'PCM_16', 'PCM_24', 'PCM_32', 'FLOAT', 'DOUBLE'

    Example:
        >>> save_audio('output.wav', audio, 16000)
        >>> save_audio('output.flac', audio, 44100, subtype='PCM_24')

    Notes:
        - Handles int16 to float32 conversion
        - Normalizes if values exceed [-1, 1] range
        - Supports WAV, FLAC, OGG, AIFF formats
    """
    file_path = Path(file_path)

    if audio_data.dtype == np.int16:
        audio_data = audio_data.astype(np.float32) / 32768.0
    elif audio_data.dtype not in (np.float32, np.float64):
        audio_data = audio_data.astype(np.float32)

    max_val = np.abs(audio_data).max()
    if max_val > 1.0:
        audio_data = audio_data / max_val

    sf.write(str(file_path), audio_data, sample_rate, subtype=subtype)


def get_audio_info(file_path: str | Path) -> dict:
    """Get audio file metadata without loading audio data.

    Args:
        file_path: Path to audio file (str or Path)

    Returns:
        dict: Audio file information
            - 'sample_rate': Sample rate in Hz
            - 'channels': Number of channels
            - 'duration': Duration in seconds
            - 'frames': Total number of frames
            - 'format': File format
            - 'subtype': Audio subtype

    Example:
        >>> info = get_audio_info('file.wav')
        >>> print(f"Duration: {info['duration']:.2f}s, SR: {info['sample_rate']} Hz")
    """
    info = sf.info(str(file_path))

    return {
        "sample_rate": info.samplerate,
        "channels": info.channels,
        "duration": info.duration,
        "frames": info.frames,
        "format": info.format,
        "subtype": info.subtype,
    }
