"""Stability analysis via joint std histograms and structural decomposition.

Two parallel paths from GlobalExtractor + StructuralExtractor outputs:

Path 1 (Stable zone):
    Joint histogram std_ma × std_ck → auto_grid → identify stable zone
    (category containing the origin = low variation on both modalities).

Path 2 (Unstable zone):
    On non-stable pixels, structural MA (quantized by ma_bin_width°) × VA
    → auto_grid → structural categories.

Outputs per-pixel labels combining both paths.
"""

from dataclasses import dataclass

import numpy as np

from soundperception.histograms.grid_utils import auto_grid_categorize_histogram
from soundperception.histograms.histogram_builder import multilinear_histogram
from soundperception.module import InputSpec, OutputSpec, TensorShape, module

__all__ = ["StabilityAnalyzerConfig", "StabilityAnalyzer"]

SENTINEL = -1


@dataclass
class StabilityAnalyzerConfig:
    """Configuration for stability analysis.

    Attributes:
        ma_bin_width: Quantization step for MA in degrees (default: 15).
    """

    ma_bin_width: float = 15.0

    @classmethod
    def default(cls) -> "StabilityAnalyzerConfig":
        """Return default configuration."""
        return cls()


@module(
    inputs={
        "std_ma": InputSpec(
            name="std_ma",
            dtype=np.ndarray,
            description="Global std of MA signal (n_channels × n_frames)",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
        "std_ck": InputSpec(
            name="std_ck",
            dtype=np.ndarray,
            description="Global std of CK signal (n_channels × n_frames)",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
        "struct_ma": InputSpec(
            name="struct_ma",
            dtype=np.ndarray,
            description="Structural MA values (0-179, -1 = inactive)",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
        "struct_va": InputSpec(
            name="struct_va",
            dtype=np.ndarray,
            description="Structural VA values (-1 = inactive)",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
        "mask": InputSpec(
            name="mask",
            dtype=np.ndarray,
            description="Boolean mask of active pixels",
            shape=TensorShape(("n_channels", "n_frames")),
            required=False,
            default=None,
        ),
    },
    outputs={
        "stable_mask": OutputSpec(
            name="stable_mask",
            dtype=np.ndarray,
            description="Boolean mask: True = stable pixel",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
        "stability_labels": OutputSpec(
            name="stability_labels",
            dtype=np.ndarray,
            description="Stability grid labels on std_ma × std_ck histogram",
        ),
        "stability_histogram": OutputSpec(
            name="stability_histogram",
            dtype=np.ndarray,
            description="Joint histogram std_ma × std_ck",
        ),
        "stable_category": OutputSpec(
            name="stable_category",
            dtype=int,
            description="Category number of the stable zone (contains origin)",
        ),
        "unstable_labels": OutputSpec(
            name="unstable_labels",
            dtype=np.ndarray,
            description="Structural grid labels on MA(quantized) × VA histogram",
        ),
        "unstable_histogram": OutputSpec(
            name="unstable_histogram",
            dtype=np.ndarray,
            description="Joint histogram MA(quantized) × VA in unstable zone",
        ),
        "pixel_labels": OutputSpec(
            name="pixel_labels",
            dtype=np.ndarray,
            description="Per-pixel labels: 0=inactive, 1=stable, 2+=unstable structural categories",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
    },
    method="process",
    description="Stability analysis: stable/unstable zone detection with structural decomposition.",
)
class StabilityAnalyzer:
    """Detect stable and unstable zones, categorize unstable via structural features.

    Example:
        >>> analyzer = StabilityAnalyzer(StabilityAnalyzerConfig.default())
        >>> result = analyzer.process(std_ma, std_ck, struct_ma, struct_va)
        >>> stable = result["stable_mask"]
        >>> labels = result["pixel_labels"]
    """

    def __init__(self, config: StabilityAnalyzerConfig):
        """Initialize with stability analysis configuration."""
        self.config = config

    def process(
        self,
        std_ma: np.ndarray,
        std_ck: np.ndarray,
        struct_ma: np.ndarray,
        struct_va: np.ndarray,
        mask: np.ndarray | None = None,
    ) -> dict[str, object]:
        """Run stability analysis.

        Args:
            std_ma: Global std of MA modality.
            std_ck: Global std of CK modality.
            struct_ma: Structural MA (0-179°, -1 = inactive).
            struct_va: Structural VA (-1 = inactive).
            mask: Optional mask of active pixels.

        Returns:
            Dictionary with stable_mask, stability_labels, stability_histogram,
            stable_category, unstable_labels, unstable_histogram, pixel_labels.
        """
        if mask is None:
            mask = np.ones(std_ma.shape, dtype=bool)

        # --- Path 1: Stability detection ---
        stability_result = self._detect_stability(std_ma, std_ck, mask)

        # --- Path 2: Unstable zone structural analysis ---
        unstable_mask = mask & ~stability_result["stable_mask"]
        unstable_result = self._analyze_unstable(
            struct_ma,
            struct_va,
            unstable_mask,
        )

        # --- Combine into per-pixel labels ---
        pixel_labels = np.zeros(std_ma.shape, dtype=np.int32)
        pixel_labels[stability_result["stable_mask"]] = 1

        # Unstable structural categories start at 2
        if unstable_result["unstable_labels"].size > 0:
            pixel_labels = self._project_unstable_labels(
                pixel_labels,
                struct_ma,
                struct_va,
                unstable_mask,
                unstable_result,
            )

        return {
            "stable_mask": stability_result["stable_mask"],
            "stability_labels": stability_result["labels"],
            "stability_histogram": stability_result["histogram"],
            "stable_category": stability_result["stable_category"],
            "unstable_labels": unstable_result["unstable_labels"],
            "unstable_histogram": unstable_result["histogram"],
            "pixel_labels": pixel_labels,
        }

    def _detect_stability(
        self,
        std_ma: np.ndarray,
        std_ck: np.ndarray,
        mask: np.ndarray,
    ) -> dict[str, object]:
        """Build std_ma × std_ck histogram, auto_grid, find stable zone."""
        std_ma_int = np.round(std_ma).astype(np.int32)
        std_ck_int = np.round(std_ck).astype(np.int32)

        max_std_ma = int(std_ma_int[mask].max()) + 1 if mask.any() else 1
        max_std_ck = int(std_ck_int[mask].max()) + 1 if mask.any() else 1

        bins_ma = np.arange(max_std_ma + 1, dtype=np.float64)
        bins_ck = np.arange(max_std_ck + 1, dtype=np.float64)

        histogram = multilinear_histogram(
            [std_ma_int, std_ck_int],
            bins=[bins_ma, bins_ck],
            mask=mask,
        )

        labels = auto_grid_categorize_histogram(histogram)

        # Stable zone = category at origin (0, 0)
        stable_cat = int(labels[0, 0])

        # Build per-pixel stable mask by back-projecting
        stable_mask = np.zeros(std_ma.shape, dtype=bool)
        if stable_cat > 0:
            # Find which (std_ma, std_ck) bins belong to stable category
            stable_bins = np.argwhere(labels == stable_cat)
            for bin_ma, bin_ck in stable_bins:
                pixel_match = mask & (std_ma_int == bin_ma) & (std_ck_int == bin_ck)
                stable_mask |= pixel_match

        return {
            "stable_mask": stable_mask,
            "labels": labels,
            "histogram": histogram,
            "stable_category": stable_cat,
        }

    def _analyze_unstable(
        self,
        struct_ma: np.ndarray,
        struct_va: np.ndarray,
        unstable_mask: np.ndarray,
    ) -> dict[str, object]:
        """Build MA(quantized) × VA histogram on unstable zone, auto_grid."""
        # Filter sentinels
        active = unstable_mask & (struct_ma >= 0) & (struct_va >= 0)

        if not active.any():
            return {
                "unstable_labels": np.array([], dtype=np.int32),
                "histogram": np.array([[]], dtype=np.float64),
            }

        # Quantize MA by bin width
        bin_width = self.config.ma_bin_width
        ma_quantized = np.floor(struct_ma / bin_width).astype(np.int32)
        n_ma_bins = int(180 / bin_width)
        va_int = np.round(struct_va).astype(np.int32)
        max_va = int(va_int[active].max()) + 1

        bins_ma = np.arange(n_ma_bins + 1, dtype=np.float64)
        bins_va = np.arange(max_va + 1, dtype=np.float64)

        histogram = multilinear_histogram(
            [ma_quantized, va_int],
            bins=[bins_ma, bins_va],
            mask=active,
        )

        labels = auto_grid_categorize_histogram(histogram)

        return {
            "unstable_labels": labels,
            "histogram": histogram,
        }

    def _project_unstable_labels(
        self,
        pixel_labels: np.ndarray,
        struct_ma: np.ndarray,
        struct_va: np.ndarray,
        unstable_mask: np.ndarray,
        unstable_result: dict[str, object],
    ) -> np.ndarray:
        """Back-project unstable histogram labels to pixel space."""
        labels_grid = unstable_result["unstable_labels"]
        if labels_grid.size == 0:
            return pixel_labels

        bin_width = self.config.ma_bin_width
        active = unstable_mask & (struct_ma >= 0) & (struct_va >= 0)

        ma_quantized = np.floor(struct_ma / bin_width).astype(np.int32)
        va_int = np.round(struct_va).astype(np.int32)

        n_ma_bins, n_va_bins = labels_grid.shape

        coords = np.argwhere(active)
        for r, c in coords:
            ma_bin = min(ma_quantized[r, c], n_ma_bins - 1)
            va_bin = min(va_int[r, c], n_va_bins - 1)
            cat = labels_grid[ma_bin, va_bin]
            if cat > 0:
                pixel_labels[r, c] = cat + 1

        return pixel_labels
