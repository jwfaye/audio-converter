"""Histogram computation modules for auditory signal analysis.

This subpackage provides 2D histogram representations of auditory signals:

Histogram Builders:
    - build_joint_histogram: Build 2D histogram from mean/std with scale factors
    - multilinear_histogram: Build N-D histogram from N images

Feature Extractors:
    - StructuralExtractor: Sobel gradient -> Angular Mean (MA) and Angular Variation (VA)

Histogram Computers:
    - BilinearHistogramComputer: Mean x Variation histogram (temporal dynamics)
    - SpectralHistogramComputer: Channel x Amplitude histogram (spectral distribution)

Categorization:
    - Categorizer: Discretize continuous values into N bins

Grid Utilities:
    - find_marginal_thresholds: peak/valley detection on 1D marginal histograms
    - auto_grid_categorize_histogram: automatic grid from marginal thresholds
    - grid_categorize_histogram: fixed grid with custom thresholds
    - find_categories_in_histogram: peak detection with region growing

These histograms serve as input to the dynamic attractor for pattern recognition.

Note: GlobalExtractor moved to soundperception.core.global_extractor
"""

from soundperception.histograms.bilinear_histogram import (
    BilinearHistogramComputer,
    BilinearHistogramConfig,
)
from soundperception.histograms.categorizer import (
    Categorizer,
    CategorizerConfig,
)
from soundperception.histograms.grid_utils import (
    auto_grid_categorize_histogram,
    find_categories_in_histogram,
    find_marginal_thresholds,
    grid_categorize_histogram,
)
from soundperception.histograms.histogram_builder import (
    build_joint_histogram,
    multilinear_histogram,
)
from soundperception.histograms.spectral_histogram import (
    SpectralHistogramComputer,
    SpectralHistogramConfig,
)
from soundperception.histograms.stability_analyzer import (
    StabilityAnalyzer,
    StabilityAnalyzerConfig,
)
from soundperception.histograms.structural_extractor import (
    StructuralExtractor,
    StructuralExtractorConfig,
)

__all__ = [
    "build_joint_histogram",
    "multilinear_histogram",
    "StructuralExtractor",
    "StructuralExtractorConfig",
    "BilinearHistogramComputer",
    "BilinearHistogramConfig",
    "SpectralHistogramComputer",
    "SpectralHistogramConfig",
    "Categorizer",
    "CategorizerConfig",
    "auto_grid_categorize_histogram",
    "find_categories_in_histogram",
    "find_marginal_thresholds",
    "grid_categorize_histogram",
    "StabilityAnalyzer",
    "StabilityAnalyzerConfig",
]
