"""Simple value categorization using fixed bins.

Discretizes continuous values into N categories based on percentile-normalized bins.
"""

from dataclasses import dataclass

import numpy as np

from soundperception.module import InputSpec, OutputSpec, TensorShape, module

__all__ = ["CategorizerConfig", "Categorizer"]


BACKGROUND_CATEGORY = 0


@dataclass
class CategorizerConfig:
    """Configuration for value categorization.

    Attributes:
        n_bins: Number of categories (default: 3).
        percentile_min: Lower percentile for normalization (default: 1.0).
        percentile_max: Upper percentile for normalization (default: 99.0).
        exclude_zeros: If True, zero values get category 0 (background),
                       and actual categories are 1 to n_bins (default: False).

    Example:
        config = CategorizerConfig(n_bins=5, exclude_zeros=True)
    """

    n_bins: int = 3
    percentile_min: float = 1.0
    percentile_max: float = 99.0
    exclude_zeros: bool = False

    @classmethod
    def default(cls) -> "CategorizerConfig":
        """Create default configuration with 3 bins."""
        return cls(n_bins=3, percentile_min=1.0, percentile_max=99.0, exclude_zeros=False)


@module(
    inputs={
        "image": InputSpec(
            name="image",
            dtype=np.ndarray,
            description="2D array of continuous values to categorize",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
        "min_val": InputSpec(
            name="min_val",
            dtype=float,
            description="Override minimum value for normalization",
            required=False,
            default=None,
        ),
        "max_val": InputSpec(
            name="max_val",
            dtype=float,
            description="Override maximum value for normalization",
            required=False,
            default=None,
        ),
        "mask": InputSpec(
            name="mask",
            dtype=np.ndarray,
            description="Optional boolean mask (True = valid pixels)",
            required=False,
            default=None,
        ),
    },
    outputs={
        "categories": OutputSpec(
            name="categories",
            dtype=np.ndarray,
            description="2D array of category indices",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
        "min_val": OutputSpec(
            name="min_val",
            dtype=float,
            description="Minimum value used for normalization",
        ),
        "max_val": OutputSpec(
            name="max_val",
            dtype=float,
            description="Maximum value used for normalization",
        ),
    },
    method="process",
    description="Categorize continuous values into discrete bins using percentile normalization.",
)
class Categorizer:
    """Categorize continuous values into discrete bins.

    Normalizes values between percentile_min and percentile_max,
    then discretizes into n_bins categories using uniform bins.

    Example:
        >>> categorizer = Categorizer(CategorizerConfig.default())
        >>> result = categorizer.process(image)
        >>> # Or via __call__:
        >>> result = categorizer(image=image, mask=mask)
        >>> categories = result["categories"]  # Values 0, 1, 2
    """

    def __init__(self, config: CategorizerConfig):
        """Initialize categorizer with configuration.

        Args:
            config: Categorization configuration.
        """
        self.config = config
        self._bins = np.linspace(0, 1, config.n_bins + 1)[1:-1]

    def process(
        self,
        image: np.ndarray,
        min_val: float | None = None,
        max_val: float | None = None,
        mask: np.ndarray | None = None,
    ) -> dict[str, np.ndarray | float]:
        """Process image values into discrete bins.

        Args:
            image: 2D array of continuous values.
            min_val: Override minimum value for normalization (default: percentile).
            max_val: Override maximum value for normalization (default: percentile).
            mask: Optional boolean mask (True = valid pixels to categorize).
                  If provided, masked-out pixels get category 0 (background).
                  Overrides exclude_zeros behavior.

        Returns:
            Dictionary containing:
            - 'categories': 2D array of category indices
              - If mask provided or exclude_zeros=True: 0=background, 1 to n_bins
              - Otherwise: values 0 to n_bins-1
            - 'min_val': Minimum value used for normalization
            - 'max_val': Maximum value used for normalization
            - 'mask': Boolean mask used (if mask provided or exclude_zeros=True)

        Example:
            categorizer = Categorizer(CategorizerConfig(n_bins=3))
            image = np.random.rand(65, 100) * 50
            result = categorizer.process(image)
            categories = result["categories"]  # values 0, 1, 2
        """
        image_f = image.astype(np.float64)
        use_mask = mask is not None or self.config.exclude_zeros

        if mask is not None:
            mask = np.asarray(mask, dtype=bool)
        elif self.config.exclude_zeros:
            mask = image_f > 0

        if use_mask:
            valid_values = image_f[mask]
            if valid_values.size == 0:
                return {
                    "categories": np.zeros(image_f.shape, dtype=np.uint8),
                    "min_val": 0.0,
                    "max_val": 0.0,
                    "mask": mask,
                }
        else:
            valid_values = image_f.ravel()

        if min_val is None:
            min_val = float(np.percentile(valid_values, self.config.percentile_min))
        if max_val is None:
            max_val = float(np.percentile(valid_values, self.config.percentile_max))

        if max_val <= min_val + 1e-12:
            result = {
                "categories": np.zeros(image_f.shape, dtype=np.uint8),
                "min_val": min_val,
                "max_val": max_val,
            }
            if use_mask:
                result["categories"] = np.where(mask, 1, BACKGROUND_CATEGORY).astype(np.uint8)
                result["mask"] = mask
            return result

        normed = (image_f - min_val) / (max_val - min_val)

        categories = np.digitize(normed, self._bins, right=False)

        categories = np.clip(categories, 0, self.config.n_bins - 1)

        if use_mask:
            categories = categories + 1
            categories = np.where(mask, categories, BACKGROUND_CATEGORY)

        categories = categories.astype(np.uint8)

        result = {
            "categories": categories,
            "min_val": min_val,
            "max_val": max_val,
        }
        if use_mask:
            result["mask"] = mask

        return result

    def categorize_with_fixed_bounds(
        self,
        image: np.ndarray,
        min_val: float,
        max_val: float,
    ) -> np.ndarray:
        """Categorize with pre-specified bounds (for consistency across frames).

        Args:
            image: 2D array of continuous values.
            min_val: Minimum value for normalization.
            max_val: Maximum value for normalization.

        Returns:
            2D array of category indices (0 to n_bins-1).

        Example:
            categorizer = Categorizer(CategorizerConfig(n_bins=3))
            image = np.random.rand(65, 100) * 50
            # Use fixed bounds for consistent categorization across frames
            cats = categorizer.categorize_with_fixed_bounds(
                image, min_val=0.0, max_val=50.0
            )
        """
        return self.process(image, min_val=min_val, max_val=max_val)["categories"]
