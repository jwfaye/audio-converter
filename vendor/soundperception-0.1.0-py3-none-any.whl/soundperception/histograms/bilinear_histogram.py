"""Bilinear histogram computation for temporal feature analysis.

Computes temporal features from integrated amplitude memory:
- Mean of consecutive frames: (frame[i] + frame[i+1]) / 2
- Absolute variation: |frame[i+1] - frame[i]|
- 2D histogram of (mean, variation) pairs with integer bins

Represents temporal dynamics and relationship between signal amplitude and temporal change.
"""

from dataclasses import dataclass

import numpy as np
import pandas as pd

__all__ = ["BilinearHistogramConfig", "BilinearHistogramComputer"]


@dataclass
class BilinearHistogramConfig:
    """Configuration for bilinear histogram computation.

    Computes temporal features from integrated amplitude memory:
    - Mean of consecutive frames: (frame[i] + frame[i+1]) / 2
    - Absolute variation: |frame[i+1] - frame[i]|
    - 2D histogram of (mean, variation) pairs with integer bins

    Attributes:
        bin_step: Step size for histogram bins
        mean_range: (min, max) range for mean axis (None = auto from data)
        variation_range: (min, max) range for variation axis (None = auto from data)
        round_decimals: Number of decimals to round mean/variation values
                       Set to None to disable rounding
    """

    bin_step: float = 1.0
    mean_range: tuple[float, float] | None = None
    variation_range: tuple[float, float] | None = None
    round_decimals: int | None = 1

    @classmethod
    def default(cls) -> "BilinearHistogramConfig":
        """Create default configuration.

        Returns:
            Configuration with:
            - Integer bins (step=1.0)
            - Automatic range detection from data
            - Rounding to 1 decimal place
        """
        return cls(
            bin_step=1.0,
            mean_range=None,
            variation_range=None,
            round_decimals=1,
        )


class BilinearHistogramComputer:
    """Bilinear histogram computer for temporal feature analysis.

    Computes temporal features from integrated amplitude memory signals.
    Calculates mean and variation between consecutive frames, then builds
    2D histogram showing distribution of (mean, variation) pairs.

    Example:
        >>> from soundperception import AuditoryPeriphery, AuditoryPeripheryConfig
        >>> from soundperception import TemporalIntegrator, TemporalIntegrationConfig
        >>> from soundperception.histograms import (
        ...     BilinearHistogramComputer, BilinearHistogramConfig
        ... )
        >>>
        >>> # Process audio through auditory periphery
        >>> periphery_config = AuditoryPeripheryConfig.default()
        >>> periphery = AuditoryPeriphery(periphery_config)
        >>> result = periphery.process(audio_signal)
        >>>
        >>> # Apply temporal integration
        >>> integration_config = TemporalIntegrationConfig.default()
        >>> integrator = TemporalIntegrator(integration_config)
        >>> integrated = integrator.process(result['memo_ma'], result['memo_ck'])
        >>>
        >>> # Compute bilinear histogram
        >>> histogram_config = BilinearHistogramConfig.default()
        >>> computer = BilinearHistogramComputer(histogram_config)
        >>> hist_result = computer.compute(integrated['memo_ma'])
        >>>
        >>> # Access results
        >>> print(f"Histogram shape: {hist_result['histogram_2d'].shape}")
        >>> print(f"Mean range: {hist_result['mean_range']}")
        >>> print(f"Variation range: {hist_result['variation_range']}")
    """

    def __init__(self, config: BilinearHistogramConfig):
        """Initialize bilinear histogram computer with configuration.

        Args:
            config: Bilinear histogram configuration
        """
        self.config = config

    def compute(
        self, memo_ma_integrated: np.ndarray, return_intermediate: bool = False
    ) -> dict[str, np.ndarray | tuple | pd.DataFrame]:
        """Compute bilinear histogram from integrated amplitude memory.

        Algorithm:
        1. Computes mean and variation between consecutive frames
        2. Rounds values if configured (default: 1 decimal place)
        3. Builds 2D histogram with integer-centered bins [n-0.5, n+0.5)
        4. Returns histogram as array and DataFrame

        Args:
            memo_ma_integrated: Integrated amplitude memory (n_channels, n_frames)
            return_intermediate: If True, return intermediate results (default: False)

        Returns:
            Dictionary containing:
            - 'consecutive_mean': Mean of consecutive frames (n_channels, n_frames-1)
            - 'abs_variation': Absolute variation between frames (n_channels, n_frames-1)
            - 'histogram_2d': 2D histogram array (n_var_bins, n_mean_bins)
            - 'histogram_df': DataFrame with histogram (rows=variation, cols=mean)
            - 'mean_range': (min, max) of mean values
            - 'variation_range': (min, max) of variation values
            - 'mean_bins': Array of mean bin centers
            - 'var_bins': Array of variation bin centers

            If return_intermediate=True, also includes:
            - 'mean_flat': Flattened mean values
            - 'variation_flat': Flattened variation values
            - 'mean_int': Integer mean values
            - 'var_int': Integer variation values
        """
        consecutive_mean = (memo_ma_integrated[:, :-1] + memo_ma_integrated[:, 1:]) / 2
        if self.config.round_decimals is not None:
            consecutive_mean = np.round(consecutive_mean, self.config.round_decimals)

        abs_variation = np.abs(memo_ma_integrated[:, 1:] - memo_ma_integrated[:, :-1])
        if self.config.round_decimals is not None:
            abs_variation = np.round(abs_variation, self.config.round_decimals)

        mean_flat = consecutive_mean.flatten()
        var_flat = abs_variation.flatten()

        mean_min = int(np.floor(mean_flat.min()))
        mean_max = int(np.ceil(mean_flat.max()))
        var_min = int(np.floor(var_flat.min()))
        var_max = int(np.ceil(var_flat.max()))

        mean_bins_edges = np.arange(mean_min - 0.5, mean_max + 1.0, 1.0)
        var_bins_edges = np.arange(var_min - 0.5, var_max + 1.0, 1.0)

        mean_bins_centers = np.arange(mean_min, mean_max + 1, 1)
        var_bins_centers = np.arange(var_min, var_max + 1, 1)

        hist_2d, _, _ = np.histogram2d(var_flat, mean_flat, bins=[var_bins_edges, mean_bins_edges])
        hist_2d = hist_2d.astype(int)

        hist_df = pd.DataFrame(hist_2d, index=var_bins_centers, columns=mean_bins_centers)

        result = {
            "consecutive_mean": consecutive_mean,
            "abs_variation": abs_variation,
            "histogram_2d": hist_2d,
            "histogram_df": hist_df,
            "mean_range": (mean_min, mean_max),
            "variation_range": (var_min, var_max),
            "mean_bins": mean_bins_centers,
            "var_bins": var_bins_centers,
        }

        if return_intermediate:
            result["mean_flat"] = mean_flat
            result["variation_flat"] = var_flat

        return result

    def compute_single_frame_histogram(
        self,
        memo_ma_integrated: np.ndarray,
        frame_index: int,
    ) -> dict[str, np.ndarray | pd.DataFrame]:
        """Compute 2D histogram for a single frame.

        Extracts mean and variation values for a specific frame
        across all channels, then computes 2D histogram.

        Args:
            memo_ma_integrated: Integrated amplitude memory (n_channels, n_frames)
            frame_index: Index of frame to analyze (0 to n_frames-2)

        Returns:
            Dictionary containing:
            - 'mean_values': Mean values for this frame (n_channels,)
            - 'variation_values': Variation values for this frame (n_channels,)
            - 'histogram_2d': 2D histogram array
            - 'histogram_df': DataFrame with histogram
        """
        n_channels, n_frames = memo_ma_integrated.shape

        if frame_index < 0 or frame_index >= n_frames - 1:
            raise ValueError(f"Frame index {frame_index} out of range [0, {n_frames - 2}]")

        mean_values = (
            memo_ma_integrated[:, frame_index] + memo_ma_integrated[:, frame_index + 1]
        ) / 2
        variation_values = np.abs(
            memo_ma_integrated[:, frame_index + 1] - memo_ma_integrated[:, frame_index]
        )

        mean_min = int(np.floor(mean_values.min()))
        mean_max = int(np.ceil(mean_values.max()))
        var_min = int(np.floor(variation_values.min()))
        var_max = int(np.ceil(variation_values.max()))

        mean_bins_edges = np.arange(mean_min - 0.5, mean_max + 1.0, 1.0)
        var_bins_edges = np.arange(var_min - 0.5, var_max + 1.0, 1.0)

        mean_bins_centers = np.arange(mean_min, mean_max + 1, 1)
        var_bins_centers = np.arange(var_min, var_max + 1, 1)

        hist_2d, _, _ = np.histogram2d(
            variation_values, mean_values, bins=[var_bins_edges, mean_bins_edges]
        )
        hist_2d = hist_2d.astype(int)

        hist_df = pd.DataFrame(hist_2d, index=var_bins_centers, columns=mean_bins_centers)

        return {
            "mean_values": mean_values,
            "variation_values": variation_values,
            "histogram_2d": hist_2d,
            "histogram_df": hist_df,
            "mean_bins": mean_bins_centers,
            "var_bins": var_bins_centers,
        }

    def compute_cumulative_50_percent_mean(
        self,
        mean_values: np.ndarray,
        variation_values: np.ndarray,
    ) -> float:
        """Compute 50% cumulative threshold for mean values, excluding (0,0) pairs.

        Builds a 2D histogram (mean x variation), then:
        1. Excludes channels where (mean=0 AND variation=0)
        2. Sums along the variation axis to get 1D distribution of counts per mean value
        3. Computes cumulative sum of counts along the mean axis
        4. Finds the mean value where cumsum reaches 50% of total non-zero channels

        Args:
            mean_values: 1D array of mean values for all channels (n_channels,)
            variation_values: 1D array of variation values for all channels (n_channels,)

        Returns:
            The mean value where cumulative count reaches 50% of total non-zero channels.
            Returns 0 if no valid data.
        """
        if len(mean_values) == 0 or len(variation_values) == 0:
            return 0.0

        non_zero_mask = (mean_values != 0.0) | (variation_values != 0.0)
        mean_filtered = mean_values[non_zero_mask]
        var_filtered = variation_values[non_zero_mask]

        if len(mean_filtered) == 0 or len(var_filtered) == 0:
            return 0.0

        mean_min = int(np.floor(mean_filtered.min()))
        mean_max = int(np.ceil(mean_filtered.max()))
        var_min = int(np.floor(var_filtered.min()))
        var_max = int(np.ceil(var_filtered.max()))

        mean_bins_edges = np.arange(mean_min - 0.5, mean_max + 1.0, 1.0)
        var_bins_edges = np.arange(var_min - 0.5, var_max + 1.0, 1.0)

        mean_bins_centers = np.arange(mean_min, mean_max + 1, 1)

        hist_2d, _, _ = np.histogram2d(
            var_filtered, mean_filtered, bins=[var_bins_edges, mean_bins_edges]
        )

        hist_1d = hist_2d.sum(axis=0)

        cumsum = np.cumsum(hist_1d)
        total_count = cumsum[-1]

        if total_count == 0:
            return 0.0

        threshold = total_count / 2
        idx_50 = np.searchsorted(cumsum, threshold)

        if idx_50 < len(mean_bins_centers):
            return float(mean_bins_centers[idx_50])
        return float(mean_bins_centers[-1])

    def compute_cumulative_50_percent_variation(
        self,
        mean_values: np.ndarray,
        variation_values: np.ndarray,
    ) -> float:
        """Compute 50% cumulative threshold for variation values, excluding (0,0) pairs.

        Builds a 2D histogram (mean x variation), then:
        1. Excludes channels where (mean=0 AND variation=0)
        2. Sums along the mean axis to get 1D distribution of counts per variation value
        3. Computes cumulative sum of counts along the variation axis
        4. Finds the variation value where cumsum reaches 50% of total non-zero channels

        Args:
            mean_values: 1D array of mean values for all channels (n_channels,)
            variation_values: 1D array of variation values for all channels (n_channels,)

        Returns:
            The variation value where cumulative count reaches 50% of total non-zero channels.
            Returns 0 if no valid data.
        """
        if len(mean_values) == 0 or len(variation_values) == 0:
            return 0.0

        non_zero_mask = (mean_values != 0.0) | (variation_values != 0.0)
        mean_filtered = mean_values[non_zero_mask]
        var_filtered = variation_values[non_zero_mask]

        if len(mean_filtered) == 0 or len(var_filtered) == 0:
            return 0.0

        mean_min = int(np.floor(mean_filtered.min()))
        mean_max = int(np.ceil(mean_filtered.max()))
        var_min = int(np.floor(var_filtered.min()))
        var_max = int(np.ceil(var_filtered.max()))

        mean_bins_edges = np.arange(mean_min - 0.5, mean_max + 1.0, 1.0)
        var_bins_edges = np.arange(var_min - 0.5, var_max + 1.0, 1.0)

        var_bins_centers = np.arange(var_min, var_max + 1, 1)

        hist_2d, _, _ = np.histogram2d(
            var_filtered, mean_filtered, bins=[var_bins_edges, mean_bins_edges]
        )

        hist_1d = hist_2d.sum(axis=1)

        cumsum = np.cumsum(hist_1d)
        total_count = cumsum[-1]

        if total_count == 0:
            return 0.0

        threshold = total_count / 2
        idx_50 = np.searchsorted(cumsum, threshold)

        if idx_50 < len(var_bins_centers):
            return float(var_bins_centers[idx_50])
        return float(var_bins_centers[-1])
