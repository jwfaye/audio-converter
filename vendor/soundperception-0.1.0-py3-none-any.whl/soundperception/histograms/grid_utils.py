"""Grid and peak-based histogram categorization utilities.

Standalone functions for categorizing N-D histograms:
- find_marginal_thresholds: peak/valley detection on 1D marginal histograms
- auto_grid_categorize_histogram: automatic grid from marginal thresholds
- grid_categorize_histogram: fixed grid with custom thresholds
- find_categories_in_histogram: peak detection with region growing
"""

import itertools

import numpy as np
from scipy import ndimage as ndi

from soundperception.utils.peak_detection import find_peaks

__all__ = [
    "find_marginal_thresholds",
    "auto_grid_categorize_histogram",
    "grid_categorize_histogram",
    "find_categories_in_histogram",
]

BACKGROUND_VALUE = 0


def find_marginal_thresholds(hist_1d: np.ndarray) -> list[int]:
    """Find thresholds from a 1D histogram using peak detection and valley finding.

    Patrick's method:
    - Detect local peaks (min height = 1% of max, adaptive window)
    - Find valleys between peaks (drops below peak/4)
    - Return bin indices where bands start

    Args:
        hist_1d: 1D histogram array.

    Returns:
        List of threshold indices (bin positions where bands start).

    Example:
        hist = np.array([0, 5, 10, 8, 2, 1, 3, 9, 12, 7, 1])
        thresholds = find_marginal_thresholds(hist)
    """
    min_ratio = 0.01
    valley_frac = 0.25

    n = len(hist_1d)
    if n == 0:
        return []

    hist_1d = np.asarray(hist_1d, dtype=np.float64)
    original_max = np.max(hist_1d)
    if original_max <= 0:
        return []
    min_peak = original_max * min_ratio

    if n > 10:  # noqa: PLR2004
        window_size = 5
    elif n >= 5:  # noqa: PLR2004
        window_size = 3
    else:
        window_size = 1

    raw_peaks = list(find_peaks(hist_1d, size=window_size, min_ratio=min_ratio))

    # find_peaks requires growth+decay, so edge peaks are excluded.
    # For histograms, a peak at the boundary is valid if it decays inward.
    half = window_size // 2
    if n > 0 and hist_1d[0] >= min_peak and 0 not in raw_peaks:
        # Left edge: check it's a local max in its right neighborhood
        right_end = min(n, half + 1)
        right_slice = hist_1d[1:right_end]
        if len(right_slice) == 0 or hist_1d[0] >= np.max(right_slice):
            raw_peaks.insert(0, 0)
    if n > 1 and hist_1d[-1] >= min_peak and (n - 1) not in raw_peaks:
        # Right edge: check it's a local max in its left neighborhood
        left_start = max(0, n - 1 - half)
        left_slice = hist_1d[left_start:-1]
        if len(left_slice) == 0 or hist_1d[-1] >= np.max(left_slice):
            raw_peaks.append(n - 1)

    if len(raw_peaks) == 0:
        return []

    # Merge adjacent peaks (plateaus) into single peak at center
    local_peaks = []
    plateau_start = raw_peaks[0]
    for k in range(1, len(raw_peaks)):
        if raw_peaks[k] == raw_peaks[k - 1] + 1:
            continue  # still on the same plateau
        else:
            local_peaks.append((plateau_start + raw_peaks[k - 1]) // 2)
            plateau_start = raw_peaks[k]
    local_peaks.append((plateau_start + raw_peaks[-1]) // 2)

    limits = [0]

    if len(local_peaks) == 1:
        peak_idx = local_peaks[0]
        peak_val = hist_1d[peak_idx]
        threshold = peak_val * valley_frac

        # Only search right — left boundary is always 0
        for i in range(peak_idx + 1, n):
            if hist_1d[i] < threshold:
                limits.append(i)
                break
    else:
        for k in range(len(local_peaks) - 1):
            peak1_idx = local_peaks[k]
            peak2_idx = local_peaks[k + 1]
            peak1_val = hist_1d[peak1_idx]
            peak2_val = hist_1d[peak2_idx]
            thresh1 = peak1_val * valley_frac
            thresh2 = peak2_val * valley_frac

            if peak2_idx <= peak1_idx + 1:
                limits.append(peak2_idx)
                continue

            min_idx = peak1_idx + 1 + np.argmin(hist_1d[peak1_idx + 1 : peak2_idx])

            right1 = None
            for j in range(peak1_idx + 1, peak2_idx):
                if hist_1d[j] < thresh1:
                    right1 = j
                    break

            left2 = None
            for j in range(peak2_idx - 1, peak1_idx, -1):
                if hist_1d[j] < thresh2:
                    left2 = j
                    break

            if right1 is not None and left2 is not None:
                valley_center_idx = (right1 + left2) // 2
            else:
                valley_center_idx = min_idx

            limits.append(valley_center_idx)

        last_peak_idx = local_peaks[-1]
        last_peak_val = hist_1d[last_peak_idx]
        threshold = last_peak_val * valley_frac

        for i in range(last_peak_idx + 1, n):
            if hist_1d[i] < threshold:
                limits.append(i)
                break

    return sorted(set(limits))


def auto_grid_categorize_histogram(histogram: np.ndarray) -> np.ndarray:
    """Categorize N-D histogram using automatically detected grid thresholds.

    For each dimension, compute the marginal histogram, detect peaks and valleys
    to find thresholds, then build a grid where each cell is a category.

    Args:
        histogram: N-D histogram array.

    Returns:
        N-D array of labels (0 = background, 1..N = categories).

    Example:
        histogram = np.random.poisson(5, size=(20, 40)).astype(float)
        labels = auto_grid_categorize_histogram(histogram)
    """
    ndim = histogram.ndim
    shape = histogram.shape

    all_thresholds = []
    for dim in range(ndim):
        axes = tuple(i for i in range(ndim) if i != dim)
        marginal = histogram.sum(axis=axes)
        thresholds = find_marginal_thresholds(marginal)
        all_thresholds.append(thresholds)

    band_indices = []
    for dim in range(ndim):
        dim_size = shape[dim]
        band_idx = np.zeros(dim_size, dtype=np.int32)
        for thresh in all_thresholds[dim]:
            if thresh == 0:
                continue  # 0 is the left edge, not a real threshold
            band_idx[thresh:] += 1
        band_indices.append(band_idx)

    grids = np.meshgrid(*band_indices, indexing="ij")

    labels = np.zeros(shape, dtype=np.int32)
    n_bands = [int(bi.max()) + 1 for bi in band_indices]

    cat = 1
    for cell_idx in itertools.product(*[range(nb) for nb in n_bands]):
        cell_mask = np.ones(shape, dtype=bool)
        for dim, band in enumerate(cell_idx):
            cell_mask &= grids[dim] == band
        labels[cell_mask] = cat
        cat += 1

    return labels


def grid_categorize_histogram(
    histogram: np.ndarray,
    thresholds: list[list[int]] | None = None,
    category_map: dict[tuple[int, ...], int] | None = None,
    background_threshold: list[int | None] | None = None,
) -> np.ndarray:
    """Categorize N-D histogram using fixed grid thresholds.

    Args:
        histogram: N-D histogram array.
        thresholds: List of threshold arrays for each dimension.
        category_map: Mapping from (band_0, band_1, ...) to category number.
        background_threshold: List of threshold values per dimension.

    Returns:
        N-D array of labels (0 = background, 1..N = categories).

    Example:
        >>> thresholds = [[4, 15], [6, 12, 24, 36]]
        >>> labels = grid_categorize_histogram(histogram, thresholds)
    """
    ndim = histogram.ndim
    shape = histogram.shape

    if thresholds is None:
        thresholds = [[] for _ in range(ndim)]

    if len(thresholds) != ndim:
        raise ValueError(f"thresholds must have {ndim} elements, got {len(thresholds)}")

    n_bands = [len(t) + 1 for t in thresholds]

    band_indices = []
    for dim in range(ndim):
        dim_size = shape[dim]
        band_idx = np.zeros(dim_size, dtype=np.int32)
        for i, thresh in enumerate(thresholds[dim]):
            band_idx[thresh:] = i + 1
        band_indices.append(band_idx)

    grids = np.meshgrid(*band_indices, indexing="ij")

    labels = np.zeros(shape, dtype=np.int32)

    if category_map is not None:
        for cell_idx, cat in category_map.items():
            mask = np.ones(shape, dtype=bool)
            for dim, band in enumerate(cell_idx):
                mask &= grids[dim] == band
            labels[mask] = cat
    else:
        cat = 1
        for cell_idx in itertools.product(*[range(n) for n in n_bands]):
            mask = np.ones(shape, dtype=bool)
            for dim, band in enumerate(cell_idx):
                mask &= grids[dim] == band
            labels[mask] = cat
            cat += 1

    if background_threshold is not None:
        for dim, thresh in enumerate(background_threshold):
            if thresh is not None:
                bg_mask = np.zeros(shape, dtype=bool)
                for idx in range(shape[dim]):
                    if idx >= thresh:
                        slices = [slice(None)] * ndim
                        slices[dim] = idx
                        bg_mask[tuple(slices)] = True
                labels[bg_mask] = BACKGROUND_VALUE

    return labels


def find_categories_in_histogram(
    histogram: np.ndarray,
    peak_min_distance: int = 1,
    peak_threshold_frac: float = 0.01,
    region_frac: float = 0.25,
    connectivity: int = 1,
) -> np.ndarray:
    """Find categories in N-D histogram via peak detection and region growing.

    Args:
        histogram: N-D histogram array.
        peak_min_distance: Minimum distance between peaks.
        peak_threshold_frac: Fraction of max for peak threshold.
        region_frac: Relative threshold for region growing.
        connectivity: Connectivity for connected components.

    Returns:
        N-D array of labels (0 = background, 1..N = categories).

    Example:
        histogram = np.random.poisson(5, size=(10, 10)).astype(float)
        labels = find_categories_in_histogram(histogram)
    """
    histogram = np.asarray(histogram, dtype=np.float64)

    if histogram.size == 0:
        return np.zeros(histogram.shape, dtype=np.int32)

    hmax = float(np.max(histogram))
    if hmax <= 0:
        return np.zeros(histogram.shape, dtype=np.int32)

    threshold_abs = hmax * peak_threshold_frac

    peaks = _find_local_maxima(
        histogram,
        min_distance=peak_min_distance,
        threshold_abs=threshold_abs,
    )

    if len(peaks) == 0:
        return np.zeros(histogram.shape, dtype=np.int32)

    labels = _regions_by_threshold(
        histogram,
        peaks,
        frac=region_frac,
        connectivity=connectivity,
    )

    return labels


def _find_local_maxima(
    image: np.ndarray,
    min_distance: int = 1,
    threshold_abs: float = 0.0,
) -> np.ndarray:
    """Find local maxima in N-D array."""
    size = 2 * min_distance + 1
    return find_peaks(image, size=size, min_value=threshold_abs)


def _regions_by_threshold(
    histogram: np.ndarray,
    peaks: np.ndarray,
    frac: float = 0.25,
    connectivity: int = 1,
) -> np.ndarray:
    """Grow regions around peaks using relative thresholding."""
    ndim = histogram.ndim
    structure = ndi.generate_binary_structure(ndim, connectivity)

    peak_vals = histogram[tuple(peaks.T)]
    order = np.argsort(-peak_vals)
    peaks_sorted = peaks[order]
    vals_sorted = peak_vals[order]

    labels = np.zeros(histogram.shape, dtype=np.int32)

    peak_pairs = zip(peaks_sorted, vals_sorted, strict=False)
    for k, (peak_coord, peak_val) in enumerate(peak_pairs, start=1):
        if peak_val <= 0:
            continue

        threshold = frac * peak_val
        mask = (histogram >= threshold) & (histogram <= peak_val + 1e-10)

        peak_tuple = tuple(peak_coord)
        mask[peak_tuple] = True

        cc, _ = ndi.label(mask, structure=structure)
        peak_cc = cc[peak_tuple]

        if peak_cc == 0:
            continue

        region = (cc == peak_cc) & (labels == 0)
        labels[region] = k

    return labels
