"""Structural modality extractor for auditory signals (Patrick's method).

Pipeline:
    1. Sobel gradients (sobel_x, sobel_y) + magnitude
    2. Sum each over 3×3 window → sum_x, sum_y, sum_energy
    3. Compute MA (angular mean) and VA (angular variation)
    4. Energy categorization: round(sum_energy/10) → category 0/1/2
       - Category 0: sum_energy < 40 or sum_energy >= 700 (weak or saturated)
       - Category 1: 40 ≤ sum_energy < 220 (medium)
       - Category 2: 220 ≤ sum_energy < 700 (strong) → KEEP ONLY THIS
    5. Filter: keep only category 2
    6. Categorize into bins: MA/20 (9 bins), VA×10/6 (9 bins)

MA formula:
    - sum_x=0 and sum_y>0 → 0
    - sum_x=0 and sum_y<0 → 180
    - sum_x≠0 → round(mod(-90 + 180/π × atan2(sum_y, sum_x), 180))
    - Else → -1 (inactive)

VA formula:
    - sum_energy>0 → round(ln(1 + 180×(1 - √(sum_x² + sum_y²)/sum_energy)), 1)
    - Else → -1 (inactive)

Categorization:
    - 0: inactive (no signal or energy not in active range)
    - MA: floor(MA / 20) + 1 → bins 1-9 (each bin = 20°)
    - VA: floor(VA × 10 / 6) + 1 → bins 1-9 (each bin ≈ 0.6)

Sobel kernels:
    - sobel_x: [[1,0,-1], [2,0,-2], [1,0,-1]] (horizontal gradient)
    - sobel_y: [[-1,-2,-1], [0,0,0], [1,2,1]] (vertical gradient)
"""

from dataclasses import dataclass

import numpy as np

from soundperception.module import InputSpec, OutputSpec, TensorShape, module

__all__ = ["StructuralExtractorConfig", "StructuralExtractor"]

ENERGY_MIN = 220
ENERGY_MAX = 700
MA_BIN_WIDTH = 20
VA_BIN_FACTOR = 10 / 6

_ENERGY_QUANT_STEP = 10
_ENERGY_QUANT_LOW = 4
_ENERGY_QUANT_MID = 22
_ENERGY_QUANT_HIGH = 70
_ENERGY_CAT_ACTIVE = 2


@dataclass
class StructuralExtractorConfig:
    """Configuration for structural feature extraction.

    Example:
        config = StructuralExtractorConfig(
            energy_min=200, energy_max=800
        )
    """

    energy_min: float = ENERGY_MIN
    energy_max: float = ENERGY_MAX
    ma_bin_width: float = MA_BIN_WIDTH
    va_bin_factor: float = VA_BIN_FACTOR

    @classmethod
    def default(cls) -> "StructuralExtractorConfig":
        """Create default configuration with Patrick's thresholds."""
        return cls()


def _sum_3x3(signal: np.ndarray) -> np.ndarray:
    """Sum over 3×3 window centered on each pixel."""
    kernel = np.ones((3, 3), dtype=np.float64)
    return _correlate_2d(signal, kernel)


def _correlate_2d(signal: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    """Apply 2D correlation with symmetric padding (no kernel flip)."""
    kh, kw = kernel.shape
    pad_h, pad_w = kh // 2, kw // 2

    padded = np.pad(signal.astype(np.float64), ((pad_h, pad_h), (pad_w, pad_w)), mode="symmetric")

    h, w = signal.shape

    shape = (h, w, kh, kw)
    strides = padded.strides + padded.strides
    windows = np.lib.stride_tricks.as_strided(padded, shape=shape, strides=strides)

    return np.einsum("ijkl,kl->ij", windows, kernel)


@module(
    inputs={
        "signal": InputSpec(
            name="signal",
            dtype=np.ndarray,
            description="2D input signal (n_channels × n_frames)",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
    },
    outputs={
        "ma": OutputSpec(
            name="ma",
            dtype=np.ndarray,
            description="Angular mean (0-180°, -1 if inactive)",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
        "va": OutputSpec(
            name="va",
            dtype=np.ndarray,
            description="Angular variation (0-5.2, -1 if inactive)",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
        "cat_ma": OutputSpec(
            name="cat_ma",
            dtype=np.ndarray,
            description="MA bins (0: inactive, 1-9: active)",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
        "cat_va": OutputSpec(
            name="cat_va",
            dtype=np.ndarray,
            description="VA bins (0: inactive, 1-9: active)",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
        "energy_category": OutputSpec(
            name="energy_category",
            dtype=np.ndarray,
            description="Energy category (0, 1, or 2)",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
        "sum_energy": OutputSpec(
            name="sum_energy",
            dtype=np.ndarray,
            description="Raw sum of magnitude over 3×3",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
    },
    method="process",
    description="Extract structural features using Sobel gradients (Patrick's method).",
)
class StructuralExtractor:
    """Extract structural features using Sobel gradients (Patrick's method).

    Example:
        >>> extractor = StructuralExtractor(StructuralExtractorConfig.default())
        >>> result = extractor.process(signal)
        >>> # Or via __call__:
        >>> result = extractor(signal=signal)
        >>> cat_ma = result["cat_ma"]
        >>> cat_va = result["cat_va"]
    """

    def __init__(self, config: StructuralExtractorConfig):
        """Initialize extractor with configuration."""
        self.config = config
        self._sobel_x = np.array([[1, 0, -1], [2, 0, -2], [1, 0, -1]], dtype=np.float64)
        self._sobel_y = np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=np.float64)

    def process(self, signal: np.ndarray) -> dict[str, np.ndarray]:
        """Process signal to extract structural features using Patrick's method.

        Args:
            signal: 2D array (n_channels × n_frames).

        Returns:
            Dictionary with:
            - 'ma': angular mean (0-180°, -1 if inactive)
            - 'va': angular variation (0-5.2, -1 if inactive)
            - 'cat_ma': MA bins (0: inactive, 1-9: active)
            - 'cat_va': VA bins (0: inactive, 1-9: active)
            - 'energy_category': energy category (0, 1, or 2)
            - 'sum_energy': raw sum of magnitude over 3×3

        Note:
            Only pixels with energy category 2 (220 ≤ sum_energy < 700) are kept.

        Example:
            extractor = StructuralExtractor(
                StructuralExtractorConfig.default()
            )
            signal = np.random.rand(65, 100) * 255
            result = extractor.process(signal)
            cat_ma = result["cat_ma"]  # MA bins, shape (65, 100)
            cat_va = result["cat_va"]  # VA bins, shape (65, 100)
        """
        signal_f = signal.astype(np.float64)

        sobel_x = _correlate_2d(signal_f, self._sobel_x)
        sobel_y = _correlate_2d(signal_f, self._sobel_y)
        magnitude = np.sqrt(sobel_x**2 + sobel_y**2)

        sum_x = _sum_3x3(sobel_x)
        sum_y = _sum_3x3(sobel_y)
        sum_energy = _sum_3x3(magnitude)

        ma = np.full_like(signal_f, -1.0)
        ma = np.where((sum_x == 0) & (sum_y > 0), 0.0, ma)
        ma = np.where((sum_x == 0) & (sum_y < 0), 180.0, ma)
        angle = np.mod(-90 + (180 / np.pi) * np.arctan2(sum_y, sum_x), 180)
        ma = np.where(sum_x != 0, np.round(angle), ma)

        va = np.full_like(signal_f, -1.0)
        resultant = np.sqrt(sum_x**2 + sum_y**2)
        va_raw = np.log(1 + 180 * (1 - resultant / sum_energy))
        va = np.where(sum_energy > 0, np.round(va_raw, 1), va)

        energy_quantized = np.round(sum_energy / _ENERGY_QUANT_STEP).astype(np.int32)
        energy_category = np.zeros_like(energy_quantized)
        energy_category = np.where(
            (energy_quantized >= _ENERGY_QUANT_LOW) & (energy_quantized < _ENERGY_QUANT_MID),
            1,
            energy_category,
        )
        energy_category = np.where(
            (energy_quantized >= _ENERGY_QUANT_MID) & (energy_quantized < _ENERGY_QUANT_HIGH),
            2,
            energy_category,
        )

        energy_mask = energy_category == _ENERGY_CAT_ACTIVE
        ma = np.where(energy_mask, ma, -1.0)
        va = np.where(energy_mask, va, -1.0)

        cat_ma = np.where(
            ma > -1, np.minimum(np.floor(ma / self.config.ma_bin_width), 8).astype(np.int32) + 1, 0
        ).astype(np.int32)
        cat_va = np.where(
            va > -1, np.minimum(np.floor(va * self.config.va_bin_factor), 8).astype(np.int32) + 1, 0
        ).astype(np.int32)

        return {
            "ma": ma,
            "va": va,
            "cat_ma": cat_ma,
            "cat_va": cat_va,
            "energy_category": energy_category,
            "sum_energy": sum_energy,
        }
