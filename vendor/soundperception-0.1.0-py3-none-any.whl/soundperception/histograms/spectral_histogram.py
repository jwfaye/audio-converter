"""Spectral histogram computation preserving frequency channel information.

Computes 2D histograms with:
- X axis: Frequency channel index (0 to num_channels-1)
- Y axis: Amplitude or variation metric

Unlike BilinearHistogramComputer which aggregates all channels into (mean, variation),
this preserves the spectral distribution across frequency channels.
"""

from dataclasses import dataclass

import numpy as np
import pandas as pd

__all__ = ["SpectralHistogramConfig", "SpectralHistogramComputer"]


@dataclass
class SpectralHistogramConfig:
    """Configuration for spectral histogram computation.

    Produces 2D histogram with channel (frequency) on X-axis and
    amplitude/variation on Y-axis.

    Attributes:
        metric: Feature to use for Y-axis ("amplitude" or "variation")
        amplitude_bin_step: Step size for metric bins (default: 1.0)
        amplitude_range: (min, max) for metric axis (None = auto from data)
        num_channels: Number of frequency channels (default: 65)
        round_decimals: Decimals for rounding values (None = no rounding)
    """

    metric: str = "amplitude"
    amplitude_bin_step: float = 1.0
    amplitude_range: tuple[float, float] | None = None
    num_channels: int = 65
    round_decimals: int | None = 1

    @classmethod
    def default(cls) -> "SpectralHistogramConfig":
        """Create default configuration for amplitude-based histogram.

        Returns:
            Configuration with:
            - Amplitude mode
            - Integer bins (step=1.0)
            - Automatic range detection
            - 65 frequency channels
            - Rounding to 1 decimal
        """
        return cls(
            metric="amplitude",
            amplitude_bin_step=1.0,
            amplitude_range=None,
            num_channels=65,
            round_decimals=1,
        )

    @classmethod
    def variation_mode(cls) -> "SpectralHistogramConfig":
        """Create configuration for variation-based histogram.

        Returns:
            Configuration with variation metric instead of amplitude.
        """
        return cls(
            metric="variation",
            amplitude_bin_step=1.0,
            amplitude_range=None,
            num_channels=65,
            round_decimals=1,
        )


class SpectralHistogramComputer:
    """Spectral histogram computer preserving frequency channel information.

    Produces 2D histograms with:
    - X axis: Channel index (0 to num_channels-1) representing frequency
    - Y axis: Amplitude or variation metric

    Unlike BilinearHistogramComputer which aggregates all channels,
    this preserves the spectral distribution across frequency channels.

    Example:
        >>> from soundperception import AuditoryPeriphery, AuditoryPeripheryConfig
        >>> from soundperception.histograms import (
        ...     SpectralHistogramComputer, SpectralHistogramConfig
        ... )
        >>>
        >>> # Process audio through auditory periphery
        >>> periphery = AuditoryPeriphery(AuditoryPeripheryConfig.default())
        >>> result = periphery.process(audio_signal)
        >>>
        >>> # Compute spectral histogram for a single frame
        >>> config = SpectralHistogramConfig.default()
        >>> computer = SpectralHistogramComputer(config)
        >>> hist_result = computer.compute_single_frame_histogram(result['memo_ma'], frame_index=0)
        >>>
        >>> # Use with DynamicAttractor
        >>> from soundperception.core import DynamicAttractor, DynamicAttractorConfig
        >>> attractor = DynamicAttractor(DynamicAttractorConfig())
        >>> frame_result = attractor.process(
        ...     hist_result['histogram_2d'],
        ...     hist_result['channel_bins'],
        ...     hist_result['metric_bins']
        ... )
    """

    def __init__(self, config: SpectralHistogramConfig):
        """Initialize spectral histogram computer with configuration.

        Args:
            config: Spectral histogram configuration
        """
        self.config = config

    def compute_single_frame_histogram(
        self,
        memo_ma: np.ndarray,
        frame_index: int,
    ) -> dict[str, np.ndarray | pd.DataFrame]:
        """Compute 2D histogram for a single frame.

        For amplitude mode: Each of 65 channels contributes its amplitude value.
        For variation mode: Computes |frame[i+1] - frame[i]| per channel.

        Args:
            memo_ma: Amplitude memory (n_channels, n_frames)
            frame_index: Frame index to analyze

        Returns:
            Dictionary containing:
            - 'histogram_2d': 2D histogram array (n_metric_bins, n_channels)
            - 'histogram_df': DataFrame with histogram (rows=metric, cols=channel)
            - 'channel_bins': Channel bin centers (0 to n_channels-1)
            - 'metric_bins': Metric bin centers
            - 'metric_values': Raw metric values per channel for this frame
            - 'metric_range': (min, max) of metric values
        """
        n_channels, n_frames = memo_ma.shape
        cfg = self.config

        max_index = n_frames - 1 if cfg.metric == "amplitude" else n_frames - 2
        if frame_index < 0 or frame_index > max_index:
            raise ValueError(f"Frame index {frame_index} out of range [0, {max_index}]")

        channel_bins = np.arange(n_channels)
        channel_edges = np.arange(-0.5, n_channels + 0.5, 1.0)

        if cfg.metric == "amplitude":
            metric_values = memo_ma[:, frame_index].copy()
        else:
            metric_values = np.abs(memo_ma[:, frame_index + 1] - memo_ma[:, frame_index])

        if cfg.round_decimals is not None:
            metric_values = np.round(metric_values, cfg.round_decimals)

        if cfg.amplitude_range is not None:
            metric_min, metric_max = cfg.amplitude_range
        else:
            metric_min = int(np.floor(metric_values.min()))
            metric_max = int(np.ceil(metric_values.max()))

        if metric_min == metric_max:
            metric_max = metric_min + 1

        metric_bins = np.arange(metric_min, metric_max + 1, int(cfg.amplitude_bin_step))
        metric_edges = np.arange(metric_min - 0.5, metric_max + 1.0, cfg.amplitude_bin_step)

        hist_2d, _, _ = np.histogram2d(
            metric_values,
            channel_bins,
            bins=[metric_edges, channel_edges],
        )
        hist_2d = hist_2d.astype(int)

        hist_df = pd.DataFrame(hist_2d, index=metric_bins, columns=channel_bins)

        return {
            "histogram_2d": hist_2d,
            "histogram_df": hist_df,
            "channel_bins": channel_bins,
            "metric_bins": metric_bins,
            "metric_values": metric_values,
            "metric_range": (metric_min, metric_max),
        }

    def compute(
        self,
        memo_ma: np.ndarray,
        return_intermediate: bool = False,
    ) -> dict[str, np.ndarray | pd.DataFrame | tuple]:
        """Compute spectral histogram from amplitude memory over all frames.

        Aggregates all frames into a single 2D histogram showing the
        overall spectral distribution.

        Args:
            memo_ma: Amplitude memory (n_channels, n_frames)
            return_intermediate: If True, return per-frame metric values

        Returns:
            Dictionary containing:
            - 'histogram_2d': 2D histogram array (n_metric_bins, n_channels)
            - 'histogram_df': DataFrame with histogram
            - 'channel_bins': Channel bin centers
            - 'metric_bins': Metric bin centers
            - 'metric_range': (min, max) of metric values
            - 'n_frames': Number of frames processed

            If return_intermediate=True, also includes:
            - 'metric_matrix': All metric values (n_channels, n_frames)
        """
        n_channels, n_frames = memo_ma.shape
        cfg = self.config

        channel_bins = np.arange(n_channels)
        channel_edges = np.arange(-0.5, n_channels + 0.5, 1.0)

        if cfg.metric == "amplitude":
            metric_matrix = memo_ma.copy()
            effective_frames = n_frames
        else:
            metric_matrix = np.abs(np.diff(memo_ma, axis=1))
            effective_frames = n_frames - 1

        if cfg.round_decimals is not None:
            metric_matrix = np.round(metric_matrix, cfg.round_decimals)

        if cfg.amplitude_range is not None:
            metric_min, metric_max = cfg.amplitude_range
        else:
            metric_min = int(np.floor(metric_matrix.min()))
            metric_max = int(np.ceil(metric_matrix.max()))

        if metric_min == metric_max:
            metric_max = metric_min + 1

        metric_bins = np.arange(metric_min, metric_max + 1, int(cfg.amplitude_bin_step))
        metric_edges = np.arange(metric_min - 0.5, metric_max + 1.0, cfg.amplitude_bin_step)

        hist_2d = np.zeros((len(metric_bins), len(channel_bins)), dtype=np.float64)

        for frame_idx in range(effective_frames):
            frame_values = metric_matrix[:, frame_idx]
            frame_hist, _, _ = np.histogram2d(
                frame_values,
                channel_bins,
                bins=[metric_edges, channel_edges],
            )
            hist_2d += frame_hist

        hist_2d = hist_2d.astype(int)

        hist_df = pd.DataFrame(hist_2d, index=metric_bins, columns=channel_bins)

        result = {
            "histogram_2d": hist_2d,
            "histogram_df": hist_df,
            "channel_bins": channel_bins,
            "metric_bins": metric_bins,
            "metric_range": (metric_min, metric_max),
            "n_frames": effective_frames,
        }

        if return_intermediate:
            result["metric_matrix"] = metric_matrix

        return result

    def compute_sequence_histograms(
        self,
        memo_ma: np.ndarray,
    ) -> dict[str, np.ndarray | list]:
        """Compute per-frame histograms for a sequence.

        Produces one histogram per frame, suitable for feeding to
        DynamicAttractor frame by frame.

        Args:
            memo_ma: Amplitude memory (n_channels, n_frames)

        Returns:
            Dictionary containing:
            - 'histograms': List of 2D histogram arrays
            - 'channel_bins': Channel bin centers (shared)
            - 'metric_bins': Metric bin centers (shared, from global range)
            - 'n_frames': Number of frames
        """
        n_channels, n_frames = memo_ma.shape
        cfg = self.config

        if cfg.metric == "amplitude":
            metric_matrix = memo_ma
            effective_frames = n_frames
        else:
            metric_matrix = np.abs(np.diff(memo_ma, axis=1))
            effective_frames = n_frames - 1

        if cfg.round_decimals is not None:
            metric_matrix = np.round(metric_matrix, cfg.round_decimals)

        if cfg.amplitude_range is not None:
            metric_min, metric_max = cfg.amplitude_range
        else:
            metric_min = int(np.floor(metric_matrix.min()))
            metric_max = int(np.ceil(metric_matrix.max()))

        if metric_min == metric_max:
            metric_max = metric_min + 1

        channel_bins = np.arange(n_channels)
        channel_edges = np.arange(-0.5, n_channels + 0.5, 1.0)
        metric_bins = np.arange(metric_min, metric_max + 1, int(cfg.amplitude_bin_step))
        metric_edges = np.arange(metric_min - 0.5, metric_max + 1.0, cfg.amplitude_bin_step)

        histograms = []
        for frame_idx in range(effective_frames):
            frame_values = metric_matrix[:, frame_idx]
            hist_2d, _, _ = np.histogram2d(
                frame_values,
                channel_bins,
                bins=[metric_edges, channel_edges],
            )
            histograms.append(hist_2d.astype(int))

        return {
            "histograms": histograms,
            "channel_bins": channel_bins,
            "metric_bins": metric_bins,
            "n_frames": effective_frames,
        }
