"""Histogram construction utilities.

Provides functions for building N-dimensional joint histograms from images/signals.
"""

import numpy as np

__all__ = [
    "build_joint_histogram",
    "multilinear_histogram",
]


def build_joint_histogram(
    mean: np.ndarray,
    std: np.ndarray,
    mean_scale: float = 1.0,
    std_scale: float = 1.0,
    bins: list[np.ndarray] | None = None,
    mask: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Build 2D joint histogram from mean and std images.

    Convenience wrapper around multilinear_histogram for the common 2D case.

    Args:
        mean: Mean image (n_channels × n_samples).
        std: Standard deviation image (n_channels × n_samples).
        mean_scale: Scale factor for mean values (default: 1.0).
        std_scale: Scale factor for std values (default: 1.0, use 5.0 for MEMO_MA).
        bins: Optional [mean_bins, std_bins]. If None, auto-computed from data.
        mask: Optional mask selecting valid pixels.

    Returns:
        Tuple of (histogram, mean_bins, std_bins):
        - histogram: 2D array (std_bins × mean_bins)
        - mean_bins: Bin edges for mean axis
        - std_bins: Bin edges for std axis

    Example:
        mean_img = np.random.randint(0, 20, size=(65, 100))
        std_img = np.random.randint(0, 10, size=(65, 100))
        hist, mean_bins, std_bins = build_joint_histogram(
            mean_img, std_img, std_scale=5.0
        )
    """
    mean_scaled = mean * mean_scale
    std_scaled = std * std_scale

    if bins is None:
        mean_min, mean_max = int(mean_scaled.min()), int(mean_scaled.max())
        std_min, std_max = int(std_scaled.min()), int(std_scaled.max())
        mean_bins = np.arange(mean_min, mean_max + 2, dtype=np.float64)
        std_bins = np.arange(std_min, std_max + 2, dtype=np.float64)
    else:
        mean_bins, std_bins = bins

    # Note: multilinear_histogram returns shape (dim0, dim1) = (mean, std)
    histogram = multilinear_histogram(
        [mean_scaled, std_scaled],
        bins=[mean_bins, std_bins],
        mask=mask,
    )

    histogram = histogram.T

    return histogram, mean_bins, std_bins


def multilinear_histogram(
    imgs: list[np.ndarray],
    bins: list[np.ndarray] | None = None,
    mask: np.ndarray | None = None,
    normalize: bool = False,
    scales: list[float] | None = None,
) -> np.ndarray:
    """Compute N-D joint histogram from N images.

    Args:
        imgs: List of N images (same shape).
        bins: List of N bin edge arrays. If None, uses 0..max+1 per image.
        mask: Optional mask selecting valid pixels.
        normalize: If True, normalize histogram to sum to 1.
        scales: Optional scale factors for each dimension. E.g., [1, 5] to
            multiply the second image by 5 before binning. Useful to adjust
            histogram resolution per axis.

    Returns:
        N-D joint histogram array.

    Example:
        img_a = np.random.randint(0, 10, size=(65, 100))
        img_b = np.random.randint(0, 10, size=(65, 100))
        # 2D joint histogram
        hist = multilinear_histogram([img_a, img_b])
        # With custom bins and normalization
        bins = [np.arange(11), np.arange(11)]
        hist_norm = multilinear_histogram(
            [img_a, img_b], bins=bins, normalize=True
        )
    """
    if len(imgs) < 1:
        raise ValueError("At least one image required")

    imgs_arr = [np.asarray(im, dtype=np.float64) for im in imgs]
    shape = imgs_arr[0].shape

    for im in imgs_arr[1:]:
        if im.shape != shape:
            raise ValueError("All images must have same shape")

    n_dims = len(imgs_arr)

    if scales is not None:
        if len(scales) != n_dims:
            raise ValueError(f"scales must have {n_dims} elements, got {len(scales)}")
        imgs_arr = [im * s for im, s in zip(imgs_arr, scales, strict=False)]

    if bins is None:
        bins = [np.arange(int(im.max()) + 2, dtype=np.float64) for im in imgs_arr]

    vals = [im.ravel() for im in imgs_arr]

    if mask is not None:
        mask_flat = np.asarray(mask, dtype=bool).ravel()
        vals = [v[mask_flat] for v in vals]

    if vals[0].size == 0:
        n_bins = [len(b) - 1 for b in bins]
        return np.zeros(tuple(n_bins), dtype=np.float64)

    indices = []
    n_bins = []
    for k in range(n_dims):
        b = bins[k]
        nk = len(b) - 1
        n_bins.append(nk)

        v = np.clip(vals[k], b[0], b[-1] - 1e-10)
        idx = np.searchsorted(b, v, side="right") - 1
        idx = np.clip(idx, 0, nk - 1)
        indices.append(idx.astype(np.int64))

    strides = np.zeros(n_dims, dtype=np.int64)
    s = 1
    for k in range(n_dims - 1, -1, -1):
        strides[k] = s
        s *= n_bins[k]

    flat_idx = np.zeros(indices[0].size, dtype=np.int64)
    for k in range(n_dims):
        flat_idx += indices[k] * strides[k]

    flat_size = int(np.prod(n_bins))
    hist_flat = np.bincount(flat_idx, minlength=flat_size).astype(np.float64)

    histogram = hist_flat.reshape(tuple(n_bins))

    if normalize and histogram.sum() > 0:
        histogram /= histogram.sum()

    return histogram
