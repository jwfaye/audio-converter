"""Backward compatibility - re-exports from audition submodule."""

from attractor import DynamicAttractorConfig
from audition import (
    AuditoryPeripheryConfig,
    F0DetectionConfig,
    FrequencyInvarianceConfig,
    TemporalIntegrationConfig,
)

__all__ = [
    "AuditoryPeripheryConfig",
    "DynamicAttractorConfig",
    "F0DetectionConfig",
    "FrequencyInvarianceConfig",
    "TemporalIntegrationConfig",
]
