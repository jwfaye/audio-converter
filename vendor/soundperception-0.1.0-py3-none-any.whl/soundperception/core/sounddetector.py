"""Sound detection and filtering utilities using gammatone filterbanks."""

import math

import numpy as np
import pandas as pd
from gammatone.filters import centre_freqs, erb_filterbank, make_erb_filters
from numpy.lib.stride_tricks import sliding_window_view


def pos_erb_filter(wave, fs, channels, f_min, f_max):
    """Calculate ERB filterbank processed matrix with half-wave rectification."""
    cfs = centre_freqs(fs, channels, f_min, f_max)
    fcoefs = np.flipud(make_erb_filters(fs, cfs))
    xf = erb_filterbank(wave, fcoefs)
    xe = np.where(xf > 0, xf, 0)
    return xe


def gammatone_filtering(signal, sample_rate=16000, f_min=40, f_max=6500, num_filters=65):
    """Gammatone filtering through application of ERB filters."""
    return pos_erb_filter(signal, sample_rate, num_filters, f_min, f_max)


def delay_compensation(
    peaks, delay_path="src/gammatone_filters_compensation.csv", threshold_delta=6
):
    """Apply group delay compensation to signal.

    Args:
        peaks: Input signal
        delay_path: Path to file with delays per frequency channel
        threshold_delta: Threshold in dB from energy max

    Returns:
        Delay compensated signal
    """
    df = pd.read_csv(delay_path)
    max_peak = np.max(peaks)
    threshold = max_peak - threshold_delta
    cutted_peaks = np.where(peaks > threshold, peaks, 0)
    compensated_peaks = np.zeros_like(cutted_peaks)
    for canal in range(len(cutted_peaks)):
        gap = df["Gaps"].iloc[canal]
        if gap > 0:
            compensated_peaks[canal][:-gap] = cutted_peaks[canal][gap:]
    return compensated_peaks


def extract_peaks_optim(signal: np.ndarray) -> np.ndarray:
    """Extract peaks from signal using sliding window (size=5) and convert to dB scale."""
    windows = sliding_window_view(signal, window_shape=5, axis=1)
    local_max = windows.max(axis=2)
    center = signal[:, 2:-2]
    mask = (center > 1) & (center == local_max)
    peaks = np.zeros_like(signal)
    peaks[:, 2:-2][mask] = center[mask]
    log_peaks = np.where(peaks > 1, np.round(10 * np.log10(peaks), 0), 0)

    return log_peaks


def extract_cpt_ck_optim(peaks: np.ndarray, lim_coef: float = 1.5) -> np.ndarray:
    """Extract clock counter from peaks.

    Args:
        peaks: Peak-extracted signal
        lim_coef: Limit coefficient (not used, limit hardcoded to 450 samples)

    Returns:
        Clock counter array
    """
    peaks_bin = (peaks > 0).astype(float)
    counts = peaks_bin.sum(axis=1).max()
    n_cols = peaks.shape[1]
    limit = np.maximum(lim_coef, lim_coef * (n_cols / counts))
    limit = 450
    col_idx = np.arange(n_cols)
    pos = peaks_bin * col_idx[None, :]
    last_peak_idx = np.maximum.accumulate(pos, axis=1)
    row_has_no_peak = peaks_bin.sum(axis=1) < 1
    distance = col_idx[None, :] - last_peak_idx
    mask = (distance >= 0) & (distance < limit)
    first_peak_idx = np.argmax(peaks_bin, axis=1)
    after_first_peak = col_idx[None, :] >= first_peak_idx[:, None]
    final_mask = mask & after_first_peak
    cpt_ck = np.where(final_mask, distance + 1, 0)
    cpt_ck[row_has_no_peak, :] = 0
    cpt_ck[peaks > 0] = 1
    return cpt_ck


def extract_memo_ma_optim(peaks: np.ndarray, cpt_ck: np.ndarray) -> np.ndarray:
    """Extract amplitude memory from peaks and clock counter."""
    n_rows, n_cols = peaks.shape
    peaks_bin = peaks > 0
    col_idx = np.arange(n_cols)
    pos = peaks_bin * col_idx[None, :]
    last_peak_idx = np.maximum.accumulate(pos, axis=1)
    peak_vals = peaks[np.arange(n_rows)[:, None], last_peak_idx]
    np.concatenate([np.zeros((n_rows, 1), dtype=bool), cpt_ck[:, :-1] > 0], axis=1)
    memo_ma = peak_vals
    return memo_ma


def extract_memo_ck_optim(peaks: np.ndarray, cpt_ck: np.ndarray) -> np.ndarray:
    """Extract temporal memory from peaks and clock counter using logarithmic encoding."""
    memo_ck = np.zeros(cpt_ck.shape)
    for j in range(cpt_ck.shape[0]):
        for i in range(1, cpt_ck.shape[1]):
            if (peaks[j][i] > 0) and (cpt_ck[j][i - 1] > 0):
                memo_ck[j][i] = int(10 * math.log(cpt_ck[j][i - 1]))
            elif cpt_ck[j][i] > 0:
                memo_ck[j][i] = memo_ck[j][i - 1]
    return memo_ck
