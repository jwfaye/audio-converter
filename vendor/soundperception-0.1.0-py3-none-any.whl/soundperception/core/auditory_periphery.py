"""Backward compatibility - re-exports from audition submodule."""

from audition import AuditoryPeriphery

__all__ = ["AuditoryPeriphery"]
