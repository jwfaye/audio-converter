"""Core processing modules.

This subpackage contains:
- Auditory processing stages (re-exported from audition submodule)
- Dynamic attractor for pattern recognition (re-exported from attractor submodule)
"""

from attractor import (
    ADBilinear,
    AssociativeMemory,
    AttractorState,
    BilinearFrameResult,
    BilinearSegment,
    CascadeAttractorBank,
    CascadeFrameResult,
    CascadeLevel,
    CascadeMode,
    ConvergenceIteration,
    DetectedSegment,
    DynamicAttractor,
    DynamicAttractorConfig,
    FrameResult,
    MemoryCell,
    RecognitionResult,
)
from audition import (
    AuditoryPeriphery,
    AuditoryPeripheryConfig,
    F0DetectionConfig,
    F0Detector,
    FrequencyInvarianceConfig,
    FrequencyInvarianceExtractor,
    TemporalIntegrationConfig,
    TemporalIntegrator,
)
from soundperception.histograms import (
    BilinearHistogramComputer,
    BilinearHistogramConfig,
    SpectralHistogramComputer,
    SpectralHistogramConfig,
)

__all__ = [
    "AuditoryPeriphery",
    "AuditoryPeripheryConfig",
    "TemporalIntegrator",
    "TemporalIntegrationConfig",
    "F0Detector",
    "F0DetectionConfig",
    "FrequencyInvarianceExtractor",
    "FrequencyInvarianceConfig",
    "ADBilinear",
    "DynamicAttractor",
    "DynamicAttractorConfig",
    "AttractorState",
    "FrameResult",
    "BilinearFrameResult",
    "DetectedSegment",
    "BilinearSegment",
    "CascadeAttractorBank",
    "CascadeFrameResult",
    "CascadeLevel",
    "CascadeMode",
    "ConvergenceIteration",
    "BilinearHistogramComputer",
    "BilinearHistogramConfig",
    "SpectralHistogramComputer",
    "SpectralHistogramConfig",
    "AssociativeMemory",
    "MemoryCell",
    "RecognitionResult",
]
