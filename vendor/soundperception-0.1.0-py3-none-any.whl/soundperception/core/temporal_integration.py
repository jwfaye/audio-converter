"""Backward compatibility - re-exports from audition submodule."""

from audition import TemporalIntegrationConfig, TemporalIntegrator

__all__ = ["TemporalIntegrationConfig", "TemporalIntegrator"]
