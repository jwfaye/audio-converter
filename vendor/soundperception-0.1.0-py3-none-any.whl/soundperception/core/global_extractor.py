"""Global modality extractor for auditory signals.

Computes local mean and standard deviation over a sliding window (default 3x3).
This represents the "global" features of the signal.

Implementation uses pure numpy for numba compatibility.
"""

from dataclasses import dataclass

import numpy as np

from soundperception.module import InputSpec, OutputSpec, TensorShape, module

__all__ = ["GlobalExtractorConfig", "GlobalExtractor"]


@dataclass
class GlobalExtractorConfig:
    """Configuration for global feature extraction.

    Attributes:
        kernel_size: Size of the sliding window (default: 3 for 3x3).

    Example:
        config = GlobalExtractorConfig(kernel_size=5)
        config_default = GlobalExtractorConfig.default()
    """

    kernel_size: int = 3

    @classmethod
    def default(cls) -> "GlobalExtractorConfig":
        """Create default configuration with 3x3 kernel."""
        return cls(kernel_size=3)


def _uniform_filter_2d(signal: np.ndarray, kernel_size: int) -> np.ndarray:
    """Apply uniform (box) filter using cumulative sums.

    This is a pure numpy implementation compatible with numba.

    Args:
        signal: 2D input array.
        kernel_size: Size of the square kernel.

    Returns:
        Filtered array with same shape as input.
    """
    h, w = signal.shape
    pad = kernel_size // 2

    padded = np.pad(signal, ((pad, pad), (pad, pad)), mode="constant", constant_values=0)

    integral = np.cumsum(np.cumsum(padded, axis=0), axis=1)

    result = np.zeros_like(signal, dtype=np.float64)

    for i in range(h):
        for j in range(w):
            y_end = i + kernel_size
            x_end = j + kernel_size
            y_start = i
            x_start = j

            total = integral[y_end, x_end]
            if y_start > 0:
                total -= integral[y_start - 1, x_end]
            if x_start > 0:
                total -= integral[y_end, x_start - 1]
            if y_start > 0 and x_start > 0:
                total += integral[y_start - 1, x_start - 1]

            result[i, j] = total

    return result / (kernel_size * kernel_size)


def _uniform_filter_2d_fast(signal: np.ndarray, kernel_size: int) -> np.ndarray:
    """Apply uniform (box) filter using cumulative sums - vectorized version.

    Args:
        signal: 2D input array.
        kernel_size: Size of the square kernel.

    Returns:
        Filtered array with same shape as input.
    """
    h, w = signal.shape
    pad = kernel_size // 2

    padded = np.pad(signal, ((pad, pad), (pad, pad)), mode="constant", constant_values=0)

    integral = np.cumsum(np.cumsum(padded.astype(np.float64), axis=0), axis=1)

    integral_padded = np.zeros((integral.shape[0] + 1, integral.shape[1] + 1), dtype=np.float64)
    integral_padded[1:, 1:] = integral

    result = (
        integral_padded[kernel_size : kernel_size + h, kernel_size : kernel_size + w]
        - integral_padded[0:h, kernel_size : kernel_size + w]
        - integral_padded[kernel_size : kernel_size + h, 0:w]
        + integral_padded[0:h, 0:w]
    )

    return result / (kernel_size * kernel_size)


@module(
    inputs={
        "signal": InputSpec(
            name="signal",
            dtype=np.ndarray,
            description="2D input signal (n_channels × n_frames)",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
    },
    outputs={
        "mean": OutputSpec(
            name="mean",
            dtype=np.ndarray,
            description="Local mean (n_channels × n_frames)",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
        "std": OutputSpec(
            name="std",
            dtype=np.ndarray,
            description="Local standard deviation (n_channels × n_frames)",
            shape=TensorShape(("n_channels", "n_frames")),
        ),
    },
    method="process",
    description="Extract global modality features (local mean and std) from auditory signals.",
)
class GlobalExtractor:
    """Extract global modality features from auditory signals.

    Computes local mean (Moy) and standard deviation (Var) over a sliding
    window. These features capture the local amplitude characteristics
    of the signal.

    Example:
        >>> extractor = GlobalExtractor(GlobalExtractorConfig.default())
        >>> result = extractor.process(memo_ma_integrated)
        >>> # Or via __call__:
        >>> result = extractor(signal=memo_ma_integrated)
        >>> mean = result["mean"]  # Local mean
        >>> std = result["std"]    # Local standard deviation
    """

    def __init__(self, config: GlobalExtractorConfig):
        """Initialize extractor with configuration.

        Args:
            config: Extraction configuration.
        """
        self.config = config

    def process(self, signal: np.ndarray) -> dict[str, np.ndarray]:
        """Process a 2D signal to extract global features.

        Args:
            signal: 2D array (n_channels × n_frames).

        Returns:
            Dictionary containing:
            - 'mean': Local mean (n_channels × n_frames)
            - 'std': Local standard deviation (n_channels × n_frames)

        Example:
            extractor = GlobalExtractor(GlobalExtractorConfig(kernel_size=3))
            signal = np.random.randint(0, 100, size=(65, 200))
            result = extractor.process(signal)
            mean = result["mean"]  # shape (65, 200)
            std = result["std"]    # shape (65, 200)
        """
        signal_f = signal.astype(np.float64)
        kernel_size = self.config.kernel_size

        mean = np.round(_uniform_filter_2d_fast(signal_f, kernel_size)).astype(np.int32)

        mean_sq = _uniform_filter_2d_fast(signal_f**2, kernel_size)
        mean_f = _uniform_filter_2d_fast(signal_f, kernel_size)
        variance = mean_sq - mean_f**2
        variance = np.maximum(variance, 0.0)
        std = np.sqrt(variance)

        std = np.round(std).astype(np.int32)

        return {
            "mean": mean,
            "std": std,
        }
