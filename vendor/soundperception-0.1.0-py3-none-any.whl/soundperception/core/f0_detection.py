"""Backward compatibility - re-exports from audition submodule."""

from audition import F0DetectionConfig, F0Detector

__all__ = ["F0Detector", "F0DetectionConfig"]
