"""Backward compatibility - re-exports from attractor submodule."""

from attractor.core.base._numba_kernels import (
    bhattacharyya_distance_numba,
    build_spectral_histograms_numba,
    categorize_histogram_numba,
    dilate_mask_numba,
    fill_interior_holes_numba,
    find_connected_components_numba,
    keep_largest_component_numba,
    smooth_1d_numba,
)

__all__ = [
    "bhattacharyya_distance_numba",
    "build_spectral_histograms_numba",
    "categorize_histogram_numba",
    "dilate_mask_numba",
    "fill_interior_holes_numba",
    "find_connected_components_numba",
    "keep_largest_component_numba",
    "smooth_1d_numba",
]
