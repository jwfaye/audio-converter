"""Correlogram computation from cochlear output.

Implements the short-time autocorrelation of each cochlear channel,
following Slaney & Lyon (1993) "On the Importance of Time" and
Malcolm Slaney's Python Auditory Toolbox.

The correlogram is a 3D representation: (n_frames, n_channels, n_lags)
- Frames: time progression
- Channels: cochlear frequency channels
- Lags: autocorrelation delay (periodicity)

References:
    Slaney, M. & Lyon, R. F. (1993). On the Importance of Time.
    Slaney, M. Python Auditory Toolbox (CorrelogramFrame/Array/Pitch).
    Licklider, J.C.R. (1951). A Duplex Theory of Pitch Perception.
"""

import math

import numpy as np
from scipy.signal import lfilter


def correlogram_frame(
    data: np.ndarray,
    width: int,
    start: int = 0,
    win_len: int = 0,
) -> np.ndarray:
    """Compute one frame of the correlogram using FFT-based autocorrelation.

    Adapted from Slaney's CorrelogramFrame.

    Args:
        data: Cochleagram, shape (n_channels, n_samples).
        width: Number of lags in the output.
        start: Starting sample index.
        win_len: Window length. If 0, uses full data length.

    Returns:
        One correlogram frame, shape (n_channels, width).
        Normalized by sqrt(power at lag 0).
    """
    channels, data_len = data.shape
    if not win_len:
        win_len = data_len

    fft_size = int(2 ** np.ceil(np.log2(2 * max(width, win_len))))

    start = max(0, start)
    last = min(data_len, start + win_len)
    actual_len = last - start

    a = 0.54
    b = -0.46
    wr = math.sqrt(64 / 256)
    phi = np.pi / win_len
    ws = (
        2
        * wr
        / np.sqrt(4 * a * a + 2 * b * b)
        * (a + b * np.cos(2 * np.pi * np.arange(win_len) / win_len + phi))
    )

    f = np.zeros((channels, fft_size), dtype=np.float64)
    f[:, :actual_len] = data[:, start:last] * ws[:actual_len]
    f = np.fft.fft(f, axis=1)
    f = np.fft.ifft(f * np.conj(f), axis=1)
    pic = np.maximum(0, np.real(f[:, :width]))

    good_rows = (pic[:, 0] > 0) & (pic[:, 0] > pic[:, 1]) & (pic[:, 0] > pic[:, 2])
    pic = np.where(
        good_rows[:, np.newaxis],
        pic / np.sqrt(pic[:, :1]),
        0.0,
    )

    return pic


def correlogram_array(
    data: np.ndarray,
    sr: int = 16000,
    frame_rate: float = 12.0,
    width: int = 256,
) -> dict:
    """Compute the full correlogram as a sequence of frames.

    Adapted from Slaney's CorrelogramArray.

    Args:
        data: Cochleagram (IHC output), shape (n_channels, n_samples).
        sr: Sample rate in Hz.
        frame_rate: Output frame rate in Hz.
        width: Number of lags (determines lowest detectable pitch).

    Returns:
        Dictionary with:
        - "correlogram": array (n_frames, n_channels, width)
        - "lag_times": array (width,), lag values in seconds
        - "frame_times": array (n_frames,), frame center times in seconds
        - "sr": sample rate
        - "width": number of lags
    """
    _, sample_len = data.shape
    frame_increment = int(sr / frame_rate)
    frame_count = max(1, (sample_len - width) // frame_increment + 1)

    movie = None
    for i in range(frame_count):
        start = i * frame_increment
        frame = correlogram_frame(data, width, start, frame_increment * 4)
        if movie is None:
            movie = np.zeros((frame_count, frame.shape[0], frame.shape[1]), dtype=np.float64)
        movie[i, :, :] = frame

    lag_times = np.arange(width) / sr
    frame_times = (np.arange(frame_count) * frame_increment + width // 2) / sr

    return {
        "correlogram": movie,
        "lag_times": lag_times,
        "frame_times": frame_times,
        "sr": sr,
        "width": width,
    }


def correlogram_pitch(
    correlogram: np.ndarray,
    width: int,
    sr: int = 16000,
    low_pitch: float = 80.0,
    high_pitch: float = 400.0,
) -> tuple[np.ndarray, np.ndarray]:
    """Extract pitch from the correlogram using Slaney's method.

    For each frame:
    1. Compute summary correlogram (sum across channels)
    2. Smooth and compute derivative to find first valley
    3. Zero out the initial decay region
    4. Find the largest peak in the valid pitch range

    Adapted from Slaney's CorrelogramPitch.

    Args:
        correlogram: array (n_frames, n_channels, width)
        width: Number of lags.
        sr: Sample rate in Hz.
        low_pitch: Lowest detectable pitch in Hz.
        high_pitch: Highest detectable pitch in Hz.

    Returns:
        Tuple of:
        - pitch: array (n_frames,), detected pitch in Hz (0 = no pitch)
        - salience: array (n_frames,), pitch clarity 0-1
    """
    drop_low = int(sr / high_pitch)
    drop_high = int(min(width, math.ceil(sr / low_pitch))) if low_pitch > 0 else width

    n_frames = correlogram.shape[0]
    pitch = np.zeros(n_frames)
    salience = np.zeros(n_frames)

    for j in range(n_frames):
        summary = np.sum(correlogram[j, :, :], axis=0)
        zero_lag = summary[0]

        if zero_lag <= 0:
            continue

        window_length = 16
        sumfilt = lfilter(np.ones(window_length), [1.0], summary)
        sumdif = sumfilt[1:width] - sumfilt[: width - 1]
        sumdif[:window_length] = 0

        valleys = np.argwhere(sumdif > 0)
        if len(valleys) == 0:
            continue

        summary[: int(valleys[0, 0])] = 0
        summary[1:drop_low] = 0
        summary[drop_high:] = 0

        p = np.argmax(summary)
        if p > 0:
            pitch[j] = sr / float(p)
        salience[j] = summary[p] / zero_lag

    return pitch, salience


def summary_correlogram(correlogram: np.ndarray) -> np.ndarray:
    """Compute summary correlogram by summing across channels.

    Args:
        correlogram: array (n_frames, n_channels, width)

    Returns:
        array (n_frames, width)
    """
    return np.sum(correlogram, axis=1)


def spectral_profile(correlogram: np.ndarray) -> np.ndarray:
    """Compute spectral profile by summing across lags.

    The spectral profile shows energy per channel, revealing
    the formant structure (spectral envelope).

    Args:
        correlogram: array (n_frames, n_channels, width)

    Returns:
        array (n_frames, n_channels)
    """
    return np.sum(correlogram, axis=2)
