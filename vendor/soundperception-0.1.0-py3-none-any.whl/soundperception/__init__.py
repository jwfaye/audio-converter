"""SoundGenerator: Auditory model for cochlear processing and frequency-invariant sound analysis.

This package implements a complete auditory processing pipeline that simulates
the human auditory periphery and extracts harmonic signatures independent of
fundamental frequency.

The auditory processing stages are provided by the audition submodule.
"""

__version__ = "0.1.0"

from soundperception.audition import (
    AuditoryPeriphery,
    AuditoryPeripheryConfig,
    F0DetectionConfig,
    F0Detector,
    FrequencyInvarianceConfig,
    FrequencyInvarianceExtractor,
    TemporalIntegrationConfig,
    TemporalIntegrator,
    load_audio,
)

__all__ = [
    "AuditoryPeriphery",
    "AuditoryPeripheryConfig",
    "TemporalIntegrator",
    "TemporalIntegrationConfig",
    "F0Detector",
    "F0DetectionConfig",
    "FrequencyInvarianceExtractor",
    "FrequencyInvarianceConfig",
    "load_audio",
]
