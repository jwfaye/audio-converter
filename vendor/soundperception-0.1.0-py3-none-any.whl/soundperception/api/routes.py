"""REST endpoints: word listing, audio serving, file upload, synthesis."""

import base64
import io
import shutil
import uuid
from pathlib import Path

import numpy as np
import soundfile as sf
from fastapi import APIRouter, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

from soundperception.audition import (
    AuditoryPeriphery,
    AuditoryPeripheryConfig,
    TemporalIntegrationConfig,
    TemporalIntegrator,
)
from soundperception.synthesis.make_vowel import make_vowel
from soundperception.api import rendering

router = APIRouter()

DATA_DIR = Path("data/diction_phonemes")
UPLOAD_DIR = Path("output/uploads")
OUTPUT_DIR = Path("output")


@router.get("/words")
async def list_words():
    """Return sorted list of available words."""
    words = sorted(
        d.name for d in DATA_DIR.iterdir() if d.is_dir() and (d / f"{d.name}.wav").exists()
    )
    return {"words": words}


@router.post("/upload")
async def upload_wav(file: UploadFile):
    """Save uploaded WAV file. Returns an ID to use with the pipeline."""
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    file_id = str(uuid.uuid4())[:8]
    dest = UPLOAD_DIR / f"{file_id}.wav"
    with open(dest, "wb") as f:
        shutil.copyfileobj(file.file, f)
    return {"id": file_id, "filename": file.filename}


@router.get("/audio/{word}")
async def get_audio(word: str):
    """Serve original audio file."""
    wav_path = DATA_DIR / word / f"{word}.wav"
    if not wav_path.exists():
        return JSONResponse({"error": "not found"}, status_code=404)
    return FileResponse(wav_path, media_type="audio/wav")


@router.get("/synth/{word}")
async def get_synth(word: str):
    """Serve synthesized audio file."""
    wav_path = OUTPUT_DIR / f"synth_{word}.wav"
    if not wav_path.exists():
        return JSONResponse({"error": "not found"}, status_code=404)
    return FileResponse(wav_path, media_type="audio/wav")


@router.get("/upload-audio/{file_id}")
async def get_uploaded_audio(file_id: str):
    """Serve uploaded audio file."""
    wav_path = UPLOAD_DIR / f"{file_id}.wav"
    if not wav_path.exists():
        return JSONResponse({"error": "not found"}, status_code=404)
    return FileResponse(wav_path, media_type="audio/wav")


@router.get("/segment-reprojection/{seg_index}")
async def get_segment_reprojection(seg_index: int):
    """Return reprojection data for a segment from the last pipeline run."""
    from soundperception.api.websocket import last_runner
    from soundperception.utils.compute_freq_canals import compute_freq_canals

    if last_runner is None or not last_runner.seg_data:
        return JSONResponse({"error": "No pipeline data available"}, status_code=404)
    if seg_index >= len(last_runner.seg_data):
        return JSONResponse({"error": "Segment index out of range"}, status_code=404)

    sd = last_runner.seg_data[seg_index]
    center_freqs = compute_freq_canals(last_runner.n_channels, 40.0, 6500.0)

    # Compute segment duration from frames
    ts, te = sd["t_start"], sd["t_end"]
    seg_duration = (te - ts) * last_runner.frame_duration

    # F0 from reprojection (snapped to MA peak)
    f0_entry = next((rp for rp in sd["reprojection"] if rp["is_f0"]), None)
    pitch_freq = float(center_freqs[f0_entry["channel"]]) if f0_entry else 0.0

    # Render formant detection image
    formant_img = rendering.render_formant_detection(sd, last_runner.n_channels)
    formant_b64 = base64.b64encode(formant_img).decode()

    return {
        "reprojection": sd["reprojection"],
        "formants": sd.get("formants", []),
        "formant_image": formant_b64,
        "pitch_freq": pitch_freq,
        "segment_duration": round(seg_duration, 4),
        "channel_freqs": [float(f) for f in center_freqs],
    }


class SynthesizeRequest(BaseModel):
    """Request body for segment synthesis endpoint."""

    pitch: float
    formants: list[float]
    gains: list[float]
    mode: str = "cascade"
    duration: float | None = None
    sample_rate: int = 16000
    padding: float = 0.2


@router.post("/synthesize-segment")
async def synthesize_segment(req: SynthesizeRequest):
    """Synthesize a segment using make_vowel and return WAV + spectrogram."""
    fs = req.sample_rate
    duration = req.duration or 0.5
    n_samples = int(duration * fs)
    pad_samples = int(req.padding * fs)

    if not req.formants:
        return JSONResponse({"error": "No formants to synthesize"}, status_code=400)

    if req.mode == "additive":
        # Improved additive: random phases, jitter, shimmer, breath noise
        signal = np.zeros(n_samples)

        # Jitter: slow random modulation of F0 (~0.5%)
        jitter = 1.0 + 0.005 * np.cumsum(np.random.randn(n_samples)) / fs
        jitter = jitter / np.max(np.abs(jitter)) * 0.005 + 1.0

        # All harmonics: F0 + overtones
        all_freqs = [req.pitch] + list(req.formants)
        all_gains = [1.0] + list(req.gains)

        for freq, gain in zip(all_freqs, all_gains):
            phi = np.random.uniform(0, 2 * np.pi)
            # Shimmer: per-cycle amplitude variation (~3%)
            shimmer = 1.0 + 0.03 * np.random.randn(n_samples)
            # Instantaneous frequency with jitter (proportional to harmonic number)
            inst_freq = freq * jitter
            phase = np.cumsum(2 * np.pi * inst_freq / fs)
            signal += gain * shimmer * np.sin(phase + phi)

        # Add shaped breath noise (-22 dB relative)
        noise = np.random.randn(n_samples)
        # Simple spectral shaping: low-pass
        from scipy.signal import butter, filtfilt

        b_lp, a_lp = butter(2, min(req.pitch * 10, fs * 0.45) / (fs / 2))
        noise = filtfilt(b_lp, a_lp, noise)
        noise_level = 10 ** (-22 / 20)
        signal += noise_level * noise

        # Temporal envelope: fade in/out (20ms)
        fade = int(0.02 * fs)
        if fade > 0 and n_samples > 2 * fade:
            signal[:fade] *= np.linspace(0, 1, fade)
            signal[-fade:] *= np.linspace(1, 0, fade)

    elif req.mode == "spline":
        # Spline envelope: interpolate harmonic amplitudes to find formants
        from scipy.interpolate import CubicSpline
        from scipy.signal import find_peaks as scipy_find_peaks

        all_freqs_arr = np.array([req.pitch] + list(req.formants))
        all_gains_arr = np.array([1.0] + list(req.gains))
        sort_idx = np.argsort(all_freqs_arr)
        all_freqs_arr = all_freqs_arr[sort_idx]
        all_gains_arr = all_gains_arr[sort_idx]

        if len(all_freqs_arr) >= 3:
            cs = CubicSpline(all_freqs_arr, all_gains_arr)
            f_cont = np.linspace(all_freqs_arr[0], all_freqs_arr[-1], 1000)
            envelope = cs(f_cont)
            peaks_idx, _ = scipy_find_peaks(envelope, distance=30)
            # Filter: only peaks above F0 region
            formant_freqs = [float(f_cont[p]) for p in peaks_idx if f_cont[p] > 1.5 * req.pitch]
            if not formant_freqs:
                formant_freqs = list(req.formants[:3])
        else:
            formant_freqs = list(req.formants[:3])

        signal = make_vowel(n_samples, req.pitch, formant_freqs, fs=fs)

    elif req.mode == "formant":
        # Formant mode: use extracted formant frequencies (broad peaks) with make_vowel cascade
        signal = make_vowel(n_samples, req.pitch, req.formants, fs=fs)
    elif req.mode == "parallel":
        signal = make_vowel(n_samples, req.pitch, req.formants, gains=req.gains, fs=fs)
    else:
        signal = make_vowel(n_samples, req.pitch, req.formants, fs=fs)

    # Normalize to int16 scale for cochlear processing, then scale for WAV
    peak = np.max(np.abs(signal))
    if peak > 0:
        signal = signal / peak
    # Scale to int16 range for cochlear decomposition
    signal_cochlear = signal * 20000.0
    # Scale to 0.8 for WAV output
    signal_wav = signal * 0.8

    # Pad (for WAV output)
    padded = np.concatenate(
        [
            np.zeros(pad_samples),
            signal_wav,
            np.zeros(pad_samples),
        ]
    )

    # WAV to base64
    wav_buf = io.BytesIO()
    sf.write(wav_buf, padded, fs, format="WAV")
    wav_b64 = base64.b64encode(wav_buf.getvalue()).decode()

    # Spectrogram
    spec_img = rendering.render_spectrogram(padded, fs)
    spec_b64 = base64.b64encode(spec_img).decode()

    # Cochlear decomposition of the synthesized signal (int16 scale)
    periphery = AuditoryPeriphery(AuditoryPeripheryConfig.default())
    stages = periphery.process(signal_cochlear, fs)
    integrator = TemporalIntegrator(TemporalIntegrationConfig.default())
    integrated = integrator.process(stages["memo_ma"], stages["memo_ck"])
    synth_ma = integrated["memo_ma"]

    # Compute MA energy per channel (same as pipeline)
    n_channels = synth_ma.shape[0]
    ma_per_ch = np.full(n_channels, np.nan)
    for ch in range(n_channels):
        vals = synth_ma[ch]
        vals = vals[vals >= 0]
        if len(vals) > 0:
            ma_per_ch[ch] = np.sum(vals)

    profile_img = rendering.render_cochlear_profile(ma_per_ch, n_channels)
    profile_b64 = base64.b64encode(profile_img).decode()

    return {
        "wav_b64": wav_b64,
        "spectrogram": spec_b64,
        "spectral_profile": profile_b64,
        "duration": duration,
        "total_duration": duration + 2 * req.padding,
        "mode": req.mode,
    }
