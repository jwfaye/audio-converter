"""WebSocket endpoint: streams pipeline stages as base64 PNG images."""

import asyncio
import base64
import traceback

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from soundperception.api.pipeline_runner import PipelineRunner
from soundperception.api import rendering

ws_router = APIRouter()

# Last completed pipeline runner, accessible by REST endpoints for synthesis
last_runner: PipelineRunner | None = None

STAGES = [
    "periphery",
    "stability_histogram",
    "stability_map",
    "segmentation",
    "ck_stable",
    "joint_histograms",
    "frequency_summary",
    "segment_profiles",
    "reprojection",
    "formant_detection",
    "synthesis",
]


async def _send_stage(ws: WebSocket, stage: str, status: str, **kwargs):
    msg = {"stage": stage, "status": status}
    msg.update(kwargs)
    await ws.send_json(msg)


async def _run_pipeline(ws: WebSocket, runner: PipelineRunner):
    """Execute pipeline stage by stage, sending results over WebSocket."""
    await _send_stage(ws, "periphery", "running")
    meta = await asyncio.to_thread(runner.run_periphery)
    await asyncio.to_thread(runner.run_global_extraction)
    img = await asyncio.to_thread(rendering.render_periphery, runner.memo_ma, runner.memo_ck)
    await _send_stage(ws, "periphery", "done", image=base64.b64encode(img).decode(), metadata=meta)

    await _send_stage(ws, "stability_histogram", "running")
    stab_meta = await asyncio.to_thread(runner.run_stability)
    img = await asyncio.to_thread(
        rendering.render_stability_histogram,
        runner.hist_std,
        runner.labels_std,
        runner.marginal_ma,
        runner.marginal_ck,
        runner.thresh_ma,
        runner.thresh_ck,
        runner.stable_cat,
    )
    await _send_stage(
        ws, "stability_histogram", "done", image=base64.b64encode(img).decode(), metadata=stab_meta
    )

    await _send_stage(ws, "stability_map", "running")
    img = await asyncio.to_thread(
        rendering.render_stability_map,
        runner.pixel_stability,
        runner.memo_ma,
        runner.memo_ck,
    )
    await _send_stage(ws, "stability_map", "done", image=base64.b64encode(img).decode())

    await _send_stage(ws, "segmentation", "running")
    await asyncio.to_thread(runner.run_structural)
    seg_meta = await asyncio.to_thread(runner.run_segmentation)
    img = await asyncio.to_thread(
        rendering.render_segmentation,
        runner.memo_ma,
        runner.sep_peaks,
        runner.n_channels_90,
        runner.n_segments,
    )
    await _send_stage(
        ws, "segmentation", "done", image=base64.b64encode(img).decode(), metadata=seg_meta
    )

    await _send_stage(ws, "ck_stable", "running")
    analysis_meta = await asyncio.to_thread(runner.run_segment_analysis)
    img = await asyncio.to_thread(
        rendering.render_ck_stable,
        runner.memo_ck,
        runner.pixel_stability,
        runner.sep_peaks,
        runner.seg_data,
    )
    await _send_stage(ws, "ck_stable", "done", image=base64.b64encode(img).decode())

    await _send_stage(ws, "joint_histograms", "running")
    img = await asyncio.to_thread(
        rendering.render_joint_histograms,
        runner.memo_ck,
        runner.memo_ma,
        runner.pixel_stability,
        runner.seg_data,
    )
    await _send_stage(
        ws, "joint_histograms", "done", image=base64.b64encode(img).decode(), metadata=analysis_meta
    )

    await _send_stage(ws, "frequency_summary", "running")
    img = await asyncio.to_thread(
        rendering.render_frequency_summary,
        runner.seg_data,
        runner.sep_peaks,
        runner.n_frames,
    )
    await _send_stage(ws, "frequency_summary", "done", image=base64.b64encode(img).decode())

    await _send_stage(ws, "segment_profiles", "running")
    segment_images = []
    for seg_i, sd in enumerate(runner.seg_data):
        img = await asyncio.to_thread(
            rendering.render_single_segment_profile,
            sd,
            seg_i,
            runner.n_channels,
        )
        segment_images.append(base64.b64encode(img).decode())
    await _send_stage(
        ws,
        "segment_profiles",
        "done",
        segments=segment_images,
        metadata={"n_segments": runner.n_segments},
    )

    await _send_stage(ws, "reprojection", "running")
    reproj_images = []
    for seg_i, sd in enumerate(runner.seg_data):
        img = await asyncio.to_thread(
            rendering.render_reprojection,
            sd,
            seg_i,
            runner.n_channels,
        )
        reproj_images.append(base64.b64encode(img).decode())
    await _send_stage(
        ws,
        "reprojection",
        "done",
        segments=reproj_images,
        metadata={"n_segments": runner.n_segments},
    )

    await _send_stage(ws, "formant_detection", "running")
    formant_images = []
    for seg_i, sd in enumerate(runner.seg_data):
        img = await asyncio.to_thread(
            rendering.render_formant_detection,
            sd,
            runner.n_channels,
        )
        formant_images.append(base64.b64encode(img).decode())
    await _send_stage(
        ws,
        "formant_detection",
        "done",
        segments=formant_images,
        metadata={"n_segments": runner.n_segments},
    )

    global last_runner
    last_runner = runner

    await _send_stage(ws, "complete", "done")


@ws_router.websocket("/ws/pipeline/{word}")
async def pipeline_ws(websocket: WebSocket, word: str):
    """WebSocket endpoint to run pipeline for a word."""
    await websocket.accept()
    try:
        runner = PipelineRunner(word)
        await _run_pipeline(websocket, runner)
    except WebSocketDisconnect:
        pass
    except Exception as e:
        try:
            await websocket.send_json(
                {
                    "stage": "error",
                    "status": "error",
                    "message": str(e),
                    "traceback": traceback.format_exc(),
                }
            )
        except Exception:
            pass
    finally:
        try:
            await websocket.close()
        except Exception:
            pass


@ws_router.websocket("/ws/pipeline-upload/{file_id}")
async def pipeline_upload_ws(websocket: WebSocket, file_id: str):
    """WebSocket endpoint to run pipeline for an uploaded file."""
    await websocket.accept()
    try:
        wav_path = f"output/uploads/{file_id}.wav"
        runner = PipelineRunner(word=file_id, wav_path=wav_path)
        await _run_pipeline(websocket, runner)
    except WebSocketDisconnect:
        pass
    except Exception as e:
        try:
            await websocket.send_json(
                {
                    "stage": "error",
                    "status": "error",
                    "message": str(e),
                    "traceback": traceback.format_exc(),
                }
            )
        except Exception:
            pass
    finally:
        try:
            await websocket.close()
        except Exception:
            pass
