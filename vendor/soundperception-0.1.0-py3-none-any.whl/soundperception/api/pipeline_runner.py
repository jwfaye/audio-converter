"""Pipeline runner: wraps the cochlear analysis pipeline for the web API."""

from pathlib import Path

import numpy as np
import soundfile as sf

from soundperception.audition import (
    AuditoryPeriphery,
    AuditoryPeripheryConfig,
    TemporalIntegrationConfig,
    TemporalIntegrator,
)
from soundperception.audition.utils.audio_io import load_audio
from soundperception.core.global_extractor import GlobalExtractor, GlobalExtractorConfig
from soundperception.histograms.structural_extractor import (
    StructuralExtractor,
    StructuralExtractorConfig,
)
from soundperception.histograms import (
    build_joint_histogram,
    auto_grid_categorize_histogram,
    find_marginal_thresholds,
)
from soundperception.utils.peak_detection import find_peaks
from soundperception.utils.compute_freq_canals import compute_freq_canals


def find_profile_peaks(profile, size=5, min_ratio=0.1):
    """Find peaks in a 1D profile using local maxima detection."""
    return find_peaks(profile, size=size, min_ratio=min_ratio)


class PipelineRunner:
    """Runs the cochlear pipeline stage by stage, storing intermediate results."""

    SR_OUT = 16000
    DECIMATION = 100

    def __init__(self, word: str, wav_path: str | None = None):
        """Initialize pipeline runner for a given word."""
        self.word = word
        self.wav_path = wav_path or f"data/diction_phonemes/{word}/{word}.wav"
        self.center_freqs = compute_freq_canals(65, 40.0, 6500.0)
        self.frame_duration = self.DECIMATION / self.SR_OUT

    def run_periphery(self) -> dict:
        """Load audio, run periphery + integration. Returns metadata."""
        self.audio, sr = load_audio(self.wav_path)

        periphery = AuditoryPeriphery(AuditoryPeripheryConfig.default())
        stages = periphery.process(self.audio, sr)

        integrator = TemporalIntegrator(TemporalIntegrationConfig.default())
        integrated = integrator.process(stages["memo_ma"], stages["memo_ck"])

        self.memo_ma = integrated["memo_ma"]
        self.memo_ck = integrated["memo_ck"]
        self.presence = self.memo_ma >= 0
        self.n_channels, self.n_frames = self.memo_ma.shape

        return {
            "n_channels": int(self.n_channels),
            "n_frames": int(self.n_frames),
            "duration": float(len(self.audio) / sr),
            "sr": int(sr),
        }

    def run_global_extraction(self) -> dict:
        """Run GlobalExtractor on memo_ma/ck."""
        memo_ma_clean = np.where(self.presence, self.memo_ma, 0.0)
        memo_ck_clean = np.where(self.presence, self.memo_ck, 0.0)

        global_ext = GlobalExtractor(GlobalExtractorConfig.default())
        self.global_ma = global_ext.process(memo_ma_clean)
        self.global_ck = global_ext.process(memo_ck_clean)

        for out in (self.global_ma, self.global_ck):
            for k in out:
                out[k] = np.where(self.presence, out[k], -1)

        return {}

    def run_stability(self) -> dict:
        """Build stability histogram, auto-grid, pixel_stability map."""
        std_ma = self.global_ma["std"]
        std_ck = self.global_ck["std"]
        valid_ma = std_ma[self.presence]
        valid_ck = std_ck[self.presence]

        bins_ma_range = np.arange(0, int(valid_ma.max()) + 2, dtype=np.float64)
        bins_ck_range = np.arange(0, int(valid_ck.max()) + 2, dtype=np.float64)
        self.hist_std, self.bins_ma, self.bins_ck = build_joint_histogram(
            std_ma, std_ck, mask=self.presence, bins=[bins_ma_range, bins_ck_range]
        )

        self.labels_std = auto_grid_categorize_histogram(self.hist_std)
        self.stable_cat = self.labels_std[0, 0]

        self.marginal_ma = self.hist_std.sum(axis=0)
        self.marginal_ck = self.hist_std.sum(axis=1)
        self.thresh_ma = find_marginal_thresholds(self.marginal_ma)
        self.thresh_ck = find_marginal_thresholds(self.marginal_ck)

        std_ma_vals = np.where(self.presence, std_ma, 0)
        std_ck_vals = np.where(self.presence, std_ck, 0)
        ma_idx = np.clip(
            np.searchsorted(self.bins_ma, std_ma_vals.ravel(), side="right") - 1,
            0,
            self.hist_std.shape[1] - 1,
        )
        ck_idx = np.clip(
            np.searchsorted(self.bins_ck, std_ck_vals.ravel(), side="right") - 1,
            0,
            self.hist_std.shape[0] - 1,
        )
        pixel_cats = self.labels_std[ck_idx, ma_idx].reshape(std_ma.shape)

        self.pixel_stability = np.full_like(self.memo_ma, -1.0)
        self.pixel_stability[self.presence] = np.where(
            pixel_cats[self.presence] == self.stable_cat, 1.0, 2.0
        )

        return {
            "n_cats": int(self.labels_std.max()),
            "stable_cat": int(self.stable_cat),
            "thresh_ma": [int(t) for t in self.thresh_ma],
            "thresh_ck": [int(t) for t in self.thresh_ck],
        }

    def run_structural(self) -> dict:
        """StructuralExtractor + structural categories on unstable pixels."""
        memo_ma_clean = np.where(self.presence, self.memo_ma, 0.0)
        struct_ext = StructuralExtractor(StructuralExtractorConfig.default())
        self.struct_ma = struct_ext.process(memo_ma_clean)

        unstable_mask = self.pixel_stability == 2
        struct_valid = unstable_mask & (self.struct_ma["ma"] >= 0)
        sma_vals = np.floor(self.struct_ma["ma"] / 15).astype(int) * 15
        bins_sma = np.arange(-7.5, 188, 15.0)

        hist_struct_path = Path("output/hist_struct_cumul.npy")
        if hist_struct_path.exists():
            hist_struct = np.load(hist_struct_path)
        else:
            sva_vals = self.struct_ma["va"]
            bins_sva = np.arange(0, 7, dtype=np.float64)
            h, _, _ = np.histogram2d(
                sva_vals[struct_valid].ravel(),
                sma_vals[struct_valid].ravel(),
                bins=[bins_sva, bins_sma],
            )
            hist_struct = h

        self.hist_struct = hist_struct
        labels_struct_path = Path("output/labels_struct_cumul.npy")
        if labels_struct_path.exists():
            labels_struct = np.load(labels_struct_path)
        else:
            labels_struct = auto_grid_categorize_histogram(hist_struct)
        self.labels_struct = labels_struct
        self.bins_sma = bins_sma

        sma_idx = np.clip(
            np.searchsorted(bins_sma, sma_vals.ravel(), side="right") - 1,
            0,
            hist_struct.shape[1] - 1,
        )
        sva_vals = self.struct_ma["va"]
        bins_sva = np.arange(0, 7, dtype=np.float64)
        sva_idx = np.clip(
            np.searchsorted(bins_sva, sva_vals.ravel(), side="right") - 1,
            0,
            hist_struct.shape[0] - 1,
        )
        pixel_struct_cats = labels_struct[sva_idx, sma_idx].reshape(sma_vals.shape)

        self.pixel_struct = np.full_like(self.memo_ma, -1.0)
        self.pixel_struct[self.presence] = 0.0
        self.pixel_struct[struct_valid] = pixel_struct_cats[struct_valid].astype(float)

        return {}

    def run_segmentation(self) -> dict:
        """MA=90 channel count, peak detection, boundaries."""
        ma90_bin = np.clip(
            np.searchsorted(self.bins_sma, 90.0, side="right") - 1,
            0,
            self.hist_struct.shape[1] - 1,
        )
        cats_at_90 = set(self.labels_struct[:, ma90_bin])
        cats_at_90.discard(0)
        mask_90 = np.isin(self.pixel_struct, list(cats_at_90))
        self.n_channels_90 = np.sum(mask_90, axis=0).astype(float)

        sep_peaks = find_peaks(self.n_channels_90, size=13, min_ratio=0.01, min_value=1.0)
        if len(sep_peaks) > 0:
            filtered = [sep_peaks[0]]
            for p in sep_peaks[1:]:
                if self.n_channels_90[p] >= 0.4 * self.n_channels_90[filtered[-1]]:
                    filtered.append(p)
            sep_peaks = np.array(filtered)

        self.sep_peaks = sep_peaks
        self.boundaries = np.concatenate([[0], sep_peaks, [self.n_frames]])
        self.n_segments = len(self.boundaries) - 1

        return {
            "n_segments": int(self.n_segments),
            "boundaries": [int(b) for b in self.boundaries],
        }

    def run_segment_analysis(self) -> dict:
        """Per-segment CK/MA profiles, joint histograms, atoms."""
        self.seg_data = []
        for seg_i in range(self.n_segments):
            ts = int(self.boundaries[seg_i])
            te = int(self.boundaries[seg_i + 1])

            seg_stable = self.pixel_stability[:, ts:te] == 1
            seg_active = self.pixel_stability[:, ts:te] >= 0
            n_active = seg_active.sum()
            stability_ratio = seg_stable.sum() / n_active if n_active > 0 else 0.0

            entry = {
                "t_start": ts,
                "t_end": te,
                "stability_ratio": stability_ratio,
                "ck_profile": None,
                "ck_profile_smooth": None,
                "ck_peaks_idx": [],
                "ck_peaks_freq": [],
                "f0": None,
                "ma_profile": None,
                "ma_profile_smooth": None,
                "ma_peaks_idx": [],
                "ma_peaks_val": [],
                "joint_hist": None,
                "joint_bins_ck": None,
                "joint_bins_ma": None,
                "atoms": [],
                "ma_per_channel": None,
            }

            if seg_stable.sum() == 0:
                self.seg_data.append(entry)
                continue

            seg_ck = self.memo_ck[:, ts:te]
            ck_stable = seg_ck[seg_stable]
            ck_stable = ck_stable[ck_stable > 0]

            if len(ck_stable) > 0:
                ck_max = int(np.ceil(ck_stable.max())) + 1
                ck_profile, _ = np.histogram(ck_stable, bins=np.arange(0, ck_max + 1))
                entry["ck_profile"] = ck_profile
                entry["ck_profile_smooth"] = ck_profile.astype(float)

                ck_peaks = find_profile_peaks(ck_profile.astype(float), size=5, min_ratio=0.1)
                ck_peaks = ck_peaks[ck_peaks > 0]
                entry["ck_peaks_idx"] = ck_peaks

                ck_peaks_freq = self.SR_OUT / np.exp(ck_peaks / 10.0)
                ck_peaks_freq = ck_peaks_freq[ck_peaks_freq >= 80]
                entry["ck_peaks_freq"] = ck_peaks_freq

                if len(ck_peaks_freq) > 0:
                    entry["f0"] = float(ck_peaks_freq.min())

            seg_ma = self.memo_ma[:, ts:te]
            ma_stable = seg_ma[seg_stable]
            ma_stable = ma_stable[ma_stable >= 0]

            if len(ma_stable) > 0:
                ma_max = int(np.ceil(ma_stable.max())) + 1
                ma_profile, _ = np.histogram(ma_stable, bins=np.arange(0, ma_max + 1))
                entry["ma_profile"] = ma_profile
                entry["ma_profile_smooth"] = ma_profile.astype(float)

                ma_peaks = find_profile_peaks(ma_profile.astype(float), size=5, min_ratio=0.1)
                entry["ma_peaks_idx"] = ma_peaks
                entry["ma_peaks_val"] = ma_peaks

            ma_per_ch = np.full(self.n_channels, np.nan)
            for ch in range(self.n_channels):
                vals = self.memo_ma[ch, ts:te][seg_stable[ch]]
                vals = vals[vals >= 0]
                if len(vals) > 0:
                    ma_per_ch[ch] = np.sum(vals)
            entry["ma_per_channel"] = ma_per_ch

            seg_ck_all = self.memo_ck[:, ts:te][seg_stable]
            seg_ma_all = self.memo_ma[:, ts:te][seg_stable]
            valid_j = (seg_ck_all > 0) & (seg_ma_all >= 0)
            seg_ck_j = seg_ck_all[valid_j]
            seg_ma_j = seg_ma_all[valid_j]

            if len(seg_ck_j) > 0 and len(entry["ck_peaks_idx"]) > 0:
                ck_max_j = int(np.ceil(seg_ck_j.max())) + 1
                ma_max_j = int(np.ceil(seg_ma_j.max())) + 1
                bins_ck_j = np.arange(0, ck_max_j + 1)
                bins_ma_j = np.arange(0, ma_max_j + 1)
                hist_joint, _, _ = np.histogram2d(
                    seg_ck_j,
                    seg_ma_j,
                    bins=[bins_ck_j, bins_ma_j],
                )
                entry["joint_hist"] = hist_joint
                entry["joint_bins_ck"] = bins_ck_j
                entry["joint_bins_ma"] = bins_ma_j

                atoms = []
                for ck_pk in entry["ck_peaks_idx"]:
                    freq = self.SR_OUT / np.exp(ck_pk / 10.0)
                    if freq < 80:
                        continue
                    if ck_pk < hist_joint.shape[0]:
                        ma_col = hist_joint[ck_pk, :]
                        if ma_col.sum() > 0:
                            dominant_ma = np.argmax(ma_col)
                            atoms.append((freq, float(dominant_ma)))
                entry["atoms"] = atoms

            # --- Reprojection CK → MA: snap CK peaks to detected MA peaks ---
            center_freqs = compute_freq_canals(self.n_channels, 40.0, 6500.0)
            ma_valid = np.nan_to_num(ma_per_ch)
            # Detect MA peaks (same params as rendering)
            ma_peak_channels = find_peaks(ma_valid, size=3, min_ratio=0.15)
            ma_peak_channels = ma_peak_channels[ma_valid[ma_peak_channels] > 0]
            ma_peak_channels = ma_peak_channels[center_freqs[ma_peak_channels] >= 80]

            reprojection = []
            if (
                entry["ck_peaks_freq"] is not None
                and len(entry["ck_peaks_freq"]) > 0
                and ma_per_ch is not None
            ):
                f0 = entry["f0"]

                def _snap_to_ma_peak(freq, radius=3):
                    """Find nearest detected MA peak within radius channels."""
                    ch0 = int(np.argmin(np.abs(center_freqs - freq)))
                    nearby = ma_peak_channels[np.abs(ma_peak_channels - ch0) <= radius]
                    if len(nearby) > 0:
                        best = nearby[np.argmax(ma_valid[nearby])]
                        return int(best)
                    return None

                f0_channel = _snap_to_ma_peak(f0) if f0 else None
                f0_energy = float(ma_valid[f0_channel]) if f0_channel is not None else 0.0

                for freq in entry["ck_peaks_freq"]:
                    ch = _snap_to_ma_peak(freq)
                    if ch is None:
                        continue
                    energy = float(ma_valid[ch])
                    ratio = energy / f0_energy if f0_energy > 0 else 0.0
                    reprojection.append(
                        {
                            "freq": float(freq),
                            "channel": ch,
                            "energy": energy,
                            "ratio": round(ratio, 3),
                            "is_f0": bool(abs(freq - f0) < 1) if f0 else False,
                        }
                    )
            entry["reprojection"] = reprojection

            # --- Formant detection: harmonics above expected spectral slope ---
            f0 = entry["f0"]
            harmonics_data = []
            if f0 and f0 > 0 and len(reprojection) > 0:
                # Collect harmonics with their energies (from reprojection)
                for rp in reprojection:
                    harmonics_data.append(
                        {
                            "channel": rp["channel"],
                            "freq": float(center_freqs[rp["channel"]]),
                            "energy": rp["energy"],
                            "is_f0": rp["is_f0"],
                        }
                    )

                # Fit expected spectral slope (linear regression in log-freq vs energy)
                if len(harmonics_data) >= 2:
                    h_freqs = np.array([h["freq"] for h in harmonics_data])
                    h_energies = np.array([h["energy"] for h in harmonics_data])
                    # Log-frequency for linear fit
                    log_freqs = np.log(h_freqs)
                    # Linear regression: energy = a * log(freq) + b
                    coeffs = np.polyfit(log_freqs, h_energies, 1)
                    expected = np.polyval(coeffs, log_freqs)

                    # Residuals: positive = above expected = formant-amplified
                    for i, h in enumerate(harmonics_data):
                        h["expected"] = float(expected[i])
                        h["residual"] = float(h_energies[i] - expected[i])

                    entry["spectral_slope"] = {"a": float(coeffs[0]), "b": float(coeffs[1])}

            entry["harmonics_data"] = harmonics_data

            self.seg_data.append(entry)

        return {
            "segments": [
                {
                    "index": i,
                    "t_start": int(sd["t_start"]),
                    "t_end": int(sd["t_end"]),
                    "stability_ratio": float(sd["stability_ratio"]),
                    "f0": float(sd["f0"]) if sd["f0"] else None,
                    "n_atoms": len(sd["atoms"]),
                    "frequencies": [float(f) for f, _ in sd["atoms"]],
                }
                for i, sd in enumerate(self.seg_data)
            ],
        }

    def run_synthesis(self) -> str:
        """Additive synthesis from atoms. Returns path to WAV file."""
        Path("output").mkdir(exist_ok=True)

        seg_signals = []
        for sd in self.seg_data:
            ts, te = sd["t_start"], sd["t_end"]
            seg_n_frames = te - ts
            seg_duration = seg_n_frames * self.frame_duration
            n_samples = int(seg_duration * self.SR_OUT)

            if n_samples == 0 or len(sd["atoms"]) == 0:
                seg_signals.append(np.zeros(max(n_samples, 1)))
                continue

            t = np.arange(n_samples) / self.SR_OUT
            signal = np.zeros(n_samples)
            for freq, amp_ma in sd["atoms"]:
                amp_lin = 10 ** (amp_ma / 20.0)
                signal += amp_lin * np.sin(2 * np.pi * freq * t)

            if np.max(np.abs(signal)) > 0:
                signal = signal / np.max(np.abs(signal))

            seg_signals.append(signal)

        synth_full = np.concatenate(seg_signals)
        if np.max(np.abs(synth_full)) > 0:
            synth_full = 0.8 * synth_full / np.max(np.abs(synth_full))

        min_samples = self.SR_OUT
        if len(synth_full) < min_samples:
            pad_total = min_samples - len(synth_full)
            pad_left = pad_total // 2
            pad_right = pad_total - pad_left
            synth_full = np.concatenate(
                [
                    np.zeros(pad_left),
                    synth_full,
                    np.zeros(pad_right),
                ]
            )

        wav_path = f"output/synth_{self.word}.wav"
        sf.write(wav_path, synth_full, self.SR_OUT)
        return wav_path
