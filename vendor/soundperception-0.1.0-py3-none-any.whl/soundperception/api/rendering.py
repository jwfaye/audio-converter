"""Server-side matplotlib rendering: one function per pipeline row → PNG bytes."""

import io

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import numpy as np
from matplotlib.colors import ListedColormap

from soundperception.utils.peak_detection import find_peaks
from soundperception.utils.compute_freq_canals import compute_freq_canals

BG = "#1a1a2e"
FG = "#e0e0e0"
SR_OUT = 16000


def _style_ax(ax):
    ax.set_facecolor("black")
    ax.tick_params(colors=FG, labelsize=6)
    for s in ax.spines.values():
        s.set_color(FG)
        s.set_linewidth(0.5)


def _fig_to_bytes(fig) -> bytes:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=120, facecolor=BG, bbox_inches="tight")
    plt.close(fig)
    buf.seek(0)
    return buf.read()


def render_periphery(memo_ma, memo_ck) -> bytes:
    """Render memo_ma and memo_ck side by side as PNG."""
    fig, (ax_ma, ax_ck) = plt.subplots(1, 2, figsize=(14, 3), facecolor=BG)

    for ax, data, cmap, title in [
        (ax_ma, memo_ma, "inferno", "memo MA"),
        (ax_ck, memo_ck, "hot", "memo CK"),
    ]:
        d = data.copy().astype(float)
        d[d < 0] = np.nan
        ax.imshow(d, origin="lower", aspect="auto", cmap=cmap)
        ax.set_title(title, color=FG, fontsize=9)
        _style_ax(ax)

    fig.tight_layout()
    return _fig_to_bytes(fig)


def render_stability_histogram(
    hist_std,
    labels_std,
    marginal_ma,
    marginal_ck,
    thresh_ma,
    thresh_ck,
    stable_cat,
) -> bytes:
    """Render stability histogram with marginals and categories."""
    fig = plt.figure(figsize=(14, 4), facecolor=BG)
    gs = gridspec.GridSpec(1, 3, figure=fig, width_ratios=[1.2, 1.2, 0.6], wspace=0.3)
    gs_hist = gs[0].subgridspec(
        2, 2, height_ratios=[1, 3], width_ratios=[3, 1], hspace=0.05, wspace=0.05
    )

    ax_marg_top = fig.add_subplot(gs_hist[0, 0])
    ax_hist = fig.add_subplot(gs_hist[1, 0])
    ax_marg_right = fig.add_subplot(gs_hist[1, 1])
    ax_cats = fig.add_subplot(gs[1])
    ax_legend = fig.add_subplot(gs[2])

    h = hist_std.copy().astype(float)
    h[h == 0] = np.nan
    ax_hist.imshow(h, origin="lower", aspect="auto", cmap="inferno")
    ax_hist.set_xlabel("std MA", color=FG, fontsize=8)
    ax_hist.set_ylabel("std CK", color=FG, fontsize=8)
    for t in thresh_ma:
        ax_hist.axvline(t - 0.5, color=FG, linewidth=0.8, linestyle="--", alpha=0.7)
    for t in thresh_ck:
        ax_hist.axhline(t - 0.5, color=FG, linewidth=0.8, linestyle="--", alpha=0.7)
    _style_ax(ax_hist)

    ax_marg_top.bar(range(len(marginal_ma)), marginal_ma, color="#e8a838", width=1.0)
    for t in thresh_ma:
        ax_marg_top.axvline(t - 0.5, color="#e74c3c", linewidth=1.2, linestyle="--")
    ax_marg_top.set_xlim(ax_hist.get_xlim())
    ax_marg_top.set_title("histo std MA x std CK", color=FG, fontsize=9)
    ax_marg_top.tick_params(labelbottom=False)
    _style_ax(ax_marg_top)

    ax_marg_right.barh(range(len(marginal_ck)), marginal_ck, color="#e8a838", height=1.0)
    for t in thresh_ck:
        ax_marg_right.axhline(t - 0.5, color="#e74c3c", linewidth=1.2, linestyle="--")
    ax_marg_right.set_ylim(ax_hist.get_ylim())
    ax_marg_right.tick_params(labelleft=False)
    _style_ax(ax_marg_right)

    n_cats = int(labels_std.max())
    rng = np.random.RandomState(42)
    cat_colors = rng.rand(n_cats, 3)
    cat_colors = cat_colors / cat_colors.max(axis=1, keepdims=True)
    cat_cmap = ListedColormap(cat_colors)
    ax_cats.imshow(
        labels_std.astype(float),
        origin="lower",
        aspect="auto",
        cmap=cat_cmap,
        vmin=0.5,
        vmax=n_cats + 0.5,
    )
    ax_cats.set_title(f"categories ({n_cats})", color=FG, fontsize=9)
    ax_cats.set_xlabel("std MA", color=FG, fontsize=8)
    for t in thresh_ma:
        ax_cats.axvline(t - 0.5, color=FG, linewidth=0.8, linestyle="--", alpha=0.7)
    for t in thresh_ck:
        ax_cats.axhline(t - 0.5, color=FG, linewidth=0.8, linestyle="--", alpha=0.7)
    _style_ax(ax_cats)

    ax_legend.set_facecolor(BG)
    ax_legend.axis("off")
    ax_legend.text(
        0.1,
        0.7,
        f"seuils MA: {list(thresh_ma)}\n"
        f"seuils CK: {list(thresh_ck)}\n"
        f"{n_cats} cat., stable=cat {stable_cat}",
        color=FG,
        fontsize=8,
        transform=ax_legend.transAxes,
        va="top",
    )

    return _fig_to_bytes(fig)


def render_stability_map(pixel_stability, memo_ma, memo_ck) -> bytes:
    """Render stable/unstable pixel map with MA and CK overlays."""
    fig = plt.figure(figsize=(14, 3), facecolor=BG)
    gs = gridspec.GridSpec(1, 4, figure=fig, wspace=0.3)

    ax_stab = fig.add_subplot(gs[0:2])
    stab_display = pixel_stability.copy()
    stab_display[stab_display < 0] = np.nan
    stab_cmap = ListedColormap(["#2ecc71", "#e74c3c"])
    ax_stab.imshow(stab_display, origin="lower", aspect="auto", cmap=stab_cmap, vmin=1, vmax=2)
    ax_stab.set_title("stable (vert) / instable (rouge)", color=FG, fontsize=9)
    _style_ax(ax_stab)

    stab_overlay = np.where(pixel_stability == 1, 1.0, np.nan)

    ax_stab_ma = fig.add_subplot(gs[2])
    d_ma = memo_ma.copy().astype(float)
    d_ma[d_ma < 0] = np.nan
    ax_stab_ma.imshow(d_ma, origin="lower", aspect="auto", cmap="inferno")
    ax_stab_ma.imshow(
        stab_overlay,
        origin="lower",
        aspect="auto",
        cmap=ListedColormap(["#2ecc7188"]),
        vmin=0.5,
        vmax=1.5,
    )
    ax_stab_ma.set_title("memo MA + stable", color=FG, fontsize=9)
    _style_ax(ax_stab_ma)

    ax_stab_ck = fig.add_subplot(gs[3])
    d_ck = memo_ck.copy().astype(float)
    d_ck[d_ck < 0] = np.nan
    ax_stab_ck.imshow(d_ck, origin="lower", aspect="auto", cmap="hot")
    ax_stab_ck.imshow(
        stab_overlay,
        origin="lower",
        aspect="auto",
        cmap=ListedColormap(["#2ecc7188"]),
        vmin=0.5,
        vmax=1.5,
    )
    ax_stab_ck.set_title("memo CK + stable", color=FG, fontsize=9)
    _style_ax(ax_stab_ck)

    fig.tight_layout()
    return _fig_to_bytes(fig)


def render_segmentation(memo_ma, sep_peaks, n_channels_90, n_segments) -> bytes:
    """Render segmentation overlay on memo_ma with peak markers."""
    fig = plt.figure(figsize=(14, 3), facecolor=BG)
    gs = gridspec.GridSpec(1, 4, figure=fig, wspace=0.3)

    ax_sep = fig.add_subplot(gs[0:3])
    d_ma = memo_ma.copy().astype(float)
    d_ma[d_ma < 0] = np.nan
    ax_sep.imshow(d_ma, origin="lower", aspect="auto", cmap="inferno")
    for p in sep_peaks:
        ax_sep.axvline(p, color="#00ff00", linewidth=1.5, alpha=0.9)
    ax_sep.set_title(
        f"segmentation ({len(sep_peaks)} pics, {n_segments} segments)", color=FG, fontsize=9
    )
    _style_ax(ax_sep)

    ax_count = fig.add_subplot(gs[3])
    ax_count.bar(range(len(n_channels_90)), n_channels_90, color="#e8a838", width=1.0)
    for p in sep_peaks:
        ax_count.axvline(p, color="#e74c3c", linewidth=1.2, linestyle="--")
    ax_count.set_title("canaux MA=90 / trame", color=FG, fontsize=9)
    ax_count.set_xlabel("trame", color=FG, fontsize=8)
    _style_ax(ax_count)

    fig.tight_layout()
    return _fig_to_bytes(fig)


def render_ck_stable(memo_ck, pixel_stability, sep_peaks, seg_data) -> bytes:
    """Render CK values on stable pixels with stability ratio bars."""
    n_segments = len(seg_data)
    fig = plt.figure(figsize=(14, 3), facecolor=BG)
    gs = gridspec.GridSpec(1, 4, figure=fig, wspace=0.3)

    ax_ck_seg = fig.add_subplot(gs[0:3])
    ck_stable_img = memo_ck.copy().astype(float)
    ck_stable_img[pixel_stability != 1] = np.nan
    ax_ck_seg.imshow(ck_stable_img, origin="lower", aspect="auto", cmap="hot")
    for p in sep_peaks:
        ax_ck_seg.axvline(p, color="#00ff00", linewidth=1.5, alpha=0.9)
    ax_ck_seg.set_title("memo CK (pixels stables)", color=FG, fontsize=9)
    _style_ax(ax_ck_seg)

    ax_stab_bar = fig.add_subplot(gs[3])
    seg_labels = [f"S{i+1}" for i in range(n_segments)]
    seg_stab_vals = [sd["stability_ratio"] for sd in seg_data]
    ax_stab_bar.bar(
        seg_labels, seg_stab_vals, color="#3498db", width=0.6, edgecolor=FG, linewidth=0.5
    )
    ax_stab_bar.axhline(0.5, color="#e74c3c", linewidth=1, linestyle="--", alpha=0.7)
    ax_stab_bar.set_ylim(0, 1)
    ax_stab_bar.set_title("ratio stabilite", color=FG, fontsize=9)
    for i, val in enumerate(seg_stab_vals):
        ax_stab_bar.text(i, val + 0.02, f"{val:.0%}", ha="center", color=FG, fontsize=7)
    _style_ax(ax_stab_bar)

    fig.tight_layout()
    return _fig_to_bytes(fig)


def render_joint_histograms(
    memo_ck,
    memo_ma,
    pixel_stability,
    seg_data,
) -> bytes:
    """Render per-segment joint CK x MA histograms with marginals."""
    n_segments = len(seg_data)
    fig = plt.figure(figsize=(14, 4), facecolor=BG)
    gs = gridspec.GridSpec(1, max(n_segments, 1), figure=fig, wspace=0.4)

    for seg_i, sd in enumerate(seg_data):
        gs_joint = gs[seg_i].subgridspec(
            2,
            2,
            height_ratios=[1, 3],
            width_ratios=[3, 1],
            hspace=0.05,
            wspace=0.05,
        )
        ax_jtop = fig.add_subplot(gs_joint[0, 0])
        ax_jmain = fig.add_subplot(gs_joint[1, 0])
        ax_jright = fig.add_subplot(gs_joint[1, 1])

        if sd["ck_profile"] is not None and sd["ma_profile"] is not None:
            ts, te = sd["t_start"], sd["t_end"]
            seg_stable_mask = pixel_stability[:, ts:te] == 1
            seg_ck_vals = memo_ck[:, ts:te][seg_stable_mask]
            seg_ma_vals = memo_ma[:, ts:te][seg_stable_mask]
            valid = (seg_ck_vals > 0) & (seg_ma_vals >= 0)
            seg_ck_vals = seg_ck_vals[valid]
            seg_ma_vals = seg_ma_vals[valid]

            if len(seg_ck_vals) > 0:
                ck_max = int(np.ceil(seg_ck_vals.max())) + 1
                ma_max = int(np.ceil(seg_ma_vals.max())) + 1
                bins_ck_j = np.arange(0, ck_max + 1)
                bins_ma_j = np.arange(0, ma_max + 1)
                hist_joint, _, _ = np.histogram2d(
                    seg_ck_vals,
                    seg_ma_vals,
                    bins=[bins_ck_j, bins_ma_j],
                )
                hj = hist_joint.astype(float)
                hj[hj == 0] = np.nan
                ax_jmain.imshow(hj, origin="lower", aspect="auto", cmap="inferno")
                ax_jmain.set_xlabel("bin MA", color=FG, fontsize=5)
                ax_jmain.set_ylabel("bin CK", color=FG, fontsize=5)

                marg_ma = hist_joint.sum(axis=0)
                ax_jtop.bar(range(len(marg_ma)), marg_ma, color="#e8a838", width=1.0, alpha=0.7)
                for pk in sd["ma_peaks_idx"]:
                    if pk < len(marg_ma):
                        ax_jtop.axvline(
                            pk, color="#e74c3c", linewidth=0.8, linestyle="--", alpha=0.8
                        )
                ax_jtop.set_xlim(ax_jmain.get_xlim())
                ax_jtop.tick_params(labelbottom=False)

                marg_ck = hist_joint.sum(axis=1)
                ax_jright.barh(range(len(marg_ck)), marg_ck, color="#3498db", height=1.0, alpha=0.7)
                for pk in sd["ck_peaks_idx"]:
                    if pk < len(marg_ck):
                        ax_jright.axhline(
                            pk, color="#e74c3c", linewidth=0.8, linestyle="--", alpha=0.8
                        )
                ax_jright.set_ylim(ax_jmain.get_ylim())
                ax_jright.tick_params(labelleft=False)

        f0_str = f"F0={sd['f0']:.0f}" if sd["f0"] else "—"
        n_ck = len(sd["ck_peaks_idx"])
        n_ma = len(sd["ma_peaks_idx"])
        ax_jtop.set_title(
            f"S{seg_i+1}: MA×CK — {f0_str} | {n_ck}p.CK {n_ma}p.MA", color=FG, fontsize=6
        )
        _style_ax(ax_jmain)
        _style_ax(ax_jtop)
        _style_ax(ax_jright)

    return _fig_to_bytes(fig)


def render_frequency_summary(seg_data, sep_peaks, n_frames) -> bytes:
    """Render detected frequencies per segment on a log-scale plot."""
    n_segments = len(seg_data)
    fig, ax = plt.subplots(1, 1, figsize=(14, 3), facecolor=BG)
    ax.set_facecolor("black")
    ax.set_xlim(0, n_frames)
    ax.set_ylim(50, 7000)
    ax.set_yscale("log")
    ax.set_title("frequences detectees par segment (pics CK)", color=FG, fontsize=9)
    ax.set_xlabel("trame", color=FG, fontsize=8)
    ax.set_ylabel("frequence (Hz)", color=FG, fontsize=8)

    colors_seg = plt.cm.tab10(np.linspace(0, 1, max(n_segments, 1)))
    for seg_i, sd in enumerate(seg_data):
        ts, te = sd["t_start"], sd["t_end"]
        mid = (ts + te) / 2
        for freq in sd["ck_peaks_freq"]:
            ax.plot([ts, te], [freq, freq], color=colors_seg[seg_i], linewidth=2, alpha=0.8)
            ax.text(
                mid,
                freq * 1.05,
                f"{freq:.0f}",
                color=colors_seg[seg_i],
                fontsize=6,
                ha="center",
                va="bottom",
            )
        if sd["f0"]:
            ax.plot([ts, te], [sd["f0"], sd["f0"]], color=colors_seg[seg_i], linewidth=3, alpha=1.0)

    for p in sep_peaks:
        ax.axvline(p, color="#00ff00", linewidth=0.8, alpha=0.5, linestyle="--")

    for ref_f, ref_name in [(100, "100"), (440, "A4"), (1000, "1k"), (4000, "4k")]:
        ax.axhline(ref_f, color=FG, linewidth=0.3, alpha=0.3)
        ax.text(n_frames + 1, ref_f, ref_name, color=FG, fontsize=5, va="center")
    _style_ax(ax)

    fig.tight_layout()
    return _fig_to_bytes(fig)


def render_single_segment_profile(sd, seg_index, n_channels) -> bytes:
    """Render profile for a single segment: CK histogram + MA energy per channel."""
    center_freqs = compute_freq_canals(65, 40.0, 6500.0)

    fig, (ax_ck_h, ax_ma_ch) = plt.subplots(1, 2, figsize=(14, 4), facecolor=BG)

    _style_ax(ax_ck_h)
    _style_ax(ax_ma_ch)

    if sd["ck_profile"] is not None:
        ax_ck_h.bar(
            range(len(sd["ck_profile"])), sd["ck_profile"], color="#e8a838", width=1.0, alpha=0.8
        )
        for pk in sd["ck_peaks_idx"]:
            if pk < len(sd["ck_profile"]):
                freq = SR_OUT / np.exp(pk / 10.0)
                ax_ck_h.axvline(pk, color="#e74c3c", linewidth=1, linestyle="--", alpha=0.8)
                ax_ck_h.text(
                    pk,
                    sd["ck_profile"][pk] * 1.05,
                    f"{freq:.0f}",
                    color="#e74c3c",
                    fontsize=6,
                    ha="center",
                    va="bottom",
                    rotation=45,
                )

    f0_str = f"F0={sd['f0']:.0f}" if sd["f0"] else "—"
    ax_ck_h.set_title(f"Segment {seg_index+1} — histo CK — {f0_str}", color=FG, fontsize=9)
    ax_ck_h.set_xlabel("bin CK", color=FG, fontsize=7)
    ax_ck_h.set_ylabel("comptage", color=FG, fontsize=7)

    ma_ch = sd["ma_per_channel"]
    if ma_ch is not None:
        channels = np.arange(n_channels)
        ax_ma_ch.plot(channels, ma_ch, color="#3498db", linewidth=1.5)
        ax_ma_ch.fill_between(channels, 0, np.nan_to_num(ma_ch), color="#3498db", alpha=0.2)

        ma_valid = np.nan_to_num(ma_ch)
        ma_pks = find_peaks(ma_valid, size=3, min_ratio=0.15)
        ma_pks = ma_pks[ma_valid[ma_pks] > 0]
        ma_pks = ma_pks[center_freqs[ma_pks] >= 80]
        for pk in ma_pks:
            ax_ma_ch.plot(pk, ma_ch[pk], "o", color="#e74c3c", markersize=6, zorder=5)
            ax_ma_ch.annotate(
                f"{center_freqs[pk]:.0f}",
                (pk, ma_ch[pk]),
                textcoords="offset points",
                xytext=(0, 8),
                color="#e74c3c",
                fontsize=6,
                ha="center",
            )

        tick_step = 10
        tp = np.arange(0, n_channels, tick_step)
        ax_ma_ch.set_xticks(tp)
        ax_ma_ch.set_xticklabels([f"{center_freqs[i]:.0f}" for i in tp])
        ax_ma_ch.set_xlim(0, n_channels - 1)

    ax_ma_ch.set_title(f"Segment {seg_index+1} — MA énergie/canal", color=FG, fontsize=9)
    ax_ma_ch.set_xlabel("freq (Hz)", color=FG, fontsize=7)
    ax_ma_ch.set_ylabel("MA énergie (somme)", color=FG, fontsize=7)

    fig.tight_layout()
    return _fig_to_bytes(fig)


def render_reprojection(sd, seg_index, n_channels) -> bytes:
    """Render CK→MA reprojection: MA energy profile with CK peaks overlaid."""
    center_freqs = compute_freq_canals(65, 40.0, 6500.0)
    reprojection = sd.get("reprojection", [])
    ma_ch = sd["ma_per_channel"]

    fig, ax = plt.subplots(1, 1, figsize=(14, 4), facecolor=BG)
    _style_ax(ax)

    # Draw MA energy profile as background
    if ma_ch is not None:
        channels = np.arange(n_channels)
        ax.fill_between(channels, 0, np.nan_to_num(ma_ch), color="#3498db", alpha=0.15)
        ax.plot(channels, np.nan_to_num(ma_ch), color="#3498db", linewidth=0.8, alpha=0.4)

    # Overlay reprojection bars
    for rp in reprojection:
        ch = rp["channel"]
        energy = rp["energy"]
        is_f0 = rp["is_f0"]
        color = "#e74c3c" if is_f0 else "#e8a838"
        ax.bar(ch, energy, width=1.2, color=color, alpha=0.85, zorder=3)
        ch_freq = center_freqs[ch]
        label = f"F0={ch_freq:.0f}" if is_f0 else f"{ch_freq:.0f}\n({rp['ratio']:.2f})"
        ax.annotate(
            label,
            (ch, energy),
            textcoords="offset points",
            xytext=(0, 8),
            color=color,
            fontsize=6,
            ha="center",
            fontweight="bold",
        )

    # X-axis: frequency labels
    tick_step = 10
    tp = np.arange(0, n_channels, tick_step)
    ax.set_xticks(tp)
    ax.set_xticklabels([f"{center_freqs[i]:.0f}" for i in tp])
    ax.set_xlim(0, n_channels - 1)

    f0_rp = next((rp for rp in reprojection if rp["is_f0"]), None)
    f0_str = f"F0={center_freqs[f0_rp['channel']]:.0f} Hz" if f0_rp else "—"
    ax.set_title(f"Segment {seg_index+1} — Reprojection CK→MA — {f0_str}", color=FG, fontsize=9)
    ax.set_xlabel("freq (Hz)", color=FG, fontsize=7)
    ax.set_ylabel("MA énergie", color=FG, fontsize=7)

    fig.tight_layout()
    return _fig_to_bytes(fig)


def render_spectrogram(signal, fs, title="Synthèse") -> bytes:
    """Render spectrogram of a synthesized signal."""
    fig, ax = plt.subplots(1, 1, figsize=(14, 3), facecolor=BG)
    _style_ax(ax)

    nfft = 512
    noverlap = 448
    ax.specgram(signal, NFFT=nfft, Fs=fs, noverlap=noverlap, cmap="inferno", scale="dB")
    ax.set_ylim(0, fs / 2)
    ax.set_title(title, color=FG, fontsize=9)
    ax.set_xlabel("temps (s)", color=FG, fontsize=7)
    ax.set_ylabel("freq (Hz)", color=FG, fontsize=7)

    fig.tight_layout()
    return _fig_to_bytes(fig)


def render_spectral_profile(signal, fs, title="Profil spectral") -> bytes:
    """Render spectral profile (FFT magnitude in dB)."""
    fig, ax = plt.subplots(1, 1, figsize=(14, 3), facecolor=BG)
    _style_ax(ax)

    n = len(signal)
    fft = np.fft.rfft(signal)
    magnitude = np.abs(fft)
    mag_db = 20 * np.log10(magnitude + 1e-10)
    mag_db -= mag_db.max()
    freqs = np.fft.rfftfreq(n, 1.0 / fs)

    ax.plot(freqs, mag_db, color="#2ecc71", linewidth=0.8)
    ax.fill_between(freqs, -80, mag_db, color="#2ecc71", alpha=0.15)
    ax.set_xlim(0, fs / 2)
    ax.set_ylim(-80, 5)
    ax.set_title(title, color=FG, fontsize=9)
    ax.set_xlabel("freq (Hz)", color=FG, fontsize=7)
    ax.set_ylabel("amplitude (dB)", color=FG, fontsize=7)

    fig.tight_layout()
    return _fig_to_bytes(fig)


def render_cochlear_profile(ma_per_ch, n_channels, title="Profil cochléaire — synthèse") -> bytes:
    """Render MA energy per channel from cochlear decomposition of synthesized signal."""
    center_freqs = compute_freq_canals(n_channels, 40.0, 6500.0)

    fig, ax = plt.subplots(1, 1, figsize=(14, 3), facecolor=BG)
    _style_ax(ax)

    channels = np.arange(n_channels)
    ma_valid = np.nan_to_num(ma_per_ch)
    ax.plot(channels, ma_valid, color="#2ecc71", linewidth=1.5)
    ax.fill_between(channels, 0, ma_valid, color="#2ecc71", alpha=0.2)

    tick_step = 10
    tp = np.arange(0, n_channels, tick_step)
    ax.set_xticks(tp)
    ax.set_xticklabels([f"{center_freqs[i]:.0f}" for i in tp])
    ax.set_xlim(0, n_channels - 1)

    ax.set_title(title, color=FG, fontsize=9)
    ax.set_xlabel("freq (Hz)", color=FG, fontsize=7)
    ax.set_ylabel("MA énergie", color=FG, fontsize=7)

    fig.tight_layout()
    return _fig_to_bytes(fig)


def render_formant_detection(sd, n_channels) -> bytes:
    """Render MA profile with spectral slope and residuals showing formant regions."""
    center_freqs = compute_freq_canals(n_channels, 40.0, 6500.0)
    ma_ch = sd.get("ma_per_channel")
    if ma_ch is None:
        ma_ch = np.zeros(n_channels)
    harmonics_data = sd.get("harmonics_data", [])
    slope = sd.get("spectral_slope")
    f0 = sd.get("f0")

    fig, (ax_top, ax_bot) = plt.subplots(
        2, 1, figsize=(14, 7), facecolor=BG, gridspec_kw={"height_ratios": [2, 1]}
    )
    _style_ax(ax_top)
    _style_ax(ax_bot)

    channels = np.arange(n_channels)
    ma_valid = np.nan_to_num(ma_ch)

    # --- Top: MA profile + spectral slope + harmonics colored by residual ---
    ax_top.fill_between(channels, 0, ma_valid, color="#3498db", alpha=0.15)
    ax_top.plot(channels, ma_valid, color="#3498db", linewidth=0.8, alpha=0.5)

    # Draw expected spectral slope across all channels
    if slope and len(harmonics_data) >= 2:
        log_cf = np.log(center_freqs)
        expected_all = slope["a"] * log_cf + slope["b"]
        ax_top.plot(
            channels,
            expected_all,
            color="#e0e0e0",
            linewidth=1.5,
            linestyle="--",
            alpha=0.5,
            label="Pente attendue",
        )

    # Harmonics: green if above slope (formant-amplified), orange if below
    for h in harmonics_data:
        ch = h["channel"]
        residual = h.get("residual", 0)
        if residual > 0:
            color = "#e74c3c"
            marker = "^"
            ms = 10
        else:
            color = "#e8a838"
            marker = "o"
            ms = 6
        ax_top.plot(ch, h["energy"], marker, color=color, markersize=ms, zorder=5, alpha=0.9)
        ax_top.annotate(
            f"{h['freq']:.0f}",
            (ch, h["energy"]),
            textcoords="offset points",
            xytext=(0, 10),
            color=color,
            fontsize=6,
            ha="center",
        )

    tick_step = 10
    tp = np.arange(0, n_channels, tick_step)
    ax_top.set_xticks(tp)
    ax_top.set_xticklabels([f"{center_freqs[i]:.0f}" for i in tp])
    ax_top.set_xlim(0, n_channels - 1)
    ax_top.legend(loc="upper right", fontsize=7, framealpha=0.3)

    f0_str = f"F0={f0:.0f} Hz" if f0 else ""
    ax_top.set_title(f"Pente spectrale + harmoniques — {f0_str}", color=FG, fontsize=9)
    ax_top.set_ylabel("MA énergie", color=FG, fontsize=7)

    # --- Bottom: Residuals bar chart ---
    if harmonics_data:
        h_channels = [h["channel"] for h in harmonics_data]
        residuals = [h.get("residual", 0) for h in harmonics_data]
        colors = ["#e74c3c" if r > 0 else "#e8a838" for r in residuals]
        ax_bot.bar(h_channels, residuals, color=colors, width=1.2, alpha=0.8)
        ax_bot.axhline(0, color="#e0e0e0", linewidth=0.5, alpha=0.3)

        for h in harmonics_data:
            if h.get("residual", 0) > 0:
                ax_bot.annotate(
                    f"{h['freq']:.0f}",
                    (h["channel"], h["residual"]),
                    textcoords="offset points",
                    xytext=(0, 5),
                    color="#e74c3c",
                    fontsize=6,
                    ha="center",
                    fontweight="bold",
                )

    ax_bot.set_xticks(tp)
    ax_bot.set_xticklabels([f"{center_freqs[i]:.0f}" for i in tp])
    ax_bot.set_xlim(0, n_channels - 1)
    ax_bot.set_title("Résidus (au-dessus de la pente = amplifié par formant)", color=FG, fontsize=9)
    ax_bot.set_xlabel("freq (Hz)", color=FG, fontsize=7)
    ax_bot.set_ylabel("résidu", color=FG, fontsize=7)

    fig.tight_layout()
    return _fig_to_bytes(fig)
