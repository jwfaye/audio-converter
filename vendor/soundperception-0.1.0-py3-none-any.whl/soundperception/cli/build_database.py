"""Build phoneme database from audio files.

Processes .wav files in data/diction_phonemes and generates:

Excel files (with automatic segmentation for files > 16384 columns):
1. {name}_stage4.xlsx: Stage 4 outputs (peaks + waveform)
   - Single sheet "data" or multiple sheets "segment_0", "segment_1", etc.
   - Rows 0-64: peaks (65 channels)
   - Row 65: audio waveform

2. {name}_stage5.xlsx: Stage 5 outputs (auditory nerve)
   - Sheets "memo_ma" + "memo_ck" (or segmented: "memo_ma_seg0", etc.)
   - Each sheet: 65 channels × n_samples

3. {name}_stage5.5.xlsx: Stage 5.5 outputs (decimated, integrated)
   - Sheets "memo_ma_integrated" + "memo_ck_integrated" (or segmented)
   - Each sheet: 65 channels × (n_samples/100)

4. {name}_invariance.xlsx: Frequency invariance table
   - Rows 0 to N-3: Invariances (N harmonics)
   - Row N-2: MA values
   - Row N-1: NBCK values

PNG visualizations:
1. {name}_waveform.png: Audio waveform
2. {name}_mean_consecutive.png: Mean of consecutive frames (median across channels)
3. {name}_abs_variation.png: Absolute variation between consecutive frames (median across channels)
4. {name}_mean_consecutive_heatmap.png: Mean of consecutive frames heatmap (all channels)
5. {name}_abs_variation_heatmap.png: Absolute variation heatmap (all channels)
6. {name}_mean_cumulative_50.png: 50% cumulative threshold for mean values over time
7. {name}_variation_cumulative_50.png: 50% cumulative threshold for variation values over time
8. {name}_bilinear_histogram.png: Global bilinear histogram (mean vs variation) for entire signal
9. {name}_temporal_memory_f0.png: Temporal memory heatmap + F0 track
10. {name}_amplitude_memory_f0.png: Amplitude memory heatmap + F0 track
11. {name}_fundamental_vs_max_ma.png: Fundamental MA vs Max MA plot
12. {name}_f0_frequency.png: F0 frequency vs lowest channel frequency comparison
13. {name}_combined_analysis.png: Multi-panel visualization with all plots

Video:
1. {name}_frame_histogram.mp4: Frame-by-frame 2D histogram evolution with audio

Technical Notes:
- matplotlib.use("Agg") called before pyplot import for non-interactive backend
- Excel channel layout: High freq at top (Row 1 = Ch 64), low at bottom (Row 65 = Ch 0)
- Harmonic data stored in ascending order (index 0 = H1 fundamental), reversed for Excel export
- Excel has 16384 column limit (segmentation implemented)
- Figure size for plots: (14, 6) inches

Usage:
    python soundperception/cli/build_database.py [--input-dir DIR] [--output-dir DIR]
    python soundperception/cli/build_database.py --limit 5
"""

import argparse
import logging
import sys
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from audition import (
    AuditoryPeriphery,
    AuditoryPeripheryConfig,
    F0DetectionConfig,
    F0Detector,
    FrequencyInvarianceConfig,
    FrequencyInvarianceExtractor,
    TemporalIntegrationConfig,
    TemporalIntegrator,
    load_audio,
)
from soundperception.histograms import BilinearHistogramComputer, BilinearHistogramConfig
from soundperception.visualization.frame_histogram_video import create_frame_histogram_video

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


EXCEL_MAX_COLUMNS = 16384

STANDARD_FIG_SIZE = (14, 6)


@dataclass
class F0PlotData:
    """Data for F0-related plots.

    Attributes:
        memo_ma_integrated: Integrated amplitude memory (n_channels, n_frames).
        memo_ck_integrated: Integrated temporal memory (n_channels, n_frames).
        f0_frames: Frame indices with F0 detection.
        f0_channels: Channel indices for F0.
        decimation_factor: Decimation factor used.
        sample_rate: Sample rate in Hz.
    """

    memo_ma_integrated: np.ndarray
    memo_ck_integrated: np.ndarray
    f0_frames: np.ndarray
    f0_channels: np.ndarray
    decimation_factor: int
    sample_rate: int


@dataclass
class StageData:
    """Stage output data for saving.

    Attributes:
        signal: Audio signal.
        peaks: Stage 4 peaks.
        memo_ma: Stage 5 amplitude memory.
        memo_ck: Stage 5 temporal memory.
        memo_ma_integrated: Stage 5.5 integrated amplitude.
        memo_ck_integrated: Stage 5.5 integrated temporal.
    """

    signal: np.ndarray
    peaks: np.ndarray
    memo_ma: np.ndarray
    memo_ck: np.ndarray
    memo_ma_integrated: np.ndarray
    memo_ck_integrated: np.ndarray


@dataclass
class ProcessingPipeline:
    """Processing pipeline components.

    Attributes:
        periphery: Auditory periphery processor.
        integrator: Temporal integrator.
        detector: F0 detector.
        extractor: Frequency invariance extractor.
        sample_rate: Sample rate in Hz.
    """

    periphery: AuditoryPeriphery
    integrator: TemporalIntegrator
    detector: F0Detector
    extractor: FrequencyInvarianceExtractor
    sample_rate: int = 16000


def split_into_segments(data: np.ndarray, max_columns: int = EXCEL_MAX_COLUMNS) -> list[np.ndarray]:
    """Split data array into segments that fit Excel column limits.

    Args:
        data: Array of shape (n_rows, n_columns)
        max_columns: Maximum columns per segment

    Returns:
        List of array segments, each with <= max_columns columns
    """
    n_columns = data.shape[1]
    if n_columns <= max_columns:
        return [data]

    segments = []
    for start_col in range(0, n_columns, max_columns):
        end_col = min(start_col + max_columns, n_columns)
        segments.append(data[:, start_col:end_col])

    return segments


def save_stage4_excel(peaks: np.ndarray, signal: np.ndarray, output_path: str) -> bool:
    """Save Stage 4 outputs (peaks + waveform) to Excel file with segmentation.

    Excel layout: high frequencies at top
    - Row 1 = Channel 64 (6500 Hz)
    - Row 65 = Channel 0 (40 Hz)
    - Row 66 = Waveform

    Args:
        peaks: Peaks array, shape (n_channels, n_samples)
        signal: Audio waveform, shape (n_samples,)
        output_path: Path to save Excel file

    Returns:
        True if saved successfully
    """
    peaks_reversed = peaks[::-1]
    signal_row = signal.reshape(1, -1)
    combined = np.vstack([peaks_reversed, signal_row])
    segments = split_into_segments(combined)

    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        for i, segment in enumerate(segments):
            sheet_name = f"segment_{i}" if len(segments) > 1 else "data"
            df = pd.DataFrame(segment)
            df.to_excel(writer, sheet_name=sheet_name, index=False, header=False)

    if len(segments) > 1:
        logger.info(
            "Saved Stage 4 outputs to: %s (%d segments, %d columns total)",
            output_path,
            len(segments),
            combined.shape[1],
        )
    else:
        logger.info("Saved Stage 4 outputs to: %s", output_path)

    return True


def save_stage5_excel(memo_ma: np.ndarray, memo_ck: np.ndarray, output_path: str) -> bool:
    """Save Stage 5 outputs (memo_ma, memo_ck) to Excel file with segmentation.

    Excel layout: high frequencies at top
    - Row 1 = Channel 64 (6500 Hz)
    - Row 65 = Channel 0 (40 Hz)

    Args:
        memo_ma: Amplitude memory, shape (n_channels, n_frames)
        memo_ck: Temporal memory, shape (n_channels, n_frames)
        output_path: Path to save Excel file

    Returns:
        True if saved successfully
    """
    ma_segments = split_into_segments(memo_ma[::-1])
    ck_segments = split_into_segments(memo_ck[::-1])

    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        for i, ma_segment in enumerate(ma_segments):
            sheet_name = f"memo_ma_seg{i}" if len(ma_segments) > 1 else "memo_ma"
            df = pd.DataFrame(ma_segment)
            df.to_excel(writer, sheet_name=sheet_name, index=False, header=False)

        for i, ck_segment in enumerate(ck_segments):
            sheet_name = f"memo_ck_seg{i}" if len(ck_segments) > 1 else "memo_ck"
            df = pd.DataFrame(ck_segment)
            df.to_excel(writer, sheet_name=sheet_name, index=False, header=False)

    if len(ma_segments) > 1:
        logger.info(
            "Saved Stage 5 outputs to: %s (%d segments per sheet, %d columns total)",
            output_path,
            len(ma_segments),
            memo_ma.shape[1],
        )
    else:
        logger.info("Saved Stage 5 outputs to: %s", output_path)

    return True


def save_stage5_5_excel(
    memo_ma_integrated: np.ndarray, memo_ck_integrated: np.ndarray, output_path: str
):
    """Save Stage 5.5 outputs (decimated memo_ma, memo_ck) to Excel file with segmentation.

    Excel layout: high frequencies at top
    - Row 1 = Channel 64 (6500 Hz)
    - Row 65 = Channel 0 (40 Hz)

    Args:
        memo_ma_integrated: Integrated/decimated amplitude memory
        memo_ck_integrated: Integrated/decimated temporal memory
        output_path: Path to save Excel file
    """
    ma_segments = split_into_segments(memo_ma_integrated[::-1])
    ck_segments = split_into_segments(memo_ck_integrated[::-1])

    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        for i, ma_segment in enumerate(ma_segments):
            sheet_name = (
                f"memo_ma_integrated_seg{i}" if len(ma_segments) > 1 else "memo_ma_integrated"
            )
            df = pd.DataFrame(ma_segment)
            df.to_excel(writer, sheet_name=sheet_name, index=False, header=False)

        for i, ck_segment in enumerate(ck_segments):
            sheet_name = (
                f"memo_ck_integrated_seg{i}" if len(ck_segments) > 1 else "memo_ck_integrated"
            )
            df = pd.DataFrame(ck_segment)
            df.to_excel(writer, sheet_name=sheet_name, index=False, header=False)

    if len(ma_segments) > 1:
        logger.info(
            "Saved Stage 5.5 outputs to: %s (%d segments per sheet, %d columns total)",
            output_path,
            len(ma_segments),
            memo_ma_integrated.shape[1],
        )
    else:
        logger.info("Saved Stage 5.5 outputs to: %s", output_path)


def save_bilinear_histogram_global_excel(memo_ma_integrated: np.ndarray, output_path: str):
    """Save global bilinear histogram to Excel file.

    Creates Excel file with three sheets:
    - 'mean': Mean of consecutive frames (all channels)
    - 'variation': Absolute variation between consecutive frames (all channels)
    - 'mean_vs_variation': 2D histogram showing density of (mean, variation) pairs

    Excel layout for mean/variation sheets: high frequencies at top
    - Row 1 = Channel 64 (6500 Hz)
    - Row 65 = Channel 0 (40 Hz)

    Args:
        memo_ma_integrated: Integrated amplitude memory (n_channels × n_frames)
        output_path: Path to save Excel file
    """
    histogram_config = BilinearHistogramConfig.default()
    computer = BilinearHistogramComputer(histogram_config)
    result = computer.compute(memo_ma_integrated)

    consecutive_mean = result["consecutive_mean"]
    abs_variation = result["abs_variation"]
    hist_df = result["histogram_df"]

    mean_reversed = consecutive_mean[::-1]
    variation_reversed = abs_variation[::-1]

    mean_segments = split_into_segments(mean_reversed)
    variation_segments = split_into_segments(variation_reversed)

    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        for i, mean_segment in enumerate(mean_segments):
            sheet_name = f"mean_seg{i}" if len(mean_segments) > 1 else "mean"
            df = pd.DataFrame(mean_segment)
            df.to_excel(writer, sheet_name=sheet_name, index=False, header=False)

        for i, var_segment in enumerate(variation_segments):
            sheet_name = f"variation_seg{i}" if len(variation_segments) > 1 else "variation"
            df = pd.DataFrame(var_segment)
            df.to_excel(writer, sheet_name=sheet_name, index=False, header=False)

        hist_df.to_excel(writer, sheet_name="mean_vs_variation", index=True, header=True)

    if len(mean_segments) > 1:
        logger.info(
            "Saved temporal derivatives to: %s (%d segments per sheet)",
            output_path,
            len(mean_segments),
        )
    else:
        logger.info("Saved temporal derivatives to: %s", output_path)


def save_bilinear_histogram_global_no_origin_excel(
    memo_ma_integrated: np.ndarray, output_path: str
):
    """Save global bilinear histogram to Excel file with (0,0) point set to 0.

    Creates Excel file with three sheets:
    - 'mean': Mean of consecutive frames (all channels)
    - 'variation': Absolute variation between consecutive frames (all channels)
    - 'mean_vs_variation': 2D histogram with (0,0) set to 0

    Excel layout for mean/variation sheets: high frequencies at top
    - Row 1 = Channel 64 (6500 Hz)
    - Row 65 = Channel 0 (40 Hz)

    Args:
        memo_ma_integrated: Integrated amplitude memory (n_channels × n_frames)
        output_path: Path to save Excel file
    """
    histogram_config = BilinearHistogramConfig.default()
    computer = BilinearHistogramComputer(histogram_config)
    result = computer.compute(memo_ma_integrated)

    consecutive_mean = result["consecutive_mean"]
    abs_variation = result["abs_variation"]
    hist_df = result["histogram_df"].copy()

    if 0 in hist_df.index and 0 in hist_df.columns:
        hist_df.loc[0, 0] = 0

    mean_reversed = consecutive_mean[::-1]
    variation_reversed = abs_variation[::-1]

    mean_segments = split_into_segments(mean_reversed)
    variation_segments = split_into_segments(variation_reversed)

    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        for i, mean_segment in enumerate(mean_segments):
            sheet_name = f"mean_seg{i}" if len(mean_segments) > 1 else "mean"
            df = pd.DataFrame(mean_segment)
            df.to_excel(writer, sheet_name=sheet_name, index=False, header=False)

        for i, var_segment in enumerate(variation_segments):
            sheet_name = f"variation_seg{i}" if len(variation_segments) > 1 else "variation"
            df = pd.DataFrame(var_segment)
            df.to_excel(writer, sheet_name=sheet_name, index=False, header=False)

        hist_df.to_excel(writer, sheet_name="mean_vs_variation", index=True, header=True)

    if len(mean_segments) > 1:
        logger.info(
            "Saved bilinear histogram (no origin) to: %s (%d segments per sheet)",
            output_path,
            len(mean_segments),
        )
    else:
        logger.info("Saved bilinear histogram (no origin) to: %s", output_path)


def _create_data_sheet(wb: Workbook, mean_reversed: np.ndarray, variation_reversed: np.ndarray):
    """Create Data sheet with mean and variation values."""
    n_channels, n_frames = mean_reversed.shape

    ws_data = wb.create_sheet("Data")
    ws_data["A1"] = "Channel"
    ws_data["A1"].font = Font(bold=True)

    for col_idx, frame in enumerate(range(n_frames), start=2):
        ws_data.cell(1, col_idx, f"Mean_F{frame}").font = Font(bold=True)
    for row_idx in range(n_channels):
        ws_data.cell(row_idx + 2, 1, f"Ch{n_channels - 1 - row_idx}")
        for col_idx in range(n_frames):
            ws_data.cell(row_idx + 2, col_idx + 2, float(mean_reversed[row_idx, col_idx]))

    mean_cols = n_frames
    for col_idx, frame in enumerate(range(n_frames), start=mean_cols + 2):
        ws_data.cell(1, col_idx, f"Var_F{frame}").font = Font(bold=True)
    for row_idx in range(n_channels):
        for col_idx in range(n_frames):
            ws_data.cell(
                row_idx + 2, mean_cols + col_idx + 2, float(variation_reversed[row_idx, col_idx])
            )


def _create_interactive_histogram_sheet(
    wb: Workbook, n_frames: int, n_channels: int, sample_rate: int, decimation_factor: int
):
    """Create Interactive_Histogram sheet with control cells and formulas."""
    ws_hist = wb.create_sheet("Interactive_Histogram", 0)

    ws_hist["B2"] = "Frame Number (0-" + str(n_frames - 1) + "):"
    ws_hist["B2"].font = Font(bold=True, size=12)
    ws_hist["C2"] = n_frames // 2
    ws_hist["C2"].fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    ws_hist["C2"].font = Font(bold=True, size=14)
    ws_hist["C2"].alignment = Alignment(horizontal="center")

    ws_hist["B3"] = "Time (seconds):"
    ws_hist["B3"].font = Font(bold=True)
    ws_hist["C3"] = f"=C2*{decimation_factor}/{sample_rate}"
    ws_hist["C3"].number_format = "0.000"

    mean_min, mean_max = 0, 31
    var_min, var_max = 0, 10

    ws_hist["B5"] = "Mean →"
    ws_hist["B5"].font = Font(bold=True)
    ws_hist["A6"] = "Variation ↓"
    ws_hist["A6"].font = Font(bold=True)

    for col_idx, mean_val in enumerate(range(mean_min, mean_max + 1), start=2):
        cell = ws_hist.cell(6, col_idx, mean_val)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center")

    for row_idx, var_val in enumerate(range(var_min, var_max + 1), start=7):
        cell = ws_hist.cell(row_idx, 1, var_val)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center")

    var_col_offset = n_frames + 2

    for row_idx, var_val in enumerate(range(var_min, var_max + 1), start=7):
        for col_idx, mean_val in enumerate(range(mean_min, mean_max + 1), start=2):
            var_col = get_column_letter(var_col_offset)
            formula = (
                f"=SUMPRODUCT("
                f"(OFFSET(Data!$B$2,0,$C$2,{n_channels},1)>={mean_val - 0.5})*"
                f"(OFFSET(Data!$B$2,0,$C$2,{n_channels},1)<{mean_val + 0.5})*"
                f"(OFFSET(Data!${var_col}$2,0,$C$2,{n_channels},1)>={var_val - 0.5})*"
                f"(OFFSET(Data!${var_col}$2,0,$C$2,{n_channels},1)<{var_val + 0.5})"
                f")"
            )
            cell = ws_hist.cell(row_idx, col_idx)
            cell.value = formula

    thin_border = Border(
        left=Side(style="thin"),
        right=Side(style="thin"),
        top=Side(style="thin"),
        bottom=Side(style="thin"),
    )

    for row_idx in range(7, 7 + var_max - var_min + 1):
        for col_idx in range(2, 2 + mean_max - mean_min + 1):
            ws_hist.cell(row_idx, col_idx).border = thin_border

    ws_hist.column_dimensions["A"].width = 12
    ws_hist.column_dimensions["B"].width = 20
    ws_hist.column_dimensions["C"].width = 15


def save_bilinear_histogram_frames_excel(
    memo_ma_integrated: np.ndarray, sample_rate: int, decimation_factor: int, output_path: str
):
    """Save frame-by-frame bilinear histogram to Excel file.

    Creates Excel workbook with two sheets:
    - 'Data': All mean and variation values for all frames
    - 'Interactive_Histogram': Control cell (C2) to select frame number,
      2D histogram computed for that frame

    Args:
        memo_ma_integrated: Integrated amplitude memory (n_channels × n_frames)
        sample_rate: Audio sample rate
        decimation_factor: Decimation factor from Stage 5.5
        output_path: Path to save Excel file
    """
    histogram_config = BilinearHistogramConfig.default()
    computer = BilinearHistogramComputer(histogram_config)
    result = computer.compute(memo_ma_integrated)

    consecutive_mean = result["consecutive_mean"]
    abs_variation = result["abs_variation"]

    n_channels, n_frames = consecutive_mean.shape

    mean_reversed = consecutive_mean[::-1]
    variation_reversed = abs_variation[::-1]

    wb = Workbook()
    wb.remove(wb.active)

    _create_data_sheet(wb, mean_reversed, variation_reversed)
    _create_interactive_histogram_sheet(wb, n_frames, n_channels, sample_rate, decimation_factor)

    wb.save(output_path)
    logger.info("Saved interactive histogram to: %s", output_path)


def save_invariance_excel(
    invariance_table: np.ndarray, ma_values: list, nbck_values: list, output_path: str
):
    """Save invariance table with MA and NBCK rows at bottom.

    Excel layout reversed:
    - Row 1 = highest harmonic (e.g., H30)
    - Row N = lowest harmonic (fundamental, H1)

    Args:
        invariance_table: Invariance table, shape (n_harmonics, n_frames)
        ma_values: List of amplitude values at fundamental
        nbck_values: List of period values (fundamental)
        output_path: Path to save Excel file
    """
    if invariance_table.size == 0 or len(ma_values) == 0:
        logger.warning("Skipping invariance export (no F0 detections found): %s", output_path)
        return

    invariance_reversed = invariance_table[::-1]

    df = pd.DataFrame(invariance_reversed)

    df.loc[len(df)] = ma_values

    df.loc[len(df)] = nbck_values

    df.to_excel(output_path, index=False, header=False)
    logger.info("Saved invariance table to: %s", output_path)


def save_waveform_plot(signal: np.ndarray, sample_rate: int, output_path: str):
    """Save waveform visualization to PNG.

    Args:
        signal: Audio signal array
        sample_rate: Sample rate in Hz
        output_path: Path to save PNG file
    """
    duration = len(signal) / sample_rate
    fig, ax = plt.subplots(1, 1, figsize=STANDARD_FIG_SIZE)
    time_seconds = np.arange(len(signal)) / sample_rate
    ax.plot(time_seconds, signal, linewidth=0.5, color="blue")
    ax.set_xlim(0, duration)
    ax.set_title("Audio Waveform", fontsize=14, fontweight="bold")
    ax.set_xlabel("Time (seconds)")
    ax.set_ylabel("Amplitude")
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved waveform plot to: %s", output_path)


def save_temporal_memory_f0_plot(
    memo_ck_integrated: np.ndarray,
    f0_frames: np.ndarray,
    f0_channels: np.ndarray,
    decimation_factor: int,
    sample_rate: int,
    output_path: str,
):
    """Save temporal memory with F0 track to PNG.

    Args:
        memo_ck_integrated: Integrated temporal memory
        f0_frames: F0 frame indices
        f0_channels: F0 channel indices
        decimation_factor: Decimation factor used
        sample_rate: Sample rate in Hz
        output_path: Path to save PNG file
    """
    fig, ax = plt.subplots(1, 1, figsize=STANDARD_FIG_SIZE)

    f0_time_seconds = f0_frames / sample_rate * decimation_factor
    duration_decimated = memo_ck_integrated.shape[1] * decimation_factor / sample_rate

    im = ax.imshow(
        memo_ck_integrated,
        aspect="auto",
        cmap="hot",
        interpolation="nearest",
        origin="lower",
        extent=[0, duration_decimated, 0, memo_ck_integrated.shape[0]],
    )

    ax.plot(
        f0_time_seconds,
        f0_channels,
        "cyan",
        linewidth=2,
        marker="o",
        markersize=3,
        label="F0 track",
    )

    ax.set_title("Temporal Memory with F0 Track", fontsize=14, fontweight="bold")
    ax.set_xlabel("Time (seconds)")
    ax.set_ylabel("Channel (0=low freq)")
    ax.legend(loc="upper right")
    plt.colorbar(im, ax=ax, label="Temporal Encoding", orientation="horizontal")

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved temporal memory plot to: %s", output_path)


def save_amplitude_memory_f0_plot(
    memo_ma_integrated: np.ndarray,
    f0_frames: np.ndarray,
    f0_channels: np.ndarray,
    decimation_factor: int,
    sample_rate: int,
    output_path: str,
):
    """Save amplitude memory with F0 track to PNG.

    Args:
        memo_ma_integrated: Integrated amplitude memory
        f0_frames: F0 frame indices
        f0_channels: F0 channel indices
        decimation_factor: Decimation factor used
        sample_rate: Sample rate in Hz
        output_path: Path to save PNG file
    """
    fig, ax = plt.subplots(1, 1, figsize=STANDARD_FIG_SIZE)

    f0_time_seconds = f0_frames / sample_rate * decimation_factor
    duration_decimated = memo_ma_integrated.shape[1] * decimation_factor / sample_rate

    im = ax.imshow(
        memo_ma_integrated,
        aspect="auto",
        cmap="hot",
        interpolation="nearest",
        origin="lower",
        extent=[0, duration_decimated, 0, memo_ma_integrated.shape[0]],
    )

    ax.plot(
        f0_time_seconds,
        f0_channels,
        "cyan",
        linewidth=2,
        marker="o",
        markersize=3,
        label="F0 track",
    )

    ax.set_title("Amplitude Memory with F0 Track", fontsize=14, fontweight="bold")
    ax.set_xlabel("Time (seconds)")
    ax.set_ylabel("Channel (0=low freq)")
    ax.legend(loc="upper right")
    plt.colorbar(im, ax=ax, label="Amplitude (dB)", orientation="horizontal")

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved amplitude memory plot to: %s", output_path)


def save_mean_consecutive_plot(
    memo_ma_integrated: np.ndarray,
    decimation_factor: int,
    sample_rate: int,
    output_path: str,
):
    """Save median of consecutive frames plot.

    Args:
        memo_ma_integrated: Integrated amplitude memory (n_channels × n_frames)
        decimation_factor: Decimation factor used
        sample_rate: Sample rate in Hz
        output_path: Path to save PNG file
    """
    n_channels, n_frames = memo_ma_integrated.shape

    consecutive_mean = (memo_ma_integrated[:, :-1] + memo_ma_integrated[:, 1:]) / 2
    median_consecutive = np.median(consecutive_mean, axis=0)

    ms_per_frame = (1000 / sample_rate) * decimation_factor
    time_derivative = np.arange(len(median_consecutive)) * ms_per_frame / 1000
    duration = memo_ma_integrated.shape[1] * decimation_factor / sample_rate

    fig, ax = plt.subplots(figsize=STANDARD_FIG_SIZE)
    ax.plot(
        time_derivative,
        median_consecutive,
        linewidth=1,
        color="blue",
        marker="o",
        markersize=2,
        markerfacecolor="blue",
        markeredgecolor="blue",
    )
    ax.set_xlabel("Time (s)")
    ax.set_xlim(0, duration)
    ax.set_ylabel("Median Mean Consecutive Frames")
    ax.set_title(
        "Mean of Consecutive Frames (Median Across Channels)", fontsize=14, fontweight="bold"
    )
    ax.grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved mean consecutive plot to: %s", output_path)


def save_abs_variation_plot(
    memo_ma_integrated: np.ndarray,
    decimation_factor: int,
    sample_rate: int,
    output_path: str,
):
    """Save absolute variation between consecutive frames plot.

    Args:
        memo_ma_integrated: Integrated amplitude memory (n_channels × n_frames)
        decimation_factor: Decimation factor used
        sample_rate: Sample rate in Hz
        output_path: Path to save PNG file
    """
    n_channels, n_frames = memo_ma_integrated.shape

    abs_diff = np.abs(memo_ma_integrated[:, 1:] - memo_ma_integrated[:, :-1])
    median_variation = np.median(abs_diff, axis=0)

    ms_per_frame = (1000 / sample_rate) * decimation_factor
    time_derivative = np.arange(len(median_variation)) * ms_per_frame / 1000
    duration = memo_ma_integrated.shape[1] * decimation_factor / sample_rate

    fig, ax = plt.subplots(figsize=STANDARD_FIG_SIZE)
    ax.plot(
        time_derivative,
        median_variation,
        linewidth=1,
        color="orange",
        marker="o",
        markersize=2,
        markerfacecolor="orange",
        markeredgecolor="orange",
    )
    ax.set_xlabel("Time (s)")
    ax.set_xlim(0, duration)
    ax.set_ylabel("Median Absolute Variation")
    ax.set_title(
        "Absolute Variation Between Frames (Median Across Channels)", fontsize=14, fontweight="bold"
    )
    ax.grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved absolute variation plot to: %s", output_path)


def save_mean_consecutive_heatmap(
    memo_ma_integrated: np.ndarray,
    decimation_factor: int,
    sample_rate: int,
    output_path: str,
):
    """Save heatmap of mean between consecutive frames.

    Args:
        memo_ma_integrated: Integrated amplitude memory (n_channels × n_frames)
        decimation_factor: Decimation factor used
        sample_rate: Sample rate in Hz
        output_path: Path to save PNG file
    """
    n_channels, n_frames = memo_ma_integrated.shape

    consecutive_mean = (memo_ma_integrated[:, :-1] + memo_ma_integrated[:, 1:]) / 2

    ms_per_frame = (1000 / sample_rate) * decimation_factor
    duration = (consecutive_mean.shape[1] * ms_per_frame) / 1000

    fig, ax = plt.subplots(figsize=STANDARD_FIG_SIZE)
    im = ax.imshow(
        consecutive_mean,
        aspect="auto",
        cmap="hot",
        interpolation="nearest",
        origin="lower",
        extent=[0, duration, 0, n_channels],
    )

    ax.set_title("Mean of Consecutive Frames (All Channels)", fontsize=14, fontweight="bold")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Channel (0=low freq)")
    plt.colorbar(im, ax=ax, label="Mean Amplitude (dB)", orientation="horizontal")

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved mean consecutive heatmap to: %s", output_path)


def save_abs_variation_heatmap(
    memo_ma_integrated: np.ndarray,
    decimation_factor: int,
    sample_rate: int,
    output_path: str,
):
    """Save heatmap of absolute variation between consecutive frames.

    Args:
        memo_ma_integrated: Integrated amplitude memory (n_channels × n_frames)
        decimation_factor: Decimation factor used
        sample_rate: Sample rate in Hz
        output_path: Path to save PNG file
    """
    n_channels, n_frames = memo_ma_integrated.shape

    abs_diff = np.abs(memo_ma_integrated[:, 1:] - memo_ma_integrated[:, :-1])

    ms_per_frame = (1000 / sample_rate) * decimation_factor
    duration = (abs_diff.shape[1] * ms_per_frame) / 1000

    fig, ax = plt.subplots(figsize=STANDARD_FIG_SIZE)
    im = ax.imshow(
        abs_diff,
        aspect="auto",
        cmap="hot",
        interpolation="nearest",
        origin="lower",
        extent=[0, duration, 0, n_channels],
    )

    ax.set_title("Absolute Variation Between Frames (All Channels)", fontsize=14, fontweight="bold")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Channel (0=low freq)")
    plt.colorbar(im, ax=ax, label="Absolute Variation (dB)", orientation="horizontal")

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved absolute variation heatmap to: %s", output_path)


def save_bilinear_histogram_plot(memo_ma_integrated: np.ndarray, output_path: str):
    """Save bilinear histogram (mean vs variation) as PNG.

    Args:
        memo_ma_integrated: Integrated amplitude memory (n_channels × n_frames)
        output_path: Path to save PNG file
    """
    config = BilinearHistogramConfig.default()
    computer = BilinearHistogramComputer(config)
    result = computer.compute(memo_ma_integrated)

    histogram_2d = result["histogram_2d"]
    mean_bins = result["mean_bins"]
    var_bins = result["var_bins"]

    if histogram_2d.size == 0:
        logger.warning("No data to plot in bilinear histogram")
        return

    logger.info(
        "Histogram shape: %d variations × %d means = %d cells",
        len(var_bins),
        len(mean_bins),
        histogram_2d.size,
    )
    logger.info("Non-zero cells: %d", np.count_nonzero(histogram_2d))
    logger.info("Total count: %d", histogram_2d.sum())

    n_var_values = len(var_bins)
    n_mean_values = len(mean_bins)

    fig_width = min(max(n_mean_values * 0.4, 10), 30)
    fig_height = min(max(n_var_values * 0.4, 6), 20)
    fig, ax = plt.subplots(figsize=(fig_width, fig_height))

    im = ax.imshow(
        histogram_2d,
        aspect="auto",
        cmap="YlGn",
        interpolation="nearest",
        origin="lower",
    )

    for i in range(n_var_values):
        for j in range(n_mean_values):
            count = histogram_2d[i, j]
            if count > 0:
                text_color = "black" if count < histogram_2d.max() * 0.6 else "white"
                ax.text(
                    j,
                    i,
                    str(int(count)),
                    ha="center",
                    va="center",
                    color=text_color,
                    fontsize=6,
                    fontweight="bold",
                )

    ax.set_xticks(range(0, n_mean_values, max(1, n_mean_values // 20)))
    ax.set_xticklabels([mean_bins[i] for i in range(0, n_mean_values, max(1, n_mean_values // 20))])
    ax.set_yticks(range(0, n_var_values, max(1, n_var_values // 10)))
    ax.set_yticklabels([var_bins[i] for i in range(0, n_var_values, max(1, n_var_values // 10))])

    ax.set_title("Bilinear Histogram: Mean vs Variation (Global)", fontsize=14, fontweight="bold")
    ax.set_xlabel("Mean of Consecutive Frames")
    ax.set_ylabel("Absolute Variation Between Frames")
    plt.colorbar(im, ax=ax, label="Count (number of occurrences)", orientation="horizontal")

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved bilinear histogram to: %s", output_path)


def save_mean_cumulative_50_plot(
    memo_ma_integrated: np.ndarray,
    decimation_factor: int,
    sample_rate: int,
    output_path: str,
):
    """Save plot of 50% cumulative threshold for mean values over time.

    For each frame, computes mean and variation for all channels, builds 2D
    histogram (mean × variation), sums along variation axis to get 1D distribution
    of counts per mean bin, and finds mean bin where cumulative count reaches 50%
    of total channels.

    Args:
        memo_ma_integrated: Integrated amplitude memory (n_channels × n_frames)
        decimation_factor: Decimation factor used
        sample_rate: Sample rate in Hz
        output_path: Path to save PNG file
    """
    config = BilinearHistogramConfig.default()
    computer = BilinearHistogramComputer(config)

    consecutive_mean = (memo_ma_integrated[:, :-1] + memo_ma_integrated[:, 1:]) / 2
    abs_variation = np.abs(memo_ma_integrated[:, 1:] - memo_ma_integrated[:, :-1])
    n_frames = consecutive_mean.shape[1]

    cumulative_50_indices = np.zeros(n_frames)
    for frame_idx in range(n_frames):
        mean_values = consecutive_mean[:, frame_idx]
        var_values = abs_variation[:, frame_idx]
        cumulative_50_indices[frame_idx] = computer.compute_cumulative_50_percent_mean(
            mean_values, var_values
        )

    ms_per_frame = (1000 / sample_rate) * decimation_factor
    time_s = np.arange(n_frames) * ms_per_frame / 1000
    duration = n_frames * ms_per_frame / 1000

    fig, ax = plt.subplots(figsize=STANDARD_FIG_SIZE)
    ax.plot(
        time_s,
        cumulative_50_indices,
        linewidth=1.5,
        color="blue",
        marker="o",
        markersize=3,
        markerfacecolor="blue",
        markeredgecolor="darkblue",
    )
    ax.set_xlabel("Time (s)")
    ax.set_xlim(0, duration)
    ax.set_ylabel("Mean Value at 50% Cumulative Count")
    ax.set_title(
        "Mean MA: 50% Cumulative Threshold Over Time (2D Histogram Method)",
        fontsize=14,
        fontweight="bold",
    )
    ax.grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved mean cumulative 50%% plot to: %s", output_path)


def save_variation_cumulative_50_plot(
    memo_ma_integrated: np.ndarray,
    decimation_factor: int,
    sample_rate: int,
    output_path: str,
):
    """Save plot of 50% cumulative threshold for variation values over time.

    For each frame, computes mean and variation for all channels, builds 2D
    histogram (mean × variation) with integer values, sums along mean axis to get
    1D distribution of counts per variation value, and finds variation value where
    cumulative count reaches 50% of total channels.

    Args:
        memo_ma_integrated: Integrated amplitude memory (n_channels × n_frames)
        decimation_factor: Decimation factor used
        sample_rate: Sample rate in Hz
        output_path: Path to save PNG file
    """
    config = BilinearHistogramConfig.default()
    computer = BilinearHistogramComputer(config)

    consecutive_mean = (memo_ma_integrated[:, :-1] + memo_ma_integrated[:, 1:]) / 2
    abs_variation = np.abs(memo_ma_integrated[:, 1:] - memo_ma_integrated[:, :-1])
    n_frames = consecutive_mean.shape[1]

    cumulative_50_indices = np.zeros(n_frames)
    for frame_idx in range(n_frames):
        mean_values = consecutive_mean[:, frame_idx]
        var_values = abs_variation[:, frame_idx]
        cumulative_50_indices[frame_idx] = computer.compute_cumulative_50_percent_variation(
            mean_values, var_values
        )

    ms_per_frame = (1000 / sample_rate) * decimation_factor
    time_s = np.arange(n_frames) * ms_per_frame / 1000
    duration = n_frames * ms_per_frame / 1000

    fig, ax = plt.subplots(figsize=STANDARD_FIG_SIZE)
    ax.plot(
        time_s,
        cumulative_50_indices,
        linewidth=1.5,
        color="orange",
        marker="o",
        markersize=3,
        markerfacecolor="orange",
        markeredgecolor="darkorange",
    )
    ax.set_xlabel("Time (s)")
    ax.set_xlim(0, duration)
    ax.set_ylabel("Variation Value at 50% Cumulative Count")
    ax.set_title(
        "Variation MA: 50% Cumulative Threshold Over Time (2D Histogram Method)",
        fontsize=14,
        fontweight="bold",
    )
    ax.grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved variation cumulative 50%% plot to: %s", output_path)


def save_fundamental_vs_max_ma_plot(
    memo_ma_integrated: np.ndarray,
    f0_frames: np.ndarray,
    f0_channels: np.ndarray,
    decimation_factor: int,
    sample_rate: int,
    output_path: str,
):
    """Plot fundamental MA and max MA at each time step.

    Args:
        memo_ma_integrated: Integrated amplitude memory (n_channels × n_frames)
        f0_frames: F0 frame indices
        f0_channels: F0 channel indices
        decimation_factor: Decimation factor used
        sample_rate: Sample rate in Hz
        output_path: Path to save PNG file
    """
    n_channels, n_frames = memo_ma_integrated.shape

    fundamental_ma = np.zeros(n_frames)
    for frame_idx, channel_idx in zip(f0_frames, f0_channels, strict=False):
        ma_value = memo_ma_integrated[channel_idx, frame_idx]
        fundamental_ma[frame_idx] = ma_value

    max_ma = np.max(memo_ma_integrated, axis=0)

    ms_per_frame = (1000 / sample_rate) * decimation_factor
    time_s = np.arange(n_frames) * ms_per_frame / 1000
    duration = n_frames * ms_per_frame / 1000

    fig, ax = plt.subplots(figsize=STANDARD_FIG_SIZE)

    ax.plot(
        time_s,
        fundamental_ma,
        marker="o",
        markersize=4,
        linestyle="-",
        linewidth=1.5,
        color="blue",
        markerfacecolor="blue",
        markeredgecolor="darkblue",
        label="Fundamental MA",
        alpha=0.8,
    )

    ax.plot(
        time_s,
        max_ma,
        marker="o",
        markersize=4,
        linestyle="-",
        linewidth=1.5,
        color="red",
        markerfacecolor="red",
        markeredgecolor="darkred",
        label="Max MA (all channels)",
        alpha=0.8,
    )

    ax.set_xlabel("Time (s)")
    ax.set_xlim(0, duration)
    ax.set_ylabel("Amplitude (dB)")
    ax.set_title("Fundamental MA vs Max MA", fontsize=14, fontweight="bold")
    ax.legend(loc="best")
    ax.grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved fundamental vs max MA plot to: %s", output_path)


def save_combined_analysis_plot(
    signal: np.ndarray,
    memo_ma_integrated: np.ndarray,
    memo_ck_integrated: np.ndarray,
    f0_frames: np.ndarray,
    f0_channels: np.ndarray,
    decimation_factor: int,
    sample_rate: int,
    output_path: str,
    phoneme_name: str = "",
):
    """Create multi-panel visualization with all plots.

    Args:
        signal: Original audio signal
        memo_ma_integrated: Integrated amplitude memory
        memo_ck_integrated: Integrated temporal memory
        f0_frames: F0 frame indices
        f0_channels: F0 channel indices
        decimation_factor: Decimation factor used
        sample_rate: Sample rate in Hz
        output_path: Path to save PNG file
        phoneme_name: Name of the phoneme for display in the title
    """
    n_channels, n_frames = memo_ma_integrated.shape
    duration = len(signal) / sample_rate
    duration_decimated = n_frames * decimation_factor / sample_rate

    fig = plt.figure(figsize=(16, 44))
    gs = fig.add_gridspec(11, 1, hspace=0.4)

    ax1 = fig.add_subplot(gs[0])
    time_seconds = np.arange(len(signal)) / sample_rate
    ax1.plot(time_seconds, signal, linewidth=0.5, color="blue")
    ax1.set_xlim(0, duration)
    ax1.set_title("Audio Waveform", fontsize=14, fontweight="bold")
    ax1.set_xlabel("Time (seconds)")
    ax1.set_ylabel("Amplitude")
    ax1.grid(True, alpha=0.3, axis="both")

    f0_time_seconds = f0_frames / sample_rate * decimation_factor
    ms_per_frame = (1000 / sample_rate) * decimation_factor
    time_s = np.arange(n_frames) * ms_per_frame / 1000
    consecutive_mean = (memo_ma_integrated[:, :-1] + memo_ma_integrated[:, 1:]) / 2
    abs_diff = np.abs(memo_ma_integrated[:, 1:] - memo_ma_integrated[:, :-1])
    duration_deriv = (consecutive_mean.shape[1] * ms_per_frame) / 1000
    time_derivative = np.arange(consecutive_mean.shape[1]) * ms_per_frame / 1000

    ax2 = fig.add_subplot(gs[1])
    fundamental_ma = np.zeros(n_frames)
    for frame_idx, channel_idx in zip(f0_frames, f0_channels, strict=False):
        fundamental_ma[frame_idx] = memo_ma_integrated[channel_idx, frame_idx]
    max_ma = np.max(memo_ma_integrated, axis=0)
    ax2.plot(
        time_s,
        fundamental_ma,
        marker="o",
        markersize=4,
        linestyle="-",
        linewidth=1.5,
        color="blue",
        label="Fundamental MA",
        alpha=0.8,
    )
    ax2.plot(
        time_s,
        max_ma,
        marker="o",
        markersize=4,
        linestyle="-",
        linewidth=1.5,
        color="red",
        label="Max MA (all channels)",
        alpha=0.8,
    )
    ax2.set_xlim(0, duration_decimated)
    ax2.set_xlabel("Time (s)")
    ax2.set_ylabel("Amplitude (dB)")
    ax2.set_title("Fundamental MA vs Max MA", fontsize=14, fontweight="bold")
    ax2.legend(loc="best")
    ax2.grid(alpha=0.3)

    ax3 = fig.add_subplot(gs[2])
    f0_nbck = np.zeros(n_frames)
    for frame_idx, channel_idx in zip(f0_frames, f0_channels, strict=False):
        f0_nbck[frame_idx] = memo_ck_integrated[channel_idx, frame_idx]
    f0_periods = np.array([np.exp(nbck / 10) if nbck > 0 else 0 for nbck in f0_nbck])
    lowest_nbck = memo_ck_integrated[0, :]
    lowest_periods = np.array([np.exp(nbck / 10) if nbck > 0 else 0 for nbck in lowest_nbck])
    ax3.plot(
        time_s,
        f0_periods,
        marker="o",
        markersize=4,
        linestyle="-",
        linewidth=1.5,
        color="blue",
        label="F0 Period (detected)",
        alpha=0.8,
    )
    ax3.plot(
        time_s,
        lowest_periods,
        marker="o",
        markersize=4,
        linestyle="-",
        linewidth=1.5,
        color="green",
        label="Lowest Channel Period (40 Hz)",
        alpha=0.8,
    )
    ax3.set_xlim(0, duration_decimated)
    ax3.set_xlabel("Time (s)")
    ax3.set_ylabel("Period (samples)")
    ax3.set_title("F0 Period vs Lowest Channel Period", fontsize=14, fontweight="bold")
    ax3.legend(loc="best")
    ax3.grid(alpha=0.3)

    ax4 = fig.add_subplot(gs[3])
    median_consecutive = np.median(consecutive_mean, axis=0)
    ax4.plot(
        time_derivative, median_consecutive, linewidth=1, color="blue", marker="o", markersize=2
    )
    ax4.set_xlim(0, duration_decimated)
    ax4.set_xlabel("Time (s)")
    ax4.set_ylabel("Median Mean Consecutive Frames")
    ax4.set_title(
        "Mean of Consecutive Frames (Median Across Channels)", fontsize=14, fontweight="bold"
    )
    ax4.grid(alpha=0.3)

    ax5 = fig.add_subplot(gs[4])
    median_variation = np.median(abs_diff, axis=0)
    ax5.plot(
        time_derivative, median_variation, linewidth=1, color="orange", marker="o", markersize=2
    )
    ax5.set_xlim(0, duration_decimated)
    ax5.set_xlabel("Time (s)")
    ax5.set_ylabel("Median Absolute Variation")
    ax5.set_title(
        "Absolute Variation Between Frames (Median Across Channels)", fontsize=14, fontweight="bold"
    )
    ax5.grid(alpha=0.3)

    ax6 = fig.add_subplot(gs[5])
    histogram_config = BilinearHistogramConfig.default()
    histogram_computer = BilinearHistogramComputer(histogram_config)

    cumulative_50_mean = np.zeros(consecutive_mean.shape[1])
    for frame_idx in range(consecutive_mean.shape[1]):
        mean_values = consecutive_mean[:, frame_idx]
        var_values = abs_diff[:, frame_idx]
        cumulative_50_mean[frame_idx] = histogram_computer.compute_cumulative_50_percent_mean(
            mean_values, var_values
        )

    ax6.plot(
        time_derivative,
        cumulative_50_mean,
        linewidth=1.5,
        color="blue",
        marker="o",
        markersize=3,
        markerfacecolor="blue",
        markeredgecolor="darkblue",
    )
    ax6.set_xlim(0, duration_decimated)
    ax6.set_xlabel("Time (s)")
    ax6.set_ylabel("Mean Value at 50% Cumulative Count")
    ax6.set_title(
        "Mean MA: 50% Cumulative Threshold Over Time (2D Histogram Method)",
        fontsize=14,
        fontweight="bold",
    )
    ax6.grid(alpha=0.3)

    ax7 = fig.add_subplot(gs[6])
    cumulative_50_var = np.zeros(consecutive_mean.shape[1])
    for frame_idx in range(consecutive_mean.shape[1]):
        mean_values = consecutive_mean[:, frame_idx]
        var_values = abs_diff[:, frame_idx]
        cumulative_50_var[frame_idx] = histogram_computer.compute_cumulative_50_percent_variation(
            mean_values, var_values
        )

    ax7.plot(
        time_derivative,
        cumulative_50_var,
        linewidth=1.5,
        color="orange",
        marker="o",
        markersize=3,
        markerfacecolor="orange",
        markeredgecolor="darkorange",
    )
    ax7.set_xlim(0, duration_decimated)
    ax7.set_xlabel("Time (s)")
    ax7.set_ylabel("Variation Value at 50% Cumulative Count")
    ax7.set_title(
        "Variation MA: 50% Cumulative Threshold Over Time (2D Histogram Method)",
        fontsize=14,
        fontweight="bold",
    )
    ax7.grid(alpha=0.3)

    ax8 = fig.add_subplot(gs[7])
    im8 = ax8.imshow(
        memo_ck_integrated,
        aspect="auto",
        cmap="hot",
        interpolation="nearest",
        origin="lower",
        extent=[0, duration_decimated, 0, n_channels],
    )
    ax8.plot(
        f0_time_seconds,
        f0_channels,
        "cyan",
        linewidth=2,
        marker="o",
        markersize=3,
        label="F0 track",
    )
    ax8.set_title("Temporal Memory with F0 Track", fontsize=14, fontweight="bold")
    ax8.set_xlabel("Time (seconds)")
    ax8.set_ylabel("Channel (0=low freq)")
    ax8.legend(loc="upper right")
    plt.colorbar(im8, ax=ax8, label="Temporal Encoding", orientation="horizontal")

    ax9 = fig.add_subplot(gs[8])
    im9 = ax9.imshow(
        memo_ma_integrated,
        aspect="auto",
        cmap="hot",
        interpolation="nearest",
        origin="lower",
        extent=[0, duration_decimated, 0, n_channels],
    )
    ax9.plot(
        f0_time_seconds,
        f0_channels,
        "cyan",
        linewidth=2,
        marker="o",
        markersize=3,
        label="F0 track",
    )
    ax9.set_title("Amplitude Memory with F0 Track", fontsize=14, fontweight="bold")
    ax9.set_xlabel("Time (seconds)")
    ax9.set_ylabel("Channel (0=low freq)")
    ax9.legend(loc="upper right")
    plt.colorbar(im9, ax=ax9, label="Amplitude (dB)", orientation="horizontal")

    ax10 = fig.add_subplot(gs[9])
    im10 = ax10.imshow(
        consecutive_mean,
        aspect="auto",
        cmap="hot",
        interpolation="nearest",
        origin="lower",
        extent=[0, duration_deriv, 0, n_channels],
    )
    ax10.set_title("Mean of Consecutive Frames (All Channels)", fontsize=14, fontweight="bold")
    ax10.set_xlabel("Time (s)")
    ax10.set_ylabel("Channel (0=low freq)")
    plt.colorbar(im10, ax=ax10, label="Mean Amplitude (dB)", orientation="horizontal")

    ax11 = fig.add_subplot(gs[10])
    im11 = ax11.imshow(
        abs_diff,
        aspect="auto",
        cmap="hot",
        interpolation="nearest",
        origin="lower",
        extent=[0, duration_deriv, 0, n_channels],
    )
    ax11.set_title(
        "Absolute Variation Between Frames (All Channels)", fontsize=14, fontweight="bold"
    )
    ax11.set_xlabel("Time (s)")
    ax11.set_ylabel("Channel (0=low freq)")
    plt.colorbar(im11, ax=ax11, label="Absolute Variation (dB)", orientation="horizontal")

    if phoneme_name:
        fig.suptitle(f"Word: {phoneme_name}", fontsize=18, fontweight="bold", y=0.995)

    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved combined analysis plot to: %s", output_path)


def save_fundamental_vs_lowest_nbck_plot(
    memo_ck_integrated: np.ndarray,
    f0_frames: np.ndarray,
    f0_channels: np.ndarray,
    decimation_factor: int,
    sample_rate: int,
    output_path: str,
):
    """Plot F0 period vs lowest channel period.

    Args:
        memo_ck_integrated: Integrated temporal memory (n_channels × n_frames)
        f0_frames: F0 frame indices
        f0_channels: F0 channel indices
        decimation_factor: Decimation factor used
        sample_rate: Sample rate in Hz
        output_path: Path to save PNG file
    """
    n_channels, n_frames = memo_ck_integrated.shape

    f0_nbck = np.zeros(n_frames)
    for frame_idx, channel_idx in zip(f0_frames, f0_channels, strict=False):
        f0_nbck[frame_idx] = memo_ck_integrated[channel_idx, frame_idx]

    f0_periods = np.zeros_like(f0_nbck)
    for i, nbck in enumerate(f0_nbck):
        if nbck > 0:
            f0_periods[i] = np.exp(nbck / 10)

    lowest_nbck = memo_ck_integrated[0, :]
    lowest_periods = np.zeros_like(lowest_nbck)
    for i, nbck in enumerate(lowest_nbck):
        if nbck > 0:
            lowest_periods[i] = np.exp(nbck / 10)

    ms_per_frame = (1000 / sample_rate) * decimation_factor
    time_s = np.arange(n_frames) * ms_per_frame / 1000
    duration = n_frames * ms_per_frame / 1000

    fig, ax = plt.subplots(figsize=STANDARD_FIG_SIZE)

    ax.plot(
        time_s,
        f0_periods,
        marker="o",
        markersize=4,
        linestyle="-",
        linewidth=1.5,
        color="blue",
        markerfacecolor="blue",
        markeredgecolor="darkblue",
        label="F0 Period (detected)",
        alpha=0.8,
    )

    ax.plot(
        time_s,
        lowest_periods,
        marker="o",
        markersize=4,
        linestyle="-",
        linewidth=1.5,
        color="green",
        markerfacecolor="green",
        markeredgecolor="darkgreen",
        label="Lowest Channel Period (40 Hz)",
        alpha=0.8,
    )

    ax.set_xlabel("Time (s)")
    ax.set_xlim(0, duration)
    ax.set_ylabel("Period (samples)")
    ax.set_title("F0 Period vs Lowest Channel Period", fontsize=14, fontweight="bold")
    ax.legend(loc="best")
    ax.grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved fundamental frequency comparison plot to: %s", output_path)


def create_readme_files(output_dir: Path, base_name: str):
    """Create README.md files in excel, figures, and videos subdirectories.

    Args:
        output_dir: Base output directory
        base_name: Base name of audio file (without extension)
    """
    excel_readme = output_dir / "excel" / "README.md"
    excel_content = f"""# Excel Files for {base_name}

This directory contains Excel files generated from the auditory processing pipeline (Stages 1-7).

**`{base_name}_stage4.xlsx`**
**Stage 4: Peak Extraction**
- Contains peaks extracted from cochlear filtering and the original audio waveform
- Layout: High frequencies at top (Channel 64 = 6500 Hz), low frequencies at bottom
  (Channel 0 = 40 Hz)
- Rows 1-65: Peaks for 65 channels
- Row 66: Audio waveform
- May be segmented into multiple sheets if > 16384 columns

**`{base_name}_stage5.xlsx`**
**Stage 5: Auditory Nerve Encoding**
- Contains auditory nerve outputs: amplitude memory (memo_ma) and temporal memory (memo_ck)
- Sheets: "memo_ma" and "memo_ck" (or segmented versions)
- Layout: High frequencies at top (Channel 64), low frequencies at bottom (Channel 0)
- 65 channels × n_samples
- May be segmented if file duration > ~1 second

**`{base_name}_stage5.5.xlsx`**
**Stage 5.5: Temporal Integration**
- Contains decimated and integrated auditory nerve signals
- Sheets: "memo_ma_integrated" and "memo_ck_integrated"
- Layout: High frequencies at top, low frequencies at bottom
- 65 channels × (n_samples / 100) - decimated by factor of 100
- Always saved regardless of file size

**`{base_name}_invariance.xlsx`**
**Stage 7: Frequency Invariance Table**
- Contains harmonic invariances (amplitude differences relative to fundamental)
- Layout: High harmonics at top (e.g., H30), fundamental at bottom (H1)
- Last 2 rows: MA values (amplitudes) and NBCK values (periods)
- Used for pitch-independent sound recognition

**`{base_name}_bilinear_histogram_global.xlsx`**
**Bilinear Histogram**
- Contains bilinear histogram analysis of amplitude memory
- Sheets:
  - "mean": Mean of consecutive frames (all 65 channels)
  - "variation": Absolute variation between consecutive frames (all 65 channels)
  - "mean_vs_variation": 2D histogram showing (mean, variation) density with integer bins (step=1)
- Layout: High frequencies at top, low frequencies at bottom
- Aggregates all frames into a single histogram

**`{base_name}_bilinear_histogram_frames.xlsx`**
**Frame-by-Frame Bilinear Histogram**
- Interactive Excel workbook with controllable frame selection
- Sheets:
  - "Data": All mean and variation values for all frames
  - "Interactive_Histogram": Control cell (C2) to select frame number,
    dynamically computes 2D histogram for that specific frame
- Change the frame number in cell C2 to see how the histogram evolves over time
- Shows temporal dynamics of the auditory representation

**Notes:**
- All Excel files support automatic segmentation when data exceeds 16384 columns (Excel limit)
- Channel ordering follows spectrogram convention (high frequencies at top)
- Files may be large for long audio samples (>1 second)
"""
    excel_readme.write_text(excel_content)
    logger.info("Created README.md in excel/ directory")

    figures_readme = output_dir / "figures" / "README.md"
    figures_content = f"""# Figures for {base_name}

This directory contains PNG visualizations generated from the auditory processing pipeline.

**`{base_name}_waveform.png`**
**Audio Waveform**
- Time-domain representation of the input audio signal
- X-axis: Time (seconds)
- Y-axis: Amplitude
- Grid: Horizontal and vertical lines for easier reading

**`{base_name}_temporal_memory_f0.png`**
**Temporal Memory with F0 Track**
- Heatmap showing temporal memory (memo_ck) across all channels and time
- Cyan line: Detected F0 (fundamental frequency) track
- Y-axis: Channel index (0 = 40 Hz low freq, 64 = 6500 Hz high freq)
- Colorbar: Temporal encoding values
- Shows periodicity information encoded in the auditory nerve

**`{base_name}_amplitude_memory_f0.png`**
**Amplitude Memory with F0 Track**
- Heatmap showing amplitude memory (memo_ma) across all channels and time
- Cyan line: Detected F0 track
- Y-axis: Channel index (0 = low freq, 64 = high freq)
- Colorbar: Amplitude in dB
- Shows energy distribution across frequency channels over time

**`{base_name}_mean_consecutive.png`**
**Mean of Consecutive Frames (Median)**
- Plot of median mean value across all channels over time
- Computed as: (frame[t] + frame[t+1]) / 2, then median across 65 channels
- Shows overall temporal smoothness of the signal

**`{base_name}_abs_variation.png`**
**Absolute Variation Between Frames (Median)**
- Plot of median absolute variation across all channels over time
- Computed as: |frame[t+1] - frame[t]|, then median across 65 channels
- Shows overall temporal dynamics and change rate

**`{base_name}_mean_consecutive_heatmap.png`**
**Mean of Consecutive Frames (All Channels Heatmap)**
- Heatmap showing mean values for all 65 channels over time
- Y-axis: Channel index (0 = low freq, 64 = high freq)
- Colorbar: Mean amplitude (dB)
- Shows channel-specific temporal smoothness

**`{base_name}_abs_variation_heatmap.png`**
**Absolute Variation Between Frames (All Channels Heatmap)**
- Heatmap showing absolute variation for all 65 channels over time
- Y-axis: Channel index (0 = low freq, 64 = high freq)
- Colorbar: Absolute variation (dB)
- Shows channel-specific temporal dynamics

**`{base_name}_mean_cumulative_50.png`**
**Mean MA: 50% Cumulative Threshold (2D Histogram Method)**
- Plot showing the mean value where 50% of non-zero channels accumulate over time
- Uses 2D histogram (mean × variation) marginalized over variation axis
- **Excludes (0,0) pairs** before computing cumulative threshold
- Represents the median of the marginal mean distribution for each frame

**`{base_name}_variation_cumulative_50.png`**
**Variation MA: 50% Cumulative Threshold (2D Histogram Method)**
- Plot showing the variation value where 50% of non-zero channels accumulate over time
- Uses 2D histogram (mean × variation) marginalized over mean axis
- **Excludes (0,0) pairs** before computing cumulative threshold
- Represents the median of the marginal variation distribution for each frame

**`{base_name}_fundamental_vs_max_ma.png`**
**Fundamental MA vs Max MA**
- Comparison of amplitude at fundamental frequency vs maximum amplitude across all channels
- Blue line: Amplitude at detected F0 channel
- Red line: Maximum amplitude across all 65 channels
- Shows relative strength of fundamental frequency

**`{base_name}_f0_frequency.png`**
**F0 Period vs Lowest Channel Period**
- Comparison of detected F0 period vs lowest channel (40 Hz) period
- Blue line: F0 period (detected fundamental)
- Green line: Lowest channel period (reference)
- Y-axis: Period in samples
- Shows F0 detection quality and reference comparison

**`{base_name}_combined_analysis.png`**
**Combined Analysis (All Plots)**
- Multi-panel visualization with all plots in one figure
- Layout:
  - Rows 1-7: Line plots (waveform, F0 analysis, temporal features, cumulative thresholds)
  - Rows 8-11: Heatmaps (temporal/amplitude memory, mean/variation heatmaps)
- Size: 16×44 inches (large format for detailed analysis)
- Provides overview of all processing stages

**Notes:**
- All figures use standard size: 14×6 inches (except combined analysis)
- All plots use 150 DPI resolution
- Heatmaps use "hot" colormap with origin="lower" (low frequencies at bottom)
- Channel 0 = 40 Hz (lowest frequency), Channel 64 = 6500 Hz (highest frequency)
"""
    figures_readme.write_text(figures_content)
    logger.info("Created README.md in figures/ directory")

    videos_readme = output_dir / "videos" / "README.md"
    videos_content = f"""# Videos for {base_name}

This directory contains video files generated from the auditory processing pipeline.

**`{base_name}_frame_histogram.mp4`**
**Frame-by-Frame Histogram Evolution with Audio**

Video showing the evolution of the 2D histogram (mean × variation)
frame by frame, synchronized with the audio playback.

**Contents:**
- **Visual**: For each temporal frame, displays the 2D histogram of all 65 cochlear channels
  - X-axis: Mean values (average between consecutive frames)
  - Y-axis: Variation values (absolute difference between consecutive frames)
  - Colors: Density (number of channels having these values)
  - Integer bins with step=1 for both axes
- **Audio**: Original audio of the phoneme plays in synchronization with the video

**Technical Details:**
- Frame rate: ~159 fps
- Duration: Matches audio duration
- Total frames: 86 frames
- Codec: H.264

**Usage:**
This video is the dynamic equivalent of the `{base_name}_interactive_histogram.xlsx` file:
- Frame numbers advance automatically
- The video shows how the histogram evolves over time
- Displays temporal dynamics during phoneme pronunciation

**Interpretation:**
- **Peaks in histogram**: Indicate many channels with similar (mean, variation) values
- **Sparse regions**: Indicate few channels with those values
- **Temporal evolution**: Shows how the auditory representation changes during sound production
- **Horizontal spread**: Indicates variation in mean values across channels
- **Vertical spread**: Indicates variation in temporal dynamics across channels

**Notes:**
- Video generation may take ~20 seconds per phoneme
- Requires ffmpeg
- Audio is mixed with video using ffmpeg
- Temporary files are cleaned up after video creation
"""
    videos_readme.write_text(videos_content)
    logger.info("Created README.md in videos/ directory")


def _save_stage_outputs(
    base_name: str,
    excel_dir: Path,
    signal: np.ndarray,
    peaks: np.ndarray,
    memo_ma: np.ndarray,
    memo_ck: np.ndarray,
    memo_ma_integrated: np.ndarray,
    memo_ck_integrated: np.ndarray,
):
    """Save outputs from processing stages to Excel files."""
    stage4_path = excel_dir / f"{base_name}_stage4.xlsx"
    save_stage4_excel(peaks, signal, str(stage4_path))

    stage5_path = excel_dir / f"{base_name}_stage5.xlsx"
    save_stage5_excel(memo_ma, memo_ck, str(stage5_path))

    stage5_5_path = excel_dir / f"{base_name}_stage5.5.xlsx"
    save_stage5_5_excel(memo_ma_integrated, memo_ck_integrated, str(stage5_5_path))


def _save_temporal_plots(
    base_name: str,
    figures_dir: Path,
    excel_dir: Path,
    memo_ma_integrated: np.ndarray,
    sample_rate: int,
    decimation_factor: int,
):
    """Save temporal feature plots and Excel files."""
    mean_consecutive_path = figures_dir / f"{base_name}_mean_consecutive.png"
    save_mean_consecutive_plot(
        memo_ma_integrated, decimation_factor, sample_rate, str(mean_consecutive_path)
    )

    abs_variation_path = figures_dir / f"{base_name}_abs_variation.png"
    save_abs_variation_plot(
        memo_ma_integrated, decimation_factor, sample_rate, str(abs_variation_path)
    )

    mean_consecutive_heatmap_path = figures_dir / f"{base_name}_mean_consecutive_heatmap.png"
    save_mean_consecutive_heatmap(
        memo_ma_integrated, decimation_factor, sample_rate, str(mean_consecutive_heatmap_path)
    )

    abs_variation_heatmap_path = figures_dir / f"{base_name}_abs_variation_heatmap.png"
    save_abs_variation_heatmap(
        memo_ma_integrated, decimation_factor, sample_rate, str(abs_variation_heatmap_path)
    )

    mean_cumulative_50_path = figures_dir / f"{base_name}_mean_cumulative_50.png"
    save_mean_cumulative_50_plot(
        memo_ma_integrated, decimation_factor, sample_rate, str(mean_cumulative_50_path)
    )

    variation_cumulative_50_path = figures_dir / f"{base_name}_variation_cumulative_50.png"
    save_variation_cumulative_50_plot(
        memo_ma_integrated, decimation_factor, sample_rate, str(variation_cumulative_50_path)
    )

    bilinear_global_path = excel_dir / f"{base_name}_bilinear_histogram_global.xlsx"
    save_bilinear_histogram_global_excel(memo_ma_integrated, str(bilinear_global_path))

    bilinear_frames_path = excel_dir / f"{base_name}_bilinear_histogram_frames.xlsx"
    save_bilinear_histogram_frames_excel(
        memo_ma_integrated, sample_rate, decimation_factor, str(bilinear_frames_path)
    )

    bilinear_global_no_origin_path = (
        excel_dir / f"{base_name}_bilinear_histogram_global_no_origin.xlsx"
    )
    save_bilinear_histogram_global_no_origin_excel(
        memo_ma_integrated, str(bilinear_global_no_origin_path)
    )

    bilinear_histogram_path = figures_dir / f"{base_name}_bilinear_histogram.png"
    save_bilinear_histogram_plot(memo_ma_integrated, str(bilinear_histogram_path))


def _save_f0_plots(
    base_name: str,
    figures_dir: Path,
    memo_ma_integrated: np.ndarray,
    memo_ck_integrated: np.ndarray,
    f0_frames: np.ndarray,
    f0_channels: np.ndarray,
    sample_rate: int,
    decimation_factor: int,
):
    """Save F0-related plots."""
    temporal_path = figures_dir / f"{base_name}_temporal_memory_f0.png"
    save_temporal_memory_f0_plot(
        memo_ck_integrated,
        f0_frames,
        f0_channels,
        decimation_factor,
        sample_rate,
        str(temporal_path),
    )

    amplitude_path = figures_dir / f"{base_name}_amplitude_memory_f0.png"
    save_amplitude_memory_f0_plot(
        memo_ma_integrated,
        f0_frames,
        f0_channels,
        decimation_factor,
        sample_rate,
        str(amplitude_path),
    )

    fundamental_vs_max_path = figures_dir / f"{base_name}_fundamental_vs_max_ma.png"
    save_fundamental_vs_max_ma_plot(
        memo_ma_integrated,
        f0_frames,
        f0_channels,
        decimation_factor,
        sample_rate,
        str(fundamental_vs_max_path),
    )

    fundamental_frequency_path = figures_dir / f"{base_name}_f0_frequency.png"
    save_fundamental_vs_lowest_nbck_plot(
        memo_ck_integrated,
        f0_frames,
        f0_channels,
        decimation_factor,
        sample_rate,
        str(fundamental_frequency_path),
    )


def process_audio_file(
    wav_path: Path,
    output_dir: Path,
    periphery: AuditoryPeriphery,
    integrator: TemporalIntegrator,
    detector: F0Detector,
    extractor: FrequencyInvarianceExtractor,
    sample_rate: int = 16000,
):
    """Process a single audio file through the complete pipeline.

    Args:
        wav_path: Path to .wav file
        output_dir: Directory to save outputs
        periphery: AuditoryPeriphery instance
        integrator: TemporalIntegrator instance
        detector: F0Detector instance
        extractor: FrequencyInvarianceExtractor instance
        sample_rate: Target sample rate
    """
    logger.info("Processing: %s", wav_path.name)

    base_name = wav_path.stem
    output_dir.mkdir(parents=True, exist_ok=True)

    excel_dir = output_dir / "excel"
    figures_dir = output_dir / "figures"
    videos_dir = output_dir / "videos"
    excel_dir.mkdir(exist_ok=True)
    figures_dir.mkdir(exist_ok=True)
    videos_dir.mkdir(exist_ok=True)

    signal, _ = load_audio(str(wav_path), target_sample_rate=sample_rate, mono=True)

    waveform_path = figures_dir / f"{base_name}_waveform.png"
    save_waveform_plot(signal, sample_rate, str(waveform_path))

    periphery_result = periphery.process(signal)
    peaks = periphery_result["peaks"]
    memo_ma = periphery_result["memo_ma"]
    memo_ck = periphery_result["memo_ck"]

    integrated = integrator.process(memo_ma, memo_ck)
    memo_ma_integrated = integrated["memo_ma"]
    memo_ck_integrated = integrated["memo_ck"]

    _save_stage_outputs(
        base_name,
        excel_dir,
        signal,
        peaks,
        memo_ma,
        memo_ck,
        memo_ma_integrated,
        memo_ck_integrated,
    )

    _save_temporal_plots(
        base_name,
        figures_dir,
        excel_dir,
        memo_ma_integrated,
        sample_rate,
        integrator.config.decimation_factor,
    )

    frame_histogram_video_path = videos_dir / f"{base_name}_frame_histogram.mp4"
    logger.info("Generating frame histogram video (this may take a minute)...")
    try:
        create_frame_histogram_video(
            memo_ma_integrated, str(wav_path), str(frame_histogram_video_path)
        )
    except Exception as e:
        logger.error("Failed to create frame histogram video: %s", e)

    f0_result = detector.detect(memo_ma_integrated, memo_ck_integrated)
    f0_frames = f0_result["f0_frames"]
    f0_channels = f0_result["f0_channels"]

    _save_f0_plots(
        base_name,
        figures_dir,
        memo_ma_integrated,
        memo_ck_integrated,
        f0_frames,
        f0_channels,
        sample_rate,
        integrator.config.decimation_factor,
    )

    inv_result = extractor.extract(f0_result, memo_ma_integrated)
    invariance_table = inv_result["invariance_table"]
    ma_values = inv_result["ma_values"]
    nbck_values = inv_result["nbck_values"]

    invariance_path = excel_dir / f"{base_name}_invariance.xlsx"
    save_invariance_excel(invariance_table, ma_values, nbck_values, str(invariance_path))

    combined_analysis_path = figures_dir / f"{base_name}_combined_analysis.png"
    save_combined_analysis_plot(
        signal,
        memo_ma_integrated,
        memo_ck_integrated,
        f0_frames,
        f0_channels,
        integrator.config.decimation_factor,
        sample_rate,
        str(combined_analysis_path),
        phoneme_name=base_name,
    )

    create_readme_files(output_dir, base_name)

    logger.info("✓ Completed: %s", wav_path.name)


def setup_configurations(project_root: Path):
    """Setup processing configurations.

    Args:
        project_root: Path to project root directory

    Returns:
        Tuple of (periphery_config, integration_config, f0_config,
                  inv_config, freq_table_path)
    """
    periphery_config = AuditoryPeripheryConfig.default()
    periphery_config.delay_compensation.compensation_file = str(
        project_root / "data/calibration/gammatone_filters_compensation.csv"
    )

    integration_config = TemporalIntegrationConfig.default()
    f0_config = F0DetectionConfig.default()
    inv_config = FrequencyInvarianceConfig.default()

    freq_table_path = str(project_root / "data/calibration/table_frq_can.csv")

    return periphery_config, integration_config, f0_config, inv_config, freq_table_path


def create_processing_instances(
    periphery_config, integration_config, f0_config, inv_config, freq_table_path
):
    """Create processing pipeline instances.

    Args:
        periphery_config: Auditory periphery configuration
        integration_config: Temporal integration configuration
        f0_config: F0 detection configuration
        inv_config: Frequency invariance configuration
        freq_table_path: Path to frequency calibration table

    Returns:
        Tuple of (periphery, integrator, detector, extractor)
    """
    periphery = AuditoryPeriphery(periphery_config)
    integrator = TemporalIntegrator(integration_config)
    detector = F0Detector(f0_config)
    extractor = FrequencyInvarianceExtractor(inv_config, freq_table_path)

    return periphery, integrator, detector, extractor


def main():
    """Build phoneme database from audio files."""
    parser = argparse.ArgumentParser(description="Build phoneme database from audio files")
    parser.add_argument(
        "--input-dir",
        type=str,
        default="data/diction_phonemes",
        help="Input directory containing phoneme folders",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="Output directory for results",
    )
    parser.add_argument("--sample-rate", type=int, default=16000, help="Target sample rate in Hz")
    parser.add_argument("--limit", type=int, default=None, help="Limit number of files to process")

    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    if not input_dir.exists():
        logger.error("Input directory not found: %s", input_dir)
        sys.exit(1)

    project_root = Path(__file__).parent.parent.parent

    periphery_config, integration_config, f0_config, inv_config, freq_table_path = (
        setup_configurations(project_root)
    )
    periphery, integrator, detector, extractor = create_processing_instances(
        periphery_config, integration_config, f0_config, inv_config, freq_table_path
    )

    logger.info("=" * 80)
    logger.info("Phoneme database builder")
    logger.info("=" * 80)
    logger.info("Input directory: %s", input_dir)
    logger.info("Sample rate: %s Hz", args.sample_rate)

    wav_files = []
    for folder in input_dir.iterdir():
        if folder.is_dir():
            for wav_file in folder.glob("*.wav"):
                wav_files.append((wav_file, folder))

    if not wav_files:
        logger.error("No .wav files found in subdirectories of %s", input_dir)
        sys.exit(1)

    logger.info("Found %s .wav files to process", len(wav_files))

    if args.limit:
        wav_files = wav_files[: args.limit]
        logger.info("Limited to %s files", len(wav_files))

    success_count = 0
    error_count = 0

    for i, (wav_path, parent_folder) in enumerate(wav_files, 1):
        if args.output_dir:
            output_dir = Path(args.output_dir) / parent_folder.name
        else:
            output_dir = parent_folder

        try:
            relative_path = wav_path.relative_to(input_dir)
            logger.info("\n[%s/%s] Processing %s", i, len(wav_files), relative_path)

            process_audio_file(
                wav_path, output_dir, periphery, integrator, detector, extractor, args.sample_rate
            )

            success_count += 1

        except Exception as e:
            logger.error("Error processing %s: %s", wav_path.name, e, exc_info=True)
            error_count += 1

    logger.info("\n%s", "=" * 80)
    logger.info("Processing complete")
    logger.info("%s", "=" * 80)
    logger.info("Success: %s/%s", success_count, len(wav_files))
    logger.info("Errors: %s/%s", error_count, len(wav_files))
    logger.info("=" * 80)


if __name__ == "__main__":
    main()
