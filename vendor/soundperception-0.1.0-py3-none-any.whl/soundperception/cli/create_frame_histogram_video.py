#!/usr/bin/env python3
"""Create video animation of frame-by-frame 2D histogram evolution."""

import argparse
import logging
import sys
from pathlib import Path

from audition import (
    AuditoryPeriphery,
    AuditoryPeripheryConfig,
    TemporalIntegrationConfig,
    TemporalIntegrator,
    load_audio,
)
from soundperception.visualization.frame_histogram_video import create_frame_histogram_video

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def main():
    """Process audio file and create frame histogram video."""
    parser = argparse.ArgumentParser(
        description="Create video animation of frame-by-frame histogram evolution"
    )
    parser.add_argument("audio_file", type=str, help="Input audio file (.wav)")
    parser.add_argument(
        "-o",
        "--output",
        type=str,
        help="Output video file",
    )
    parser.add_argument("--sample-rate", type=int, default=16000, help="Audio sample rate")

    args = parser.parse_args()

    audio_path = Path(args.audio_file)
    if not audio_path.exists():
        logger.error("Audio file not found: %s", audio_path)
        sys.exit(1)

    if args.output:
        output_path = Path(args.output)
    else:
        output_path = audio_path.parent / f"{audio_path.stem}_frame_histogram.mp4"

    logger.info("=" * 80)
    logger.info("Frame-by-frame histogram video generator")
    logger.info("=" * 80)
    logger.info("Input audio: %s", audio_path)
    logger.info("Output video: %s", output_path)
    logger.info("FPS calculated based on frame count and audio duration")
    logger.info("")

    logger.info("Loading audio...")
    signal, actual_sr = load_audio(str(audio_path), target_sample_rate=args.sample_rate, mono=True)
    logger.info("Audio loaded: %.2f seconds, %d samples", len(signal) / actual_sr, len(signal))

    logger.info("Processing through auditory periphery (Stages 1-5)...")
    periphery_config = AuditoryPeripheryConfig.default()
    periphery = AuditoryPeriphery(periphery_config)
    result = periphery.process(signal)

    logger.info("Temporal integration (Stage 5.5)...")
    integration_config = TemporalIntegrationConfig.default()
    integrator = TemporalIntegrator(integration_config)
    integrated = integrator.process(result["memo_ma"], result["memo_ck"])
    memo_ma_integrated = integrated["memo_ma"]

    logger.info("Integrated output shape: %s", memo_ma_integrated.shape)

    logger.info("")
    logger.info("Creating video animation...")
    create_frame_histogram_video(
        memo_ma_integrated,
        str(audio_path),
        str(output_path),
    )

    logger.info("")
    logger.info("=" * 80)
    logger.info("Video created")
    logger.info("=" * 80)
    logger.info("Output: %s", output_path)
    logger.info("")


if __name__ == "__main__":
    main()
