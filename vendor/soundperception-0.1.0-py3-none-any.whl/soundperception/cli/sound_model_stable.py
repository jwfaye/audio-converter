#!/usr/bin/env python3
"""Extract invariance tables from audio files.

DEPRECATED: This script is maintained for historical reference.

Use class-based API instead:
- soundperception.core.auditory_periphery.AuditoryPeriphery (Stages 1-5)
- soundperception.core.temporal_integration.TemporalIntegrator (Stage 5.5)
- soundperception.core.f0_detection.F0Detector (Stage 6)
- soundperception.core.frequency_invariance.FrequencyInvarianceExtractor (Stage 7)

See soundperception/cli/build_database.py for pipeline example.

Known issues:
- Line 435: Harmonic inversion bug ([::-1] inverts harmonic order)
- Line 148: Hardcoded channel count (65) instead of num_channels variable
- Uses different F0 detection algorithm (see Stage 6 implementation)
"""

import argparse
import logging
import os
import sys
import time

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.signal import convolve2d

from soundperception.core.sounddetector import (
    delay_compensation,
    extract_cpt_ck_optim,
    extract_memo_ck_optim,
    extract_memo_ma_optim,
    extract_peaks_optim,
    gammatone_filtering,
)
from soundperception.utils.audio_io import load_audio

SECOND_ENERGY_PEAK = 2
MIN_INVARIANCE_DB = -30


def init(wav_file, freq_sample, freq_table_file, compensation_file):
    """Initialize audio processing pipeline."""
    t0 = time.time()
    signal, _ = load_audio(wav_file, target_sample_rate=freq_sample, mono=True)
    signal_duration = len(signal) / freq_sample
    num_samples = len(signal)
    t_load = time.time() - t0
    logging.info(
        "Audio loading: %.2f ms (%.3f μs/sample)", t_load * 1000, (t_load * 1e6) / num_samples
    )

    t0 = time.time()
    erb_signal = gammatone_filtering(signal, freq_sample)
    t_gammatone = time.time() - t0
    logging.info(
        "Gammatone filtering: %.2f ms (%.3f μs/sample)",
        t_gammatone * 1000,
        (t_gammatone * 1e6) / num_samples,
    )

    t0 = time.time()
    peaks = extract_peaks_optim(erb_signal)
    t_peaks = time.time() - t0
    logging.info(
        "Peak extraction: %.2f ms (%.3f μs/sample)", t_peaks * 1000, (t_peaks * 1e6) / num_samples
    )

    t0 = time.time()
    peaks = delay_compensation(peaks, delay_path=compensation_file, threshold_delta=60)
    t_delay = time.time() - t0
    logging.info(
        "Delay compensation: %.2f ms (%.3f μs/sample)",
        t_delay * 1000,
        (t_delay * 1e6) / num_samples,
    )

    t0 = time.time()
    cpt_ck = extract_cpt_ck_optim(peaks)
    t_cpt_ck = time.time() - t0
    logging.info(
        "Clock counter extraction: %.2f ms (%.3f μs/sample)",
        t_cpt_ck * 1000,
        (t_cpt_ck * 1e6) / num_samples,
    )

    t0 = time.time()
    memo_ma = extract_memo_ma_optim(peaks, cpt_ck)
    t_memo_ma = time.time() - t0
    logging.info(
        "Memo MA extraction: %.2f ms (%.3f μs/sample)",
        t_memo_ma * 1000,
        (t_memo_ma * 1e6) / num_samples,
    )

    t0 = time.time()
    memo_ck = extract_memo_ck_optim(peaks, cpt_ck)
    t_memo_ck = time.time() - t0
    logging.info(
        "Memo CK extraction: %.2f ms (%.3f μs/sample)",
        t_memo_ck * 1000,
        (t_memo_ck * 1e6) / num_samples,
    )

    t_total = t_load + t_gammatone + t_peaks + t_delay + t_cpt_ck + t_memo_ma + t_memo_ck
    num_samples = len(signal)
    time_per_sample_us = (t_total * 1e6) / num_samples
    time_per_sample_ns = (t_total * 1e9) / num_samples

    logging.info(
        "TOTAL PIPELINE TIME: %.2f ms for %.2fs audio (%d samples)",
        t_total * 1000,
        signal_duration,
        num_samples,
    )
    logging.info("Time per sample: %.3f μs (%.1f ns)", time_per_sample_us, time_per_sample_ns)
    logging.info("Processing speed: %.2fx real-time", signal_duration / t_total)

    freq_can = pd.read_csv(freq_table_file, sep=",")

    return peaks, cpt_ck, memo_ma, memo_ck, freq_can


def full_table(nbck_fund, freq_can, nb_harmoniques=30):
    """Compute frequency table for harmonic analysis."""
    table = np.zeros((freq_can.shape[0], nb_harmoniques))
    for i in range(freq_can.shape[0]):
        for h in range(nb_harmoniques):
            table[i, h] = abs(
                np.log(nbck_fund) - np.log(h + 1) - np.log(freq_can["calibrage"].iloc[i])
            )
    return table


def min_table(freq_table):
    """Extract local minima from frequency table."""
    table = np.zeros_like(freq_table)
    rangs = []
    for frame in range(freq_table.shape[1]):
        col = freq_table[:, frame]
        for i, val in enumerate(col):
            neighbors = []
            if i > 0:
                neighbors.append(col[i - 1])
            if i < len(col) - 1:
                neighbors.append(col[i + 1])
            if val < min(neighbors):
                table[i, frame] = 1
                rangs.append(65 - i)
    return table, rangs


def ma_harmos(min_rangs, memo_ma_col):
    """Extract MA values for harmonics at given ranks."""
    mas = []
    for rang in min_rangs:
        mas.append(memo_ma_col[rang - 1])
    return mas


def ma_invariance(mas):
    """Compute MA invariance by subtracting first value."""
    return [x - mas[0] for x in mas]


def invariance_table(invariances):
    """Convert list of invariances to 2D table."""
    table = []
    for invariance in invariances:
        table.append(invariance)
    table = np.array(table).T
    return table


def filtrage_edr_7x7(memo_ma_suppr, quotient=708):
    """Apply 7x7 EDR filtering kernel."""
    kernel = np.array(
        [
            [0, 0, 15, 16, 15, 0, 0],
            [0, 17, 19, 20, 19, 17, 0],
            [15, 19, 23, 25, 23, 19, 15],
            [16, 20, 25, 32, 25, 20, 16],
            [15, 19, 23, 25, 23, 19, 15],
            [0, 17, 19, 20, 19, 17, 0],
            [0, 0, 15, 16, 15, 0, 0],
        ]
    )
    kernel = kernel / quotient
    filtered = convolve2d(memo_ma_suppr, kernel, mode="same", boundary="symm")
    return filtered


def filtrage_edr_5x5(memo_ma_suppr):
    """Apply 5x5 EDR filtering kernel."""
    kernel = np.array(
        [
            [17, 19, 20, 19, 17],
            [19, 23, 25, 23, 19],
            [20, 25, 32, 25, 20],
            [19, 23, 25, 23, 19],
            [17, 19, 20, 19, 17],
        ]
    )
    kernel = kernel / kernel.sum()
    filtered = convolve2d(memo_ma_suppr, kernel, mode="same", boundary="symm")
    return filtered


def filtrage_edr_3x3(memo_ma_suppr):
    """Apply 3x3 EDR filtering kernel."""
    kernel = np.array([[23, 25, 23], [25, 32, 25], [23, 25, 23]])
    kernel = kernel / kernel.sum()
    filtered = convolve2d(memo_ma_suppr, kernel, mode="same", boundary="symm")
    return filtered


def suppression_des_intrus(memo_ma_2d, std_threshold=4):
    """Remove outliers from 2D array."""
    result = memo_ma_2d.copy()
    std_before = np.zeros_like(memo_ma_2d)
    std_short = np.zeros_like(memo_ma_2d)
    std_after = np.zeros_like(memo_ma_2d)

    for i in range(2, memo_ma_2d.shape[1] - 2):
        _min = max(0, i - 2)
        _max = min(i + 2, memo_ma_2d.shape[1])

        if i > 0:
            std_before[:, i] = np.std(memo_ma_2d[:, _min:i], axis=1)
        if 0 < i < memo_ma_2d.shape[1] - 1:
            std_short[:, i] = np.std(memo_ma_2d[:, i - 1 : i + 2], axis=1)
        if i < memo_ma_2d.shape[1] - 1:
            std_after[:, i] = np.std(memo_ma_2d[:, i:_max], axis=1)

    mask_intrus = (
        (std_before > std_threshold) & (std_short > std_threshold) & (std_after > std_threshold)
    )

    for i in range(1, memo_ma_2d.shape[1] - 1):
        if i < memo_ma_2d.shape[1] - 1:
            replacement = ((memo_ma_2d[:, i - 1] + memo_ma_2d[:, i + 1]) / 2).astype(int)
            result[:, i] = np.where(mask_intrus[:, i], replacement, memo_ma_2d[:, i])

    return result


def position_crete(filtered_ma_2d, threshold=5):
    """Detect peak positions above threshold."""
    result = np.zeros_like(filtered_ma_2d)
    for frame in range(filtered_ma_2d.shape[1]):
        for j in range(1, filtered_ma_2d.shape[0] - 1):
            if (
                (filtered_ma_2d[j - 1, frame] <= filtered_ma_2d[j, frame])
                and (filtered_ma_2d[j + 1, frame] <= filtered_ma_2d[j, frame])
                and (filtered_ma_2d[j, frame] > threshold)
            ):
                result[j, frame] = filtered_ma_2d[j, frame]
    return result


def deter_bas(pos_cretes):
    """Determine bass positions from peak data."""
    result = np.zeros_like(pos_cretes)
    for i in range(pos_cretes.shape[1]):
        for j in range(1, pos_cretes.shape[0]):
            if (pos_cretes[j, i] > 0) and (pos_cretes[j - 1, i] == 0):
                result[j, i] = result[j - 1, i] + 1
            else:
                result[j, i] = result[j - 1, i]
    return result


def demarrage_suivi_incr(deter_2d, pos_crete, marge=4):
    """Start incremental tracking with margin."""
    result = np.zeros_like(deter_2d)
    for frame in range(deter_2d.shape[1]):
        if frame == 0:
            for j in range(1, deter_2d.shape[0]):
                if (deter_2d[j, frame] == 1) and (deter_2d[j - 1, frame] == 0):
                    result[j, frame] = 1
        else:
            for j in range(1, deter_2d.shape[0] - 1):
                _min = max(0, j - marge)
                _max = min(j + marge, deter_2d.shape[0])

                if (
                    (deter_2d[j, frame] == 1)
                    and (deter_2d[j - 1, frame] == 0)
                    and (deter_2d[j, frame - 1] == 0)
                    and (deter_2d[j + 1, frame - 1] == 0)
                ):
                    result[j, frame] = 1
                elif (
                    (np.max(result[_min : _max + 1, frame - 1]) > 0)
                    and (deter_2d[j, frame] == 1)
                    and (pos_crete[j, frame] > 0)
                ):
                    result[j, frame] = np.max(result[_min : _max + 1, frame - 1]) + 1
                elif (
                    (pos_crete[j, frame] > 0)
                    and (deter_2d[j, frame] >= SECOND_ENERGY_PEAK)
                    and np.max(result[_min : _max + 1, frame - 1]) > 0
                ):
                    result[j, frame] = np.max(result[_min : _max + 1, frame - 1]) + 1
    return result


def calcul_fondamentale(validation_2d, memo_nbck_2d):
    """Calculate fundamental frequency."""
    result = np.where(validation_2d > 0, np.exp(memo_nbck_2d / 10), 0)
    return result


def recherche_fondamentale(memo_ma_2d, memo_nbck_2d, num_samples=None):
    """Search for fundamental frequency."""
    t0 = time.time()
    result = suppression_des_intrus(memo_ma_2d)
    t_outlier = time.time() - t0
    if num_samples:
        logging.info(
            "Periodicity - Outlier suppression: %.2f ms (%.3f μs/sample)",
            t_outlier * 1000,
            (t_outlier * 1e6) / num_samples,
        )

    t0 = time.time()
    result = filtrage_edr_3x3(result)
    edr_filtered = result.copy()
    t_edr = time.time() - t0
    if num_samples:
        logging.info(
            "Periodicity - EDR filtering: %.2f ms (%.3f μs/sample)",
            t_edr * 1000,
            (t_edr * 1e6) / num_samples,
        )

    t0 = time.time()
    pos_crete = position_crete(edr_filtered)
    t_peak = time.time() - t0
    if num_samples:
        logging.info(
            "Periodicity - Peak detection: %.2f ms (%.3f μs/sample)",
            t_peak * 1000,
            (t_peak * 1e6) / num_samples,
        )

    t0 = time.time()
    result = deter_bas(pos_crete)
    t_bass = time.time() - t0
    if num_samples:
        logging.info(
            "Periodicity - Bass determination: %.2f ms (%.3f μs/sample)",
            t_bass * 1000,
            (t_bass * 1e6) / num_samples,
        )

    t0 = time.time()
    result = demarrage_suivi_incr(result, pos_crete)
    t_tracking = time.time() - t0
    if num_samples:
        logging.info(
            "Periodicity - Incremental tracking: %.2f ms (%.3f μs/sample)",
            t_tracking * 1000,
            (t_tracking * 1e6) / num_samples,
        )

    t0 = time.time()
    result = calcul_fondamentale(result, memo_nbck_2d)
    t_fundamental = time.time() - t0
    if num_samples:
        logging.info(
            "Periodicity - Fundamental calculation: %.2f ms (%.3f μs/sample)",
            t_fundamental * 1000,
            (t_fundamental * 1e6) / num_samples,
        )

    if num_samples:
        t_periodicity_total = t_outlier + t_edr + t_peak + t_bass + t_tracking + t_fundamental
        logging.info(
            "TOTAL PERIODICITY TIME: %.2f ms (%.3f μs/sample)",
            t_periodicity_total * 1000,
            (t_periodicity_total * 1e6) / num_samples,
        )

    return result


def signal_to_invariance(
    wavefile, freq_sample, freq_table_file, decimation_step=100, compensation_file=None
):
    """Convert audio signal to invariance table."""
    invariances = []
    flag_indices = []
    inv_mas = []
    inv_clocks = []

    _peaks, _cpt_ck, memo_ma, memo_ck, freq_can = init(
        wavefile, freq_sample, freq_table_file, compensation_file
    )
    num_samples = memo_ma.shape[1]

    fondamentale = recherche_fondamentale(memo_ma, memo_ck, num_samples=num_samples)

    t0 = time.time()
    fts = []
    for i in range(1, fondamentale.shape[1]):
        if i % decimation_step == 0:
            flag_indices.append(i)
            nn = np.where(fondamentale[:, i] > 0)[0]
            nbck = fondamentale[nn[-1], i] if len(nn) > 0 else np.max(fondamentale[:, i])
            ma = np.max(memo_ma[:, i])
            if len(nn) > 0:
                ma = memo_ma[nn[-1], i]
            ft = full_table(nbck, freq_can)
            fts.append(ft)
            _mt, mt_ranks = min_table(ft)
            mas = ma_harmos(mt_ranks, memo_ma[:, i])
            ma_inv = ma_invariance(mas)
            if len(ma_inv) > 0:
                invariances.append(ma_inv[::-1])
                flag_indices.append(i)
                inv_mas.append(ma)
                inv_clocks.append(nbck)

    t_invariance = time.time() - t0
    logging.info(
        "Invariance extraction: %.2f ms (%.3f μs/sample)",
        t_invariance * 1000,
        (t_invariance * 1e6) / num_samples,
    )

    inv_table = invariance_table(invariances)
    inv_table = np.where(inv_table < MIN_INVARIANCE_DB, MIN_INVARIANCE_DB, inv_table)
    return inv_table, inv_mas, inv_clocks


def invariance_to_excel(table, mas, clocks, output_config):
    """Export invariance table to Excel file.

    Args:
        table: Invariance table array
        mas: MA values
        clocks: Clock values
        output_config: Dict with 'output_dir', 'name', 'max_columns'
    """
    output_dir = output_config["output_dir"]
    name = output_config.get("name", "test")
    max_columns = output_config.get("max_columns", 16000)

    inv_dir = os.path.join(output_dir, "inv")
    os.makedirs(inv_dir, exist_ok=True)

    df = pd.DataFrame(table)
    df.loc[len(df)] = mas
    df.loc[len(df)] = clocks
    df.loc[len(df)] = [None] * df.shape[1]
    total_cols = df.shape[1]
    if total_cols > max_columns:
        new_df = df.iloc[:max_columns]
        num_segments = (total_cols + max_columns - 1) // max_columns
        for i in range(1, num_segments):
            start_col = i * max_columns
            end_col = min((i + 1) * max_columns, total_cols)
            df_part = df.iloc[:, start_col:end_col]
            new_df = pd.concat([new_df, df_part], axis=0).reset_index(drop=True)
        df = new_df

    output_path = os.path.join(inv_dir, f"{name}.xlsx")
    df.to_excel(output_path, index=False)
    logging.info("Invariance table saved to %s", output_path)


def main():
    """Extract invariance tables from audio files."""
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )

    logging.info("Sound model stable script starting...")

    parser = argparse.ArgumentParser(description="Extract invariance tables from audio files.")
    parser.add_argument(
        "input_dir", help="Directory containing audio files (.wav, .mp3) to analyze."
    )
    parser.add_argument(
        "--output-dir",
        help="Directory where results will be saved. Defaults to the input directory.",
    )
    parser.add_argument(
        "--freq-table",
        required=True,
        help="Path to the frequency table CSV file (table_frq_can.csv).",
    )
    parser.add_argument(
        "--compensation-file",
        default="src/gammatone_filters_compensation.csv",
        help="Path to the gammatone filters compensation CSV file",
    )
    parser.add_argument("--sample-rate", type=int, default=16000, help="Sample rate for resampling")
    parser.add_argument(
        "--decimation-step", type=int, default=100, help="Decimation step for analysis"
    )
    parser.add_argument(
        "--save-plots", action="store_true", help="Save the generated plots as image files"
    )
    parser.add_argument(
        "--limit", type=int, default=None, help="Limit the number of files to process"
    )

    args = parser.parse_args()
    logging.info("Arguments parsed successfully")
    logging.info("Input dir: %s", args.input_dir)
    logging.info("Output dir: %s", args.output_dir)
    logging.info("Limit: %s", args.limit)

    output_dir = args.output_dir if args.output_dir else args.input_dir
    os.makedirs(output_dir, exist_ok=True)
    logging.info("Output directory created: %s", output_dir)

    audio_files = []
    for root, _dirs, files in os.walk(args.input_dir):
        for file in files:
            if file.endswith((".wav", ".mp3")):
                audio_files.append(os.path.join(root, file))

    audio_files.sort()
    logging.info("Found %d audio files", len(audio_files))

    if args.limit:
        audio_files = audio_files[: args.limit]
        logging.info("Limited to %d files", len(audio_files))

    for idx, wave_path in enumerate(audio_files, 1):
        wave_filename = os.path.basename(wave_path)
        logging.info("=" * 80)
        logging.info("[%d/%d] Processing: %s", idx, len(audio_files), wave_filename)
        logging.info("=" * 80)

        inv_table, inv_mas, inv_clock = signal_to_invariance(
            wavefile=wave_path,
            freq_sample=args.sample_rate,
            freq_table_file=args.freq_table,
            decimation_step=args.decimation_step,
            compensation_file=args.compensation_file,
        )
        output_name = os.path.splitext(wave_filename)[0]

        invariance_to_excel(
            inv_table,
            inv_mas,
            inv_clock,
            output_config={"output_dir": output_dir, "name": output_name},
        )

        if args.save_plots:
            plt.figure(figsize=(10, 8))
            plt.imshow(inv_table, cmap="hot", interpolation="nearest")
            plt.colorbar()
            plot_path = os.path.join(output_dir, f"{output_name}.png")
            plt.savefig(plot_path)
            plt.close()
            logging.info("Plot saved to %s", plot_path)


if __name__ == "__main__":
    main()
