"""Analyze temporal features from audio files.

Processes .wav files and generates multi-panel visualizations showing temporal
derivatives and features after decimation (Stage 5.5).

Generated visualizations ({name}_temporal_analysis.png):
1. Mean of consecutive frames (averaged over channels)
2. Absolute variation between consecutive frames (averaged over channels)
3. Maximum MA value across all channels
4. Fundamental MA (amplitude at F0 channel)
5. Fundamental NBCK (temporal memory at F0 channel)
6. Waveform (downsampled by 100 to match decimated timescale)
7. Invariance table heatmap (30 harmonics × time)
8. Memo MA integrated heatmap (65 channels × time)
9. Memo CK integrated heatmap (65 channels × time)

All plots share the same time axis (decimated scale: 1 frame = 6.25ms @ 16kHz).

Usage:
    python soundperception/cli/analyze_temporal_features.py [--input-dir DIR] [--output-dir DIR]
    python soundperception/cli/analyze_temporal_features.py --limit 5
"""

import argparse
import logging
import sys
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from audition import (
    AuditoryPeriphery,
    AuditoryPeripheryConfig,
    F0DetectionConfig,
    F0Detector,
    FrequencyInvarianceConfig,
    FrequencyInvarianceExtractor,
    TemporalIntegrationConfig,
    TemporalIntegrator,
    load_audio,
)

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


@dataclass
class PlotData:
    """Container for temporal analysis plot data."""

    audio: np.ndarray
    memo_ma_integrated: np.ndarray
    memo_ck_integrated: np.ndarray
    invariance_table: np.ndarray
    features: dict
    sample_rate: int
    decimation: int
    title: str


def compute_temporal_features(memo_ma_integrated, memo_ck_integrated, f0_result):
    """Compute temporal features from decimated signals.

    Args:
        memo_ma_integrated: Amplitude memory after integration (65 × n_frames)
        memo_ck_integrated: Temporal memory after integration (65 × n_frames)
        f0_result: F0 detection results with f0_frames and f0_channels

    Returns:
        Dictionary with features:
        - mean_consecutive: Mean of consecutive frames (averaged over channels)
        - abs_variation: Absolute variation between frames (averaged over channels)
        - max_ma: Maximum MA across all channels at each time
        - fundamental_ma: MA at fundamental frequency channel
        - fundamental_ck: CK at fundamental frequency channel
    """
    n_channels, n_frames = memo_ma_integrated.shape

    consecutive_mean = (memo_ma_integrated[:, :-1] + memo_ma_integrated[:, 1:]) / 2
    mean_consecutive = np.mean(consecutive_mean, axis=0)

    abs_diff = np.abs(memo_ma_integrated[:, 1:] - memo_ma_integrated[:, :-1])
    abs_variation = np.mean(abs_diff, axis=0)

    max_ma = np.max(memo_ma_integrated, axis=0)

    fundamental_ma = np.zeros(n_frames)
    fundamental_ck = np.zeros(n_frames)
    if len(f0_result["f0_frames"]) > 0:
        f0_frames = f0_result["f0_frames"]
        f0_channels = f0_result["f0_channels"]

        for frame_idx, channel_idx in zip(f0_frames, f0_channels, strict=False):
            if frame_idx < n_frames and 0 <= channel_idx < n_channels:
                fundamental_ma[frame_idx] = memo_ma_integrated[channel_idx, frame_idx]
                fundamental_ck[frame_idx] = memo_ck_integrated[channel_idx, frame_idx]

    return {
        "mean_consecutive": mean_consecutive,
        "abs_variation": abs_variation,
        "max_ma": max_ma,
        "fundamental_ma": fundamental_ma,
        "fundamental_ck": fundamental_ck,
    }


def downsample_audio(audio, decimation_factor=100):
    """Downsample audio waveform to match decimated timescale.

    Args:
        audio: Original audio waveform
        decimation_factor: Decimation factor

    Returns:
        Downsampled audio array
    """
    return audio[::decimation_factor]


@dataclass
class LineSeriesParams:
    """Parameters for line series plot."""

    time: np.ndarray
    data: np.ndarray
    ylabel: str
    color: str
    title: str | None = None
    xlim: tuple | None = None


@dataclass
class HeatmapParams:
    """Parameters for heatmap plot."""

    data: np.ndarray
    time_extent: tuple
    ylabel: str
    cbar_label: str
    yticks: list | None = None


def _plot_line_series(ax, params: LineSeriesParams):
    """Plot line series.

    Args:
        ax: Matplotlib axis
        params: Line series plot parameters
    """
    ax.plot(params.time, params.data, linewidth=1, color=params.color)
    ax.set_ylabel(params.ylabel, fontsize=9)
    if params.title:
        ax.set_title(params.title, fontsize=12, fontweight="bold")
    ax.grid(alpha=0.3)
    if params.xlim:
        ax.set_xlim(*params.xlim)


def _plot_heatmap(ax, params: HeatmapParams):
    """Plot heatmap.

    Args:
        ax: Matplotlib axis
        params: Heatmap plot parameters
    """
    im = ax.imshow(
        params.data,
        aspect="auto",
        origin="lower",
        cmap="hot",
        interpolation="nearest",
        extent=[params.time_extent[0], params.time_extent[1], 0, params.data.shape[0]],
    )
    ax.set_ylabel(params.ylabel, fontsize=9)
    if params.yticks:
        ax.set_yticks(params.yticks)
    plt.colorbar(im, ax=ax, label=params.cbar_label, fraction=0.02, pad=0.01)


def create_temporal_analysis_plot(plot_data: PlotData):
    """Create temporal analysis visualization.

    Args:
        plot_data: PlotData container with data and parameters

    Returns:
        matplotlib.figure.Figure: The figure
    """
    n_frames = plot_data.memo_ma_integrated.shape[1]

    ms_per_frame = (1000 / plot_data.sample_rate) * plot_data.decimation
    time_decimated = np.arange(n_frames) * ms_per_frame / 1000
    time_derivative = time_decimated[:-1]
    xlim = (time_decimated[0], time_decimated[-1])

    audio_downsampled = downsample_audio(plot_data.audio, plot_data.decimation)[:n_frames]

    fig = plt.figure(figsize=(16, 36))

    ax1 = plt.subplot(9, 1, 1)
    _plot_line_series(
        ax1,
        LineSeriesParams(
            time=time_derivative,
            data=plot_data.features["mean_consecutive"],
            ylabel="Mean\nConsecutive\nFrames",
            color="blue",
            title=plot_data.title,
            xlim=xlim,
        ),
    )

    ax2 = plt.subplot(9, 1, 2)
    _plot_line_series(
        ax2,
        LineSeriesParams(
            time=time_derivative,
            data=plot_data.features["abs_variation"],
            ylabel="Abs\nVariation",
            color="orange",
            xlim=xlim,
        ),
    )

    ax3 = plt.subplot(9, 1, 3)
    _plot_line_series(
        ax3,
        LineSeriesParams(
            time=time_decimated,
            data=plot_data.features["max_ma"],
            ylabel="Max MA",
            color="green",
            xlim=xlim,
        ),
    )

    ax4 = plt.subplot(9, 1, 4)
    _plot_line_series(
        ax4,
        LineSeriesParams(
            time=time_decimated,
            data=plot_data.features["fundamental_ma"],
            ylabel="Fundamental\nMA",
            color="purple",
            xlim=xlim,
        ),
    )

    ax5 = plt.subplot(9, 1, 5)
    _plot_line_series(
        ax5,
        LineSeriesParams(
            time=time_decimated,
            data=plot_data.features["fundamental_ck"],
            ylabel="Fundamental\nNBCK",
            color="red",
            xlim=xlim,
        ),
    )

    ax6 = plt.subplot(9, 1, 6)
    time_audio = time_decimated[: len(audio_downsampled)]
    ax6.plot(time_audio, audio_downsampled, linewidth=0.5, color="black")
    ax6.set_ylabel("Waveform\n(downsampled)", fontsize=9)
    ax6.grid(alpha=0.3)
    ax6.set_xlim(*xlim)

    ax7 = plt.subplot(9, 1, 7)
    inv_shape = plot_data.invariance_table.shape[0]
    inv_yticks = [0, inv_shape // 2, inv_shape - 1]
    _plot_heatmap(
        ax7,
        HeatmapParams(
            data=plot_data.invariance_table,
            time_extent=xlim,
            ylabel="Invariance\nTable\n(Harmonics)",
            cbar_label="dB",
            yticks=inv_yticks,
        ),
    )

    ax8 = plt.subplot(9, 1, 8)
    _plot_heatmap(
        ax8,
        HeatmapParams(
            data=plot_data.memo_ma_integrated,
            time_extent=xlim,
            ylabel="Memo MA\n(Channels)",
            cbar_label="Amplitude (dB)",
            yticks=[0, 32, 64],
        ),
    )

    ax9 = plt.subplot(9, 1, 9)
    _plot_heatmap(
        ax9,
        HeatmapParams(
            data=plot_data.memo_ck_integrated,
            time_extent=xlim,
            ylabel="Memo CK\n(Channels)",
            cbar_label="Log(interval)",
            yticks=[0, 32, 64],
        ),
    )
    ax9.set_xlabel("Time (s)", fontsize=10)

    plt.tight_layout()
    return fig


def process_audio_file(audio_path, output_dir, sample_rate=16000, decimation=100):
    """Process a single audio file and generate temporal analysis visualization.

    Args:
        audio_path: Path to audio file
        output_dir: Output directory for visualizations
        sample_rate: Target sample rate
        decimation: Decimation factor
    """
    logger.info("Processing: %s", audio_path.name)

    audio, sr = load_audio(audio_path, target_sample_rate=sample_rate, mono=True)
    logger.info("  Duration: %.3fs, Samples: %d", len(audio) / sr, len(audio))

    periphery_config = AuditoryPeripheryConfig.default()
    periphery = AuditoryPeriphery(periphery_config)
    periphery_result = periphery.process(audio)

    integration_config = TemporalIntegrationConfig.default()
    integrator = TemporalIntegrator(integration_config)
    integrated = integrator.process(periphery_result["memo_ma"], periphery_result["memo_ck"])

    memo_ma_integrated = integrated["memo_ma"]
    memo_ck_integrated = integrated["memo_ck"]
    logger.info("  Integrated shape: %s", memo_ma_integrated.shape)

    f0_config = F0DetectionConfig.default()
    detector = F0Detector(f0_config)
    f0_result = detector.detect(memo_ma_integrated, memo_ck_integrated)
    logger.info("  F0 detections: %d", len(f0_result["f0_frames"]))

    freq_table_path = Path(__file__).parent.parent.parent / "data/calibration/table_frq_can.csv"
    inv_config = FrequencyInvarianceConfig.default()
    extractor = FrequencyInvarianceExtractor(inv_config, str(freq_table_path))
    inv_result = extractor.extract(f0_result, memo_ma_integrated)

    invariance_table = inv_result["invariance_table"]
    logger.info("  Invariance table: %s", invariance_table.shape)

    features = compute_temporal_features(memo_ma_integrated, memo_ck_integrated, f0_result)
    logger.info("  Temporal features computed")

    plot_data = PlotData(
        audio=audio,
        memo_ma_integrated=memo_ma_integrated,
        memo_ck_integrated=memo_ck_integrated,
        invariance_table=invariance_table,
        features=features,
        sample_rate=sample_rate,
        decimation=decimation,
        title=f"Temporal Analysis: {audio_path.stem}",
    )
    fig = create_temporal_analysis_plot(plot_data)

    output_path = output_dir / f"{audio_path.stem}_temporal_analysis.png"
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)

    logger.info("  Saved: %s", output_path.name)


def main():
    """Analyze temporal features from audio files."""
    parser = argparse.ArgumentParser(description="Analyze temporal features from audio files")
    parser.add_argument(
        "--input-dir",
        type=str,
        default="data/diction_phonemes",
        help="Input directory containing phoneme subdirectories with .wav files",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="output/temporal_analysis",
        help="Output directory for visualizations",
    )
    parser.add_argument(
        "--sample-rate",
        type=int,
        default=16000,
        help="Target sample rate in Hz",
    )
    parser.add_argument(
        "--decimation",
        type=int,
        default=100,
        help="Decimation factor for Stage 5.5",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Limit number of files to process",
    )

    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)

    if not input_dir.exists():
        logger.error("Input directory not found: %s", input_dir)
        return 1

    output_dir.mkdir(parents=True, exist_ok=True)
    logger.info("Output directory: %s", output_dir)

    wav_files = sorted(input_dir.rglob("*.wav"))

    if not wav_files:
        logger.error("No .wav files found in %s", input_dir)
        return 1

    if args.limit:
        wav_files = wav_files[: args.limit]
        logger.info("Limited to %d files", args.limit)

    logger.info("Found %d .wav files", len(wav_files))

    success_count = 0
    error_count = 0

    for i, wav_file in enumerate(wav_files, 1):
        logger.info("\n[%d/%d] Processing: %s", i, len(wav_files), wav_file.relative_to(input_dir))

        try:
            process_audio_file(
                wav_file, output_dir, sample_rate=args.sample_rate, decimation=args.decimation
            )
            success_count += 1
        except Exception as e:
            logger.error("  Error processing %s: %s", wav_file.name, e, exc_info=True)
            error_count += 1

    logger.info("\n%s", "=" * 70)
    logger.info("Processing complete")
    logger.info("%s", "=" * 70)
    logger.info("Total files: %d", len(wav_files))
    logger.info("Successful: %d", success_count)
    logger.info("Errors: %d", error_count)
    logger.info("Output directory: %s", output_dir)

    return 0 if error_count == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
