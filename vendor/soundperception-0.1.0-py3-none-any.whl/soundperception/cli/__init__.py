"""Command-line scripts for batch processing and analysis."""
