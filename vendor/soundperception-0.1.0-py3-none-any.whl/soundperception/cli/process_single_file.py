"""Process a single audio file through the complete pipeline (Stages 1-7).

Processes a single .wav file and generates all outputs in the same directory.

Usage:
    python soundperception/cli/process_single_file.py <audio_file.wav>
    python soundperception/cli/process_single_file.py /path/to/audio.wav
"""

import argparse
import logging
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from soundperception.cli.build_database import (
    create_processing_instances,
    process_audio_file,
    setup_configurations,
)

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def main():
    """Process single audio file through Stages 1-7 pipeline."""
    parser = argparse.ArgumentParser(
        description="Process a single audio file through the complete pipeline"
    )
    parser.add_argument(
        "audio_file",
        type=str,
        help="Path to the audio file",
    )
    parser.add_argument(
        "--sample-rate",
        type=int,
        default=16000,
        help="Target sample rate in Hz",
    )

    args = parser.parse_args()

    audio_path = Path(args.audio_file)
    if not audio_path.exists():
        logger.error("Audio file not found: %s", audio_path)
        sys.exit(1)

    if audio_path.suffix.lower() != ".wav":
        logger.error("Only .wav files are supported. Got: %s", audio_path.suffix)
        sys.exit(1)

    output_dir = audio_path.parent

    project_root = Path(__file__).parent.parent.parent

    (
        periphery_config,
        integration_config,
        f0_config,
        inv_config,
        freq_table_path,
    ) = setup_configurations(project_root)

    periphery, integrator, detector, extractor = create_processing_instances(
        periphery_config, integration_config, f0_config, inv_config, freq_table_path
    )

    logger.info("=" * 80)
    logger.info("Single file processor")
    logger.info("=" * 80)
    logger.info("Audio file: %s", audio_path)
    logger.info("Output directory: %s", output_dir)
    logger.info("Sample rate: %s Hz", args.sample_rate)
    logger.info("=" * 80)

    try:
        process_audio_file(
            audio_path,
            output_dir,
            periphery,
            integrator,
            detector,
            extractor,
            args.sample_rate,
        )

        logger.info("\n%s", "=" * 80)
        logger.info("Processing complete")
        logger.info("=" * 80)
        logger.info("All outputs saved to: %s", output_dir)
        logger.info("=" * 80)

    except Exception as e:
        logger.error("Error processing %s: %s", audio_path.name, e, exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
