"""Phoneme synthesis using formant synthesis and source-filter models.

Supported phoneme types:
- Vowels: /a/, /i/, /u/, /e/, /o/
- Nasal consonants: /m/, /n/, /ng/
- Voiced fricatives: /v/, /z/, /zh/
- Unvoiced fricatives: /f/, /s/, /sh/, /th/, /h/
- Plosives: /p/, /t/, /k/, /b/, /d/, /g/
- Liquids: /l/, /r/
- Semi-vowels: /w/, /j/
"""

from soundperception.synthesis.phoneme_synthesizer import (
    PhonemeSynthesizer,
    PhonemeType,
    synthesize_phoneme,
)

__all__ = [
    "PhonemeSynthesizer",
    "PhonemeType",
    "synthesize_phoneme",
]
