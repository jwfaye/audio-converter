"""Phoneme synthesis using source-filter model.

Implements formant synthesis for phoneme types based on acoustic phonetics
principles:
- Glottal pulse trains for voiced sounds
- Noise sources for unvoiced sounds
- Formant filters for spectral envelope shaping
- Anti-formants for nasals

References:
- Klatt, D. (1980). Software for a cascade/parallel formant synthesizer.
- Flanagan, J.L. (1972). Speech Analysis, Synthesis and Perception.
"""

from enum import Enum

import numpy as np
from scipy import signal


class PhonemeType(Enum):
    """Phoneme classification by production mechanism."""

    VOWEL = "vowel"
    NASAL = "nasal"
    FRICATIVE_VOICED = "fricative_voiced"
    FRICATIVE_UNVOICED = "fricative_unvoiced"
    PLOSIVE_VOICED = "plosive_voiced"
    PLOSIVE_UNVOICED = "plosive_unvoiced"
    LIQUID = "liquid"
    SEMIVOWEL = "semivowel"


PHONEME_SPECS = {
    "vowels": {
        "a": {"formants": [(730, 80), (1090, 90), (2440, 120), (3500, 150), (4500, 200)]},
        "e": {"formants": [(530, 60), (1840, 90), (2480, 120), (3500, 150), (4500, 200)]},
        "i": {"formants": [(270, 60), (2290, 110), (3010, 170), (3500, 200), (4500, 200)]},
        "o": {"formants": [(570, 70), (840, 80), (2410, 100), (3500, 150), (4500, 200)]},
        "u": {"formants": [(300, 60), (870, 80), (2240, 100), (3500, 150), (4500, 200)]},
    },
    "nasals": {
        "m": {
            "formants": [(300, 80), (1700, 140), (2500, 200)],
            "antiformant": (1000, 100),
        },
        "n": {
            "formants": [(300, 80), (1800, 140), (2600, 200)],
            "antiformant": (1000, 100),
        },
        "ng": {
            "formants": [(300, 80), (2200, 140), (3000, 200)],
            "antiformant": (1200, 100),
        },
    },
    "fricatives_voiced": {
        "v": {"noise_center": 4000, "noise_bw": 2000, "voice_ratio": 0.7},
        "z": {"noise_center": 6000, "noise_bw": 3000, "voice_ratio": 0.6},
        "zh": {"noise_center": 3500, "noise_bw": 2500, "voice_ratio": 0.65},
    },
    "fricatives_unvoiced": {
        "f": {"center": 7000, "bandwidth": 4000},
        "s": {"center": 7000, "bandwidth": 3000},
        "sh": {"center": 3500, "bandwidth": 2000},
        "th": {"center": 8000, "bandwidth": 3000},
        "h": {"center": 2500, "bandwidth": 3000},
    },
    "plosives": {
        "p": {"burst_center": 1000, "burst_duration": 10, "closure": 50, "aspiration": 30},
        "t": {"burst_center": 4000, "burst_duration": 10, "closure": 50, "aspiration": 40},
        "k": {"burst_center": 2500, "burst_duration": 15, "closure": 60, "aspiration": 50},
        "b": {"burst_center": 1000, "burst_duration": 10, "closure": 40, "voicing_delay": 10},
        "d": {"burst_center": 4000, "burst_duration": 10, "closure": 40, "voicing_delay": 10},
        "g": {"burst_center": 2500, "burst_duration": 15, "closure": 50, "voicing_delay": 15},
    },
    "liquids": {
        "l": {"formants": [(360, 80), (1200, 100), (2400, 150), (3500, 200)]},
        "r": {"formants": [(360, 80), (1400, 100), (1700, 150), (3500, 200)]},
    },
    "semivowels": {
        "w": {"formants": [(300, 60), (600, 80), (2400, 120), (3500, 150)]},
        "j": {"formants": [(250, 60), (2200, 120), (3000, 150), (3500, 200)]},
    },
}


class PhonemeSynthesizer:
    """Formant synthesizer for phoneme types using source-filter models.

    Example:
        >>> synthesizer = PhonemeSynthesizer(sample_rate=16000)
        >>> vowel_a = synthesizer.synthesize_vowel(duration=0.5, pitch=120, vowel='a')
        >>> fricative_s = synthesizer.synthesize_fricative_unvoiced(duration=0.2, fricative='s')
        >>> plosive_p = synthesizer.synthesize_plosive(duration=0.15, pitch=120, plosive='p')
    """

    def __init__(self, sample_rate: int = 16000):
        """Initialize phoneme synthesizer.

        Args:
            sample_rate: Sample rate for generated audio in Hz
        """
        self.sample_rate = sample_rate

    def generate_glottal_pulses(
        self,
        duration: float,
        pitch: float | np.ndarray,
        vibrato_freq: float = 6.0,
        vibrato_amp: float | None = None,
    ) -> np.ndarray:
        """Generate glottal pulse train with optional vibrato.

        Args:
            duration: Duration in seconds
            pitch: Either constant pitch (Hz) or array of impulse locations
            vibrato_freq: Vibrato frequency in Hz (default: 6 Hz)
            vibrato_amp: Vibrato amplitude in Hz (default: 5% of pitch)

        Returns:
            Glottal pulse train signal
        """
        sample_len = int(duration * self.sample_rate)
        y = np.zeros(sample_len, dtype=float)

        if isinstance(pitch, int | float):
            if vibrato_amp is None:
                vibrato_amp = 0.05 * pitch

            kmax = int(pitch * duration)
            k_points = np.arange(kmax)
            points = (self.sample_rate / pitch) * (
                k_points
                - (vibrato_amp / (2 * np.pi * vibrato_freq))
                * np.sin(2 * np.pi * (vibrato_freq / pitch) * k_points)
            )
            points = points[points < sample_len - 1]
        else:
            points = np.sort(np.asarray(pitch))
            points = points[points < sample_len - 1]

        indices = np.floor(points).astype(int)
        if len(indices) > 0:
            y[indices] = (indices + 1) - points
            y[indices + 1] = points - indices

        return y

    def apply_glottal_filter(self, signal_in: np.ndarray) -> np.ndarray:
        """Apply glottal source filter (two cascaded poles at 250 Hz).

        Args:
            signal_in: Input impulse train

        Returns:
            Filtered signal simulating glottal waveform
        """
        a = np.exp(-250 * 2 * np.pi / self.sample_rate)
        return signal.lfilter([1], [1, 0, -(a * a)], signal_in)

    def apply_formant_filter(
        self, signal_in: np.ndarray, freq: float, bandwidth: float
    ) -> np.ndarray:
        """Apply formant resonance filter.

        Args:
            signal_in: Input signal
            freq: Formant frequency in Hz
            bandwidth: Formant bandwidth in Hz

        Returns:
            Signal with formant resonance applied
        """
        cft = freq / self.sample_rate
        q = freq / bandwidth
        rho = np.exp(-np.pi * cft / q)
        theta = 2 * np.pi * cft * np.sqrt(1 - 1 / (4 * q * q))
        a2 = -2 * rho * np.cos(theta)
        a3 = rho * rho
        return signal.lfilter([1 + a2 + a3], [1, a2, a3], signal_in)

    def apply_antiformant_filter(
        self, signal_in: np.ndarray, freq: float, bandwidth: float
    ) -> np.ndarray:
        """Apply anti-formant (notch filter) for nasal sounds.

        Swaps numerator and denominator coefficients relative to formant filter to
        create spectral valleys.

        Args:
            signal_in: Input signal
            freq: Anti-formant frequency in Hz
            bandwidth: Anti-formant bandwidth in Hz

        Returns:
            Signal with anti-formant applied
        """
        cft = freq / self.sample_rate
        q = freq / bandwidth
        rho = np.exp(-np.pi * cft / q)
        theta = 2 * np.pi * cft * np.sqrt(1 - 1 / (4 * q * q))
        a2 = -2 * rho * np.cos(theta)
        a3 = rho * rho
        return signal.lfilter([1, a2, a3], [1 + a2 + a3], signal_in)

    def apply_bandpass_filter(
        self, signal_in: np.ndarray, center_freq: float, bandwidth: float
    ) -> np.ndarray:
        """Apply bandpass filter for fricative noise shaping.

        Args:
            signal_in: Input signal (typically white noise)
            center_freq: Center frequency in Hz
            bandwidth: Filter bandwidth in Hz

        Returns:
            Bandpass filtered signal
        """
        nyquist = self.sample_rate / 2
        low = max((center_freq - bandwidth / 2) / nyquist, 0.01)
        high = min((center_freq + bandwidth / 2) / nyquist, 0.99)
        b, a = signal.butter(4, [low, high], btype="band")
        return signal.filtfilt(b, a, signal_in)

    def synthesize_vowel(
        self,
        duration: float,
        pitch: float,
        vowel: str = "a",
        vibrato_freq: float = 6.0,
        vibrato_amp: float | None = None,
    ) -> np.ndarray:
        """Synthesize a vowel sound.

        Args:
            duration: Duration in seconds
            pitch: Fundamental frequency in Hz
            vowel: Vowel type: 'a', 'e', 'i', 'o', 'u'
            vibrato_freq: Vibrato frequency in Hz
            vibrato_amp: Vibrato amplitude in Hz

        Returns:
            Synthesized vowel waveform

        Example:
            >>> synth = PhonemeSynthesizer()
            >>> vowel = synth.synthesize_vowel(duration=0.5, pitch=120, vowel='a')
        """
        if vowel not in PHONEME_SPECS["vowels"]:
            raise ValueError(
                f"Unknown vowel '{vowel}'. Must be one of: {list(PHONEME_SPECS['vowels'].keys())}"
            )

        y = self.generate_glottal_pulses(duration, pitch, vibrato_freq, vibrato_amp)
        y = self.apply_glottal_filter(y)

        formants = PHONEME_SPECS["vowels"][vowel]["formants"]
        for freq, bw in formants:
            y = self.apply_formant_filter(y, freq, bw)

        return y

    def synthesize_nasal(
        self,
        duration: float,
        pitch: float,
        nasal: str = "m",
        vibrato_freq: float = 6.0,
        vibrato_amp: float | None = None,
    ) -> np.ndarray:
        """Synthesize a nasal consonant.

        Args:
            duration: Duration in seconds
            pitch: Fundamental frequency in Hz
            nasal: Nasal type: 'm', 'n', 'ng'
            vibrato_freq: Vibrato frequency in Hz
            vibrato_amp: Vibrato amplitude in Hz

        Returns:
            Synthesized nasal waveform

        Example:
            >>> synth = PhonemeSynthesizer()
            >>> nasal = synth.synthesize_nasal(duration=0.3, pitch=120, nasal='m')
        """
        if nasal not in PHONEME_SPECS["nasals"]:
            raise ValueError(
                f"Unknown nasal '{nasal}'. Must be one of: {list(PHONEME_SPECS['nasals'].keys())}"
            )

        y = self.generate_glottal_pulses(duration, pitch, vibrato_freq, vibrato_amp)
        y = self.apply_glottal_filter(y)

        spec = PHONEME_SPECS["nasals"][nasal]
        for freq, bw in spec["formants"]:
            y = self.apply_formant_filter(y, freq, bw)

        anti_freq, anti_bw = spec["antiformant"]
        y = self.apply_antiformant_filter(y, anti_freq, anti_bw)

        return y

    def synthesize_fricative_voiced(
        self,
        duration: float,
        pitch: float,
        fricative: str = "v",
        vibrato_freq: float = 6.0,
        vibrato_amp: float | None = None,
    ) -> np.ndarray:
        """Synthesize a voiced fricative consonant.

        Args:
            duration: Duration in seconds
            pitch: Fundamental frequency in Hz
            fricative: Fricative type: 'v', 'z', 'zh'
            vibrato_freq: Vibrato frequency in Hz
            vibrato_amp: Vibrato amplitude in Hz

        Returns:
            Synthesized voiced fricative waveform

        Example:
            >>> synth = PhonemeSynthesizer()
            >>> fricative = synth.synthesize_fricative_voiced(
            ...     duration=0.2, pitch=120, fricative='z'
            ... )
        """
        if fricative not in PHONEME_SPECS["fricatives_voiced"]:
            raise ValueError(
                f"Unknown voiced fricative '{fricative}'. "
                f"Must be one of: {list(PHONEME_SPECS['fricatives_voiced'].keys())}"
            )

        sample_len = int(duration * self.sample_rate)
        spec = PHONEME_SPECS["fricatives_voiced"][fricative]

        voiced = self.generate_glottal_pulses(duration, pitch, vibrato_freq, vibrato_amp)
        voiced = self.apply_glottal_filter(voiced)

        noise = np.random.randn(sample_len)
        noise = self.apply_bandpass_filter(noise, spec["noise_center"], spec["noise_bw"])

        y = spec["voice_ratio"] * voiced + (1 - spec["voice_ratio"]) * noise

        return y

    def synthesize_fricative_unvoiced(self, duration: float, fricative: str = "s") -> np.ndarray:
        """Synthesize an unvoiced fricative consonant.

        Args:
            duration: Duration in seconds
            fricative: Fricative type: 'f', 's', 'sh', 'th', 'h'

        Returns:
            Synthesized unvoiced fricative waveform

        Example:
            >>> synth = PhonemeSynthesizer()
            >>> fricative = synth.synthesize_fricative_unvoiced(duration=0.2, fricative='s')
        """
        if fricative not in PHONEME_SPECS["fricatives_unvoiced"]:
            raise ValueError(
                f"Unknown unvoiced fricative '{fricative}'. "
                f"Must be one of: {list(PHONEME_SPECS['fricatives_unvoiced'].keys())}"
            )

        sample_len = int(duration * self.sample_rate)
        spec = PHONEME_SPECS["fricatives_unvoiced"][fricative]

        noise = np.random.randn(sample_len)
        y = self.apply_bandpass_filter(noise, spec["center"], spec["bandwidth"])

        return y

    def synthesize_plosive(
        self, duration: float, pitch: float, plosive: str = "p", voiced: bool = False
    ) -> np.ndarray:
        """Synthesize a plosive (stop) consonant.

        Args:
            duration: Duration in seconds
            pitch: Fundamental frequency in Hz (for voiced plosives)
            plosive: Plosive type: 'p', 't', 'k', 'b', 'd', 'g'
            voiced: Whether plosive is voiced (auto-detected from plosive name)

        Returns:
            Synthesized plosive waveform

        Example:
            >>> synth = PhonemeSynthesizer()
            >>> plosive = synth.synthesize_plosive(duration=0.15, pitch=120, plosive='p')
        """
        if plosive not in PHONEME_SPECS["plosives"]:
            raise ValueError(
                f"Unknown plosive '{plosive}'. "
                f"Must be one of: {list(PHONEME_SPECS['plosives'].keys())}"
            )

        voiced = plosive in ["b", "d", "g"]
        sample_len = int(duration * self.sample_rate)
        spec = PHONEME_SPECS["plosives"][plosive]

        y = np.zeros(sample_len, dtype=float)

        closure_samples = int(spec["closure"] * self.sample_rate / 1000)

        burst_samples = int(spec["burst_duration"] * self.sample_rate / 1000)
        burst = np.random.randn(burst_samples)
        burst = self.apply_bandpass_filter(burst, spec["burst_center"], 1000)
        burst *= np.exp(-np.linspace(0, 5, burst_samples))
        y[closure_samples : closure_samples + burst_samples] = burst

        release_start = closure_samples + burst_samples

        if not voiced and "aspiration" in spec:
            aspiration_samples = int(spec["aspiration"] * self.sample_rate / 1000)
            if release_start + aspiration_samples < sample_len:
                aspiration = np.random.randn(aspiration_samples) * 0.3
                aspiration *= np.linspace(1, 0, aspiration_samples)
                y[release_start : release_start + aspiration_samples] = aspiration

        elif voiced:
            voicing_delay_samples = int(spec.get("voicing_delay", 0) * self.sample_rate / 1000)
            voicing_start = release_start + voicing_delay_samples

            if voicing_start < sample_len:
                voicing_duration = (sample_len - voicing_start) / self.sample_rate
                voiced_part = self.synthesize_vowel(voicing_duration, pitch, vowel="a")
                voiced_part *= np.linspace(0, 1, len(voiced_part)) ** 2
                y[voicing_start:] = voiced_part[: sample_len - voicing_start]

        return y

    def synthesize_liquid(
        self,
        duration: float,
        pitch: float,
        liquid: str = "l",
        vibrato_freq: float = 6.0,
        vibrato_amp: float | None = None,
    ) -> np.ndarray:
        """Synthesize a liquid consonant.

        Args:
            duration: Duration in seconds
            pitch: Fundamental frequency in Hz
            liquid: Liquid type: 'l', 'r'
            vibrato_freq: Vibrato frequency in Hz
            vibrato_amp: Vibrato amplitude in Hz

        Returns:
            Synthesized liquid waveform

        Example:
            >>> synth = PhonemeSynthesizer()
            >>> liquid = synth.synthesize_liquid(duration=0.3, pitch=120, liquid='l')
        """
        if liquid not in PHONEME_SPECS["liquids"]:
            available_liquids = list(PHONEME_SPECS["liquids"].keys())
            raise ValueError(f"Unknown liquid '{liquid}'. Must be one of: {available_liquids}")

        y = self.generate_glottal_pulses(duration, pitch, vibrato_freq, vibrato_amp)
        y = self.apply_glottal_filter(y)

        formants = PHONEME_SPECS["liquids"][liquid]["formants"]
        for freq, bw in formants:
            y = self.apply_formant_filter(y, freq, bw)

        return y

    def synthesize_semivowel(
        self,
        duration: float,
        pitch: float,
        semivowel: str = "w",
        vibrato_freq: float = 6.0,
        vibrato_amp: float | None = None,
    ) -> np.ndarray:
        """Synthesize a semi-vowel (glide).

        Args:
            duration: Duration in seconds
            pitch: Fundamental frequency in Hz
            semivowel: Semi-vowel type: 'w', 'j'
            vibrato_freq: Vibrato frequency in Hz
            vibrato_amp: Vibrato amplitude in Hz

        Returns:
            Synthesized semi-vowel waveform

        Example:
            >>> synth = PhonemeSynthesizer()
            >>> semivowel = synth.synthesize_semivowel(duration=0.2, pitch=120, semivowel='w')
        """
        if semivowel not in PHONEME_SPECS["semivowels"]:
            raise ValueError(
                f"Unknown semivowel '{semivowel}'. "
                f"Must be one of: {list(PHONEME_SPECS['semivowels'].keys())}"
            )

        y = self.generate_glottal_pulses(duration, pitch, vibrato_freq, vibrato_amp)
        y = self.apply_glottal_filter(y)

        formants = PHONEME_SPECS["semivowels"][semivowel]["formants"]
        for freq, bw in formants:
            y = self.apply_formant_filter(y, freq, bw)

        return y


def _synthesize_vowel_phoneme(
    synthesizer: PhonemeSynthesizer, phoneme: str, duration: float, pitch: float, **kwargs
) -> np.ndarray:
    """Synthesize vowel phoneme."""
    return synthesizer.synthesize_vowel(duration, pitch, vowel=phoneme, **kwargs)


def _synthesize_nasal_phoneme(
    synthesizer: PhonemeSynthesizer, phoneme: str, duration: float, pitch: float, **kwargs
) -> np.ndarray:
    """Synthesize nasal phoneme."""
    return synthesizer.synthesize_nasal(duration, pitch, nasal=phoneme, **kwargs)


def _synthesize_voiced_fricative_phoneme(
    synthesizer: PhonemeSynthesizer, phoneme: str, duration: float, pitch: float, **kwargs
) -> np.ndarray:
    """Synthesize voiced fricative phoneme."""
    return synthesizer.synthesize_fricative_voiced(duration, pitch, fricative=phoneme, **kwargs)


def _synthesize_unvoiced_fricative_phoneme(
    synthesizer: PhonemeSynthesizer, phoneme: str, duration: float, **kwargs
) -> np.ndarray:
    """Synthesize unvoiced fricative phoneme."""
    return synthesizer.synthesize_fricative_unvoiced(duration, fricative=phoneme, **kwargs)


def _synthesize_plosive_phoneme(
    synthesizer: PhonemeSynthesizer, phoneme: str, duration: float, pitch: float
) -> np.ndarray:
    """Synthesize plosive phoneme."""
    voiced = phoneme in ["b", "d", "g"]
    return synthesizer.synthesize_plosive(duration, pitch, plosive=phoneme, voiced=voiced)


def _synthesize_liquid_phoneme(
    synthesizer: PhonemeSynthesizer, phoneme: str, duration: float, pitch: float, **kwargs
) -> np.ndarray:
    """Synthesize liquid phoneme."""
    return synthesizer.synthesize_liquid(duration, pitch, liquid=phoneme, **kwargs)


def _synthesize_semivowel_phoneme(
    synthesizer: PhonemeSynthesizer, phoneme: str, duration: float, pitch: float, **kwargs
) -> np.ndarray:
    """Synthesize semivowel phoneme."""
    return synthesizer.synthesize_semivowel(duration, pitch, semivowel=phoneme, **kwargs)


def synthesize_phoneme(
    phoneme: str,
    duration: float = 0.3,
    pitch: float = 120.0,
    sample_rate: int = 16000,
    **kwargs,
) -> np.ndarray:
    """Synthesize any phoneme by detecting type and calling appropriate method.

    Args:
        phoneme: Phoneme symbol (e.g., 'a', 'm', 's', 'p', 'l')
        duration: Duration in seconds
        pitch: Fundamental frequency in Hz
        sample_rate: Sample rate in Hz
        **kwargs: Additional arguments passed to specific synthesizer

    Returns:
        Synthesized phoneme waveform

    Raises:
        ValueError: If phoneme is unknown

    Example:
        >>> vowel = synthesize_phoneme('a', duration=0.5, pitch=150)
        >>> nasal = synthesize_phoneme('m', duration=0.3, pitch=120)
        >>> fricative = synthesize_phoneme('s', duration=0.2)
    """
    synthesizer = PhonemeSynthesizer(sample_rate=sample_rate)

    phoneme_handlers = [
        (PHONEME_SPECS["vowels"], _synthesize_vowel_phoneme, True),
        (PHONEME_SPECS["nasals"], _synthesize_nasal_phoneme, True),
        (PHONEME_SPECS["fricatives_voiced"], _synthesize_voiced_fricative_phoneme, True),
        (PHONEME_SPECS["fricatives_unvoiced"], _synthesize_unvoiced_fricative_phoneme, False),
        (PHONEME_SPECS["plosives"], _synthesize_plosive_phoneme, False),
        (PHONEME_SPECS["liquids"], _synthesize_liquid_phoneme, True),
        (PHONEME_SPECS["semivowels"], _synthesize_semivowel_phoneme, True),
    ]

    for specs, handler, use_kwargs in phoneme_handlers:
        if phoneme in specs:
            if use_kwargs:
                return handler(synthesizer, phoneme, duration, pitch, **kwargs)
            return handler(synthesizer, phoneme, duration, pitch)

    raise ValueError(
        f"Unknown phoneme '{phoneme}'. Supported phonemes: {list(_get_all_phonemes())}"
    )


def _get_all_phonemes() -> set:
    """Get set of all supported phoneme symbols."""
    all_phonemes = set()
    for category in PHONEME_SPECS.values():
        all_phonemes.update(category.keys())
    return all_phonemes
