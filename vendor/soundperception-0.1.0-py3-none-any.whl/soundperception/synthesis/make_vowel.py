"""Vowel synthesis based on MakeVowel (Slaney/Lyon).

Source-filter model:
  1. Impulse train (pitch scalar or array of impulse positions)
  2. Glottal filter (250 Hz, 2nd order)
  3. Formant filters (2nd order IIR resonators) in cascade

From Malcolm Slaney's Python Auditory Toolbox.
Original MakeVowel by Richard O. Duda.

References:
    Slaney, M. Python Auditory Toolbox.
    https://github.com/MalcolmSlaney/python_auditory_toolbox
"""

import numpy as np
from scipy import signal


def fm_points(sample_len, freq, fm_freq=6, fm_amp=None, fs=16000):
    """Generate fractional sample locations for FM impulse train (vibrato).

    Args:
        sample_len: Number of samples to generate.
        freq: Pitch frequency (Hz).
        fm_freq: Vibrato frequency (Hz), default 6.
        fm_amp: Max pitch deviation (Hz), default 5% of freq.
        fs: Sample rate (Hz).

    Returns:
        Array of fractional impulse positions.
    """
    if fm_amp is None:
        fm_amp = 0.05 * freq

    kmax = int(freq * (sample_len / fs))
    points = np.arange(kmax)
    points = (fs / freq) * (
        points - (fm_amp / (2 * np.pi * fm_freq)) * np.sin(2 * np.pi * (fm_freq / freq) * points)
    )
    return points


def make_vowel(sample_len, pitch, sample_rate=16000, f1=0, f2=0, f3=0, bw=50):
    """Synthesize a vowel using source-filter model.

    Source: impulse train filtered by glottal pulse (250 Hz resonance).
    Filter: cascade of 2nd-order formant resonators.

    Args:
        sample_len: Number of output samples.
        pitch: Either a scalar pitch (Hz) or an array of impulse positions
               (from fm_points).
        sample_rate: Sample rate (Hz).
        f1: First formant freq (Hz), or vowel string ('a', 'i', 'u').
        f2: Second formant freq (Hz).
        f3: Third formant freq (Hz).
        bw: Bandwidth of formant filters (Hz).

    Returns:
        Synthesized vowel waveform, shape (sample_len,).

    Common French vowels (approximate):
        /a/  f1=730  f2=1090 f3=2440
        /i/  f1=270  f2=2290 f3=3010
        /u/  f1=300  f2=870  f3=2240
        /e/  f1=400  f2=2000 f3=2550
        /o/  f1=500  f2=900  f3=2450
        /y/  f1=300  f2=1800 f3=2300
    """
    vowel_table = {
        "a": (730, 1090, 2440),
        "/a/": (730, 1090, 2440),
        "i": (270, 2290, 3010),
        "/i/": (270, 2290, 3010),
        "u": (300, 870, 2240),
        "/u/": (300, 870, 2240),
        "e": (400, 2000, 2550),
        "/e/": (400, 2000, 2550),
        "o": (500, 900, 2450),
        "/o/": (500, 900, 2450),
        "y": (300, 1800, 2300),
        "/y/": (300, 1800, 2300),
    }

    if isinstance(f1, str):
        f1, f2, f3 = vowel_table.get(f1, (730, 1090, 2440))

    # Build impulse train
    y = np.zeros(sample_len, dtype=np.float64)
    if isinstance(pitch, (int, float)):
        points = np.arange(0, sample_len - 1, sample_rate / pitch)
    else:
        points = np.sort(np.asarray(pitch, dtype=np.float64))
        points = points[points < sample_len - 1]

    indices = np.floor(points).astype(int)
    y[indices] = (indices + 1) - points
    y[indices + 1] = points - indices

    # Glottal pulse filter (250 Hz resonance)
    a = np.exp(-250 * 2 * np.pi / sample_rate)
    y = signal.lfilter([1], [1, 0, -a * a], y)

    # Formant filters (cascade of 2nd-order resonators)
    for f in [f1, f2, f3]:
        if f > 0:
            y = _formant_filter(y, f, bw, sample_rate)

    return y


def _formant_filter(y, freq, bw, sample_rate):
    """Apply one 2nd-order formant resonator."""
    cft = freq / sample_rate
    q = freq / bw
    rho = np.exp(-np.pi * cft / q)
    theta = 2 * np.pi * cft * np.sqrt(1 - 1 / (4 * q * q))
    a2 = -2 * rho * np.cos(theta)
    a3 = rho * rho
    return signal.lfilter([1 + a2 + a3], [1, a2, a3], y)
