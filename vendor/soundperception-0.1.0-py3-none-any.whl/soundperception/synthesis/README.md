##

 Phoneme Synthesis Module

Module de synthèse de phonèmes basé sur le modèle source-filtre (formant synthesis).

## Vue d'ensemble

Ce module permet de générer synthétiquement tous les types de phonèmes utilisés dans la parole humaine :

| Catégorie | Phonèmes | Caractéristiques |
|-----------|----------|------------------|
| **Voyelles** | /a/, /e/, /i/, /o/, /u/ | Source glottale + 3-5 formants |
| **Nasales** | /m/, /n/, /ŋ/ (ng) | Source glottale + formants + anti-formant (~1000 Hz) |
| **Fricatives voisées** | /v/, /z/, /ʒ/ (zh) | Source glottale + bruit filtré |
| **Fricatives non-voisées** | /f/, /s/, /ʃ/ (sh), /θ/ (th), /h/ | Bruit blanc filtré uniquement |
| **Plosives non-voisées** | /p/, /t/, /k/ | Silence + burst explosif + aspiration |
| **Plosives voisées** | /b/, /d/, /g/ | Silence + burst + voisement |
| **Liquides** | /l/, /r/ | Source glottale + formants spéciaux |
| **Semi-voyelles** | /w/, /j/ | Source glottale + formants en transition |

## Installation

Le module est inclus dans le package `soundgenerator` :

```python
from soundgenerator.synthesis import PhonemeSynthesizer, synthesize_phoneme
```

## Utilisation rapide

### Fonction de convenance

```python
from soundgenerator.synthesis import synthesize_phoneme
from soundgenerator.utils.audio_io import save_audio

# Voyelle /a/
vowel = synthesize_phoneme('a', duration=0.5, pitch=120, sample_rate=16000)
save_audio('vowel_a.wav', vowel, sample_rate=16000)

# Consonne nasale /m/
nasal = synthesize_phoneme('m', duration=0.3, pitch=120, sample_rate=16000)
save_audio('nasal_m.wav', nasal, sample_rate=16000)

# Fricative non-voisée /s/
fricative = synthesize_phoneme('s', duration=0.2, sample_rate=16000)
save_audio('fricative_s.wav', fricative, sample_rate=16000)

# Plosive /p/
plosive = synthesize_phoneme('p', duration=0.15, pitch=120, sample_rate=16000)
save_audio('plosive_p.wav', plosive, sample_rate=16000)
```

### Classe PhonemeSynthesizer

```python
from soundgenerator.synthesis import PhonemeSynthesizer

# Initialiser le synthétiseur
synth = PhonemeSynthesizer(sample_rate=16000)

# Synthétiser différents types de phonèmes
vowel_a = synth.synthesize_vowel(duration=0.5, pitch=120, vowel='a')
nasal_m = synth.synthesize_nasal(duration=0.3, pitch=120, nasal='m')
fric_s = synth.synthesize_fricative_unvoiced(duration=0.2, fricative='s')
plos_p = synth.synthesize_plosive(duration=0.15, pitch=120, plosive='p')
liquid_l = synth.synthesize_liquid(duration=0.3, pitch=120, liquid='l')
```

## Exemples détaillés

### 1. Voyelles avec vibrato

```python
from soundgenerator.synthesis import PhonemeSynthesizer

synth = PhonemeSynthesizer(sample_rate=16000)

# Voyelle /a/ avec vibrato
vowel = synth.synthesize_vowel(
    duration=0.8,
    pitch=150,
    vowel='a',
    vibrato_freq=6.0,      # Vibrato à 6 Hz
    vibrato_amp=7.5        # Amplitude du vibrato (5% de F0)
)
```

### 2. Consonnes nasales

```python
# Différentes nasales
nasal_m = synth.synthesize_nasal(duration=0.3, pitch=120, nasal='m')  # Bilabiale
nasal_n = synth.synthesize_nasal(duration=0.3, pitch=120, nasal='n')  # Alvéolaire
nasal_ng = synth.synthesize_nasal(duration=0.3, pitch=120, nasal='ng')  # Vélaire
```

### 3. Fricatives voisées vs non-voisées

```python
# Voisée : /z/ (nécessite un pitch)
fric_z = synth.synthesize_fricative_voiced(duration=0.25, pitch=120, fricative='z')

# Non-voisée : /s/ (pas de pitch)
fric_s = synth.synthesize_fricative_unvoiced(duration=0.25, fricative='s')
```

### 4. Plosives avec ou sans aspiration

```python
# Non-voisée avec aspiration
plos_p = synth.synthesize_plosive(duration=0.15, pitch=120, plosive='p')

# Voisée sans aspiration mais avec voisement
plos_b = synth.synthesize_plosive(duration=0.15, pitch=120, plosive='b', voiced=True)
```

### 5. Variations de pitch (homme, femme, enfant)

```python
# Voix d'homme (F0 ~ 120 Hz)
male_voice = synth.synthesize_vowel(duration=0.5, pitch=120, vowel='a')

# Voix de femme (F0 ~ 220 Hz)
female_voice = synth.synthesize_vowel(duration=0.5, pitch=220, vowel='a')

# Voix d'enfant (F0 ~ 350 Hz)
child_voice = synth.synthesize_vowel(duration=0.5, pitch=350, vowel='a')
```

## Phonèmes supportés

### Voyelles (`synthesize_vowel`)

| Symbole | IPA | Exemple français | Formants (F1, F2, F3) Hz |
|---------|-----|------------------|--------------------------|
| `a` | /a/ | p**a**tte | 730, 1090, 2440 |
| `e` | /e/ | caf**é** | 530, 1840, 2480 |
| `i` | /i/ | v**i**te | 270, 2290, 3010 |
| `o` | /o/ | d**o**me | 570, 840, 2410 |
| `u` | /u/ | t**ou**r | 300, 870, 2240 |

### Nasales (`synthesize_nasal`)

| Symbole | IPA | Exemple | Caractéristique |
|---------|-----|---------|-----------------|
| `m` | /m/ | **m**aman | Bilabiale |
| `n` | /n/ | **n**ez | Alvéolaire |
| `ng` | /ŋ/ | parki**ng** | Vélaire |

### Fricatives voisées (`synthesize_fricative_voiced`)

| Symbole | IPA | Exemple | Fréquence centrale |
|---------|-----|---------|-------------------|
| `v` | /v/ | **v**ite | 4000 Hz |
| `z` | /z/ | ro**s**e | 6000 Hz |
| `zh` | /ʒ/ | **j**e | 3500 Hz |

### Fricatives non-voisées (`synthesize_fricative_unvoiced`)

| Symbole | IPA | Exemple | Fréquence centrale |
|---------|-----|---------|-------------------|
| `f` | /f/ | **f**eu | 7000 Hz |
| `s` | /s/ | **s**ac | 7000 Hz |
| `sh` | /ʃ/ | **ch**at | 3500 Hz |
| `th` | /θ/ | **th**ing (anglais) | 8000 Hz |
| `h` | /h/ | **h**ello | 2500 Hz |

### Plosives (`synthesize_plosive`)

| Symbole | IPA | Voisement | Exemple | Lieu d'articulation |
|---------|-----|-----------|---------|---------------------|
| `p` | /p/ | Non | **p**as | Bilabiale |
| `t` | /t/ | Non | **t**as | Alvéolaire |
| `k` | /k/ | Non | **c**as | Vélaire |
| `b` | /b/ | Oui | **b**as | Bilabiale |
| `d` | /d/ | Oui | **d**as | Alvéolaire |
| `g` | /g/ | Oui | **g**as | Vélaire |

### Liquides (`synthesize_liquid`)

| Symbole | IPA | Exemple | Caractéristique |
|---------|-----|---------|-----------------|
| `l` | /l/ | **l**ac | Latérale |
| `r` | /r/ | **r**ac | Rhotique (F2 et F3 proches) |

### Semi-voyelles (`synthesize_semivowel`)

| Symbole | IPA | Exemple | Caractéristique |
|---------|-----|---------|-----------------|
| `w` | /w/ | **ou**i | Labio-vélaire |
| `j` | /j/ | **y**es (anglais) | Palatale |

## Paramètres acoustiques

### Formants

Résonances du conduit vocal qui déterminent le timbre des phonèmes voisés.

```python
# Exemple : voyelle /a/
# F1 = 730 Hz  (ouverture de la bouche)
# F2 = 1090 Hz (position de la langue avant-arrière)
# F3 = 2440 Hz (cavité labiale)
```

### Bande passante (bandwidth)

Largeur spectrale des formants.

```python
# Exemple
formant_freq = 1000  # Hz
bandwidth = 80       # Hz (Q factor ~ 12.5)
```

### Vibrato

Modulation de fréquence.

```python
vibrato_freq = 6.0    # Hz
vibrato_amp = 7.5     # Hz (~5% du F0)
```

## Architecture du code

```
soundgenerator/synthesis/
├── __init__.py                 # Exports publics
├── phoneme_synthesizer.py      # Module principal
└── README.md                   # Cette documentation

Fonctions principales :
├── synthesize_phoneme()        # Fonction de convenance (auto-détection)
└── PhonemeSynthesizer          # Classe principale
    ├── synthesize_vowel()
    ├── synthesize_nasal()
    ├── synthesize_fricative_voiced()
    ├── synthesize_fricative_unvoiced()
    ├── synthesize_plosive()
    ├── synthesize_liquid()
    └── synthesize_semivowel()
```

## Principes acoustiques

### Modèle source-filtre

Le module implémente le modèle source-filtre classique :

```
Source → Filtre → Sortie
```

**Sources** :
- **Glottale** : Train d'impulsions périodiques (pour phonèmes voisés)
- **Bruit** : Bruit blanc (pour phonèmes non-voisés)
- **Mixte** : Combinaison glottale + bruit (fricatives voisées)

**Filtres** :
- **Formants** : Résonances du conduit vocal (filtres passe-bande)
- **Anti-formants** : Vallées spectrales (filtres coupe-bande, pour nasales)

### Équations

**Filtre formant** (résonateur du 2nd ordre) :
```
H(z) = (1 + a2 + a3) / (1 + a2*z^-1 + a3*z^-2)

où :
  ρ = exp(-π * (f/fs) / Q)
  θ = 2π * (f/fs) * sqrt(1 - 1/(4Q²))
  a2 = -2ρ cos(θ)
  a3 = ρ²
  Q = f / bandwidth
```

**Source glottale** :
```
Période T = fs / F0
Impulsions aux instants : n = k * T + FM(k)
FM(k) = (A_vib / f_vib) * sin(2π * f_vib * k / F0)
```

## Tests

Un script de test complet est fourni :

```bash
python test_phoneme_synthesis.py
```

Ce script génère 34 exemples audio dans `data/phoneme_synthesis_examples/` :
- 5 voyelles
- 3 nasales
- 3 fricatives voisées
- 5 fricatives non-voisées
- 6 plosives (3 voisées + 3 non-voisées)
- 2 liquides
- 2 semi-voyelles
- 4 variations de pitch
- 4 tests de la fonction de convenance

## Références

### Livres
- **Flanagan, J.L.** (1972). *Speech Analysis, Synthesis and Perception*. Springer-Verlag.
- **Fant, G.** (1960). *Acoustic Theory of Speech Production*. Mouton.
- **Klatt, D.H.** (1980). Software for a cascade/parallel formant synthesizer. *JASA*, 67(3), 971-995.

### Articles
- Stevens, K.N. (1998). *Acoustic Phonetics*. MIT Press.
- Peterson, G.E., & Barney, H.L. (1952). Control methods used in a study of the vowels. *JASA*, 24(2), 175-184.

### Bases de données
- Les formants des voyelles sont basés sur Peterson & Barney (1952)
- Les paramètres des consonnes suivent les spécifications de Klatt (1980)

## Limitations et extensions

### Limitations
- **Coarticulation** : Pas de transitions formantiques entre phonèmes
- **Prosodie** : Pas de modulation d'intensité ou de durée contextuelle
- **Variations allophoniques** : Un seul exemplaire par phonème
- **Bruit d'aspiration** : Modèle à bruit blanc filtré

### Extensions
- [ ] Séquençage de phonèmes avec coarticulation
- [ ] Générateur de mots avec règles phonologiques
- [ ] Support de l'IPA complet
- [ ] Prosodie (intonation, accentuation, rythme)
- [ ] Modèle glottal LF
- [ ] Synthèse guidée par spectrogramme

## Licence

Ce module fait partie du projet `sound-generator` et suit la même licence.

---

**Auteurs** : Développé avec Claude Code (Anthropic)
**Date** : Novembre 2025
**Version** : 1.0.0