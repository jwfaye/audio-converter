"""Visualization style configuration for scientific plots.

References:
- SciencePlots: https://github.com/garrettj403/SciencePlots
- Matplotlib best practices: https://matplotlib.org/stable/tutorials/
- Seaborn color palettes: https://seaborn.pydata.org/tutorial/color_palettes.html
- Colorblind-safe palettes: https://medium.com/data-science-collective/
"""

import os
import warnings
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from matplotlib import rcParams
from matplotlib.ticker import FuncFormatter, ScalarFormatter

STYLE_CONFIG = {
    "figure": {
        "figsize": (8, 6),
        "dpi": 300,
        "facecolor": "white",
        "edgecolor": "white",
        "autolayout": False,
    },
    "axes": {
        "grid": True,
        "grid.alpha": 0.3,
        "grid.linestyle": "--",
        "grid.linewidth": 0.5,
        "facecolor": "white",
        "edgecolor": "black",
        "linewidth": 1.0,
        "labelsize": 11,
        "titlesize": 12,
        "titleweight": "bold",
        "labelweight": "normal",
        "spines.top": False,
        "spines.right": False,
    },
    "colors": {
        "palette": "colorblind",
        "categorical": [
            "#0173B2",
            "#DE8F05",
            "#029E73",
            "#CC78BC",
            "#CA9161",
            "#949494",
            "#ECE133",
            "#56B4E9",
        ],
        "sequential": "viridis",
        "sequential_alternatives": ["rocket", "mako", "flare", "crest"],
        "divergent": "RdBu_r",
        "divergent_alternatives": ["vlag", "icefire", "coolwarm"],
    },
    "fonts": {
        "family": "sans-serif",
        "sans-serif": ["DejaVu Sans", "Arial", "Helvetica", "Liberation Sans"],
        "size": 10,
        "weight": "normal",
    },
    "legend": {
        "frameon": True,
        "framealpha": 0.8,
        "fancybox": False,
        "edgecolor": "black",
        "facecolor": "white",
        "fontsize": 9,
        "loc": "best",
        "numpoints": 1,
        "scatterpoints": 1,
        "markerscale": 1.0,
        "borderpad": 0.5,
        "labelspacing": 0.5,
    },
    "lines": {
        "linewidth": 1.5,
        "markersize": 6,
        "markeredgewidth": 0.5,
    },
    "xtick": {
        "labelsize": 10,
        "direction": "out",
        "top": False,
        "bottom": True,
    },
    "ytick": {
        "labelsize": 10,
        "direction": "out",
        "right": False,
        "left": True,
    },
}


LAYOUT_PRESETS = {
    "single_plot": {
        "figsize": (8, 6),
        "margins": {"left": 0.12, "right": 0.95, "top": 0.92, "bottom": 0.12},
        "description": "Single plot with margins for labels",
    },
    "subplot_2x2": {
        "figsize": (12, 10),
        "margins": {"left": 0.08, "right": 0.96, "top": 0.94, "bottom": 0.08},
        "spacing": {"wspace": 0.25, "hspace": 0.30},
        "description": "2x2 grid layout",
    },
    "subplot_1x2": {
        "figsize": (14, 6),
        "margins": {"left": 0.08, "right": 0.96, "top": 0.92, "bottom": 0.12},
        "spacing": {"wspace": 0.20, "hspace": 0.20},
        "description": "1x2 horizontal layout",
    },
    "subplot_2x1": {
        "figsize": (10, 10),
        "margins": {"left": 0.12, "right": 0.95, "top": 0.94, "bottom": 0.08},
        "spacing": {"wspace": 0.20, "hspace": 0.25},
        "description": "2x1 vertical layout",
    },
    "grid_complex": {
        "figsize": (16, 12),
        "margins": {"left": 0.06, "right": 0.97, "top": 0.95, "bottom": 0.06},
        "spacing": {"wspace": 0.30, "hspace": 0.35},
        "description": "Complex grid layout for multiple plots",
    },
    "wide_dashboard": {
        "figsize": (18, 8),
        "margins": {"left": 0.05, "right": 0.98, "top": 0.92, "bottom": 0.10},
        "spacing": {"wspace": 0.25, "hspace": 0.30},
        "description": "Wide format for dashboards",
    },
}


class ColorPalettes:
    """Color palette management for plots."""

    @staticmethod
    def get_categorical(n_colors: int = 8, colorblind_safe: bool = True) -> list[str]:
        """Get categorical palette.

        Args:
            n_colors: Number of colors needed.
            colorblind_safe: Use colorblind-safe palette.

        Returns:
            List of hex color codes.
        """
        if colorblind_safe:
            if n_colors <= 8:
                return sns.color_palette("colorblind", n_colors).as_hex()
            elif n_colors <= 20:
                return sns.color_palette("tab20", n_colors).as_hex()
            else:
                warnings.warn(
                    f"Requesting {n_colors} categorical colors may be difficult to distinguish. "
                    "Consider grouping categories or using alternative visualization.",
                    stacklevel=2,
                )
                return sns.color_palette("husl", n_colors).as_hex()
        elif n_colors <= 10:
            return sns.color_palette("tab10", n_colors).as_hex()
        else:
            return sns.color_palette("Set3", n_colors).as_hex()

    @staticmethod
    def get_sequential(name: str = "viridis", n_colors: int = 256, as_cmap: bool = False) -> Any:
        """Get sequential palette.

        Args:
            name: Colormap name (viridis, plasma, inferno, magma, cividis, rocket, mako).
            n_colors: Number of discrete colors (ignored if as_cmap=True).
            as_cmap: Return matplotlib colormap object instead of list.

        Returns:
            List of colors or matplotlib colormap.
        """
        if as_cmap:
            return plt.get_cmap(name)
        else:
            return sns.color_palette(name, n_colors=n_colors).as_hex()

    @staticmethod
    def get_divergent(name: str = "RdBu_r", n_colors: int = 11, center: str = "light") -> list[str]:
        """Get divergent palette.

        Args:
            name: Colormap name (RdBu_r, vlag, icefire, coolwarm).
            n_colors: Number of discrete colors.
            center: Center color intensity ('light', 'dark').

        Returns:
            List of hex color codes.
        """
        return sns.color_palette(name, n_colors=n_colors, center=center).as_hex()

    @staticmethod
    def show_palette(palette: list[str], labels: list[str] | None = None) -> None:
        """Display a color palette with optional labels.

        Args:
            palette: List of color codes.
            labels: Optional labels for each color.
        """
        n = len(palette)
        fig, ax = plt.subplots(figsize=(10, 0.5))
        ax.imshow(
            [list(range(n))], cmap=plt.matplotlib.colors.ListedColormap(palette), aspect="auto"
        )
        ax.set_xticks(range(n))
        if labels:
            ax.set_xticklabels(labels, rotation=45, ha="right")
        ax.set_yticks([])
        plt.tight_layout()
        plt.show()


def apply_style(style_name: str = "publication") -> None:
    """Apply predefined style to all subsequent plots.

    Args:
        style_name: Style name ('publication', 'presentation', 'notebook')
    """
    if style_name == "publication":
        plt.style.use("seaborn-v0_8-paper")
        rcParams.update(
            {
                "figure.dpi": 300,
                "font.size": 10,
                "axes.linewidth": 0.8,
                "lines.linewidth": 1.5,
                "grid.alpha": 0.3,
                "axes.spines.top": False,
                "axes.spines.right": False,
            }
        )
    elif style_name == "presentation":
        plt.style.use("seaborn-v0_8-talk")
        rcParams.update(
            {
                "figure.dpi": 150,
                "font.size": 14,
                "axes.linewidth": 1.5,
                "lines.linewidth": 2.5,
                "axes.spines.top": False,
                "axes.spines.right": False,
            }
        )
    elif style_name == "notebook":
        plt.style.use("seaborn-v0_8-notebook")
        rcParams.update(
            {
                "figure.dpi": 100,
                "font.size": 11,
                "axes.spines.top": False,
                "axes.spines.right": False,
            }
        )
    else:
        warnings.warn(f"Unknown style '{style_name}', using default.", stacklevel=2)


def configure_axes(
    ax: plt.Axes,
    xlabel: str | None = None,
    ylabel: str | None = None,
    title: str | None = None,
    grid: bool = True,
    legend: bool = False,
    legend_loc: str = "best",
    xlim: tuple[float, float] | None = None,
    ylim: tuple[float, float] | None = None,
    xscale: str = "linear",
    yscale: str = "linear",
    spines: bool = True,
) -> None:
    """Configure axes with styling options.

    Args:
        ax: Matplotlib axes object.
        xlabel: X-axis label.
        ylabel: Y-axis label.
        title: Axes title.
        grid: Show grid.
        legend: Show legend.
        legend_loc: Legend location.
        xlim: X-axis limits.
        ylim: Y-axis limits.
        xscale: X-axis scale ('linear', 'log', 'symlog').
        yscale: Y-axis scale ('linear', 'log', 'symlog').
        spines: Show all spines (if False, removes top and right).
    """
    if xlabel:
        ax.set_xlabel(xlabel, fontsize=STYLE_CONFIG["axes"]["labelsize"])
    if ylabel:
        ax.set_ylabel(ylabel, fontsize=STYLE_CONFIG["axes"]["labelsize"])
    if title:
        ax.set_title(title, fontsize=STYLE_CONFIG["axes"]["titlesize"], weight="bold")

    if grid:
        ax.grid(
            True,
            alpha=STYLE_CONFIG["axes"]["grid.alpha"],
            linestyle=STYLE_CONFIG["axes"]["grid.linestyle"],
            linewidth=STYLE_CONFIG["axes"]["grid.linewidth"],
        )

    if legend:
        ax.legend(loc=legend_loc, frameon=True, framealpha=0.8, fontsize=9)

    if xlim:
        ax.set_xlim(xlim)
    if ylim:
        ax.set_ylim(ylim)

    ax.set_xscale(xscale)
    ax.set_yscale(yscale)

    if not spines:
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)


def plot_with_density(
    ax: plt.Axes,
    x: np.ndarray,
    y: np.ndarray,
    alpha: float = 0.5,
    s: float = 10,
    cmap: str = "viridis",
    method: str = "hexbin",
) -> None:
    """Plot data with density-based coloring.

    Args:
        ax: Matplotlib axes.
        x: X data array.
        y: Y data array.
        alpha: Transparency (0-1).
        s: Marker size (for scatter).
        cmap: Colormap.
        method: 'hexbin', 'hist2d', or 'scatter_alpha'.
    """
    if method == "hexbin":
        hb = ax.hexbin(x, y, gridsize=30, cmap=cmap, mincnt=1)
        plt.colorbar(hb, ax=ax, label="Density")
    elif method == "hist2d":
        h = ax.hist2d(x, y, bins=50, cmap=cmap)
        plt.colorbar(h[3], ax=ax, label="Density")
    elif method == "scatter_alpha":
        ax.scatter(x, y, alpha=alpha, s=s, c="blue", edgecolors="none")
    else:
        raise ValueError(f"Unknown method: {method}")


def add_jitter(data: np.ndarray, amount: float = 0.02) -> np.ndarray:
    """Add random noise to data.

    Args:
        data: Input array
        amount: Jitter amount (fraction of data range)

    Returns:
        Jittered data
    """
    data_range = np.ptp(data)
    jitter = np.random.normal(0, amount * data_range, size=data.shape)
    return data + jitter


def annotate_point(
    ax: plt.Axes,
    x: float,
    y: float,
    text: str,
    arrow: bool = True,
    color: str = "black",
    fontsize: int = 9,
) -> None:
    """Annotate a point with text and arrow.

    Args:
        ax: Matplotlib axes.
        x: X coordinate.
        y: Y coordinate.
        text: Annotation text.
        arrow: Show arrow from text to point.
        color: Text color.
        fontsize: Font size.
    """
    if arrow:
        ax.annotate(
            text,
            xy=(x, y),
            xytext=(20, 20),
            textcoords="offset points",
            fontsize=fontsize,
            color=color,
            bbox={
                "boxstyle": "round,pad=0.5",
                "facecolor": "white",
                "edgecolor": color,
                "alpha": 0.8,
            },
            arrowprops={"arrowstyle": "->", "connectionstyle": "arc3,rad=0.2", "color": color},
        )
    else:
        ax.text(
            x,
            y,
            text,
            fontsize=fontsize,
            color=color,
            bbox={
                "boxstyle": "round,pad=0.5",
                "facecolor": "white",
                "edgecolor": color,
                "alpha": 0.8,
            },
        )


def add_significance_bar(
    ax: plt.Axes,
    x1: float,
    x2: float,
    y: float,
    text: str = "***",
    linewidth: float = 1.5,
    color: str = "black",
) -> None:
    """Add significance bar between two x positions.

    Args:
        ax: Matplotlib axes.
        x1: Left X position for bar.
        x2: Right X position for bar.
        y: Y position for bar.
        text: Significance text (*, **, ***, ns).
        linewidth: Bar line width.
        color: Bar color.
    """
    ax.plot([x1, x1, x2, x2], [y, y * 1.02, y * 1.02, y], linewidth=linewidth, color=color)
    ax.text((x1 + x2) / 2, y * 1.03, text, ha="center", va="bottom", fontsize=10, color=color)


def create_smart_legend(
    ax: plt.Axes,
    handles: list | None = None,
    labels: list[str] | None = None,
    max_items: int = 10,
    ncol: int = 1,
    loc: str = "best",
    outside: bool = False,
) -> None:
    """Create legend with layout adjustment.

    Args:
        ax: Matplotlib axes.
        handles: Legend handles (auto-detected if None).
        labels: Legend labels (auto-detected if None).
        max_items: Maximum items before warning.
        ncol: Number of columns.
        loc: Location ('best', 'upper right', etc.).
        outside: Place legend outside plot area.
    """
    if handles is None or labels is None:
        handles, labels = ax.get_legend_handles_labels()

    n_items = len(handles)

    if n_items > max_items:
        warnings.warn(
            f"Legend has {n_items} items (>{max_items}). Consider grouping or using "
            "color bars for continuous variables.",
            stacklevel=2,
        )

    if n_items > 15:
        ncol = min(3, (n_items + 4) // 5)

    if outside:
        ax.legend(
            handles,
            labels,
            loc="center left",
            bbox_to_anchor=(1.02, 0.5),
            ncol=ncol,
            frameon=True,
            framealpha=0.9,
        )
    else:
        ax.legend(handles, labels, loc=loc, ncol=ncol, frameon=True, framealpha=0.9)


def format_ticks(
    ax: plt.Axes,
    axis: str = "both",
    rotation: float = 0,
    decimals: int | None = None,
    scientific: bool = False,
    thousands_sep: bool = False,
) -> None:
    """Format tick labels.

    Args:
        ax: Matplotlib axes.
        axis: 'x', 'y', or 'both'.
        rotation: Label rotation in degrees.
        decimals: Number of decimal places.
        scientific: Use scientific notation.
        thousands_sep: Add thousands separator.
    """

    def format_func(value, tick_number):
        if decimals is not None:
            formatted = f"{value:.{decimals}f}"
        else:
            formatted = str(value)

        if thousands_sep and abs(value) >= 1000:
            formatted = f"{value:,.0f}"

        return formatted

    formatter = FuncFormatter(format_func) if not scientific else ScalarFormatter(useMathText=True)

    if axis in ["x", "both"]:
        ax.xaxis.set_major_formatter(formatter)
        ax.tick_params(axis="x", rotation=rotation)

    if axis in ["y", "both"]:
        ax.yaxis.set_major_formatter(formatter)
        if rotation != 0:
            ax.tick_params(axis="y", rotation=rotation)

    if scientific:
        ax.ticklabel_format(style="scientific", scilimits=(0, 0), axis=axis)


def create_scientific_plot(
    plot_func: callable,
    data: dict[str, Any],
    layout: str = "single_plot",
    style: str = "publication",
    title: str | None = None,
    xlabel: str | None = None,
    ylabel: str | None = None,
    save_path: str | None = None,
    **kwargs,
) -> tuple[plt.Figure, plt.Axes]:
    """Create plot with template function.

    Args:
        plot_func: Function that takes (ax, data, **kwargs) and plots.
        data: Dictionary containing plot data.
        layout: Layout preset name.
        style: Style preset name.
        title: Plot title.
        xlabel: X-axis label.
        ylabel: Y-axis label.
        save_path: Path to save figure.
        **kwargs: Additional arguments passed to plot_func.

    Returns:
        (figure, axes) tuple.
    """
    apply_style(style)

    layout_config = LAYOUT_PRESETS.get(layout, LAYOUT_PRESETS["single_plot"])
    figsize = layout_config["figsize"]
    margins = layout_config["margins"]

    fig, ax = plt.subplots(figsize=figsize, dpi=STYLE_CONFIG["figure"]["dpi"])

    plot_func(ax, data, **kwargs)

    configure_axes(ax, xlabel=xlabel, ylabel=ylabel, title=title, spines=False)

    plt.subplots_adjust(**margins)

    if save_path:
        save_figure(fig, save_path)

    return fig, ax


def create_subplot_grid(
    nrows: int,
    ncols: int,
    layout: str = "subplot_2x2",
    style: str = "publication",
    sharex: bool = False,
    sharey: bool = False,
    **gridspec_kw,
) -> tuple[plt.Figure, np.ndarray]:
    """Create subplot grid.

    Args:
        nrows: Number of rows.
        ncols: Number of columns.
        layout: Layout preset name.
        style: Style preset name.
        sharex: Share X axes between subplots.
        sharey: Share Y axes between subplots.
        **gridspec_kw: Additional GridSpec parameters.

    Returns:
        (figure, axes_array) tuple.
    """
    apply_style(style)

    layout_config = LAYOUT_PRESETS.get(layout, LAYOUT_PRESETS["grid_complex"])
    figsize = layout_config["figsize"]
    margins = layout_config.get("margins", {})
    spacing = layout_config.get("spacing", {})

    gs_kw = {**spacing, **gridspec_kw}

    fig, axes = plt.subplots(
        nrows, ncols, figsize=figsize, sharex=sharex, sharey=sharey, gridspec_kw=gs_kw
    )

    if margins:
        plt.subplots_adjust(**margins)

    return fig, axes


def save_figure(
    fig: plt.Figure,
    path: str,
    dpi: int = 300,
    bbox_inches: str = "tight",
    pad_inches: float = 0.1,
    formats: list[str] | None = None,
) -> None:
    """Save figure.

    Args:
        fig: Matplotlib figure.
        path: Output path (extension determines format).
        dpi: Resolution.
        bbox_inches: Bounding box.
        pad_inches: Padding around figure.
        formats: Save in multiple formats (e.g., ['png', 'pdf']).
    """
    if formats is None:
        fig.savefig(
            path, dpi=dpi, bbox_inches=bbox_inches, pad_inches=pad_inches, facecolor="white"
        )
    else:
        base_path = os.path.splitext(path)[0]
        for fmt in formats:
            output_path = f"{base_path}.{fmt}"
            fig.savefig(
                output_path,
                dpi=dpi,
                bbox_inches=bbox_inches,
                pad_inches=pad_inches,
                facecolor="white",
            )
            print(f"Saved: {output_path}")


def example_single_plot():
    """Example single plot with annotations."""

    def plot_data(ax, data, color="blue"):
        ax.plot(data["x"], data["y"], "o-", color=color, label="Data", markersize=8)
        max_idx = np.argmax(data["y"])
        annotate_point(
            ax,
            data["x"][max_idx],
            data["y"][max_idx],
            f"Max: {data['y'][max_idx]:.1f}",
            color=color,
        )

    x = np.linspace(0, 10, 50)
    y = np.sin(x) * np.exp(-x / 10) + np.random.normal(0, 0.1, 50)
    data = {"x": x, "y": y}

    fig, ax = create_scientific_plot(
        plot_data,
        data,
        layout="single_plot",
        title="Plot Example",
        xlabel="Time (s)",
        ylabel="Amplitude (a.u.)",
        color="#0173B2",
    )

    plt.show()


def example_subplot_grid():
    """Example 2x2 subplot grid."""
    fig, axes = create_subplot_grid(2, 2, layout="subplot_2x2")

    x = np.linspace(0, 10, 100)
    axes[0, 0].plot(x, np.sin(x), color="#0173B2")
    configure_axes(axes[0, 0], xlabel="X", ylabel="sin(X)", title="Sine Wave")

    axes[0, 1].plot(x, np.cos(x), color="#DE8F05")
    configure_axes(axes[0, 1], xlabel="X", ylabel="cos(X)", title="Cosine Wave")

    axes[1, 0].plot(x, np.exp(-x / 5), color="#029E73")
    configure_axes(axes[1, 0], xlabel="X", ylabel="exp(-X/5)", title="Exponential Decay")

    data = np.random.randn(10, 10)
    im = axes[1, 1].imshow(data, cmap="viridis", aspect="auto")
    configure_axes(axes[1, 1], xlabel="X", ylabel="Y", title="Heatmap")
    plt.colorbar(im, ax=axes[1, 1])

    plt.show()


def example_color_palettes():
    """Example color palette display."""
    palettes = ColorPalettes()

    print("Categorical palette (8 colors, colorblind-safe):")
    cat_palette = palettes.get_categorical(8)
    palettes.show_palette(cat_palette, labels=[f"C{i}" for i in range(8)])

    print("\nSequential palette (viridis):")
    seq_palette = palettes.get_sequential("viridis", n_colors=8)
    palettes.show_palette(seq_palette)

    print("\nDivergent palette (RdBu_r):")
    div_palette = palettes.get_divergent("RdBu_r", n_colors=11)
    palettes.show_palette(div_palette)


if __name__ == "__main__":
    print("Scientific Style Guide - Examples")
    print("=" * 50)
    print("\n1. Single plot example:")
    example_single_plot()
    print("\n2. Subplot grid example:")
    example_subplot_grid()
    print("\n3. Color palettes:")
    example_color_palettes()
