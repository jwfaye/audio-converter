#!/usr/bin/env python3
"""Generate video showing 2D histogram evolution frame by frame."""

import logging
import shutil
import subprocess
import tempfile
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import soundfile as sf

logger = logging.getLogger(__name__)


def _prepare_figure():
    """Prepare matplotlib figure and axis for histogram frames.

    Returns:
        Tuple of (fig, ax, mean_min, mean_max, var_min, var_max).
    """
    mean_min, mean_max = 0, 31
    var_min, var_max = 0, 10
    fig, ax = plt.subplots(figsize=(14, 8), dpi=100)
    return fig, ax, mean_min, mean_max, var_min, var_max


def _compute_frame_histogram(
    frame_mean: np.ndarray,
    frame_var: np.ndarray,
    mean_range: tuple[int, int],
    var_range: tuple[int, int],
):
    """Compute 2D histogram from mean and variation arrays.

    Args:
        frame_mean: Mean values for current frame (n_channels,).
        frame_var: Variation values for current frame (n_channels,).
        mean_range: Tuple of (min, max) for mean values.
        var_range: Tuple of (min, max) for variation values.

    Returns:
        Tuple of (hist_2d, n_filtered) where hist_2d is the 2D histogram
        and n_filtered is the count of non-zero elements.
    """
    mean_min, mean_max = mean_range
    var_min, var_max = var_range

    mean_int = np.round(frame_mean).astype(int)
    var_int = np.round(frame_var).astype(int)

    mean_int = np.clip(mean_int, mean_min, mean_max)
    var_int = np.clip(var_int, var_min, var_max)

    mask = ~((mean_int == 0) & (var_int == 0))
    mean_int_filtered = mean_int[mask]
    var_int_filtered = var_int[mask]

    mean_unique = np.arange(mean_min, mean_max + 1)
    var_unique = np.arange(var_min, var_max + 1)

    hist_2d = np.zeros((len(var_unique), len(mean_unique)), dtype=int)

    for m, v in zip(mean_int_filtered, var_int_filtered, strict=False):
        hist_2d[v - var_min, m - mean_min] += 1

    return hist_2d, len(mean_int_filtered)


def _generate_frames(
    consecutive_mean: np.ndarray,
    abs_variation: np.ndarray,
    n_channels: int,
    n_video_frames: int,
    frames_dir: Path,
):
    """Generate histogram frames.

    Args:
        consecutive_mean: Mean values array (n_channels × n_video_frames).
        abs_variation: Variation values array (n_channels × n_video_frames).
        n_channels: Number of channels.
        n_video_frames: Number of video frames.
        frames_dir: Directory to save frame images.
    """
    fig, ax, mean_min, mean_max, var_min, var_max = _prepare_figure()

    decimation_factor = 100
    sample_rate = 16000

    try:
        for frame_idx in range(n_video_frames):
            frame_mean = consecutive_mean[:, frame_idx]
            frame_var = abs_variation[:, frame_idx]

            hist_2d, n_filtered = _compute_frame_histogram(
                frame_mean, frame_var, (mean_min, mean_max), (var_min, var_max)
            )

            ax.clear()

            ax.imshow(
                hist_2d,
                aspect="auto",
                cmap="hot",
                interpolation="nearest",
                origin="upper",
                extent=[mean_min - 0.5, mean_max + 0.5, var_max + 0.5, var_min - 0.5],
                vmin=0,
                vmax=n_channels,
            )

            time_seconds = frame_idx * decimation_factor / sample_rate

            ax.set_xlabel("Mean Value (dB)", fontsize=12)
            ax.set_ylabel("Variation Value (dB)", fontsize=12)
            title = (
                f"Mean vs Variation Density - Frame {frame_idx + 1}/{n_video_frames} "
                f"(t={time_seconds:.3f}s, {n_filtered}/{n_channels} channels, excl. (0,0))"
            )
            ax.set_title(title, fontsize=14, fontweight="bold")
            ax.grid(alpha=0.3, linestyle="--", linewidth=0.5)

            frame_path = frames_dir / f"frame_{frame_idx:06d}.png"
            plt.savefig(frame_path, dpi=100)

            if frame_idx % 10 == 0:
                logger.info("Generated frame %d/%d", frame_idx + 1, n_video_frames)
    finally:
        plt.close(fig)


def _encode_video(
    frames_dir: Path,
    fps: float,
    audio_path: str,
    output_path: str,
    temp_dir: Path,
):
    """Encode frames to video and add audio track.

    Args:
        frames_dir: Directory containing frame images.
        fps: Frames per second.
        audio_path: Path to audio file.
        output_path: Path to save final video.
        temp_dir: Temporary directory for intermediate video.
    """
    logger.info("Encoding video with ffmpeg...")

    temp_video = temp_dir / "temp_video.mp4"
    cmd_video = [
        "ffmpeg",
        "-y",
        "-framerate",
        str(fps),
        "-i",
        str(frames_dir / "frame_%06d.png"),
        "-c:v",
        "libx264",
        "-pix_fmt",
        "yuv420p",
        "-preset",
        "medium",
        str(temp_video),
    ]

    result = subprocess.run(cmd_video, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        logger.error("ffmpeg video creation failed: %s", result.stderr)
        raise RuntimeError(f"ffmpeg failed: {result.stderr}")

    logger.info("Adding audio track...")
    cmd_audio = [
        "ffmpeg",
        "-y",
        "-i",
        str(temp_video),
        "-i",
        audio_path,
        "-c:v",
        "copy",
        "-c:a",
        "aac",
        "-shortest",
        output_path,
    ]

    result = subprocess.run(cmd_audio, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        logger.error("ffmpeg audio merge failed: %s", result.stderr)
        raise RuntimeError(f"ffmpeg failed: {result.stderr}")

    logger.info("Video created successfully: %s", output_path)


def create_frame_histogram_video(
    consecutive_mean: np.ndarray,
    abs_variation: np.ndarray,
    audio_path: str,
    output_path: str,
):
    """Create video showing 2D histogram for each frame.

    Args:
        consecutive_mean: Pre-computed consecutive frame means (n_channels × n_frames-1).
        abs_variation: Pre-computed absolute variations (n_channels × n_frames-1).
        audio_path: Path to audio file to sync with video.
        output_path: Path to save output video (should end with .mp4).
    """
    n_channels = consecutive_mean.shape[0]

    n_video_frames = consecutive_mean.shape[1]

    audio_info = sf.info(audio_path)
    audio_duration = audio_info.duration
    fps = n_video_frames / audio_duration

    logger.info(
        "Creating frame-by-frame histogram video: %d frames, %.3f seconds, %.2f fps",
        n_video_frames,
        audio_duration,
        fps,
    )

    temp_dir = Path(tempfile.mkdtemp(prefix="frame_histogram_"))
    frames_dir = temp_dir / "frames"
    frames_dir.mkdir()

    try:
        _generate_frames(consecutive_mean, abs_variation, n_channels, n_video_frames, frames_dir)
        _encode_video(frames_dir, fps, audio_path, output_path, temp_dir)
    finally:
        shutil.rmtree(temp_dir)
        logger.info("Cleaned up temporary files")
