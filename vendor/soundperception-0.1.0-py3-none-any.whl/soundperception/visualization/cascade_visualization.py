"""Cascade visualization: MAP1 to MAP2 to Associative Memory."""

import logging
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import soundfile as sf
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

from attractor.core.associative_memory import AssociativeMemory
from soundperception.core import (
    AttractorState,
    DetectedSegment,
    FrameResult,
)
from soundperception.visualization.attractor_plots import FrameCategorization

logger = logging.getLogger(__name__)

MIN_HIST_SIZE = 2


@dataclass
class SegmentProfile:
    """Pre-computed profile data for a segment.

    Attributes:
        segment_id: Segment class ID.
        mean_profile: Mean amplitude profile per channel.
        var_profile: Mean variation profile per channel.
        mean_peaks: Channel indices of mean profile peaks.
        var_peaks: Channel indices of variation profile peaks.
    """

    segment_id: int
    mean_profile: np.ndarray
    var_profile: np.ndarray
    mean_peaks: list[int] | None = None
    var_peaks: list[int] | None = None


def create_cascade_video(  # noqa: PLR0913
    frame_results: list[FrameResult],
    audio_path: str,
    output_path: str,
    audio_signal: np.ndarray = None,
    sample_rate: int = 16000,
    decimation_factor: int = 100,
    save_frames_dir: str | Path = None,
    memo_ma_integrated: np.ndarray = None,
    segments: list[DetectedSegment] = None,
    memory: AssociativeMemory | None = None,
    realtime_mode: bool = False,
    frame_categorizations: list[FrameCategorization | None] | None = None,
    segment_profiles: list[SegmentProfile] | None = None,
    recognition_results: dict[int, tuple[int | None, float, bool]] | None = None,
) -> None:
    """Create video showing attractor evolution with MAP2 and Associative Memory.

    Args:
        frame_results: Frame-by-frame results with stored histograms.
        audio_path: Path to audio file.
        output_path: Output path for video file (.mp4).
        audio_signal: Audio signal (loaded from audio_path if None).
        sample_rate: Sampling rate.
        decimation_factor: Temporal decimation factor.
        save_frames_dir: Directory to save PNG frames (optional).
        memo_ma_integrated: Integrated amplitude memory (n_channels, n_frames) for MAP2.
        segments: List of detected segments.
        memory: Associative Memory instance for recognition display.
        realtime_mode: Learn segments during video generation if True,
            otherwise pre-compute recognition results.
        frame_categorizations: Pre-computed categorization results per frame.
        segment_profiles: Pre-computed mean/var profiles for segments.
        recognition_results: Pre-computed recognition results per segment ID.
            Dict mapping segment_id to (label, confidence, is_new).
    """
    n_frames = len(frame_results)

    if audio_signal is None:
        audio_signal, sr = sf.read(audio_path)
        if len(audio_signal.shape) > 1:
            audio_signal = audio_signal[:, 0]
    else:
        sr = sample_rate

    audio_duration = len(audio_signal) / sr
    fps = n_frames / audio_duration

    logger.info(
        "Creating cascade video: %d frames, %.2fs, %.1f fps",
        n_frames,
        audio_duration,
        fps,
    )

    precomputed_recognition = recognition_results or {}
    learned_segments: set[int] = set()

    if realtime_mode:
        logger.info("Real-time mode: segments will be learned during video generation")

    if save_frames_dir is not None:
        save_frames_dir = Path(save_frames_dir)
        save_frames_dir.mkdir(parents=True, exist_ok=True)
        frames_dir = save_frames_dir
        temp_dir = None
        logger.info("Frames saved in: %s", save_frames_dir)
    else:
        temp_dir = Path(tempfile.mkdtemp(prefix="cascade_video_"))
        frames_dir = temp_dir / "frames"
        frames_dir.mkdir()

    state_colors = {
        AttractorState.ATTENTE: "#CCCCCC",
        AttractorState.ACCROCHE: "#FF8800",
        AttractorState.SUIVI: "#00AA00",
    }

    show_memory = segments is not None and len(segments) > 0

    try:
        plt.style.use("dark_background")

        fig = plt.figure(figsize=(20, 16), dpi=120)
        fig.set_facecolor("black")

        for frame_idx, result in enumerate(frame_results):
            fig.clear()
            fig.set_facecolor("black")

            current_segment = None
            for seg in segments or []:
                if seg.start_frame <= frame_idx <= seg.end_frame:
                    current_segment = seg
                    break

            n_cols = 3
            gs = fig.add_gridspec(
                5,
                n_cols,
                height_ratios=[3, 2.5, 1, 2, 1.5],
                width_ratios=[1, 1, 0.8],
                hspace=0.3,
                wspace=0.25,
            )

            ax_hist = fig.add_subplot(gs[0, 0])
            ax_cat = fig.add_subplot(gs[0, 1])
            ax_state = fig.add_subplot(gs[0, 2])
            ax_assoc = fig.add_subplot(gs[1, 2])
            ax_memo_ma = fig.add_subplot(gs[3, :])
            ax_audio = fig.add_subplot(gs[4, :])
            ax_memory = fig.add_subplot(gs[2, :]) if show_memory else None

            time_seconds = frame_idx * decimation_factor / sample_rate

            fig.suptitle(
                f"Frame {frame_idx + 1}/{n_frames} | t = {time_seconds:.3f}s | "
                f"State: {result.state.name} | NbPts: {result.nb_pts}",
                fontsize=14,
                fontweight="bold",
                color="white",
            )

            ax_state.set_xlim(0, 1)
            ax_state.set_ylim(0, 3)
            ax_state.axis("off")
            ax_state.set_title("State", fontsize=11, color="white")

            states_info = [
                (AttractorState.SUIVI, 2, "TRACKING"),
                (AttractorState.ACCROCHE, 1, "LOCKING"),
                (AttractorState.ATTENTE, 0, "WAITING"),
            ]

            for state, y_pos, label in states_info:
                is_active = result.state == state
                color = state_colors[state] if is_active else "#333333"
                alpha = 1.0 if is_active else 0.3

                rect = plt.Rectangle(
                    (0.05, y_pos + 0.1),
                    0.9,
                    0.8,
                    facecolor=color if is_active else "none",
                    edgecolor=color,
                    linewidth=3 if is_active else 1,
                    alpha=alpha,
                )
                ax_state.add_patch(rect)

                ax_state.text(
                    0.5,
                    y_pos + 0.5,
                    label,
                    fontsize=11,
                    fontweight="bold" if is_active else "normal",
                    color="black" if is_active else "#666666",
                    ha="center",
                    va="center",
                )

            if result.histogram is not None:
                hist = result.histogram
                mean_bins = result.mean_bins
                var_bins = result.var_bins

                if mean_bins is not None and var_bins is not None:
                    extent = [
                        mean_bins[0] - 0.5,
                        mean_bins[-1] + 0.5,
                        var_bins[0] - 0.5,
                        var_bins[-1] + 0.5,
                    ]
                else:
                    extent = None

                im1 = ax_hist.imshow(
                    hist,
                    aspect="auto",
                    origin="lower",
                    cmap="hot",
                    vmin=0,
                    vmax=max(hist.max(), 1),
                    extent=extent,
                )
                ax_hist.set_xlim(-0.5, 50.5)
                ax_hist.set_ylim(-0.5, 50.5)
                ax_hist.set_xlabel("Mean", fontsize=10)
                ax_hist.set_ylabel("Variation", fontsize=10)
                ax_hist.set_title(f"2D Histogram (Rmax={result.rmax:.0f})", fontsize=11)
                plt.colorbar(im1, ax=ax_hist, shrink=0.8)

                if result.bounds_x and result.bounds_y:
                    bx = result.bounds_x
                    by = result.bounds_y
                    rect = plt.Rectangle(
                        (bx[0], by[0]),
                        bx[1] - bx[0],
                        by[1] - by[0],
                        facecolor="none",
                        edgecolor=state_colors[result.state],
                        linewidth=2,
                        linestyle="--" if result.state == AttractorState.ATTENTE else "-",
                    )
                    ax_hist.add_patch(rect)

                if result.med_x is not None and result.med_y is not None:
                    ax_hist.plot(
                        result.med_x,
                        result.med_y,
                        "x",
                        markersize=12,
                        markeredgewidth=2,
                        color="white",
                        zorder=10,
                    )

                frame_cat = (
                    frame_categorizations[frame_idx]
                    if frame_categorizations is not None and frame_idx < len(frame_categorizations)
                    else None
                )

                if frame_cat is not None:
                    labels = frame_cat.labels
                    num_categories = frame_cat.num_categories

                    base_cmap = plt.colormaps.get_cmap("Set2").resampled(max(num_categories + 1, 2))
                    colors = [base_cmap(i) for i in range(max(num_categories + 1, 2))]
                    colors[0] = (0.15, 0.15, 0.15, 1.0)
                    cmap = ListedColormap(colors)

                    ax_cat.imshow(
                        labels,
                        aspect="auto",
                        origin="lower",
                        cmap=cmap,
                        interpolation="nearest",
                        vmin=0,
                        vmax=max(num_categories, 1),
                        extent=extent,
                    )

                    legend_patches = [Patch(facecolor=colors[0], edgecolor="white", label="0")]
                    for cat_id in range(1, num_categories + 1):
                        legend_patches.append(
                            Patch(facecolor=colors[cat_id], edgecolor="white", label=str(cat_id))
                        )
                    ax_cat.legend(
                        handles=legend_patches,
                        loc="upper right",
                        fontsize=9,
                        framealpha=0.8,
                        facecolor="black",
                        edgecolor="white",
                    )
                else:
                    ax_cat.imshow(
                        hist,
                        aspect="auto",
                        origin="lower",
                        cmap="gray",
                        interpolation="nearest",
                        vmin=0,
                        vmax=max(hist.max(), 1),
                        extent=extent,
                    )
                    num_categories = 0

                ax_cat.set_xlim(-0.5, 50.5)
                ax_cat.set_ylim(-0.5, 50.5)
                ax_cat.set_xlabel("Mean", fontsize=10)
                ax_cat.set_ylabel("Variation", fontsize=10)
                title_cat = f"Categorization ({num_categories} cat)"
                if result.med_x is not None:
                    title_cat += f" | Med=({result.med_x:.1f}, {result.med_y:.1f})"
                ax_cat.set_title(title_cat, fontsize=11)

            else:
                ax_hist.text(0.5, 0.5, "No histogram", ha="center", va="center", color="white")
                ax_hist.set_title("2D Histogram", fontsize=11)
                ax_cat.text(0.5, 0.5, "No data", ha="center", va="center", color="white")
                ax_cat.set_title("Categorization", fontsize=11)

            ax_map2_mean = fig.add_subplot(gs[1, 0])
            ax_map2_var = fig.add_subplot(gs[1, 1])

            ax_map2_mean.set_facecolor("#1a1a1a")
            ax_map2_var.set_facecolor("#1a1a1a")

            profile = None
            if current_segment is not None and segment_profiles is not None:
                for p in segment_profiles:
                    if p.segment_id == current_segment.class_id:
                        profile = p
                        break

            if profile is not None:
                mean_profile = profile.mean_profile
                var_profile = profile.var_profile
                n_channels = len(mean_profile)
                channels = np.arange(n_channels)

                ax_map2_mean.barh(channels, mean_profile, color="#00AA00", height=0.8)
                ax_map2_var.barh(channels, var_profile, color="#FF8800", height=0.8)

                if profile.mean_peaks is not None:
                    for i, peak_idx in enumerate(profile.mean_peaks):
                        ax_map2_mean.plot(
                            mean_profile[peak_idx],
                            peak_idx,
                            "o",
                            markersize=6,
                            color="cyan",
                            markeredgecolor="white",
                        )
                        ax_map2_mean.text(
                            mean_profile[peak_idx] + 0.5,
                            peak_idx,
                            f"F{i + 1}",
                            va="center",
                            fontsize=8,
                            color="cyan",
                        )

                if profile.var_peaks is not None:
                    for i, peak_idx in enumerate(profile.var_peaks):
                        ax_map2_var.plot(
                            var_profile[peak_idx],
                            peak_idx,
                            "o",
                            markersize=6,
                            color="magenta",
                            markeredgecolor="white",
                        )
                        ax_map2_var.text(
                            var_profile[peak_idx] + 0.2,
                            peak_idx,
                            f"V{i + 1}",
                            va="center",
                            fontsize=8,
                            color="magenta",
                        )

                ax_map2_mean.set_xlim(0, max(mean_profile.max() * 1.2, 1))
                ax_map2_mean.set_ylim(-0.5, n_channels - 0.5)
                ax_map2_var.set_xlim(0, max(var_profile.max() * 1.2, 0.5))
                ax_map2_var.set_ylim(-0.5, n_channels - 0.5)

                seg_id = current_segment.class_id
                ax_map2_mean.set_title(f"Mean Profile (Seg {seg_id})", fontsize=10, color="white")
                ax_map2_var.set_title(
                    f"Variation Profile (Seg {seg_id})", fontsize=10, color="white"
                )
            else:
                ax_map2_mean.text(
                    0.5, 0.5, "(no segment)", ha="center", va="center", color="#666666", fontsize=11
                )
                ax_map2_mean.set_title("Mean Profile", fontsize=10, color="white")
                ax_map2_var.text(
                    0.5, 0.5, "(no segment)", ha="center", va="center", color="#666666", fontsize=11
                )
                ax_map2_var.set_title("Variation Profile", fontsize=10, color="white")

            ax_map2_mean.set_xlabel("Mean Amplitude", fontsize=9)
            ax_map2_mean.set_ylabel("Channel", fontsize=9)
            ax_map2_var.set_xlabel("Mean Variation", fontsize=9)
            ax_map2_var.set_ylabel("Channel", fontsize=9)

            ax_assoc.set_facecolor("#1a1a1a")
            ax_assoc.axis("off")
            ax_assoc.set_title("Associative Memory (OT)", fontsize=11, color="white")

            y_text = 0.9
            recognition_info = None

            if current_segment is not None and current_segment.signature_histogram is not None:
                seg_id = current_segment.class_id

                if realtime_mode and memory is not None:
                    if seg_id not in learned_segments:
                        label = memory.learning_mode(
                            current_segment.signature_histogram,
                            metadata={"segment_id": seg_id},
                        )
                        learned_segments.add(seg_id)
                        is_new = (label == len(memory) - 1) and (memory.entries[-1].n_samples == 1)
                        precomputed_recognition[seg_id] = (label, 1.0, is_new)

                    recognition_info = precomputed_recognition.get(seg_id)
                elif seg_id in precomputed_recognition:
                    recognition_info = precomputed_recognition[seg_id]

            if recognition_info is not None:
                label, confidence, is_new = recognition_info

                ax_assoc.text(
                    0.05,
                    y_text,
                    f"Segment {current_segment.class_id}",
                    transform=ax_assoc.transAxes,
                    fontsize=12,
                    color="white",
                    fontweight="bold",
                )
                y_text -= 0.12
                ax_assoc.text(
                    0.05,
                    y_text,
                    f"Median: ({current_segment.med_x:.1f}, {current_segment.med_y:.1f})",
                    transform=ax_assoc.transAxes,
                    fontsize=10,
                    color="#AAAAAA",
                )
                y_text -= 0.15

                if is_new:
                    ax_assoc.text(
                        0.05,
                        y_text,
                        "NEW PHONEME",
                        transform=ax_assoc.transAxes,
                        fontsize=14,
                        color="#FF8800",
                        fontweight="bold",
                    )
                    y_text -= 0.1
                    ax_assoc.text(
                        0.05,
                        y_text,
                        f"→ Assigned Label {label}",
                        transform=ax_assoc.transAxes,
                        fontsize=11,
                        color="#FF8800",
                    )
                else:
                    ax_assoc.text(
                        0.05,
                        y_text,
                        "RECOGNIZED",
                        transform=ax_assoc.transAxes,
                        fontsize=14,
                        color="#00AA00",
                        fontweight="bold",
                    )
                    y_text -= 0.1
                    ax_assoc.text(
                        0.05,
                        y_text,
                        f"→ Label {label}",
                        transform=ax_assoc.transAxes,
                        fontsize=11,
                        color="#00AA00",
                    )
            else:
                ax_assoc.text(
                    0.5,
                    0.5,
                    "(waiting for segment)",
                    transform=ax_assoc.transAxes,
                    ha="center",
                    fontsize=12,
                    color="#666666",
                )

            y_text = 0.35
            ax_assoc.text(
                0.05,
                y_text,
                "Memory:",
                transform=ax_assoc.transAxes,
                fontsize=10,
                color="#888888",
            )
            y_text -= 0.1
            max_display = 4
            if memory is not None and len(memory) > 0:
                for entry in memory.entries[:max_display]:
                    ax_assoc.text(
                        0.08,
                        y_text,
                        f"L{entry.label}: {entry.n_samples} sample(s)",
                        transform=ax_assoc.transAxes,
                        fontsize=9,
                        color="#666666",
                    )
                    y_text -= 0.08
                if len(memory) > max_display:
                    ax_assoc.text(
                        0.08,
                        y_text,
                        f"... (+{len(memory) - max_display} more)",
                        transform=ax_assoc.transAxes,
                        fontsize=9,
                        color="#555555",
                    )
            else:
                ax_assoc.text(
                    0.08,
                    y_text,
                    "(empty)",
                    transform=ax_assoc.transAxes,
                    fontsize=9,
                    color="#555555",
                )

            if ax_memory is not None and show_memory:
                ax_memory.set_facecolor("black")
                ax_memory.axis("off")
                ax_memory.set_title("Word Sequence", fontsize=11, color="white")

                n_slots = min(len(segments), 8)
                sequence_parts = []

                for slot_idx in range(n_slots):
                    seg = segments[slot_idx]
                    is_detected = seg.end_frame <= frame_idx
                    is_active = seg.start_frame <= frame_idx <= seg.end_frame

                    if seg.class_id in precomputed_recognition:
                        label, confidence, is_new = precomputed_recognition[seg.class_id]
                        label_str = f"L{label}"
                    else:
                        label_str = "?"

                    if is_active:
                        sequence_parts.append(f"[S{seg.class_id}:{label_str}]")
                    elif is_detected:
                        sequence_parts.append(f"S{seg.class_id}:{label_str}")
                    else:
                        sequence_parts.append(f"S{seg.class_id}:--")

                x_start = 0.05
                x_step = 0.12
                for i, part in enumerate(sequence_parts):
                    is_active = segments[i].start_frame <= frame_idx <= segments[i].end_frame
                    is_detected = segments[i].end_frame <= frame_idx

                    if is_active:
                        color = "#00FF00"
                        fontweight = "bold"
                        fontsize = 12
                    elif is_detected:
                        color = "#AAAAAA"
                        fontweight = "normal"
                        fontsize = 11
                    else:
                        color = "#444444"
                        fontweight = "normal"
                        fontsize = 10

                    ax_memory.text(
                        x_start + i * x_step,
                        0.5,
                        part,
                        transform=ax_memory.transAxes,
                        fontsize=fontsize,
                        color=color,
                        fontweight=fontweight,
                        ha="center",
                        va="center",
                    )

                    if i < len(sequence_parts) - 1:
                        arrow_color = "#666666" if segments[i].end_frame <= frame_idx else "#333333"
                        ax_memory.text(
                            x_start + i * x_step + x_step / 2,
                            0.5,
                            "→",
                            transform=ax_memory.transAxes,
                            fontsize=10,
                            color=arrow_color,
                            ha="center",
                            va="center",
                        )

            if memo_ma_integrated is not None:
                n_channels, n_total_frames = memo_ma_integrated.shape

                ax_memo_ma.imshow(
                    memo_ma_integrated,
                    aspect="auto",
                    origin="lower",
                    cmap="hot",
                    extent=[0, n_total_frames, 0, n_channels],
                )

                ax_memo_ma.axvline(frame_idx, color="red", linewidth=2)

                segment_colors = ["#00FF00", "#00FFFF", "#FF00FF", "#FFFF00", "#FF8800", "#00FF88"]
                for i, seg in enumerate(segments or []):
                    is_active = seg.start_frame <= frame_idx <= seg.end_frame
                    is_detected = seg.end_frame <= frame_idx

                    if is_detected or is_active:
                        color = segment_colors[i % len(segment_colors)]
                        alpha = 0.4 if is_active else 0.2

                        rect = plt.Rectangle(
                            (seg.start_frame, 0),
                            seg.end_frame - seg.start_frame,
                            n_channels,
                            facecolor=color,
                            edgecolor=color,
                            alpha=alpha,
                            linewidth=2 if is_active else 1,
                        )
                        ax_memo_ma.add_patch(rect)

                        label_x = (seg.start_frame + seg.end_frame) / 2
                        ax_memo_ma.text(
                            label_x,
                            n_channels + 2,
                            f"S{seg.class_id}",
                            ha="center",
                            fontsize=9,
                            color=color,
                            fontweight="bold" if is_active else "normal",
                        )

                ax_memo_ma.set_xlim(0, n_total_frames)
                ax_memo_ma.set_ylim(0, n_channels)
                ax_memo_ma.set_xlabel("Frame", fontsize=10)
                ax_memo_ma.set_ylabel("Channel", fontsize=10)
                ax_memo_ma.set_title("memo_ma with Segment Overlays", fontsize=11, color="white")
            else:
                ax_memo_ma.text(0.5, 0.5, "(no memo_ma)", ha="center", va="center", color="#666666")
                ax_memo_ma.set_title("memo_ma", fontsize=11, color="white")

            time_axis = np.arange(len(audio_signal)) / sr
            ax_audio.plot(time_axis, audio_signal, color="#2196F3", linewidth=0.5)
            ax_audio.axvline(time_seconds, color="red", linewidth=2, label="Position")
            ax_audio.fill_between(
                [0, time_seconds],
                -1,
                1,
                alpha=0.1,
                color=state_colors[result.state],
            )

            segment_colors = ["#00FF00", "#00FFFF", "#FF00FF", "#FFFF00", "#FF8800", "#00FF88"]
            for i, seg in enumerate(segments or []):
                is_active = seg.start_frame <= frame_idx <= seg.end_frame
                is_detected = seg.end_frame <= frame_idx

                if is_detected or is_active:
                    start_t = seg.start_frame * decimation_factor / sample_rate
                    end_t = seg.end_frame * decimation_factor / sample_rate
                    color = segment_colors[i % len(segment_colors)]
                    alpha = 0.3 if is_active else 0.1
                    ax_audio.axvspan(start_t, end_t, alpha=alpha, color=color)

            ax_audio.set_xlim(0, audio_duration)
            y_max = 1.1 * np.abs(audio_signal).max() if np.abs(audio_signal).max() > 0 else 1
            ax_audio.set_ylim(-y_max, y_max)
            ax_audio.set_xlabel("Time (s)", fontsize=10)
            ax_audio.set_ylabel("Amplitude", fontsize=10)
            ax_audio.set_title("Audio Signal", fontsize=11)
            ax_audio.grid(True, alpha=0.3)

            plt.tight_layout()

            frame_path = frames_dir / f"frame_{frame_idx:06d}.png"
            fig.savefig(frame_path, dpi=120, facecolor="black")

            if frame_idx % 10 == 0:
                logger.info("Frame %d/%d generated", frame_idx + 1, n_frames)

        plt.close(fig)

        logger.info("Encoding video with ffmpeg...")

        if temp_dir is not None:
            temp_video = temp_dir / "temp_video.mp4"
        else:
            temp_video = frames_dir / "temp_video.mp4"

        cmd_video = [
            "ffmpeg",
            "-y",
            "-framerate",
            str(fps),
            "-i",
            str(frames_dir / "frame_%06d.png"),
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-preset",
            "medium",
            str(temp_video),
        ]

        result_ffmpeg = subprocess.run(cmd_video, capture_output=True, text=True, check=False)
        if result_ffmpeg.returncode != 0:
            logger.error("ffmpeg error: %s", result_ffmpeg.stderr)
            raise RuntimeError(f"ffmpeg failed: {result_ffmpeg.stderr}")

        logger.info("Adding audio track...")
        cmd_audio = [
            "ffmpeg",
            "-y",
            "-i",
            str(temp_video),
            "-i",
            audio_path,
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-shortest",
            output_path,
        ]

        result_ffmpeg = subprocess.run(cmd_audio, capture_output=True, text=True, check=False)
        if result_ffmpeg.returncode != 0:
            logger.error("ffmpeg audio error: %s", result_ffmpeg.stderr)
            raise RuntimeError(f"ffmpeg failed: {result_ffmpeg.stderr}")

        logger.info("Video created: %s", output_path)

    finally:
        plt.style.use("default")

        if temp_dir is not None:
            shutil.rmtree(temp_dir, ignore_errors=True)
