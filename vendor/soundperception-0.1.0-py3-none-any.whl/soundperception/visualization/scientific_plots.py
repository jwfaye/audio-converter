"""Scientific plotting functions for diagnostic experiments."""

import logging
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.metrics import confusion_matrix

from soundperception.visualization.scientific_style import ColorPalettes
from soundperception.visualization.scientific_style import apply_style as _apply_style

logger = logging.getLogger(__name__)


@dataclass
class RegressionResult:
    """Pre-computed linear regression result.

    Attributes:
        slope: Regression slope.
        intercept: Regression intercept.
        r_value: Correlation coefficient.
        p_value: Two-sided p-value.
        std_err: Standard error of the estimate.
    """

    slope: float
    intercept: float
    r_value: float
    p_value: float
    std_err: float


@dataclass
class TSNEResult:
    """Pre-computed t-SNE result.

    Attributes:
        coordinates_2d: Array of shape (n_samples, 2) with 2D coordinates.
        silhouette: Silhouette score for the clustering.
    """

    coordinates_2d: np.ndarray
    silhouette: float


class ScientificPlotStyle:
    """Configuration for plot styling."""

    COLORS = {
        "success": "#2ecc71",
        "warning": "#f39c12",
        "error": "#e74c3c",
        "neutral": "#3498db",
        "accent": "#9b59b6",
    }

    FONT_SIZES = {
        "title": 14,
        "label": 12,
        "tick": 10,
        "annotation": 9,
    }

    FIG_SIZES = {
        "single": (12, 6),
        "double": (16, 6),
        "quad": (16, 12),
        "grid_6": (20, 12),
    }


def apply_style(style="publication"):
    """Apply plotting style.

    Args:
        style: Style name ('publication', 'presentation', 'notebook').
    """
    _apply_style(style)


def create_figure(layout="single", **kwargs):
    """Create figure with layout.

    Args:
        layout: Layout name ('single', 'double', 'quad', 'grid_6').
        **kwargs: Additional arguments passed to plt.subplots().

    Returns:
        Tuple (fig, axes).
    """
    figsize = ScientificPlotStyle.FIG_SIZES.get(layout, (12, 6))
    if "figsize" not in kwargs:
        kwargs["figsize"] = figsize

    if layout == "single":
        return plt.subplots(1, 1, **kwargs)
    elif layout == "double":
        return plt.subplots(1, 2, **kwargs)
    elif layout == "quad":
        return plt.subplots(2, 2, **kwargs)
    elif layout == "grid_6":
        return plt.subplots(2, 3, **kwargs)
    else:
        return plt.subplots(**kwargs)


def save_figure(fig, output_path, dpi=300, formats=None):
    """Save figure in multiple formats.

    Args:
        fig: Matplotlib figure.
        output_path: Output path (without extension).
        dpi: Resolution (default: 300).
        formats: List of formats (default: ['png']).
    """
    if formats is None:
        formats = ["png"]

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    for fmt in formats:
        path = output_path.with_suffix(f".{fmt}")
        fig.savefig(path, dpi=dpi, bbox_inches="tight", facecolor="white")
        logger.info(f"Saved figure: {path}")


def plot_confusion_heatmap(
    df: pd.DataFrame, output_path: Path | None = None, top_n: int = 20
) -> tuple:
    """Plot confusion heatmap: phonemes vs nb_segments detected.

    Args:
        df: DataFrame with columns [ipa, n_segments, n_phonemes].
        output_path: Optional output path for saving.
        top_n: Number of top phonemes to display.

    Returns:
        Tuple (fig, ax).
    """
    phoneme_list = []
    for _, row in df.iterrows():
        ipa = row["ipa"]
        n_segs = row["n_segments"]
        phonemes = list(ipa) if isinstance(ipa, str) else []

        for phoneme in phonemes:
            seg_category = (
                "0" if n_segs == 0 else "1" if n_segs == 1 else "2" if n_segs == 2 else "3+"
            )
            phoneme_list.append({"phoneme": phoneme, "n_segments_cat": seg_category})

    if not phoneme_list:
        logger.warning("No phoneme data available for confusion heatmap")
        return None, None

    phoneme_df = pd.DataFrame(phoneme_list)
    confusion = pd.crosstab(phoneme_df["phoneme"], phoneme_df["n_segments_cat"])

    phoneme_counts = phoneme_df["phoneme"].value_counts()
    top_phonemes = phoneme_counts.head(top_n).index
    confusion = confusion.loc[top_phonemes]

    confusion_pct = confusion.div(confusion.sum(axis=1), axis=0) * 100

    fig, ax = plt.subplots(figsize=(12, max(8, len(top_phonemes) * 0.3)))

    sns.heatmap(
        confusion_pct,
        annot=True,
        fmt=".1f",
        cmap="RdYlGn_r",
        center=None,
        vmin=0,
        vmax=100,
        cbar_kws={"label": "Percentage (%)"},
        ax=ax,
    )

    ax.set_xlabel("Number of Segments D�tect�s", fontsize=12)
    ax.set_ylabel("Phon�me IPA", fontsize=12)
    ax.set_title(f"Matrice de Confusion Phon�mique (top {top_n})", fontsize=14, pad=15)

    plt.tight_layout()

    if output_path:
        save_figure(fig, output_path)

    return fig, ax


def plot_category_comparison(df_categories: pd.DataFrame, output_path: Path | None = None) -> tuple:
    """Plot grouped bar chart comparing phoneme categories.

    Args:
        df_categories: DataFrame with columns [category, detection_rate,
                       over_segmentation, under_segmentation].
        output_path: Optional output path for saving.

    Returns:
        Tuple (fig, ax).
    """
    fig, ax = plt.subplots(figsize=(14, 6))

    categories = df_categories["category"].values
    x = np.arange(len(categories))
    width = 0.25

    ax.bar(
        x - width,
        df_categories["detection_rate"] * 100,
        width,
        label="Detection Rate",
        color=ScientificPlotStyle.COLORS["success"],
        alpha=0.8,
    )

    ax.bar(
        x,
        df_categories["over_segmentation"] * 100,
        width,
        label="Over-segmentation",
        color=ScientificPlotStyle.COLORS["error"],
        alpha=0.8,
    )

    ax.bar(
        x + width,
        df_categories["under_segmentation"] * 100,
        width,
        label="Under-segmentation",
        color=ScientificPlotStyle.COLORS["warning"],
        alpha=0.8,
    )

    ax.set_xlabel("Phonetic Category", fontsize=12)
    ax.set_ylabel("Percentage (%)", fontsize=12)
    ax.set_title("Performance de Segmentation par Cat�gorie", fontsize=14, pad=15)
    ax.set_xticks(x)
    ax.set_xticklabels(categories, rotation=45, ha="right")
    ax.legend(loc="upper right")
    ax.grid(axis="y", alpha=0.3)
    ax.axhline(y=100, color="green", linestyle="--", linewidth=1, alpha=0.5)

    plt.tight_layout()

    if output_path:
        save_figure(fig, output_path)

    return fig, ax


def plot_correlation_scatter(
    df: pd.DataFrame,
    output_path: Path | None = None,
    annotate_outliers: int = 5,
    regression: RegressionResult | None = None,
) -> tuple:
    """Plot scatter: n_segments vs n_phonemes with regression.

    Args:
        df: DataFrame with columns [n_phonemes, n_segments, word, is_outlier].
        output_path: Optional output path for saving.
        annotate_outliers: Number of outliers to annotate.
        regression: Pre-computed regression result. If None, regression line is not shown.

    Returns:
        Tuple (fig, ax).
    """
    fig, ax = plt.subplots(figsize=(10, 8))

    if "is_outlier" in df.columns:
        outliers = df[df["is_outlier"]]
        inliers = df[~df["is_outlier"]]
    else:
        inliers = df
        outliers = pd.DataFrame()

    ax.scatter(
        inliers["n_phonemes"],
        inliers["n_segments"],
        alpha=0.6,
        s=80,
        color=ScientificPlotStyle.COLORS["neutral"],
        label="Words",
    )

    if len(outliers) > 0:
        ax.scatter(
            outliers["n_phonemes"],
            outliers["n_segments"],
            marker="x",
            s=200,
            color=ScientificPlotStyle.COLORS["error"],
            linewidths=3,
            label="Outliers",
        )

        outliers_sorted = outliers.copy()
        outliers_sorted["error"] = abs(
            outliers_sorted["n_segments"] - outliers_sorted["n_phonemes"]
        )
        outliers_sorted = outliers_sorted.nlargest(annotate_outliers, "error")

        for _, row in outliers_sorted.iterrows():
            if "word" in row:
                ax.annotate(
                    row["word"],
                    (row["n_phonemes"], row["n_segments"]),
                    fontsize=9,
                    alpha=0.8,
                    xytext=(5, 5),
                    textcoords="offset points",
                )

    max_val = max(df["n_phonemes"].max(), df["n_segments"].max())
    ax.plot([0, max_val], [0, max_val], "g--", linewidth=2, label="Perfect Segmentation (y=x)")

    if regression is not None:
        x_reg = np.array([df["n_phonemes"].min(), df["n_phonemes"].max()])
        y_reg = regression.slope * x_reg + regression.intercept
        ax.plot(
            x_reg,
            y_reg,
            "b-",
            linewidth=2,
            alpha=0.7,
            label=f"Régression (r={regression.r_value:.3f}, p<0.001)",
        )

    ax.set_xlabel("Number of Phon�mes", fontsize=12)
    ax.set_ylabel("Number of Segments D�tect�s", fontsize=12)
    ax.set_title(f"Corr�lation Segments vs Phon�mes (n={len(df)} mots)", fontsize=14, pad=15)
    ax.legend(loc="upper left")
    ax.grid(alpha=0.3)

    plt.tight_layout()

    if output_path:
        save_figure(fig, output_path)

    return fig, ax


def plot_segmentation_overview_4panel(
    df: pd.DataFrame,
    df_categories: pd.DataFrame,
    output_path: Path | None = None,
) -> tuple:
    """Plot 4-panel overview: scatter + bar + heatmap + violin.

    Args:
        df: Segmentation results DataFrame.
        df_categories: Category statistics DataFrame.
        output_path: Optional output path for saving.

    Returns:
        Tuple (fig, axes).
    """
    fig, axes = plt.subplots(2, 2, figsize=(18, 14))

    ax1 = axes[0, 0]
    if "is_outlier" in df.columns:
        inliers = df[~df["is_outlier"]]
        outliers = df[df["is_outlier"]]
    else:
        inliers = df
        outliers = pd.DataFrame()

    ax1.scatter(inliers["n_phonemes"], inliers["n_segments"], alpha=0.6, s=80)
    if len(outliers) > 0:
        ax1.scatter(outliers["n_phonemes"], outliers["n_segments"], marker="x", s=200, color="red")

    max_val = max(df["n_phonemes"].max(), df["n_segments"].max())
    ax1.plot([0, max_val], [0, max_val], "g--", linewidth=2, label="y=x")
    ax1.set_xlabel("Number of Phon�mes")
    ax1.set_ylabel("Number of Segments")
    ax1.set_title("Corr�lation Segmentation")
    ax1.legend()
    ax1.grid(alpha=0.3)

    ax2 = axes[0, 1]
    categories = df_categories["category"].values
    x = np.arange(len(categories))
    width = 0.25

    ax2.bar(
        x - width,
        df_categories["detection_rate"] * 100,
        width,
        label="Detection",
        color="green",
        alpha=0.7,
    )
    ax2.bar(
        x, df_categories["over_segmentation"] * 100, width, label="Over-seg", color="red", alpha=0.7
    )
    ax2.bar(
        x + width,
        df_categories["under_segmentation"] * 100,
        width,
        label="Under-seg",
        color="orange",
        alpha=0.7,
    )

    ax2.set_xticks(x)
    ax2.set_xticklabels(categories, rotation=45, ha="right")
    ax2.set_ylabel("Percentage (%)")
    ax2.set_title("Performance par Cat�gorie")
    ax2.legend()
    ax2.grid(axis="y", alpha=0.3)

    ax3 = axes[1, 0]
    if "category" in df.columns:
        df_plot = df.copy()
        df_plot["error"] = df_plot["n_segments"] - df_plot["n_phonemes"]
        sns.violinplot(data=df_plot, x="category", y="error", ax=ax3, alpha=0.7)
        ax3.axhline(y=0, color="green", linestyle="--")
        ax3.set_xlabel("Category")
        ax3.set_ylabel("Error (segments - phonemes)")
        ax3.set_title("Error Distribution")
        ax3.tick_params(axis="x", rotation=45)
    else:
        ax3.text(0.5, 0.5, "Category not available", ha="center", va="center")
        ax3.set_title("Error Distribution")

    ax4 = axes[1, 1]
    ratio = df["n_segments"] / df["n_phonemes"].replace(0, 1)
    ax4.hist(
        ratio, bins=30, alpha=0.7, edgecolor="black", color=ScientificPlotStyle.COLORS["neutral"]
    )
    ax4.axvline(
        x=ratio.mean(),
        color="red",
        linestyle="--",
        linewidth=2,
        label=f"Mean: {ratio.mean():.2f}",
    )
    ax4.axvline(
        x=ratio.median(),
        color="orange",
        linestyle="--",
        linewidth=2,
        label=f"Median: {ratio.median():.2f}",
    )
    ax4.axvline(x=1.0, color="green", linestyle="--", linewidth=2, label="Ideal: 1.0")
    ax4.set_xlabel("Ratio (segments / phonemes)")
    ax4.set_ylabel("Frequency")
    ax4.set_title("Segmentation Ratio Distribution")
    ax4.legend()
    ax4.grid(axis="y", alpha=0.3)

    plt.tight_layout()

    if output_path:
        save_figure(fig, output_path)

    return fig, axes


def plot_sensitivity_curves(
    df: pd.DataFrame,
    output_path: Path | None = None,
) -> tuple:
    """Plot sensitivity curves: n_segments = f(parameter) in 2�3 grid.

    Args:
        df: DataFrame with columns [parameter_name, parameter_value, n_segments, n_phonemes]
        output_path: Optional output path for saving

    Returns:
        Tuple (fig, axes)
    """
    parameters = df["parameter_name"].unique()
    n_params = len(parameters)

    n_rows = (n_params + 2) // 3
    n_cols = min(3, n_params)

    fig, axes = plt.subplots(n_rows, n_cols, figsize=(20, 6 * n_rows))
    if n_params == 1:
        axes = np.array([axes])
    axes = axes.flatten() if n_params > 1 else [axes]

    for i, param in enumerate(parameters):
        if i >= len(axes):
            break

        ax = axes[i]
        param_data = df[df["parameter_name"] == param]

        grouped = (
            param_data.groupby("parameter_value")
            .agg({"n_segments": ["mean", "std"], "n_phonemes": "mean"})
            .reset_index()
        )

        ax.plot(
            grouped["parameter_value"],
            grouped[("n_segments", "mean")],
            "o-",
            linewidth=2,
            markersize=8,
            label="Detected segments",
        )

        ax.fill_between(
            grouped["parameter_value"],
            grouped[("n_segments", "mean")] - grouped[("n_segments", "std")],
            grouped[("n_segments", "mean")] + grouped[("n_segments", "std")],
            alpha=0.2,
        )

        mean_phonemes = grouped[("n_phonemes", "mean")].mean()
        ax.axhline(
            y=mean_phonemes,
            color="green",
            linestyle="--",
            linewidth=2,
            label=f"Expected phonemes ({mean_phonemes:.1f})",
        )

        ax.set_xlabel(param, fontsize=12)
        ax.set_ylabel("Number of Segments", fontsize=12)
        ax.set_title(f"Sensibilit�: {param}", fontsize=14)
        ax.legend()
        ax.grid(alpha=0.3)

    for j in range(i + 1, len(axes)):
        axes[j].set_visible(False)

    plt.tight_layout()

    if output_path:
        save_figure(fig, output_path)

    return fig, axes


def plot_sensitivity_ranking(
    df_summary: pd.DataFrame,
    output_path: Path | None = None,
) -> tuple:
    """Plot lollipop chart: sensitivity_score by parameter.

    Args:
        df_summary: DataFrame with columns [parameter, sensitivity_score, mean_segments,
            std_segments].
        output_path: Optional output path for saving.

    Returns:
        Tuple (fig, axes)
    """
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))

    df_sorted = df_summary.sort_values("sensitivity_score", ascending=True)

    ax1 = axes[0]
    colors = [
        ScientificPlotStyle.COLORS["error"]
        if x > 0.5
        else ScientificPlotStyle.COLORS["warning"]
        if x > 0.2
        else ScientificPlotStyle.COLORS["success"]
        for x in df_sorted["sensitivity_score"]
    ]

    ax1.hlines(
        y=range(len(df_sorted)),
        xmin=0,
        xmax=df_sorted["sensitivity_score"],
        color=colors,
        alpha=0.5,
        linewidth=3,
    )

    ax1.plot(
        df_sorted["sensitivity_score"], range(len(df_sorted)), "o", color=colors, markersize=10
    )

    ax1.set_yticks(range(len(df_sorted)))
    ax1.set_yticklabels(df_sorted["parameter"])
    ax1.set_xlabel("Sensitivity Score", fontsize=12)
    ax1.set_title("Parameter Sensitivity", fontsize=14)
    ax1.axvline(x=0.2, color="orange", linestyle="--", label="Moderate threshold")
    ax1.axvline(x=0.5, color="red", linestyle="--", label="Critical threshold")
    ax1.legend()
    ax1.grid(axis="x", alpha=0.3)

    ax2 = axes[1]
    ax2.axis("off")
    table_data = (
        df_sorted[["parameter", "mean_segments", "std_segments", "sensitivity_score"]]
        .round(2)
        .values
    )

    table = ax2.table(
        cellText=table_data,
        colLabels=["Parameter", "Mean seg", "Std seg", "Sensitivity"],
        loc="center",
        cellLoc="center",
    )

    table.auto_set_font_size(False)
    table.set_fontsize(9)
    table.scale(1, 2.5)
    ax2.set_title("Sensitivity Details", pad=20, fontsize=12, fontweight="bold")

    for i in range(1, len(df_sorted) + 1):
        score = df_sorted.iloc[i - 1]["sensitivity_score"]
        color = "lightcoral" if score > 0.5 else "lightyellow" if score > 0.2 else "lightgreen"
        for j in range(4):
            table[(i, j)].set_facecolor(color)

    plt.tight_layout()

    if output_path:
        save_figure(fig, output_path)

    return fig, axes


def plot_fragmentation_lollipop(
    df: pd.DataFrame,
    output_path: Path | None = None,
) -> tuple:
    """Plot lollipop chart: phoneme fragmentation scores.

    Args:
        df: DataFrame with columns [phoneme, n_labels, fragmentation_score]
        output_path: Optional output path for saving

    Returns:
        Tuple (fig, axes)
    """
    fig, axes = plt.subplots(1, 2, figsize=(16, max(8, len(df) * 0.3)))

    df_sorted = df.sort_values("fragmentation_score", ascending=True)

    ax1 = axes[0]
    colors = [
        ScientificPlotStyle.COLORS["error"]
        if x > 2.0
        else ScientificPlotStyle.COLORS["warning"]
        if x > 1.5
        else ScientificPlotStyle.COLORS["success"]
        for x in df_sorted["fragmentation_score"]
    ]

    ax1.hlines(
        y=range(len(df_sorted)),
        xmin=0,
        xmax=df_sorted["fragmentation_score"],
        color=colors,
        alpha=0.5,
        linewidth=2,
    )

    ax1.plot(
        df_sorted["fragmentation_score"], range(len(df_sorted)), "o", color=colors, markersize=8
    )

    ax1.set_yticks(range(len(df_sorted)))
    ax1.set_yticklabels(df_sorted["phoneme"])
    ax1.set_xlabel("Fragmentation Score", fontsize=12)
    ax1.set_title("Phoneme Fragmentation", fontsize=14)
    ax1.axvline(x=1.0, color="green", linestyle="--", label="No fragmentation")
    ax1.axvline(x=1.5, color="orange", linestyle="--", label="Moderate")
    ax1.axvline(x=2.0, color="red", linestyle="--", label="Severe")
    ax1.legend()
    ax1.grid(axis="x", alpha=0.3)

    ax2 = axes[1]
    ax2.hist(df["fragmentation_score"], bins=20, color="steelblue", alpha=0.7, edgecolor="black")
    ax2.axvline(
        x=df["fragmentation_score"].mean(),
        color="red",
        linestyle="--",
        linewidth=2,
        label=f"Mean: {df['fragmentation_score'].mean():.2f}",
    )
    ax2.axvline(
        x=df["fragmentation_score"].median(),
        color="orange",
        linestyle="--",
        linewidth=2,
        label=f"Median: {df['fragmentation_score'].median():.2f}",
    )
    ax2.set_xlabel("Score de Fragmentation", fontsize=12)
    ax2.set_ylabel("Number of Phon�mes", fontsize=12)
    ax2.set_title("Distribution de la Fragmentation", fontsize=14)
    ax2.legend()
    ax2.grid(axis="y", alpha=0.3)

    plt.tight_layout()

    if output_path:
        save_figure(fig, output_path)

    return fig, axes


def plot_recognition_confusion(
    df: pd.DataFrame,
    output_path: Path | None = None,
) -> tuple:
    """Plot 4-panel recognition analysis: confusion matrix + accuracy + distance + confidence.

    Args:
        df: DataFrame with columns [true_label, predicted_label, is_correct, distance, confidence]
        output_path: Optional output path for saving

    Returns:
        Tuple (fig, axes)
    """
    fig, axes = plt.subplots(2, 2, figsize=(18, 16))

    ax1 = axes[0, 0]
    labels = sorted(df["true_label"].unique())
    cm = confusion_matrix(df["true_label"], df["predicted_label"], labels=labels)

    im = ax1.imshow(cm, cmap="Blues", aspect="auto")
    ax1.set_xticks(range(len(labels)))
    ax1.set_yticks(range(len(labels)))
    ax1.set_xticklabels(labels, rotation=45, ha="right")
    ax1.set_yticklabels(labels)
    ax1.set_xlabel("Predicted Label")
    ax1.set_ylabel("True Label")
    ax1.set_title("Confusion Matrix")
    plt.colorbar(im, ax=ax1)

    for i in range(len(labels)):
        for j in range(len(labels)):
            text_color = "white" if cm[i, j] > cm.max() / 2 else "black"
            ax1.text(j, i, cm[i, j], ha="center", va="center", color=text_color)

    ax2 = axes[0, 1]
    accuracy_per_label = df.groupby("true_label")["is_correct"].mean().sort_values()
    colors_acc = [
        ScientificPlotStyle.COLORS["error"]
        if x < 0.5
        else ScientificPlotStyle.COLORS["warning"]
        if x < 0.8
        else ScientificPlotStyle.COLORS["success"]
        for x in accuracy_per_label.values
    ]

    ax2.barh(accuracy_per_label.index, accuracy_per_label.values, color=colors_acc, alpha=0.7)
    ax2.set_xlabel("Accuracy")
    ax2.set_title("Accuracy per Label")
    ax2.axvline(x=0.8, color="orange", linestyle="--", label="Acceptable")
    ax2.axvline(x=0.9, color="green", linestyle="--", label="Excellent")
    ax2.legend()
    ax2.grid(axis="x", alpha=0.3)

    ax3 = axes[1, 0]
    correct = df[df["is_correct"]]
    incorrect = df[~df["is_correct"]]

    if len(correct) > 0:
        ax3.hist(correct["distance"], bins=30, alpha=0.5, label="Correct", color="green")
    if len(incorrect) > 0:
        ax3.hist(incorrect["distance"], bins=30, alpha=0.5, label="Incorrect", color="red")

    ax3.set_xlabel("Distance OT")
    ax3.set_ylabel("Frequency")
    ax3.set_title("Distance Distribution")
    ax3.legend()
    ax3.grid(axis="y", alpha=0.3)

    ax4 = axes[1, 1]
    df_binned = df.copy()
    df_binned["confidence_bin"] = pd.cut(df_binned["confidence"], bins=10)
    conf_accuracy = df_binned.groupby("confidence_bin")["is_correct"].mean()
    conf_counts = df_binned.groupby("confidence_bin").size()

    x_pos = range(len(conf_accuracy))
    bars = ax4.bar(x_pos, conf_accuracy.values, alpha=0.7, color="steelblue")

    ax4.set_xticks(x_pos)
    ax4.set_xticklabels(
        [f"{interval.left:.2f}" for interval in conf_accuracy.index], rotation=45, ha="right"
    )
    ax4.set_xlabel("Confidence (binned)")
    ax4.set_ylabel("Accuracy")
    ax4.set_title("Accuracy vs Confidence")
    ax4.axhline(y=0.8, color="orange", linestyle="--")
    ax4.grid(axis="y", alpha=0.3)

    for _i, (bar, count) in enumerate(zip(bars, conf_counts.values, strict=False)):
        height = bar.get_height()
        ax4.text(
            bar.get_x() + bar.get_width() / 2, height + 0.02, f"n={count}", ha="center", fontsize=8
        )

    plt.tight_layout()

    if output_path:
        save_figure(fig, output_path)

    return fig, axes


def plot_tsne_clustering(
    labels: list,
    tsne_result: TSNEResult,
    output_path: Path | None = None,
) -> tuple:
    """Plot t-SNE clustering of phoneme signatures.

    Args:
        labels: List of phoneme labels (length n_samples).
        tsne_result: Pre-computed t-SNE result with 2D coordinates and silhouette score.
        output_path: Optional output path for saving.

    Returns:
        Tuple (fig, ax).
    """
    signatures_2d = tsne_result.coordinates_2d
    silhouette = tsne_result.silhouette

    fig, ax = plt.subplots(figsize=(14, 10))

    unique_labels = sorted(set(labels))
    palettes = ColorPalettes()
    colors = palettes.get_categorical(len(unique_labels), colorblind_safe=True)

    for i, phoneme in enumerate(unique_labels):
        mask = np.array(labels) == phoneme
        ax.scatter(
            signatures_2d[mask, 0],
            signatures_2d[mask, 1],
            label=phoneme,
            alpha=0.6,
            s=50,
            color=colors[i],
        )

    ax.set_xlabel("t-SNE Dimension 1", fontsize=12)
    ax.set_ylabel("t-SNE Dimension 2", fontsize=12)
    ax.set_title(
        f"t-SNE: Clustering des Signatures Phonémiques\n(Silhouette={silhouette:.3f})",
        fontsize=14,
        pad=15,
    )

    n_cols = 2 if len(unique_labels) > 10 else 1
    ax.legend(bbox_to_anchor=(1.05, 1), loc="upper left", ncol=n_cols, fontsize=9)

    ax.grid(alpha=0.3)

    plt.tight_layout()

    if output_path:
        save_figure(fig, output_path)

    logger.info(f"t-SNE clustering plot completed. Silhouette score: {silhouette:.3f}")

    return fig, ax
