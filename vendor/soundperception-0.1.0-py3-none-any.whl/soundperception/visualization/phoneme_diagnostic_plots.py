"""Phoneme segmentation diagnostic plotting functions for temporal analysis."""

from dataclasses import dataclass
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from matplotlib import gridspec
from matplotlib.patches import Rectangle

from soundperception.visualization.scientific_style import (
    ColorPalettes,
    apply_style,
    configure_axes,
    save_figure,
)


@dataclass
class BoundaryAnalysisResult:
    """Pre-computed boundary analysis result.

    Attributes:
        true_positives: Detected boundaries matching ground truth (samples).
        false_positives: Detected boundaries not matching ground truth (samples).
        false_negatives: Ground truth boundaries not detected (samples).
        boundary_errors_ms: Errors in milliseconds for true positives.
        mean_error_ms: Mean boundary error in milliseconds.
    """

    true_positives: list[int]
    false_positives: list[int]
    false_negatives: np.ndarray
    boundary_errors_ms: list[float]
    mean_error_ms: float | None


@dataclass
class ConfusionMatrixResult:
    """Pre-computed confusion matrix result.

    Attributes:
        matrix: The confusion matrix array.
        labels: List of labels in order.
    """

    matrix: np.ndarray
    labels: list[str]


def plot_segmentation_overview(
    audio: np.ndarray,
    sample_rate: int,
    segments: list[dict[str, Any]],
    landmarks: dict[str, np.ndarray] | None = None,
    ground_truth: list[dict[str, Any]] | None = None,
    save_path: str | None = None,
    envelope: np.ndarray | None = None,
) -> tuple[plt.Figure, np.ndarray]:
    """Create segmentation diagnostic overview.

    Args:
        audio: Audio waveform.
        sample_rate: Sampling rate (Hz).
        segments: List of detected segments with 'start', 'end', 'label' keys.
        landmarks: Optional dict with landmark arrays ('onset', 'peakRate', etc.).
        ground_truth: Optional ground truth segments for comparison.
        save_path: Path to save figure.
        envelope: Pre-computed envelope. If None, envelope panel uses audio absolute values.

    Returns:
        (figure, axes) tuple.
    """
    apply_style("publication")

    fig = plt.figure(figsize=(16, 12), dpi=150)
    gs = gridspec.GridSpec(4, 1, height_ratios=[2, 1.5, 1.5, 1], hspace=0.3)

    ax_wave = fig.add_subplot(gs[0])
    ax_envelope = fig.add_subplot(gs[1], sharex=ax_wave)
    ax_landmarks = fig.add_subplot(gs[2], sharex=ax_wave)
    ax_segments = fig.add_subplot(gs[3], sharex=ax_wave)

    time = np.arange(len(audio)) / sample_rate
    colors = ColorPalettes.get_categorical(max(8, len(segments)))

    ax_wave.plot(time, audio, color="#0173B2", linewidth=0.5, alpha=0.7, label="Audio")

    for i, seg in enumerate(segments):
        start_time = seg["start"] / sample_rate
        end_time = seg["end"] / sample_rate
        label = seg.get("label", f"Seg {i}")

        ax_wave.axvspan(start_time, end_time, alpha=0.2, color=colors[i % len(colors)])

        ax_wave.axvline(start_time, color=colors[i % len(colors)], linestyle="--", alpha=0.6)
        ax_wave.axvline(end_time, color=colors[i % len(colors)], linestyle="--", alpha=0.6)

        mid_time = (start_time + end_time) / 2
        ax_wave.text(
            mid_time,
            audio.max() * 0.9,
            label,
            ha="center",
            fontsize=9,
            bbox={"boxstyle": "round,pad=0.3", "facecolor": "white", "alpha": 0.8},
        )

    configure_axes(
        ax_wave,
        ylabel="Amplitude",
        title="Phoneme Segmentation Overview",
        grid=True,
        spines=False,
    )
    plt.setp(ax_wave.get_xticklabels(), visible=False)

    env = envelope if envelope is not None else np.abs(audio)
    ax_envelope.plot(time, env, color="#DE8F05", linewidth=1.5, label="Envelope")

    if landmarks:
        if "onset" in landmarks:
            onset_times = landmarks["onset"] / sample_rate
            for onset_t in onset_times:
                ax_envelope.axvline(onset_t, color="red", linestyle=":", alpha=0.7, linewidth=2)
            ax_envelope.scatter(
                onset_times,
                [env.max() * 0.95] * len(onset_times),
                marker="^",
                color="red",
                s=100,
                label="Onset",
                zorder=5,
            )

        if "peakRate" in landmarks:
            peak_times = landmarks["peakRate"] / sample_rate
            for peak_t in peak_times:
                ax_envelope.axvline(peak_t, color="green", linestyle=":", alpha=0.7, linewidth=2)
            ax_envelope.scatter(
                peak_times,
                [env.max() * 0.85] * len(peak_times),
                marker="v",
                color="green",
                s=100,
                label="PeakRate",
                zorder=5,
            )

    configure_axes(
        ax_envelope,
        ylabel="Envelope",
        grid=True,
        legend=True,
        legend_loc="upper right",
        spines=False,
    )
    plt.setp(ax_envelope.get_xticklabels(), visible=False)

    if landmarks:
        landmark_types = list(landmarks.keys())
        n_types = len(landmark_types)

        for i, ltype in enumerate(landmark_types):
            landmark_samples = landmarks[ltype]
            landmark_times = landmark_samples / sample_rate

            for lt in landmark_times:
                ax_landmarks.plot(
                    [lt, lt], [i - 0.4, i + 0.4], color=colors[i], linewidth=2, alpha=0.8
                )

        ax_landmarks.set_yticks(range(n_types))
        ax_landmarks.set_yticklabels(landmark_types)
        configure_axes(ax_landmarks, ylabel="Landmarks", grid=True, spines=False)
        plt.setp(ax_landmarks.get_xticklabels(), visible=False)
    else:
        ax_landmarks.text(
            0.5,
            0.5,
            "No landmarks provided",
            ha="center",
            va="center",
            transform=ax_landmarks.transAxes,
            fontsize=12,
        )
        ax_landmarks.set_yticks([])

    if ground_truth:
        for i, gt_seg in enumerate(ground_truth):
            start_time = gt_seg["start"] / sample_rate
            end_time = gt_seg["end"] / sample_rate
            width = end_time - start_time

            rect = Rectangle(
                (start_time, 0.5),
                width,
                0.3,
                facecolor=colors[i % len(colors)],
                edgecolor="black",
                alpha=0.6,
                label=f"GT: {gt_seg.get('label', '')}",
            )
            ax_segments.add_patch(rect)

        for i, seg in enumerate(segments):
            start_time = seg["start"] / sample_rate
            end_time = seg["end"] / sample_rate
            width = end_time - start_time

            rect = Rectangle(
                (start_time, 0.0),
                width,
                0.3,
                facecolor=colors[i % len(colors)],
                edgecolor="black",
                alpha=0.6,
                linestyle="--",
            )
            ax_segments.add_patch(rect)

        ax_segments.set_ylim(-0.1, 1.0)
        ax_segments.set_yticks([0.15, 0.65])
        ax_segments.set_yticklabels(["Detected", "Ground Truth"])
    else:
        for i, seg in enumerate(segments):
            start_time = seg["start"] / sample_rate
            end_time = seg["end"] / sample_rate
            width = end_time - start_time

            rect = Rectangle(
                (start_time, 0.3),
                width,
                0.4,
                facecolor=colors[i % len(colors)],
                edgecolor="black",
                alpha=0.6,
                label=seg.get("label", f"Seg {i}"),
            )
            ax_segments.add_patch(rect)

        ax_segments.set_ylim(0, 1.0)
        ax_segments.set_yticks([0.5])
        ax_segments.set_yticklabels(["Detected Segments"])

    configure_axes(ax_segments, xlabel="Time (s)", grid=True, spines=False)

    ax_wave.set_xlim(0, time[-1])

    if save_path:
        save_figure(fig, save_path, dpi=300, bbox_inches="tight")

    return fig, np.array([ax_wave, ax_envelope, ax_landmarks, ax_segments])


def plot_feature_evolution(
    features: dict[str, np.ndarray],
    sample_rate: int,
    segments: list[dict[str, Any]] | None = None,
    feature_names: list[str] | None = None,
    save_path: str | None = None,
) -> tuple[plt.Figure, np.ndarray]:
    """Plot temporal evolution of features with segmentation overlay.

    Args:
        features: Dict of feature arrays (keys: feature names, values: time series).
        sample_rate: Sampling rate (Hz).
        segments: Optional segment boundaries.
        feature_names: Optional subset of features to plot.
        save_path: Path to save figure.

    Returns:
        (figure, axes) tuple.
    """
    apply_style("publication")

    if feature_names is None:
        feature_names = list(features.keys())

    n_features = len(feature_names)
    fig, axes = plt.subplots(n_features, 1, figsize=(14, 2 * n_features), sharex=True)

    if n_features == 1:
        axes = [axes]

    colors = ColorPalettes.get_categorical(n_features)

    for i, fname in enumerate(feature_names):
        feature_data = features[fname]
        time = np.arange(len(feature_data)) / sample_rate

        axes[i].plot(time, feature_data, color=colors[i], linewidth=1.5, label=fname)

        if segments:
            for seg in segments:
                start_time = seg["start"] / sample_rate
                end_time = seg["end"] / sample_rate
                axes[i].axvspan(start_time, end_time, alpha=0.1, color="gray")
                axes[i].axvline(start_time, color="red", linestyle="--", alpha=0.5, linewidth=1)

        configure_axes(axes[i], ylabel=fname, grid=True, legend=True, spines=False)

    configure_axes(axes[-1], xlabel="Time (s)")
    plt.tight_layout()

    if save_path:
        save_figure(fig, save_path, dpi=300, bbox_inches="tight")

    return fig, np.array(axes)


def plot_confusion_matrix(
    labels: list[str],
    confusion: ConfusionMatrixResult,
    normalize: bool = True,
    save_path: str | None = None,
) -> tuple[plt.Figure, plt.Axes]:
    """Plot confusion matrix for phoneme classification.

    Args:
        labels: Label order for display.
        confusion: Pre-computed confusion matrix result.
        normalize: Normalize to percentages.
        save_path: Path to save figure.

    Returns:
        (figure, axes) tuple.
    """
    apply_style("publication")

    cm = confusion.matrix

    if normalize:
        cm = cm.astype("float") / cm.sum(axis=1)[:, np.newaxis]
        fmt = ".2%"
        cbar_label = "Proportion"
    else:
        fmt = "d"
        cbar_label = "Count"

    fig, ax = plt.subplots(figsize=(10, 8))

    sns.heatmap(
        cm,
        annot=True,
        fmt=fmt,
        cmap="Blues",
        xticklabels=labels,
        yticklabels=labels,
        ax=ax,
        cbar_kws={"label": cbar_label},
        vmin=0,
        vmax=1 if normalize else None,
    )

    configure_axes(
        ax,
        xlabel="Predicted Label",
        ylabel="True Label",
        title="Phoneme Classification Confusion Matrix",
    )
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right")
    ax.set_yticklabels(ax.get_yticklabels(), rotation=0)

    plt.tight_layout()

    if save_path:
        save_figure(fig, save_path, dpi=300, bbox_inches="tight")

    return fig, ax


def plot_boundary_errors(
    detected_boundaries: np.ndarray,
    ground_truth_boundaries: np.ndarray,
    audio: np.ndarray,
    sample_rate: int,
    save_path: str | None = None,
    analysis: BoundaryAnalysisResult | None = None,
) -> tuple[plt.Figure, np.ndarray]:
    """Visualize boundary detection errors (missed, false alarms, shifted).

    Args:
        detected_boundaries: Detected boundary sample indices.
        ground_truth_boundaries: Ground truth boundary sample indices.
        audio: Audio waveform.
        sample_rate: Sampling rate (Hz).
        save_path: Path to save figure.
        analysis: Pre-computed boundary analysis result.
            If None, no classification is shown, only raw boundaries.

    Returns:
        (figure, axes) tuple.
    """
    apply_style("publication")

    if analysis is not None:
        true_positives = analysis.true_positives
        false_positives = analysis.false_positives
        false_negatives = analysis.false_negatives
        boundary_errors = analysis.boundary_errors_ms
        mean_error = analysis.mean_error_ms
    else:
        true_positives = []
        false_positives = list(detected_boundaries)
        false_negatives = ground_truth_boundaries
        boundary_errors = []
        mean_error = None

    fig, axes = plt.subplots(3, 1, figsize=(14, 10), sharex=True)

    time = np.arange(len(audio)) / sample_rate

    axes[0].plot(time, audio, color="#0173B2", linewidth=0.5, alpha=0.5)

    for gt_b in ground_truth_boundaries:
        axes[0].axvline(gt_b / sample_rate, color="green", linestyle="-", alpha=0.7, linewidth=2)

    for det_b in detected_boundaries:
        axes[0].axvline(det_b / sample_rate, color="blue", linestyle="--", alpha=0.7, linewidth=1.5)

    axes[0].legend(["Audio", "Ground Truth", "Detected"], loc="upper right")
    configure_axes(axes[0], ylabel="Amplitude", title="Boundary Detection Overview", grid=True)

    axes[1].plot(time, audio, color="gray", linewidth=0.5, alpha=0.3)

    for tp in true_positives:
        axes[1].axvline(tp / sample_rate, color="green", linestyle="-", alpha=0.8, linewidth=2)

    for fp in false_positives:
        axes[1].axvline(fp / sample_rate, color="red", linestyle="--", alpha=0.8, linewidth=2)

    for fn in false_negatives:
        axes[1].axvline(fn / sample_rate, color="orange", linestyle=":", alpha=0.8, linewidth=2)

    axes[1].legend(["True Positive", "False Positive", "False Negative"], loc="upper right")
    configure_axes(axes[1], ylabel="Amplitude", title="Boundary Classification", grid=True)

    if boundary_errors:
        axes[2].hist(boundary_errors, bins=30, color="#029E73", alpha=0.7, edgecolor="black")
        if mean_error is not None:
            axes[2].axvline(
                mean_error,
                color="red",
                linestyle="--",
                linewidth=2,
                label=f"Mean: {mean_error:.1f} ms",
            )
            axes[2].legend()
    else:
        axes[2].text(
            0.5,
            0.5,
            "No matched boundaries",
            ha="center",
            va="center",
            transform=axes[2].transAxes,
            fontsize=12,
        )

    configure_axes(
        axes[2],
        xlabel="Time (s)" if not boundary_errors else "Boundary Error (ms)",
        ylabel="Count",
        title="Temporal Error Distribution",
        grid=True,
    )

    axes[0].set_xlim(0, time[-1])
    plt.tight_layout()

    if save_path:
        save_figure(fig, save_path, dpi=300, bbox_inches="tight")

    return fig, axes


def plot_segmentation_metrics(
    metrics: dict[str, float],
    save_path: str | None = None,
) -> tuple[plt.Figure, plt.Axes]:
    """Visualize segmentation performance metrics.

    Args:
        metrics: Dict with keys like 'precision', 'recall', 'f1', 'boundary_error_ms', etc.
        save_path: Path to save figure.

    Returns:
        (figure, axes) tuple.
    """
    apply_style("publication")

    fig, ax = plt.subplots(figsize=(8, 6))

    metric_names = list(metrics.keys())
    metric_values = list(metrics.values())

    colors = ColorPalettes.get_categorical(len(metric_names))
    ax.barh(metric_names, metric_values, color=colors, alpha=0.8, edgecolor="black")

    for i, (_name, value) in enumerate(zip(metric_names, metric_values, strict=False)):
        ax.text(value + 0.02, i, f"{value:.3f}", va="center", fontsize=10)

    configure_axes(
        ax,
        xlabel="Metric Value",
        ylabel="Metric",
        title="Segmentation Performance Metrics",
        grid=True,
        spines=False,
    )
    ax.set_xlim(0, max(metric_values) * 1.15)

    plt.tight_layout()

    if save_path:
        save_figure(fig, save_path, dpi=300, bbox_inches="tight")

    return fig, ax


def example_diagnostic_workflow():
    """Example of diagnostic plot workflow."""
    np.random.seed(42)
    sample_rate = 16000
    duration = 2.0
    n_samples = int(sample_rate * duration)

    t = np.linspace(0, duration, n_samples)
    audio = np.concatenate(
        [
            np.sin(2 * np.pi * 440 * t[: n_samples // 3]) * 0.5,
            np.sin(2 * np.pi * 880 * t[n_samples // 3 : 2 * n_samples // 3]) * 0.3,
            np.sin(2 * np.pi * 220 * t[2 * n_samples // 3 :]) * 0.6,
        ]
    )

    audio += np.random.normal(0, 0.05, n_samples)

    segments = [
        {"start": 0, "end": n_samples // 3, "label": "Phoneme A"},
        {"start": n_samples // 3, "end": 2 * n_samples // 3, "label": "Phoneme E"},
        {"start": 2 * n_samples // 3, "end": n_samples, "label": "Phoneme I"},
    ]

    landmarks = {
        "onset": np.array([0, n_samples // 3, 2 * n_samples // 3]),
        "peakRate": np.array([n_samples // 6, n_samples // 2, 5 * n_samples // 6]),
    }

    ground_truth = [
        {"start": 100, "end": n_samples // 3 - 50, "label": "Phoneme A"},
        {"start": n_samples // 3 + 50, "end": 2 * n_samples // 3 - 100, "label": "Phoneme E"},
        {"start": 2 * n_samples // 3 + 100, "end": n_samples - 50, "label": "Phoneme I"},
    ]

    print("Creating segmentation overview...")
    fig1, axes1 = plot_segmentation_overview(
        audio,
        sample_rate,
        segments,
        landmarks,
        ground_truth,
        save_path="output/diagnostic_overview.png",
    )
    plt.show()

    print("Creating feature evolution plot...")
    features = {
        "Energy": np.abs(audio),
        "ZCR": np.abs(np.diff(np.sign(audio))),
        "Envelope": np.convolve(np.abs(audio), np.ones(100) / 100, mode="same"),
    }
    fig2, axes2 = plot_feature_evolution(
        features, sample_rate, segments, save_path="output/feature_evolution.png"
    )
    plt.show()

    print("Creating boundary error plot...")
    detected_boundaries = np.array([s["start"] for s in segments])
    gt_boundaries = np.array([s["start"] for s in ground_truth])
    fig3, axes3 = plot_boundary_errors(
        detected_boundaries,
        gt_boundaries,
        audio,
        sample_rate,
        tolerance_ms=50,
        save_path="output/boundary_errors.png",
    )
    plt.show()

    print("Creating metrics plot...")
    metrics = {
        "Precision": 0.85,
        "Recall": 0.78,
        "F1-Score": 0.81,
        "Boundary Error (ms)": 25.3,
        "Over-Segmentation": 0.12,
        "Under-Segmentation": 0.08,
    }
    fig4, ax4 = plot_segmentation_metrics(metrics, save_path="output/metrics.png")
    plt.show()

    print("Diagnostic plots completed")


if __name__ == "__main__":
    print("Phoneme Diagnostic Plots - Example Workflow")
    print("=" * 60)
    example_diagnostic_workflow()
