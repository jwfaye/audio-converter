"""Layout system for multi-attractor bank visualization.

Layout structure:
    +--------------------------------------------------+
    |  Attractor 0      |  Attractor 1      | ...      |
    |  (hist + state)   |  (hist + state)   |          |
    +--------------------------------------------------+
    |  Memory Panel                                     |
    |  [A0: S0 S1 S2]  [A1: S0 S1]  [A2: ...]          |
    +--------------------------------------------------+
    |  memo_ma spectrogram with segment overlay        |
    +--------------------------------------------------+
    |  Waveform with segment markers                   |
    +--------------------------------------------------+
"""

import logging
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import soundfile as sf
from matplotlib.gridspec import GridSpec
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

from soundperception.core import (
    AttractorState,
    DetectedSegment,
    FrameResult,
)


class PanelType(Enum):
    """Types of panels in the layout."""

    HISTOGRAM = "histogram"
    STATE = "state"
    MEMORY = "memory"
    SPECTROGRAM = "spectrogram"
    WAVEFORM = "waveform"


@dataclass
class PanelConfig:
    """Configuration for a single panel.

    Attributes:
        panel_type: Type of panel to render.
        row: Grid row position.
        col: Grid column position.
        rowspan: Number of rows to span.
        colspan: Number of columns to span.
        attractor_idx: For attractor-specific panels, which attractor.
        title: Optional panel title.
        show_colorbar: Show colorbar for heatmaps.
    """

    panel_type: PanelType
    row: int
    col: int
    rowspan: int = 1
    colspan: int = 1
    attractor_idx: int | None = None
    title: str | None = None
    show_colorbar: bool = False


@dataclass
class LayoutConfig:
    """Configuration for the entire visualization layout.

    Attributes:
        num_attractors: Number of attractors in the bank.
        figsize: Figure size (width, height) in inches.
        dpi: Resolution for saved figures.
        n_rows: Number of grid rows.
        n_cols: Number of grid columns.
        panels: List of panel configurations.
        height_ratios: Height ratios for grid rows.
        width_ratios: Width ratios for grid columns.
        attractor_colors: Colors for each attractor.
        state_colors: Colors for attractor states.
        background_color: Figure background color.
        max_memory_slots: Maximum slots in shared memory.
        colormap: Colormap for histograms.
    """

    num_attractors: int = 4
    figsize: tuple[float, float] = (18, 12)
    dpi: int = 100
    n_rows: int = 4
    n_cols: int = 4
    panels: list[PanelConfig] = field(default_factory=list)
    height_ratios: list[float] = field(default_factory=list)
    width_ratios: list[float] = field(default_factory=list)
    attractor_colors: list[str] = field(default_factory=list)
    state_colors: dict[AttractorState, str] = field(default_factory=dict)
    background_color: str = "black"
    max_memory_slots: int = 8
    colormap: str = "hot"

    def __post_init__(self):
        """Set default colors and build layout if not provided."""
        if not self.attractor_colors:
            self.attractor_colors = [
                "#00FF00",
                "#00FFFF",
                "#FF00FF",
                "#FFFF00",
                "#FF8800",
                "#00FF88",
                "#8800FF",
                "#FF0088",
            ]

        if not self.state_colors:
            self.state_colors = {
                AttractorState.ATTENTE: "#444444",
                AttractorState.ACCROCHE: "#FF8800",
                AttractorState.SUIVI: "#00AA00",
            }

        if not self.panels:
            self._build_default_layout()

    def _build_default_layout(self):
        """Build layout based on number of attractors.

        Layout:
            Row 0: Histogram panels for each attractor.
            Row 1: Shared memory panel (spans all columns).
            Row 2: Spectrogram (spans all columns).
            Row 3: Waveform (spans all columns).
        """
        self.n_cols = self.num_attractors
        self.n_rows = 4
        self.height_ratios = [3, 2, 2, 1]
        self.width_ratios = [1] * self.num_attractors

        self.panels = []

        for i in range(self.num_attractors):
            self.panels.append(
                PanelConfig(
                    panel_type=PanelType.HISTOGRAM,
                    row=0,
                    col=i,
                    attractor_idx=i,
                    title=f"A{i}",
                )
            )

        self.panels.append(
            PanelConfig(
                panel_type=PanelType.MEMORY,
                row=1,
                col=0,
                colspan=self.num_attractors,
                attractor_idx=None,
                title="Memory",
            )
        )

        self.panels.append(
            PanelConfig(
                panel_type=PanelType.SPECTROGRAM,
                row=2,
                col=0,
                colspan=self.num_attractors,
                title="memo_ma",
            )
        )

        self.panels.append(
            PanelConfig(
                panel_type=PanelType.WAVEFORM,
                row=3,
                col=0,
                colspan=self.num_attractors,
                title="Audio",
            )
        )


@dataclass
class BankFrameData:
    """Data for rendering a single frame of the bank visualization.

    Attributes:
        frame_idx: Current frame index.
        time_seconds: Current time in seconds.
        attractor_results: Results per attractor for this frame.
        attractor_segments: Detected segments per attractor.
        attractor_states: Current state per attractor.
        memo_ma: Full memo_ma spectrogram.
        audio_signal: Audio waveform.
        sample_rate: Sample rate.
        decimation_factor: Decimation factor.
    """

    frame_idx: int
    time_seconds: float
    attractor_results: list[FrameResult]
    attractor_segments: list[list[DetectedSegment]]
    attractor_states: list[AttractorState]
    memo_ma: np.ndarray | None = None
    audio_signal: np.ndarray | None = None
    sample_rate: int = 16000
    decimation_factor: int = 100


class BankLayoutRenderer:
    """Renderer for multi-attractor bank visualization."""

    def __init__(self, config: LayoutConfig):
        """Initialize renderer with layout configuration.

        Args:
            config: Layout configuration.
        """
        self.config = config
        self._fig: plt.Figure | None = None
        self._axes: dict[str, plt.Axes] = {}
        self._gs: GridSpec | None = None

    def create_figure(self) -> plt.Figure:
        """Create figure with configured layout.

        Returns:
            Matplotlib figure.
        """
        plt.style.use("dark_background")

        self._fig = plt.figure(
            figsize=self.config.figsize,
            facecolor=self.config.background_color,
        )

        self._gs = GridSpec(
            self.config.n_rows,
            self.config.n_cols,
            figure=self._fig,
            height_ratios=self.config.height_ratios,
            width_ratios=self.config.width_ratios,
            hspace=0.3,
            wspace=0.2,
        )

        self._axes = {}
        for panel in self.config.panels:
            key = self._panel_key(panel)
            ax = self._fig.add_subplot(
                self._gs[
                    panel.row : panel.row + panel.rowspan, panel.col : panel.col + panel.colspan
                ]
            )
            self._axes[key] = ax

        return self._fig

    def _panel_key(self, panel: PanelConfig) -> str:
        """Generate unique key for panel."""
        if panel.attractor_idx is not None:
            return f"{panel.panel_type.value}_{panel.attractor_idx}"
        return f"{panel.panel_type.value}_{panel.row}_{panel.col}"

    def render_frame(self, data: BankFrameData) -> plt.Figure:
        """Render a single frame with all panels.

        Args:
            data: Frame data to render.

        Returns:
            Rendered figure.
        """
        if self._fig is None:
            self.create_figure()

        for ax in self._axes.values():
            ax.clear()

        for panel in self.config.panels:
            key = self._panel_key(panel)
            ax = self._axes[key]

            if panel.panel_type == PanelType.HISTOGRAM:
                self._render_histogram_panel(ax, panel, data)
            elif panel.panel_type == PanelType.MEMORY:
                self._render_memory_panel(ax, panel, data)
            elif panel.panel_type == PanelType.SPECTROGRAM:
                self._render_spectrogram_panel(ax, panel, data)
            elif panel.panel_type == PanelType.WAVEFORM:
                self._render_waveform_panel(ax, panel, data)

        self._fig.suptitle(
            f"Frame {data.frame_idx + 1} | t = {data.time_seconds:.3f}s",
            fontsize=14,
            color="white",
            fontweight="bold",
        )

        return self._fig

    def _render_histogram_panel(
        self,
        ax: plt.Axes,
        panel: PanelConfig,
        data: BankFrameData,
    ) -> None:
        """Render histogram panel for one attractor."""
        idx = panel.attractor_idx
        if idx is None or idx >= len(data.attractor_results):
            ax.set_visible(False)
            return

        result = data.attractor_results[idx]
        state = data.attractor_states[idx]
        color = self.config.attractor_colors[idx % len(self.config.attractor_colors)]
        state_color = self.config.state_colors[state]

        hist = result.histogram if result.histogram is not None else None

        if hist is not None and hist.size > 0:
            ax.imshow(
                hist,
                aspect="auto",
                origin="lower",
                cmap=self.config.colormap,
                interpolation="nearest",
            )

            (x_min, x_max), (y_min, y_max) = result.bounds_x, result.bounds_y
            rect = Rectangle(
                (x_min, y_min),
                x_max - x_min,
                y_max - y_min,
                fill=False,
                edgecolor=color,
                linewidth=2,
            )
            ax.add_patch(rect)

            if result.med_x is not None and result.med_y is not None:
                ax.plot(
                    result.med_x,
                    result.med_y,
                    "o",
                    color="white",
                    markersize=8,
                    markeredgecolor=color,
                    markeredgewidth=2,
                )

            ax.text(
                0.02,
                0.98,
                f"Rmax={result.rmax}",
                transform=ax.transAxes,
                fontsize=8,
                color="white",
                va="top",
            )
        else:
            ax.text(
                0.5,
                0.5,
                "No data",
                transform=ax.transAxes,
                ha="center",
                va="center",
                color="#666666",
            )

        state_symbol = {"ATTENTE": "W", "ACCROCHE": "L", "SUIVI": "T"}[state.name]
        ax.set_title(
            f"A{idx} [{state_symbol}]",
            fontsize=11,
            color=state_color,
            fontweight="bold",
        )

        for spine in ax.spines.values():
            spine.set_color(state_color)
            spine.set_linewidth(2)

        ax.set_xlabel("Channel", fontsize=9)
        ax.set_ylabel("Amplitude", fontsize=9)

    def _render_memory_panel(
        self,
        ax: plt.Axes,
        panel: PanelConfig,
        data: BankFrameData,
    ) -> None:
        """Render memory panel showing all segment signatures."""
        ax.set_facecolor("#111111")
        ax.set_xlim(0, self.config.max_memory_slots)
        ax.set_ylim(0, 1)

        all_segments_with_attr = []
        for attr_idx, segments in enumerate(data.attractor_segments):
            for seg in segments:
                all_segments_with_attr.append((seg, attr_idx))

        detected = [(s, a) for s, a in all_segments_with_attr if s.end_frame <= data.frame_idx]
        active = [
            (s, a)
            for s, a in all_segments_with_attr
            if s.start_frame <= data.frame_idx <= s.end_frame
        ]

        detected.sort(key=lambda x: x[0].end_frame)

        to_display = detected + active

        for slot_idx in range(min(len(to_display), self.config.max_memory_slots)):
            seg, attr_idx = to_display[slot_idx]
            color = self.config.attractor_colors[attr_idx % len(self.config.attractor_colors)]
            is_active = seg.start_frame <= data.frame_idx <= seg.end_frame

            x_start = slot_idx

            slot_color = "#002200" if is_active else "#1a1a1a"
            rect = Rectangle(
                (x_start + 0.05, 0.1),
                0.9,
                0.8,
                facecolor=slot_color,
                edgecolor=color,
                linewidth=2 if is_active else 1.5,
            )
            ax.add_patch(rect)

            if seg.mean_med_x is not None and seg.mean_med_y is not None:
                norm_x = x_start + 0.1 + 0.8 * (seg.mean_med_x / 64.0)
                norm_y = 0.15 + 0.7 * min(1.0, seg.mean_med_y / 40.0)
                ax.plot(
                    norm_x,
                    norm_y,
                    "o",
                    color="yellow",
                    markersize=6,
                    markeredgecolor="white",
                    markeredgewidth=1,
                )

            label = f"A{attr_idx}:S{seg.class_id % 100}"
            ax.text(
                x_start + 0.5,
                0.92,
                label,
                ha="center",
                va="top",
                fontsize=8,
                color=color,
                fontweight="bold" if is_active else "normal",
            )

            ax.text(
                x_start + 0.5,
                0.02,
                f"[{seg.start_frame}-{seg.end_frame}]",
                ha="center",
                va="bottom",
                fontsize=6,
                color="#888888",
            )

        for slot_idx in range(len(to_display), self.config.max_memory_slots):
            x_start = slot_idx
            rect = Rectangle(
                (x_start + 0.05, 0.1),
                0.9,
                0.8,
                facecolor="#0a0a0a",
                edgecolor="#333333",
                linewidth=1,
                linestyle="--",
            )
            ax.add_patch(rect)
            ax.text(
                x_start + 0.5,
                0.5,
                "---",
                ha="center",
                va="center",
                fontsize=10,
                color="#333333",
            )

        ax.set_title("Shared Memory (all attractors)", fontsize=10, color="white")
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)

    def _render_spectrogram_panel(
        self,
        ax: plt.Axes,
        panel: PanelConfig,
        data: BankFrameData,
    ) -> None:
        """Render spectrogram with segment overlays from all attractors."""
        if data.memo_ma is None:
            ax.text(0.5, 0.5, "No spectrogram data", ha="center", va="center", color="#666666")
            return

        ax.imshow(
            data.memo_ma,
            aspect="auto",
            origin="lower",
            cmap="hot",
            interpolation="nearest",
        )

        sample_pos = int(data.time_seconds * data.sample_rate)
        ax.axvline(sample_pos, color="cyan", linewidth=2, alpha=0.8)

        for attr_idx, segments in enumerate(data.attractor_segments):
            color = self.config.attractor_colors[attr_idx % len(self.config.attractor_colors)]

            for seg in segments:
                if seg.end_frame <= data.frame_idx:
                    start_sample = seg.start_frame * data.decimation_factor
                    end_sample = (seg.end_frame + 1) * data.decimation_factor

                    ax.axvspan(
                        start_sample,
                        end_sample,
                        alpha=0.15,
                        color=color,
                        zorder=1,
                    )
                    ax.axvline(start_sample, color=color, linewidth=1, linestyle="--", alpha=0.6)
                    ax.axvline(end_sample, color=color, linewidth=1, linestyle="--", alpha=0.6)

                    label_y = data.memo_ma.shape[0] - 3 - (attr_idx * 5)
                    ax.text(
                        (start_sample + end_sample) / 2,
                        label_y,
                        f"A{attr_idx}:S{seg.class_id % 100}",
                        fontsize=7,
                        color=color,
                        ha="center",
                        va="top",
                        fontweight="bold",
                    )
                elif seg.start_frame <= data.frame_idx:
                    start_sample = seg.start_frame * data.decimation_factor
                    ax.axvline(start_sample, color=color, linewidth=2, alpha=0.8)

        ax.set_xlabel("Samples", fontsize=9)
        ax.set_ylabel("Channel", fontsize=9)
        ax.set_title(panel.title or "Spectrogram", fontsize=10)

    def _render_waveform_panel(
        self,
        ax: plt.Axes,
        panel: PanelConfig,
        data: BankFrameData,
    ) -> None:
        """Render waveform with segment markers from all attractors."""
        if data.audio_signal is None:
            ax.text(0.5, 0.5, "No audio data", ha="center", va="center", color="#666666")
            return

        time_axis = np.arange(len(data.audio_signal)) / data.sample_rate
        audio_duration = len(data.audio_signal) / data.sample_rate

        ax.plot(time_axis, data.audio_signal, color="#2196F3", linewidth=0.5, alpha=0.8)

        ax.axvline(data.time_seconds, color="red", linewidth=2, label="Position")

        max_amp = np.abs(data.audio_signal).max()

        for attr_idx, segments in enumerate(data.attractor_segments):
            color = self.config.attractor_colors[attr_idx % len(self.config.attractor_colors)]
            y_offset = max_amp * (0.9 - attr_idx * 0.15)

            for seg in segments:
                if seg.end_frame <= data.frame_idx:
                    start_time = seg.start_frame * data.decimation_factor / data.sample_rate
                    end_time = (seg.end_frame + 1) * data.decimation_factor / data.sample_rate

                    ax.hlines(
                        y_offset,
                        start_time,
                        end_time,
                        colors=color,
                        linewidth=3,
                        alpha=0.8,
                    )

                    ax.vlines(
                        [start_time, end_time],
                        y_offset - max_amp * 0.05,
                        y_offset + max_amp * 0.05,
                        colors=color,
                        linewidth=1.5,
                        alpha=0.8,
                    )

                    ax.text(
                        (start_time + end_time) / 2,
                        y_offset + max_amp * 0.08,
                        f"S{seg.class_id % 100}",
                        fontsize=7,
                        color=color,
                        ha="center",
                        va="bottom",
                    )

        ax.set_xlim(0, audio_duration)
        ax.set_ylim(-1.2 * max_amp, 1.2 * max_amp)
        ax.set_xlabel("Time (s)", fontsize=9)
        ax.set_ylabel("Amplitude", fontsize=9)
        ax.set_title(panel.title or "Waveform", fontsize=10)
        ax.grid(True, alpha=0.2)

        legend_elements = []
        for i in range(min(len(data.attractor_segments), 4)):
            legend_elements.append(
                Line2D([0], [0], color=self.config.attractor_colors[i], linewidth=2, label=f"A{i}")
            )
        if legend_elements:
            ax.legend(handles=legend_elements, loc="upper right", fontsize=7, framealpha=0.5)

    def save_frame(self, path: str, dpi: int | None = None) -> None:
        """Save current frame to file.

        Args:
            path: Output path.
            dpi: Resolution (uses config.dpi if not specified).
        """
        if self._fig is None:
            return
        self._fig.savefig(
            path,
            dpi=dpi or self.config.dpi,
            facecolor=self.config.background_color,
            bbox_inches="tight",
        )

    def close(self) -> None:
        """Close figure and cleanup."""
        if self._fig is not None:
            plt.close(self._fig)
            self._fig = None
        self._axes = {}


def create_bank_video(
    attractor_results: list[list[FrameResult]],
    attractor_segments: list[list[DetectedSegment]],
    audio_path: str,
    output_path: str,
    sample_rate: int = 16000,
    decimation_factor: int = 100,
    memo_ma: np.ndarray | None = None,
    save_frames_dir: str | None = None,
    config: LayoutConfig | None = None,
    fps: int | None = None,
) -> None:
    """Create video of multi-attractor bank visualization.

    Args:
        attractor_results: Results per attractor, each a list of FrameResult.
        attractor_segments: Detected segments per attractor.
        audio_path: Path to audio file.
        output_path: Output video path.
        sample_rate: Sample rate.
        decimation_factor: Decimation factor.
        memo_ma: Full memo_ma spectrogram.
        save_frames_dir: If provided, save PNG frames to this directory.
        config: Layout configuration.
        fps: Frames per second (computed from audio if not provided).
    """
    logger = logging.getLogger(__name__)

    audio_signal, sr = sf.read(audio_path)
    if audio_signal.ndim > 1:
        audio_signal = audio_signal[:, 0]
    audio_duration = len(audio_signal) / sr

    num_attractors = len(attractor_results)
    n_frames = len(attractor_results[0]) if attractor_results else 0

    if n_frames == 0:
        logger.error("No frames to render")
        return

    if config is None:
        config = LayoutConfig(num_attractors=num_attractors)

    if fps is None:
        fps = max(1, int(n_frames / audio_duration))
    logger.info(f"Creating bank video: {n_frames} frames, {audio_duration:.2f}s, {fps} fps")

    temp_dir = None
    if save_frames_dir:
        frames_dir = Path(save_frames_dir)
        frames_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"Frames saved in: {frames_dir}")
    else:
        temp_dir = Path(tempfile.mkdtemp())
        frames_dir = temp_dir

    renderer = BankLayoutRenderer(config)

    try:
        plt.style.use("dark_background")

        for frame_idx in range(n_frames):
            time_seconds = (frame_idx + 0.5) * decimation_factor / sample_rate

            frame_results = [results[frame_idx] for results in attractor_results]
            frame_states = [result.state for result in frame_results]

            frame_data = BankFrameData(
                frame_idx=frame_idx,
                time_seconds=time_seconds,
                attractor_results=frame_results,
                attractor_segments=attractor_segments,
                attractor_states=frame_states,
                memo_ma=memo_ma,
                audio_signal=audio_signal,
                sample_rate=sample_rate,
                decimation_factor=decimation_factor,
            )

            renderer.render_frame(frame_data)

            frame_path = frames_dir / f"frame_{frame_idx:06d}.png"
            renderer.save_frame(str(frame_path))

            if frame_idx % 10 == 0:
                logger.info(f"Frame {frame_idx + 1}/{n_frames} generated")

        renderer.close()

        logger.info("Encoding video with ffmpeg...")
        temp_video = frames_dir / "temp_video.mp4"

        cmd_video = [
            "ffmpeg",
            "-y",
            "-framerate",
            str(fps),
            "-i",
            str(frames_dir / "frame_%06d.png"),
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-preset",
            "medium",
            str(temp_video),
        ]

        result_ffmpeg = subprocess.run(cmd_video, capture_output=True, text=True, check=False)
        if result_ffmpeg.returncode != 0:
            logger.error(f"ffmpeg error: {result_ffmpeg.stderr}")
            raise RuntimeError(f"ffmpeg failed: {result_ffmpeg.stderr}")

        logger.info("Adding audio track...")
        cmd_audio = [
            "ffmpeg",
            "-y",
            "-i",
            str(temp_video),
            "-i",
            audio_path,
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-shortest",
            output_path,
        ]

        result_ffmpeg = subprocess.run(cmd_audio, capture_output=True, text=True, check=False)
        if result_ffmpeg.returncode != 0:
            logger.error(f"ffmpeg audio error: {result_ffmpeg.stderr}")
            raise RuntimeError(f"ffmpeg failed: {result_ffmpeg.stderr}")

        logger.info(f"Video created: {output_path}")

        if temp_video.exists():
            temp_video.unlink()

    finally:
        plt.style.use("default")

        if temp_dir is not None:
            shutil.rmtree(temp_dir, ignore_errors=True)
        elif save_frames_dir:
            logger.info(f"Frames kept in: {frames_dir}")
