"""Visualization functions for dynamic attractor.

Functions to visualize:
- Dynamic attractor behavior (states, bounds, medians)
- 2D histograms with categorized zones
- Detected segments
- Temporal parameter evolution
- Frame-by-frame video of histogram evolution and categorization
"""

import logging
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import soundfile as sf
from matplotlib.colors import ListedColormap
from matplotlib.gridspec import GridSpec
from matplotlib.patches import Ellipse, Patch

from soundperception.core import (
    AttractorState,
    CascadeAttractorBank,
    CascadeFrameResult,
    ConvergenceIteration,
    DetectedSegment,
    FrameResult,
)

logger = logging.getLogger(__name__)

MIN_HIST_SIZE = 2


@dataclass
class AttractorPlotConfig:
    """Configuration for attractor visualizations.

    Attributes:
        figsize: Default figure size (width, height).
        colormap: Colormap for heatmaps.
        dpi: Resolution for saved figures.
        state_colors: Colors for each attractor state.
        show_grid: Show grid on plots.
    """

    figsize: tuple[int, int] = (14, 6)
    colormap: str = "hot"
    dpi: int = 150
    state_colors: dict = None
    show_grid: bool = True

    def __post_init__(self):
        """Set default state colors if not provided."""
        if self.state_colors is None:
            self.state_colors = {
                AttractorState.ATTENTE: "#CCCCCC",
                AttractorState.ACCROCHE: "#FF8800",
                AttractorState.SUIVI: "#00AA00",
            }


@dataclass
class HistogramPlotData:
    """Data for histogram visualization.

    Attributes:
        histogram: 2D histogram (n_var_bins x n_mean_bins).
        mean_bins: Bin centers on X axis (mean).
        var_bins: Bin centers on Y axis (variation).
        category_mask: Boolean mask of categorized zone.
        bounds: Current bounds ((x_min, x_max), (y_min, y_max)).
        medians: Medians (med_x, med_y).
    """

    histogram: np.ndarray
    mean_bins: np.ndarray
    var_bins: np.ndarray
    category_mask: np.ndarray | None = None
    bounds: tuple[tuple[float, float], tuple[float, float]] | None = None
    medians: tuple[float, float] | None = None


@dataclass
class ConvergencePlotParams:
    """Parameters for convergence visualization.

    Attributes:
        convergence_history: List of convergence iterations.
        frame_index: Frame index.
        data_range_x: Global range on X for consistent display.
        data_range_y: Global range on Y for consistent display.
        config: Visualization configuration.
    """

    convergence_history: list[ConvergenceIteration]
    frame_index: int
    data_range_x: tuple[float, float] | None = None
    data_range_y: tuple[float, float] | None = None
    config: AttractorPlotConfig | None = None


def plot_attractor_analysis(
    frame_results: list[FrameResult],
    segments: list[DetectedSegment],
    output_path: Path | str,
    config: AttractorPlotConfig = None,
    title: str = "Dynamic Attractor Analysis",
) -> plt.Figure:
    """Create multi-panel analysis figure of the attractor.

    Args:
        frame_results: Frame-by-frame results.
        segments: Detected segments.
        output_path: Output path for figure.
        config: Visualization configuration.
        title: Figure title.

    Returns:
        Matplotlib figure.
    """
    if config is None:
        config = AttractorPlotConfig()

    fig, axes = plt.subplots(2, 2, figsize=(config.figsize[0], config.figsize[1] * 1.5))
    fig.suptitle(title, fontsize=14, fontweight="bold")

    ax1 = axes[0, 0]
    _plot_state_timeline(ax1, frame_results, config)

    ax2 = axes[0, 1]
    _plot_nbpts_evolution(ax2, frame_results, config)

    ax3 = axes[1, 0]
    _plot_medians_trajectory(ax3, frame_results, segments, config)

    ax4 = axes[1, 1]
    _plot_segments_summary(ax4, segments, len(frame_results), config)

    plt.tight_layout()

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=config.dpi, bbox_inches="tight", facecolor="white")
    plt.close(fig)

    return fig


def _plot_state_timeline(
    ax: plt.Axes,
    frame_results: list[FrameResult],
    config: AttractorPlotConfig,
) -> None:
    """Draw colored timeline of states.

    Args:
        ax: Matplotlib axes.
        frame_results: Frame-by-frame results.
        config: Configuration.
    """
    n_frames = len(frame_results)

    state_values = np.array([r.state.value for r in frame_results])

    cmap = plt.cm.colors.ListedColormap([config.state_colors[AttractorState(i)] for i in range(3)])

    ax.imshow(
        state_values.reshape(1, -1),
        aspect="auto",
        cmap=cmap,
        vmin=0,
        vmax=2,
        extent=[0, n_frames, 0, 1],
    )

    ax.set_xlabel("Frame")
    ax.set_yticks([])
    ax.set_title("Attractor state", fontsize=11)

    legend_elements = [
        Patch(facecolor=config.state_colors[AttractorState.ATTENTE], label="WAITING"),
        Patch(facecolor=config.state_colors[AttractorState.ACCROCHE], label="LOCKING"),
        Patch(facecolor=config.state_colors[AttractorState.SUIVI], label="TRACKING"),
    ]
    ax.legend(handles=legend_elements, loc="upper right", fontsize=8)


def _plot_nbpts_evolution(
    ax: plt.Axes,
    frame_results: list[FrameResult],
    config: AttractorPlotConfig,
) -> None:
    """Draw evolution of NbPts and Rmax.

    Args:
        ax: Matplotlib axes.
        frame_results: Frame-by-frame results.
        config: Configuration.
    """
    n_frames = len(frame_results)
    frames = np.arange(n_frames)

    nb_pts = np.array([r.nb_pts for r in frame_results])
    rmax = np.array([r.rmax for r in frame_results])

    ax.plot(frames, nb_pts, label="NbPts (validated points)", color="#2196F3", linewidth=1)
    ax.fill_between(frames, 0, nb_pts, alpha=0.3, color="#2196F3")

    ax2 = ax.twinx()
    ax2.plot(
        frames, rmax, label="Rmax (histogram max)", color="#E91E63", linewidth=1, linestyle="--"
    )

    ax.set_xlabel("Frame")
    ax.set_ylabel("NbPts", color="#2196F3")
    ax2.set_ylabel("Rmax", color="#E91E63")
    ax.set_title("Attractor activity", fontsize=11)

    if config.show_grid:
        ax.grid(True, alpha=0.3)

    lines1, labels1 = ax.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax.legend(lines1 + lines2, labels1 + labels2, loc="upper right", fontsize=8)


def _plot_medians_trajectory(
    ax: plt.Axes,
    frame_results: list[FrameResult],
    segments: list[DetectedSegment],
    config: AttractorPlotConfig,
) -> None:
    """Draw median trajectory in (mean, var) space.

    Args:
        ax: Matplotlib axes.
        frame_results: Frame-by-frame results.
        segments: Detected segments.
        config: Configuration.
    """
    med_x = []
    med_y = []
    states = []
    frame_indices = []

    for i, r in enumerate(frame_results):
        if r.med_x is not None and r.med_y is not None:
            med_x.append(r.med_x)
            med_y.append(r.med_y)
            states.append(r.state)
            frame_indices.append(i)

    if len(med_x) == 0:
        ax.text(
            0.5,
            0.5,
            "No median computed\n(no signal detected)",
            ha="center",
            va="center",
            fontsize=10,
            transform=ax.transAxes,
        )
        ax.set_title("Median trajectory", fontsize=11)
        return

    med_x = np.array(med_x)
    med_y = np.array(med_y)

    scatter = ax.scatter(med_x, med_y, c=frame_indices, cmap="plasma", s=20, alpha=0.7)
    plt.colorbar(scatter, ax=ax, label="Frame", shrink=0.7)

    ax.plot(med_x, med_y, "k-", alpha=0.3, linewidth=0.5)

    for seg in segments:
        ax.plot(
            seg.med_x,
            seg.med_y,
            "o",
            markersize=12,
            markeredgecolor="black",
            markeredgewidth=2,
            markerfacecolor=config.state_colors[AttractorState.SUIVI],
            label=f"Seg {seg.class_id}",
        )
        ax.annotate(
            f"S{seg.class_id}",
            (seg.med_x, seg.med_y),
            textcoords="offset points",
            xytext=(5, 5),
            fontsize=9,
            fontweight="bold",
        )

    ax.set_xlabel("Mean (consecutive mean)")
    ax.set_ylabel("Variation (|diff|)")
    ax.set_title("Median trajectory in (mean, var) space", fontsize=11)

    if config.show_grid:
        ax.grid(True, alpha=0.3)


def _plot_segments_summary(
    ax: plt.Axes,
    segments: list[DetectedSegment],
    n_frames: int,
    config: AttractorPlotConfig,
) -> None:
    """Display text summary of segments.

    Args:
        ax: Matplotlib axes.
        segments: Detected segments.
        n_frames: Total number of frames.
        config: Configuration.
    """
    ax.axis("off")

    if len(segments) == 0:
        ax.text(
            0.5,
            0.5,
            "No segment detected",
            ha="center",
            va="center",
            fontsize=12,
            bbox={"boxstyle": "round", "facecolor": "#FFEEEE", "edgecolor": "#FF0000"},
        )
        ax.set_title("Detected segments", fontsize=11)
        return

    headers = ["ID", "Frames", "Duration", "Med (X, Y)", "Energy"]
    rows = []
    for seg in segments:
        rows.append(
            [
                f"{seg.class_id}",
                f"{seg.start_frame}–{seg.end_frame}",
                f"{seg.duration_frames}",
                f"({seg.med_x:.1f}, {seg.med_y:.1f})",
                f"{seg.total_energy}",
            ]
        )

    table = ax.table(
        cellText=rows,
        colLabels=headers,
        loc="center",
        cellLoc="center",
    )
    table.auto_set_font_size(False)
    table.set_fontsize(9)
    table.scale(1.2, 1.5)

    for j, _header in enumerate(headers):
        table[(0, j)].set_facecolor("#4CAF50")
        table[(0, j)].set_text_props(color="white", fontweight="bold")

    ax.set_title(f"Detected segments ({len(segments)} total)", fontsize=11)


def plot_bounds_evolution(
    frame_results: list[FrameResult],
    output_path: Path | str,
    config: AttractorPlotConfig = None,
    title: str = "Bounds Evolution",
) -> plt.Figure:
    """Visualize evolution of X and Y bounds over time.

    Args:
        frame_results: Frame-by-frame results.
        output_path: Output path.
        config: Configuration.
        title: Figure title.

    Returns:
        Matplotlib figure.
    """
    if config is None:
        config = AttractorPlotConfig()

    fig, axes = plt.subplots(2, 1, figsize=config.figsize, sharex=True)
    fig.suptitle(title, fontsize=14, fontweight="bold")

    n_frames = len(frame_results)
    frames = np.arange(n_frames)

    bounds_x_min = np.array([r.bounds_x[0] for r in frame_results])
    bounds_x_max = np.array([r.bounds_x[1] for r in frame_results])
    bounds_y_min = np.array([r.bounds_y[0] for r in frame_results])
    bounds_y_max = np.array([r.bounds_y[1] for r in frame_results])

    med_x = np.array([r.med_x if r.med_x is not None else np.nan for r in frame_results])
    med_y = np.array([r.med_y if r.med_y is not None else np.nan for r in frame_results])

    ax1 = axes[0]
    ax1.fill_between(frames, bounds_x_min, bounds_x_max, alpha=0.3, color="#2196F3", label="Zone X")
    ax1.plot(frames, bounds_x_min, color="#2196F3", linewidth=1, linestyle="--")
    ax1.plot(frames, bounds_x_max, color="#2196F3", linewidth=1, linestyle="--")
    ax1.plot(frames, med_x, color="#E91E63", linewidth=1.5, label="Med_X")

    ax1.set_ylabel("X (mean)")
    ax1.set_title("Bounds and median on X (mean)", fontsize=11)
    ax1.legend(loc="upper right", fontsize=8)
    if config.show_grid:
        ax1.grid(True, alpha=0.3)

    _add_state_background(ax1, frame_results, config)

    ax2 = axes[1]
    ax2.fill_between(frames, bounds_y_min, bounds_y_max, alpha=0.3, color="#4CAF50", label="Zone Y")
    ax2.plot(frames, bounds_y_min, color="#4CAF50", linewidth=1, linestyle="--")
    ax2.plot(frames, bounds_y_max, color="#4CAF50", linewidth=1, linestyle="--")
    ax2.plot(frames, med_y, color="#E91E63", linewidth=1.5, label="Med_Y")

    ax2.set_xlabel("Frame")
    ax2.set_ylabel("Y (variation)")
    ax2.set_title("Bounds and median on Y (variation)", fontsize=11)
    ax2.legend(loc="upper right", fontsize=8)
    if config.show_grid:
        ax2.grid(True, alpha=0.3)

    _add_state_background(ax2, frame_results, config)

    plt.tight_layout()

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=config.dpi, bbox_inches="tight", facecolor="white")
    plt.close(fig)

    return fig


def _add_state_background(
    ax: plt.Axes,
    frame_results: list[FrameResult],
    config: AttractorPlotConfig,
) -> None:
    """Add colored background according to attractor state.

    Args:
        ax: Matplotlib axes.
        frame_results: Frame-by-frame results.
        config: Configuration.
    """
    n_frames = len(frame_results)

    current_state = frame_results[0].state
    start_frame = 0

    for i, r in enumerate(frame_results):
        if r.state != current_state or i == n_frames - 1:
            end_frame = i if r.state != current_state else i + 1
            color = config.state_colors[current_state]
            ax.axvspan(start_frame, end_frame, alpha=0.1, color=color, linewidth=0)
            current_state = r.state
            start_frame = i


def plot_segments_details(
    segments: list[DetectedSegment],
    output_path: Path | str,
    config: AttractorPlotConfig = None,
    title: str = "Segment Details",
) -> plt.Figure:
    """Visualize details of each detected segment.

    Args:
        segments: Detected segments.
        output_path: Output path.
        config: Configuration.
        title: Figure title.

    Returns:
        Matplotlib figure.
    """
    if config is None:
        config = AttractorPlotConfig()

    if len(segments) == 0:
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.text(0.5, 0.5, "No segment detected", ha="center", va="center", fontsize=14)
        ax.axis("off")
        fig.savefig(output_path, dpi=config.dpi, bbox_inches="tight", facecolor="white")
        plt.close(fig)
        return fig

    n_segments = len(segments)
    fig, axes = plt.subplots(
        1,
        min(n_segments, 4),
        figsize=(min(n_segments, 4) * 4, 4),
        squeeze=False,
    )
    fig.suptitle(title, fontsize=14, fontweight="bold")

    for i, seg in enumerate(segments[:4]):
        ax = axes[0, i]

        if seg.frame_results and len(seg.frame_results) > 0:
            nb_pts_in_seg = [r.nb_pts for r in seg.frame_results]

            ax.bar(range(len(nb_pts_in_seg)), nb_pts_in_seg, color="#4CAF50", alpha=0.7)
            ax.set_xlabel("Frame relative")
            ax.set_ylabel("NbPts")
        else:
            info_text = (
                f"Segment {seg.class_id}\n\n"
                f"Frames: {seg.start_frame}–{seg.end_frame}\n"
                f"Duration: {seg.duration_frames} frames\n"
                f"Med_X: {seg.med_x:.2f}\n"
                f"Med_Y: {seg.med_y:.2f}\n"
                f"Energy: {seg.total_energy}"
            )
            ax.text(
                0.5,
                0.5,
                info_text,
                ha="center",
                va="center",
                fontsize=10,
                bbox={"boxstyle": "round", "facecolor": "#E8F5E9", "edgecolor": "#4CAF50"},
                transform=ax.transAxes,
            )
            ax.axis("off")

        ax.set_title(f"Segment {seg.class_id}", fontsize=11)

    plt.tight_layout()

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=config.dpi, bbox_inches="tight", facecolor="white")
    plt.close(fig)

    return fig


def plot_histogram_with_category(
    data: HistogramPlotData,
    output_path: Path | str,
    config: AttractorPlotConfig = None,
    title: str = "2D Histogram with Categorization",
) -> plt.Figure:
    """Visualize 2D histogram with categorized zone and bounds.

    Args:
        data: Histogram data including histogram, bins, mask, bounds, and medians.
        output_path: Output path.
        config: Configuration.
        title: Title.

    Returns:
        Matplotlib figure.
    """
    if config is None:
        config = AttractorPlotConfig()

    fig, axes = plt.subplots(1, 2, figsize=config.figsize)
    fig.suptitle(title, fontsize=14, fontweight="bold")

    ax1 = axes[0]

    extent = [
        data.mean_bins[0] - 0.5,
        data.mean_bins[-1] + 0.5,
        data.var_bins[0] - 0.5,
        data.var_bins[-1] + 0.5,
    ]

    im1 = ax1.imshow(
        data.histogram,
        aspect="auto",
        origin="lower",
        cmap=config.colormap,
        extent=extent,
    )
    plt.colorbar(im1, ax=ax1, label="Count")

    ax1.set_xlabel("Mean (consecutive mean)")
    ax1.set_ylabel("Variation (|diff|)")
    ax1.set_title("Raw 2D Histogram", fontsize=11)

    ax2 = axes[1]

    im2 = ax2.imshow(
        data.histogram,
        aspect="auto",
        origin="lower",
        cmap=config.colormap,
        extent=extent,
    )
    plt.colorbar(im2, ax=ax2, label="Count")

    if data.category_mask is not None:
        overlay = np.ma.masked_where(~data.category_mask, np.ones_like(data.histogram))
        ax2.imshow(
            overlay,
            aspect="auto",
            origin="lower",
            cmap="Reds",
            alpha=0.3,
            extent=extent,
        )
        ax2.contour(
            data.category_mask,
            levels=[0.5],
            colors=["red"],
            linewidths=[2],
            extent=extent,
        )

    if data.bounds is not None:
        (x_min, x_max), (y_min, y_max) = data.bounds
        rect = plt.Rectangle(
            (x_min, y_min),
            x_max - x_min,
            y_max - y_min,
            fill=False,
            edgecolor="lime",
            linewidth=2,
            linestyle="--",
            label="Bounds",
        )
        ax2.add_patch(rect)

    if data.medians is not None:
        med_x, med_y = data.medians
        ax2.plot(
            med_x,
            med_y,
            "x",
            markersize=15,
            markeredgewidth=3,
            color="white",
            label=f"Median ({med_x:.1f}, {med_y:.1f})",
        )
        ax2.plot(med_x, med_y, "+", markersize=12, markeredgewidth=2, color="black")

    ax2.set_xlabel("Mean (consecutive mean)")
    ax2.set_ylabel("Variation (|diff|)")
    ax2.set_title("Categorized zone + bounds", fontsize=11)
    ax2.legend(loc="upper right", fontsize=8)

    plt.tight_layout()

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=config.dpi, bbox_inches="tight", facecolor="white")
    plt.close(fig)

    return fig


def plot_category_map_on_memo(
    memo_ma: np.ndarray,
    category_map: np.ndarray,
    output_path: Path | str,
    config: AttractorPlotConfig = None,
    title: str = "Category Map on memo_ma",
) -> plt.Figure:
    """Visualize memo_ma colored by category assigned to each pixel.

    Args:
        memo_ma: Amplitude memory (n_channels, n_frames).
        category_map: Category of each pixel (n_channels, n_frames).
        output_path: Output path.
        config: Configuration.
        title: Title.

    Returns:
        Matplotlib figure.
    """
    if config is None:
        config = AttractorPlotConfig()

    fig, axes = plt.subplots(1, 2, figsize=config.figsize)
    fig.suptitle(title, fontsize=14, fontweight="bold")

    ax1 = axes[0]
    im1 = ax1.imshow(
        memo_ma,
        aspect="auto",
        origin="lower",
        cmap=config.colormap,
    )
    plt.colorbar(im1, ax=ax1, label="Amplitude")
    ax1.set_xlabel("Frame")
    ax1.set_ylabel("Channel")
    ax1.set_title("Integrated memo_ma", fontsize=11)

    ax2 = axes[1]

    n_categories = int(np.max(category_map)) + 1
    if n_categories <= 1:
        cmap = "gray"
    else:
        cmap = plt.cm.get_cmap("tab10", n_categories)

    im2 = ax2.imshow(
        category_map,
        aspect="auto",
        origin="lower",
        cmap=cmap,
        vmin=0,
        vmax=max(n_categories - 1, 1),
    )
    cbar = plt.colorbar(im2, ax=ax2, label="Category")
    cbar.set_ticks(range(n_categories))

    ax2.set_xlabel("Frame")
    ax2.set_ylabel("Channel")
    ax2.set_title(f"Categories ({n_categories - 1} + silence)", fontsize=11)

    plt.tight_layout()

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=config.dpi, bbox_inches="tight", facecolor="white")
    plt.close(fig)

    return fig


@dataclass
class FrameCategorization:
    """Pre-computed categorization for a single frame.

    Attributes:
        labels: Category labels array (same shape as histogram).
        num_categories: Number of categories detected.
        category_medians: Dict mapping category_id to (med_x, med_y).
    """

    labels: np.ndarray
    num_categories: int
    category_medians: dict[int, tuple[float, float]] | None = None


def create_attractor_video(
    frame_results: list[FrameResult],
    audio_path: str,
    output_path: str,
    audio_signal: np.ndarray = None,
    sample_rate: int = 16000,
    decimation_factor: int = 100,
    save_frames_dir: str | Path = None,
    memo_ma: np.ndarray = None,
    memo_ck: np.ndarray = None,
    segments: list[DetectedSegment] = None,
    frame_categorizations: list[FrameCategorization | None] | None = None,
) -> None:
    """Create video showing histogram evolution and categorization.

    Args:
        frame_results: Frame-by-frame results with stored histograms.
        audio_path: Path to audio file.
        output_path: Output path for video (.mp4).
        audio_signal: Audio signal (loaded from audio_path if None).
        sample_rate: Sampling rate.
        decimation_factor: Temporal decimation factor.
        save_frames_dir: Directory to save PNG frames.
        memo_ma: Amplitude memory (n_channels, n_samples) for display.
        segments: List of detected segments.
        memo_ck: Temporal memory (n_channels, n_samples) for display.
        frame_categorizations: Pre-computed categorization results per frame.
            If None, categorization panel shows raw histogram.
    """
    n_frames = len(frame_results)

    if audio_signal is None:
        audio_signal, sr = sf.read(audio_path)
        if len(audio_signal.shape) > 1:
            audio_signal = audio_signal[:, 0]
    else:
        sr = sample_rate

    audio_duration = len(audio_signal) / sr
    fps = n_frames / audio_duration

    logger.info(
        "Creating attractor video: %d frames, %.2fs, %.1f fps",
        n_frames,
        audio_duration,
        fps,
    )

    if save_frames_dir is not None:
        save_frames_dir = Path(save_frames_dir)
        save_frames_dir.mkdir(parents=True, exist_ok=True)
        frames_dir = save_frames_dir
        temp_dir = None
        logger.info("Frames saved in: %s", save_frames_dir)
    else:
        temp_dir = Path(tempfile.mkdtemp(prefix="attractor_video_"))
        frames_dir = temp_dir / "frames"
        frames_dir.mkdir()

    state_colors = {
        AttractorState.ATTENTE: "#CCCCCC",
        AttractorState.ACCROCHE: "#FF8800",
        AttractorState.SUIVI: "#00AA00",
    }

    show_memo = memo_ma is not None or memo_ck is not None

    show_memory = segments is not None and len(segments) > 0
    max_memory_slots = min(len(segments), 6) if show_memory else 0

    try:
        plt.style.use("dark_background")

        if show_memo:
            fig = plt.figure(figsize=(16, 14), dpi=100)
        else:
            fig = plt.figure(figsize=(16, 10), dpi=100)
        fig.set_facecolor("black")

        for frame_idx, result in enumerate(frame_results):
            fig.clear()
            fig.set_facecolor("black")

            has_convergence = (
                result.convergence_history is not None and len(result.convergence_history) > 0
            )

            n_cols = 3

            if show_memo:
                gs = fig.add_gridspec(
                    4,
                    n_cols,
                    height_ratios=[3, 1.2, 1.2, 1],
                    width_ratios=[1, 1, 0.8],
                )
                ax_conv = []
                ax_hist = fig.add_subplot(gs[0, 0])
                ax_cat = fig.add_subplot(gs[0, 1])
                ax_state = fig.add_subplot(gs[0, 2])
                ax_memo_ma = fig.add_subplot(gs[1, :2]) if memo_ma is not None else None
                ax_memo_ck = fig.add_subplot(gs[2, :2]) if memo_ck is not None else None
                ax_audio = fig.add_subplot(gs[3, :2])
                ax_memory = fig.add_subplot(gs[1:4, 2]) if show_memory else None
            else:
                gs = fig.add_gridspec(
                    2,
                    n_cols,
                    height_ratios=[3, 1.5],
                    width_ratios=[1, 1, 0.8],
                )
                ax_conv = []
                ax_hist = fig.add_subplot(gs[0, 0])
                ax_cat = fig.add_subplot(gs[0, 1])
                ax_state = fig.add_subplot(gs[0, 2])
                ax_memo_ma = None
                ax_memo_ck = None
                ax_audio = fig.add_subplot(gs[1, :2])
                ax_memory = fig.add_subplot(gs[1, 2]) if show_memory else None

            time_seconds = frame_idx * decimation_factor / sample_rate

            fig.suptitle(
                f"Frame {frame_idx + 1}/{n_frames} | t = {time_seconds:.3f}s | "
                f"NbPts: {result.nb_pts}",
                fontsize=14,
                fontweight="bold",
                color="white",
            )

            ax_state.set_xlim(0, 1)
            ax_state.set_ylim(0, 3)
            ax_state.axis("off")

            states_info = [
                (AttractorState.SUIVI, 2, "S"),
                (AttractorState.ACCROCHE, 1, "A"),
                (AttractorState.ATTENTE, 0, "W"),
            ]

            for state, y_pos, label in states_info:
                is_active = result.state == state
                color = state_colors[state] if is_active else "#333333"
                alpha = 1.0 if is_active else 0.3

                rect = plt.Rectangle(
                    (0.1, y_pos + 0.1),
                    0.8,
                    0.8,
                    facecolor=color,
                    edgecolor="white" if is_active else "#555555",
                    linewidth=2 if is_active else 1,
                    alpha=alpha,
                )
                ax_state.add_patch(rect)

                ax_state.text(
                    0.5,
                    y_pos + 0.5,
                    label,
                    fontsize=12,
                    fontweight="bold",
                    color="white" if is_active else "#666666",
                    ha="center",
                    va="center",
                )

            if has_convergence and ax_conv:
                for i, (ax_c, conv_iter) in enumerate(
                    zip(ax_conv, result.convergence_history, strict=False)
                ):
                    ax_c.set_facecolor("black")

                    hist_conv = conv_iter.histogram
                    mean_bins_conv = conv_iter.mean_bins
                    var_bins_conv = conv_iter.var_bins

                    if hist_conv is not None and hist_conv.size > 0 and len(mean_bins_conv) > 0:
                        extent_conv = [
                            mean_bins_conv[0] - 0.5,
                            mean_bins_conv[-1] + 0.5,
                            var_bins_conv[0] - 0.5,
                            var_bins_conv[-1] + 0.5,
                        ]
                        ax_c.imshow(
                            hist_conv,
                            aspect="auto",
                            origin="lower",
                            cmap="hot",
                            vmin=0,
                            vmax=max(hist_conv.max(), 1),
                            extent=extent_conv,
                        )

                        bounds_x = conv_iter.bounds_x
                        bounds_y = conv_iter.bounds_y
                        rect_start = plt.Rectangle(
                            (bounds_x[0], bounds_y[0]),
                            bounds_x[1] - bounds_x[0],
                            bounds_y[1] - bounds_y[0],
                            linewidth=1.5,
                            edgecolor="red",
                            facecolor="none",
                            linestyle="--",
                        )
                        ax_c.add_patch(rect_start)

                        new_bounds_x = conv_iter.new_bounds_x
                        new_bounds_y = conv_iter.new_bounds_y
                        if new_bounds_x != bounds_x or new_bounds_y != bounds_y:
                            rect_end = plt.Rectangle(
                                (new_bounds_x[0], new_bounds_y[0]),
                                new_bounds_x[1] - new_bounds_x[0],
                                new_bounds_y[1] - new_bounds_y[0],
                                linewidth=1.5,
                                edgecolor="lime",
                                facecolor="none",
                            )
                            ax_c.add_patch(rect_end)

                    ax_c.set_xlim(-0.5, 50.5)
                    ax_c.set_ylim(-0.5, 25.5)

                    status = "✓" if conv_iter.converged else "→"
                    ax_c.set_title(
                        f"Iter {i + 1} {status} | NbPts={conv_iter.nb_pts_no_origin}",
                        fontsize=9,
                        color="white",
                    )
                    ax_c.tick_params(labelsize=7, colors="white")

            if result.histogram is not None:
                hist = result.histogram
                mean_bins = result.mean_bins
                var_bins = result.var_bins

                if mean_bins is not None and var_bins is not None:
                    extent = [
                        mean_bins[0] - 0.5,
                        mean_bins[-1] + 0.5,
                        var_bins[0] - 0.5,
                        var_bins[-1] + 0.5,
                    ]
                else:
                    extent = None

                im1 = ax_hist.imshow(
                    hist,
                    aspect="auto",
                    origin="lower",
                    cmap="hot",
                    vmin=0,
                    vmax=max(hist.max(), 1),
                    extent=extent,
                )
                ax_hist.set_xlim(-0.5, 50.5)
                ax_hist.set_ylim(-0.5, 50.5)
                ax_hist.set_xlabel("Mean")
                ax_hist.set_ylabel("Variation")
                ax_hist.set_title(f"2D Histogram (Rmax={result.rmax:.0f})", fontsize=11)
                plt.colorbar(im1, ax=ax_hist, shrink=0.8)

                frame_cat = (
                    frame_categorizations[frame_idx]
                    if frame_categorizations is not None and frame_idx < len(frame_categorizations)
                    else None
                )

                if frame_cat is not None:
                    labels = frame_cat.labels
                    num_categories = frame_cat.num_categories

                    base_cmap = plt.colormaps.get_cmap("Set2").resampled(max(num_categories + 1, 2))
                    colors = [base_cmap(i) for i in range(max(num_categories + 1, 2))]
                    colors[0] = (0.15, 0.15, 0.15, 1.0)
                    cmap = ListedColormap(colors)

                    ax_cat.imshow(
                        labels,
                        aspect="auto",
                        origin="lower",
                        cmap=cmap,
                        interpolation="nearest",
                        vmin=0,
                        vmax=max(num_categories, 1),
                        extent=extent,
                    )

                    legend_patches = [Patch(facecolor=colors[0], edgecolor="white", label="0")]
                    for cat_id in range(1, num_categories + 1):
                        legend_patches.append(
                            Patch(facecolor=colors[cat_id], edgecolor="white", label=str(cat_id))
                        )
                    ax_cat.legend(
                        handles=legend_patches,
                        loc="upper right",
                        fontsize=9,
                        framealpha=0.8,
                        facecolor="black",
                        edgecolor="white",
                    )

                    if frame_cat.category_medians is not None:
                        for cat_id, (med_x, med_y) in frame_cat.category_medians.items():
                            if cat_id > 0 and cat_id <= num_categories:
                                ax_cat.text(
                                    med_x,
                                    med_y,
                                    str(cat_id),
                                    fontsize=14,
                                    fontweight="bold",
                                    color="white",
                                    ha="center",
                                    va="center",
                                    bbox={
                                        "boxstyle": "circle,pad=0.3",
                                        "facecolor": colors[cat_id],
                                        "edgecolor": "white",
                                        "linewidth": 2,
                                    },
                                )
                else:
                    ax_cat.imshow(
                        hist,
                        aspect="auto",
                        origin="lower",
                        cmap="gray",
                        interpolation="nearest",
                        vmin=0,
                        vmax=max(hist.max(), 1),
                        extent=extent,
                    )
                    num_categories = 0

                ax_cat.set_xlim(-0.5, 50.5)
                ax_cat.set_ylim(-0.5, 50.5)
                ax_cat.set_xlabel("Mean")
                ax_cat.set_ylabel("Variation")
                title_cat = f"Categorization ({num_categories} cat)"
                if result.med_x is not None:
                    title_cat += f" | Med=({result.med_x:.1f}, {result.med_y:.1f})"
                ax_cat.set_title(title_cat, fontsize=11)

            else:
                ax_hist.text(0.5, 0.5, "No histogram", ha="center", va="center")
                ax_hist.set_title("2D Histogram")
                ax_cat.text(0.5, 0.5, "No data", ha="center", va="center")
                ax_cat.set_title("Categorization")

            if ax_memo_ma is not None and memo_ma is not None:
                sample_pos = int(time_seconds * sample_rate)
                n_channels = memo_ma.shape[0]

                ax_memo_ma.imshow(
                    memo_ma,
                    aspect="auto",
                    origin="lower",
                    cmap="hot",
                    interpolation="nearest",
                )

                if show_memory:
                    segment_colors = [
                        "#00FF00",
                        "#00FFFF",
                        "#FF00FF",
                        "#FFFF00",
                        "#FF8800",
                        "#00FF88",
                    ]
                    for seg_idx, seg in enumerate(segments):
                        if seg.end_frame <= frame_idx:
                            start_sample = seg.start_frame * decimation_factor
                            end_sample = (seg.end_frame + 1) * decimation_factor
                            color = segment_colors[seg_idx % len(segment_colors)]
                            ax_memo_ma.axvspan(
                                start_sample,
                                end_sample,
                                alpha=0.15,
                                color=color,
                                zorder=1,
                            )
                            ax_memo_ma.axvline(
                                start_sample, color=color, linewidth=1, linestyle="--", alpha=0.7
                            )
                            ax_memo_ma.axvline(
                                end_sample, color=color, linewidth=1, linestyle="--", alpha=0.7
                            )
                            ax_memo_ma.text(
                                (start_sample + end_sample) / 2,
                                n_channels - 3,
                                f"S{seg.class_id}",
                                fontsize=8,
                                color=color,
                                ha="center",
                                va="top",
                                fontweight="bold",
                            )

                ax_memo_ma.axvline(sample_pos, color="cyan", linewidth=2)
                ax_memo_ma.set_xlabel("Samples")
                ax_memo_ma.set_ylabel("Channel")
                ax_memo_ma.set_title("memo_ma (amplitude)", fontsize=11)

            if ax_memo_ck is not None and memo_ck is not None:
                sample_pos = int(time_seconds * sample_rate)
                n_channels = memo_ck.shape[0]

                ax_memo_ck.imshow(
                    memo_ck,
                    aspect="auto",
                    origin="lower",
                    cmap="hot",
                    interpolation="nearest",
                )

                if show_memory:
                    segment_colors = [
                        "#00FF00",
                        "#00FFFF",
                        "#FF00FF",
                        "#FFFF00",
                        "#FF8800",
                        "#00FF88",
                    ]
                    for seg_idx, seg in enumerate(segments):
                        if seg.end_frame <= frame_idx:
                            start_sample = seg.start_frame * decimation_factor
                            end_sample = (seg.end_frame + 1) * decimation_factor
                            color = segment_colors[seg_idx % len(segment_colors)]
                            ax_memo_ck.axvspan(
                                start_sample,
                                end_sample,
                                alpha=0.15,
                                color=color,
                                zorder=1,
                            )
                            ax_memo_ck.axvline(
                                start_sample, color=color, linewidth=1, linestyle="--", alpha=0.7
                            )
                            ax_memo_ck.axvline(
                                end_sample, color=color, linewidth=1, linestyle="--", alpha=0.7
                            )
                            ax_memo_ck.text(
                                (start_sample + end_sample) / 2,
                                n_channels - 3,
                                f"S{seg.class_id}",
                                fontsize=8,
                                color=color,
                                ha="center",
                                va="top",
                                fontweight="bold",
                            )

                ax_memo_ck.axvline(sample_pos, color="cyan", linewidth=2)
                ax_memo_ck.set_xlabel("Samples")
                ax_memo_ck.set_ylabel("Channel")
                ax_memo_ck.set_title("memo_ck (periods)", fontsize=11)

            time_axis = np.arange(len(audio_signal)) / sr
            ax_audio.plot(time_axis, audio_signal, color="#2196F3", linewidth=0.5)
            ax_audio.axvline(time_seconds, color="red", linewidth=2, label="Position")
            ax_audio.fill_between(
                [0, time_seconds],
                -1,
                1,
                alpha=0.1,
                color=state_colors[result.state],
            )
            ax_audio.set_xlim(0, audio_duration)
            ax_audio.set_ylim(-1.1 * np.abs(audio_signal).max(), 1.1 * np.abs(audio_signal).max())
            ax_audio.set_xlabel("Time (s)")
            ax_audio.set_ylabel("Amplitude")
            ax_audio.set_title("Audio signal", fontsize=11)
            ax_audio.grid(True, alpha=0.3)

            if ax_memory is not None and show_memory:
                ax_memory.set_facecolor("black")
                ax_memory.axis("off")
                ax_memory.set_title("Memory", fontsize=11, color="white", pad=10)

                mem_bbox = ax_memory.get_position()
                slot_height = mem_bbox.height / max_memory_slots
                slot_width = mem_bbox.width

                segment_colors = ["#00FF00", "#00FFFF", "#FF00FF", "#FFFF00", "#FF8800", "#00FF88"]

                for slot_idx in range(max_memory_slots):
                    seg = segments[slot_idx]
                    color = segment_colors[slot_idx % len(segment_colors)]

                    slot_bottom = mem_bbox.y0 + (max_memory_slots - slot_idx - 1) * slot_height
                    slot_left = mem_bbox.x0

                    is_in_memory = seg.end_frame < frame_idx

                    ax_slot = fig.add_axes([slot_left, slot_bottom, slot_width, slot_height * 0.85])
                    ax_slot.set_facecolor("#1a1a1a")

                    if is_in_memory:
                        bx = seg.median_bounds_x
                        by = seg.median_bounds_y
                        std_bx = seg.std_bounds_x
                        std_by = seg.std_bounds_y

                        if seg.signature_histogram is not None:
                            sig_hist = seg.signature_histogram
                            if (
                                seg.signature_mean_bins is not None
                                and seg.signature_var_bins is not None
                            ):
                                extent = [
                                    seg.signature_mean_bins[0],
                                    seg.signature_mean_bins[-1],
                                    seg.signature_var_bins[0],
                                    seg.signature_var_bins[-1],
                                ]
                            else:
                                extent = [0, sig_hist.shape[1], 0, sig_hist.shape[0]]
                            ax_slot.imshow(
                                sig_hist,
                                aspect="auto",
                                origin="lower",
                                cmap="hot",
                                extent=extent,
                                alpha=0.8,
                            )

                            if bx and by:
                                margin_x = max(2, (bx[1] - bx[0]) * 0.3)
                                margin_y = max(2, (by[1] - by[0]) * 0.3)
                                ax_slot.set_xlim(bx[0] - margin_x, bx[1] + margin_x)
                                ax_slot.set_ylim(by[0] - margin_y, by[1] + margin_y)
                            else:
                                ax_slot.set_xlim(extent[0], extent[1])
                                ax_slot.set_ylim(extent[2], extent[3])
                        else:
                            ax_slot.set_xlim(0, 65)
                            ax_slot.set_ylim(0, 40)

                        if bx and by:
                            rect = plt.Rectangle(
                                (bx[0], by[0]),
                                bx[1] - bx[0],
                                by[1] - by[0],
                                facecolor="none",
                                edgecolor=color,
                                linewidth=2,
                                alpha=0.9,
                            )
                            ax_slot.add_patch(rect)

                            if std_bx and std_by:
                                rect_std = plt.Rectangle(
                                    (bx[0] - std_bx[0], by[0] - std_by[0]),
                                    (bx[1] + std_bx[1]) - (bx[0] - std_bx[0]),
                                    (by[1] + std_by[1]) - (by[0] - std_by[0]),
                                    facecolor="none",
                                    edgecolor=color,
                                    linewidth=1,
                                    linestyle="--",
                                    alpha=0.5,
                                )
                                ax_slot.add_patch(rect_std)

                        if seg.mean_med_x is not None and seg.mean_med_y is not None:
                            ax_slot.plot(
                                seg.mean_med_x,
                                seg.mean_med_y,
                                "o",
                                color="cyan",
                                markersize=6,
                                markeredgecolor="white",
                                markeredgewidth=1.5,
                                zorder=10,
                            )

                            sigma_x = seg.hist_std_x if seg.hist_std_x is not None else 1.0
                            sigma_y = seg.hist_std_y if seg.hist_std_y is not None else 1.0
                            if sigma_x > 0 and sigma_y > 0:
                                ellipse = Ellipse(
                                    (seg.mean_med_x, seg.mean_med_y),
                                    width=2 * sigma_x,
                                    height=2 * sigma_y,
                                    facecolor="none",
                                    edgecolor="cyan",
                                    linewidth=2,
                                    alpha=0.9,
                                    zorder=9,
                                )
                                ax_slot.add_patch(ellipse)

                        title_color = color if is_active else "white"
                        energy_str = f"E={seg.total_energy:.0f}" if seg.total_energy else ""
                        ax_slot.set_title(
                            f"S{seg.class_id} [{seg.start_frame}-{seg.end_frame}] {energy_str}",
                            fontsize=8,
                            color=title_color,
                            pad=2,
                        )

                        ax_slot.tick_params(colors="white", labelsize=5)
                        for spine in ax_slot.spines.values():
                            spine.set_color(color if is_active else "#444444")

                    else:
                        ax_slot.set_xlim(0, 1)
                        ax_slot.set_ylim(0, 1)
                        ax_slot.text(
                            0.5,
                            0.5,
                            "---",
                            fontsize=12,
                            color="#444444",
                            ha="center",
                            va="center",
                        )
                        ax_slot.axis("off")

            plt.tight_layout()

            frame_path = frames_dir / f"frame_{frame_idx:06d}.png"
            fig.savefig(frame_path, dpi=100, facecolor="black")

            if frame_idx % 10 == 0:
                logger.info("Frame %d/%d generated", frame_idx + 1, n_frames)

        plt.close(fig)

        logger.info("Encoding video with ffmpeg...")

        if temp_dir is not None:
            temp_video = temp_dir / "temp_video.mp4"
        else:
            temp_video = frames_dir / "temp_video.mp4"
        cmd_video = [
            "ffmpeg",
            "-y",
            "-framerate",
            str(fps),
            "-i",
            str(frames_dir / "frame_%06d.png"),
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-preset",
            "medium",
            str(temp_video),
        ]

        result_ffmpeg = subprocess.run(cmd_video, capture_output=True, text=True, check=False)
        if result_ffmpeg.returncode != 0:
            logger.error("ffmpeg error: %s", result_ffmpeg.stderr)
            raise RuntimeError(f"ffmpeg failed: {result_ffmpeg.stderr}")

        logger.info("Adding audio track...")
        cmd_audio = [
            "ffmpeg",
            "-y",
            "-i",
            str(temp_video),
            "-i",
            audio_path,
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-shortest",
            output_path,
        ]

        result_ffmpeg = subprocess.run(cmd_audio, capture_output=True, text=True, check=False)
        if result_ffmpeg.returncode != 0:
            logger.error("ffmpeg audio error: %s", result_ffmpeg.stderr)
            raise RuntimeError(f"ffmpeg failed: {result_ffmpeg.stderr}")

        logger.info("Video created: %s", output_path)

    finally:
        plt.style.use("default")

        if temp_dir is not None:
            shutil.rmtree(temp_dir)
            logger.info("Temporary files cleaned")
        else:
            logger.info("Frames kept in: %s", save_frames_dir)


def plot_convergence_iterations(
    params: ConvergencePlotParams,
    output_dir: Path | str,
) -> list[Path]:
    """Visualizes convergence iterations for a given frame.

    Creates one image per iteration showing:
    - 2D histogram
    - Zone bounds (rectangle)
    - Categorized zone (contour)
    - Statistics (NbPts, Rmax, convergence)

    Args:
        params: Convergence plot parameters.
        output_dir: Output directory for images.

    Returns:
        List of paths to created images.
    """
    config = params.config or AttractorPlotConfig()
    convergence_history = params.convergence_history
    frame_index = params.frame_index
    data_range_x = params.data_range_x
    data_range_y = params.data_range_y

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    saved_paths = []

    for iteration_data in convergence_history:
        fig, ax = plt.subplots(figsize=(10, 8))
        fig.patch.set_facecolor("black")
        ax.set_facecolor("black")

        iter_num = iteration_data.iteration
        histogram = iteration_data.histogram
        mean_bins = iteration_data.mean_bins
        var_bins = iteration_data.var_bins
        category_mask = iteration_data.category_mask
        bounds_x = iteration_data.bounds_x
        bounds_y = iteration_data.bounds_y
        new_bounds_x = iteration_data.new_bounds_x
        new_bounds_y = iteration_data.new_bounds_y

        if (
            histogram is not None
            and histogram.size > 0
            and len(mean_bins) > 0
            and len(var_bins) > 0
        ):
            extent = [
                mean_bins[0] - 0.5,
                mean_bins[-1] + 0.5,
                var_bins[0] - 0.5,
                var_bins[-1] + 0.5,
            ]
            im = ax.imshow(
                histogram,
                origin="lower",
                aspect="auto",
                extent=extent,
                cmap=config.colormap,
                interpolation="nearest",
            )
            plt.colorbar(im, ax=ax, label="Count")

            rect_start = plt.Rectangle(
                (bounds_x[0], bounds_y[0]),
                bounds_x[1] - bounds_x[0],
                bounds_y[1] - bounds_y[0],
                linewidth=2,
                edgecolor="red",
                facecolor="none",
                linestyle="--",
                label="Start bounds",
            )
            ax.add_patch(rect_start)

            if new_bounds_x != bounds_x or new_bounds_y != bounds_y:
                rect_end = plt.Rectangle(
                    (new_bounds_x[0], new_bounds_y[0]),
                    new_bounds_x[1] - new_bounds_x[0],
                    new_bounds_y[1] - new_bounds_y[0],
                    linewidth=2,
                    edgecolor="lime",
                    facecolor="none",
                    linestyle="-",
                    label="End bounds",
                )
                ax.add_patch(rect_end)

            if category_mask is not None and np.any(category_mask):
                ax.contour(
                    category_mask,
                    levels=[0.5],
                    colors=["yellow"],
                    linewidths=2,
                    extent=extent,
                )

        if data_range_x is not None:
            ax.set_xlim(data_range_x)
        if data_range_y is not None:
            ax.set_ylim(data_range_y)

        status = "✓ CONVERGED" if iteration_data.converged else "→ Continue"
        bx0, bx1 = bounds_x[0], bounds_x[1]
        by0, by1 = bounds_y[0], bounds_y[1]
        nbx0, nbx1 = new_bounds_x[0], new_bounds_x[1]
        nby0, nby1 = new_bounds_y[0], new_bounds_y[1]
        title = (
            f"Frame {frame_index} - Iteration {iter_num + 1}\n"
            f"NbPts={iteration_data.nb_pts} (excl. origin: {iteration_data.nb_pts_no_origin}), "
            f"Rmax={iteration_data.rmax:.0f}\n"
            f"Bounds X: [{bx0:.1f}, {bx1:.1f}] → [{nbx0:.1f}, {nbx1:.1f}]\n"
            f"Bounds Y: [{by0:.1f}, {by1:.1f}] → [{nby0:.1f}, {nby1:.1f}]\n"
            f"{status}"
        )
        ax.set_title(title, fontsize=10, color="white")
        ax.set_xlabel("Mean", color="white")
        ax.set_ylabel("Variation", color="white")
        ax.tick_params(colors="white")
        for spine in ax.spines.values():
            spine.set_color("white")
        ax.legend(loc="upper right", facecolor="black", edgecolor="white", labelcolor="white")
        ax.grid(True, alpha=0.3, color="white")

        output_path = output_dir / f"frame_{frame_index:04d}_convergence_iter{iter_num + 1}.png"
        plt.tight_layout()
        fig.savefig(output_path, dpi=config.dpi, bbox_inches="tight")
        plt.close(fig)

        saved_paths.append(output_path)
        logger.info("Convergence iter %d saved: %s", iter_num + 1, output_path)

    return saved_paths


def plot_convergence_summary(
    params: ConvergencePlotParams,
    output_path: Path | str,
) -> Path:
    """Creates summary image with all iterations side by side.

    Args:
        params: Convergence plot parameters.
        output_path: Output path for image.

    Returns:
        Path to created image.
    """
    config = params.config or AttractorPlotConfig()
    convergence_history = params.convergence_history
    frame_index = params.frame_index
    data_range_x = params.data_range_x
    data_range_y = params.data_range_y

    n_iterations = len(convergence_history)
    if n_iterations == 0:
        return None

    fig, axes = plt.subplots(1, n_iterations, figsize=(6 * n_iterations, 6))
    fig.patch.set_facecolor("black")
    if n_iterations == 1:
        axes = [axes]

    for i, iteration_data in enumerate(convergence_history):
        ax = axes[i]
        ax.set_facecolor("black")
        histogram = iteration_data.histogram
        mean_bins = iteration_data.mean_bins
        var_bins = iteration_data.var_bins
        category_mask = iteration_data.category_mask
        bounds_x = iteration_data.bounds_x
        bounds_y = iteration_data.bounds_y
        new_bounds_x = iteration_data.new_bounds_x
        new_bounds_y = iteration_data.new_bounds_y

        if (
            histogram is not None
            and histogram.size > 0
            and len(mean_bins) > 0
            and len(var_bins) > 0
        ):
            extent = [
                mean_bins[0] - 0.5,
                mean_bins[-1] + 0.5,
                var_bins[0] - 0.5,
                var_bins[-1] + 0.5,
            ]
            ax.imshow(
                histogram,
                origin="lower",
                aspect="auto",
                extent=extent,
                cmap=config.colormap,
                interpolation="nearest",
            )

            rect_start = plt.Rectangle(
                (bounds_x[0], bounds_y[0]),
                bounds_x[1] - bounds_x[0],
                bounds_y[1] - bounds_y[0],
                linewidth=2,
                edgecolor="red",
                facecolor="none",
                linestyle="--",
            )
            ax.add_patch(rect_start)

            if new_bounds_x != bounds_x or new_bounds_y != bounds_y:
                rect_end = plt.Rectangle(
                    (new_bounds_x[0], new_bounds_y[0]),
                    new_bounds_x[1] - new_bounds_x[0],
                    new_bounds_y[1] - new_bounds_y[0],
                    linewidth=2,
                    edgecolor="lime",
                    facecolor="none",
                )
                ax.add_patch(rect_end)

            if category_mask is not None and np.any(category_mask):
                ax.contour(
                    category_mask,
                    levels=[0.5],
                    colors=["yellow"],
                    linewidths=2,
                    extent=extent,
                )

        if data_range_x is not None:
            ax.set_xlim(data_range_x)
        if data_range_y is not None:
            ax.set_ylim(data_range_y)

        status = "✓" if iteration_data.converged else "→"
        ax.set_title(
            f"Iter {i + 1} {status}\n"
            f"NbPts={iteration_data.nb_pts_no_origin}, Rmax={iteration_data.rmax:.0f}",
            fontsize=10,
            color="white",
        )
        ax.set_xlabel("Mean", color="white")
        ax.set_ylabel("Variation", color="white")
        ax.tick_params(colors="white")
        for spine in ax.spines.values():
            spine.set_color("white")
        ax.grid(True, alpha=0.3, color="white")

    fig.suptitle(
        f"Frame {frame_index} - Convergence ({n_iterations} iterations)", fontsize=12, color="white"
    )
    plt.tight_layout()

    output_path = Path(output_path)
    fig.savefig(output_path, dpi=config.dpi, bbox_inches="tight")
    plt.close(fig)

    logger.info("Convergence summary saved: %s", output_path)
    return output_path


def plot_segment_signatures(
    segments: list[DetectedSegment],
    output_path: str | Path,
    data_range_x: tuple[float, float] | None = None,
    data_range_y: tuple[float, float] | None = None,
    config: AttractorPlotConfig | None = None,
) -> Path:
    """Visualizes class signatures of all detected segments.

    Displays for each segment:
    - Median position (point) of medians across all frames
    - Median bounds (filled rectangle)
    - Standard deviation of bounds (dashed rectangle)

    Args:
        segments: List of detected segments with signatures.
        output_path: Output path for image.
        data_range_x: Data range on X for consistent axes.
        data_range_y: Data range on Y for consistent axes.
        config: Visualization configuration.

    Returns:
        Path to created file.
    """
    if config is None:
        config = AttractorPlotConfig()

    n_segments = len(segments)
    if n_segments == 0:
        logger.warning("No segment to visualize")
        return None

    n_cols = min(3, n_segments)
    n_rows = (n_segments + n_cols - 1) // n_cols

    fig, axes = plt.subplots(n_rows, n_cols, figsize=(5 * n_cols, 4 * n_rows))
    fig.patch.set_facecolor("black")

    if n_segments == 1:
        axes = np.array([[axes]])
    elif n_rows == 1:
        axes = axes.reshape(1, -1)

    for idx, seg in enumerate(segments):
        row, col = idx // n_cols, idx % n_cols
        ax = axes[row, col]
        ax.set_facecolor("black")

        if seg.median_bounds_x is None or seg.median_bounds_y is None:
            ax.text(
                0.5,
                0.5,
                "No statistics",
                ha="center",
                va="center",
                fontsize=10,
                color="white",
                transform=ax.transAxes,
            )
            ax.set_title(f"Segment {seg.class_id}", fontsize=10, color="white")
            continue

        bx = seg.median_bounds_x
        by = seg.median_bounds_y
        rect_median = plt.Rectangle(
            (bx[0], by[0]),
            bx[1] - bx[0],
            by[1] - by[0],
            fill=False,
            edgecolor="lime",
            linewidth=2,
            linestyle="-",
            label="Median bounds",
        )
        ax.add_patch(rect_median)

        if seg.std_bounds_x and seg.std_bounds_y:
            std_x = seg.std_bounds_x
            std_y = seg.std_bounds_y
            rect_std = plt.Rectangle(
                (bx[0] - std_x[0], by[0] - std_y[0]),
                (bx[1] + std_x[1]) - (bx[0] - std_x[0]),
                (by[1] + std_y[1]) - (by[0] - std_y[0]),
                fill=False,
                edgecolor="cyan",
                linewidth=1.5,
                linestyle="--",
                label="±σ",
            )
            ax.add_patch(rect_std)

        if seg.mean_med_x is not None and seg.mean_med_y is not None:
            ax.plot(
                seg.mean_med_x,
                seg.mean_med_y,
                "o",
                markersize=10,
                color="yellow",
                markeredgecolor="white",
                markeredgewidth=1.5,
                label="Mean",
            )

            if seg.std_med_x is not None and seg.std_med_y is not None:
                ellipse = Ellipse(
                    (seg.mean_med_x, seg.mean_med_y),
                    width=2 * seg.std_med_x,
                    height=2 * seg.std_med_y,
                    facecolor="none",
                    edgecolor="yellow",
                    linewidth=1.5,
                    linestyle="--",
                    alpha=0.8,
                    label="±σ med.",
                )
                ax.add_patch(ellipse)

        if data_range_x is not None:
            ax.set_xlim(data_range_x)
        if data_range_y is not None:
            ax.set_ylim(data_range_y)

        mean_x = seg.mean_med_x if seg.mean_med_x is not None else 0.0
        mean_y = seg.mean_med_y if seg.mean_med_y is not None else 0.0
        ax.set_title(
            f"S{seg.class_id} [{seg.start_frame}-{seg.end_frame}]\n"
            f"Mean=({mean_x:.1f}, {mean_y:.1f}), E={seg.total_energy}",
            fontsize=10,
            color="white",
        )
        ax.set_xlabel("Mean", color="white")
        ax.set_ylabel("Variation", color="white")
        ax.tick_params(colors="white")
        for spine in ax.spines.values():
            spine.set_color("white")
        ax.grid(True, alpha=0.2, color="white")
        ax.legend(loc="lower right", fontsize=8, facecolor="black", labelcolor="white")

    for idx in range(n_segments, n_rows * n_cols):
        row, col = idx // n_cols, idx % n_cols
        axes[row, col].set_visible(False)

    fig.suptitle("Class Signatures", fontsize=14, color="white")
    plt.tight_layout()

    output_path = Path(output_path)
    fig.savefig(output_path, dpi=config.dpi, bbox_inches="tight", facecolor="black")
    plt.close(fig)

    logger.info("Segment signatures saved: %s", output_path)
    return output_path


@dataclass
class AndSegmentAnalysis:
    """Pre-computed analysis for an AND segment.

    Attributes:
        segment_idx: Index of the AND segment.
        spectral_profile: Mean spectral profile across segment frames.
        f0_channel: Detected F0 channel index (or None).
        invariances: Invariance values relative to F0 (or None).
    """

    segment_idx: int
    spectral_profile: np.ndarray
    f0_channel: int | None = None
    invariances: np.ndarray | None = None


def create_dual_attractor_video(
    results_temporal: list[FrameResult],
    results_spatial: list[FrameResult],
    segments_temporal: list[DetectedSegment],
    segments_spatial: list[DetectedSegment],
    audio_path: str,
    output_path: str,
    audio_signal: np.ndarray = None,
    sample_rate: int = 16000,
    decimation_factor: int = 100,
    save_frames_dir: str | Path = None,
    memo_ma_int: np.ndarray = None,
    and_segment_analyses: list[AndSegmentAnalysis] | None = None,
) -> None:
    """Creates video showing dual attractor evolution (temporal + spatial).

    Layout:
    - Row 0: Temporal Histogram | Spatial Histogram | States (T/S)
    - Row 1: memo_ma_int with AND mask overlay
    - Row 2: Audio waveform

    Args:
        results_temporal: Frame-by-frame results from temporal attractor.
        results_spatial: Frame-by-frame results from spatial attractor.
        segments_temporal: Detected segments (temporal).
        segments_spatial: Detected segments (spatial).
        audio_path: Path to audio file.
        output_path: Output path for video (.mp4).
        audio_signal: Audio signal (optional).
        sample_rate: Sampling rate.
        decimation_factor: Temporal decimation factor.
        save_frames_dir: Directory to save PNG frames.
        memo_ma_int: Integrated amplitude memory for display.
        and_segment_analyses: Pre-computed spectral analysis for AND segments.
            If None, spectral invariance panel is not shown.
    """
    n_frames = min(len(results_temporal), len(results_spatial))

    if audio_signal is None:
        audio_signal, sr = sf.read(audio_path)
        if len(audio_signal.shape) > 1:
            audio_signal = audio_signal[:, 0]
    else:
        sr = sample_rate

    audio_duration = len(audio_signal) / sr
    fps = n_frames / audio_duration

    logger.info(
        "Creating dual attractor video: %d frames, %.2fs, %.1f fps",
        n_frames,
        audio_duration,
        fps,
    )

    if save_frames_dir is not None:
        save_frames_dir = Path(save_frames_dir)
        save_frames_dir.mkdir(parents=True, exist_ok=True)
        frames_dir = save_frames_dir
        temp_dir = None
        logger.info("Frames saved in: %s", save_frames_dir)
    else:
        temp_dir = Path(tempfile.mkdtemp(prefix="dual_attractor_video_"))
        frames_dir = temp_dir / "frames"
        frames_dir.mkdir()

    state_colors = {
        AttractorState.ATTENTE: "#CCCCCC",
        AttractorState.ACCROCHE: "#FF8800",
        AttractorState.SUIVI: "#00AA00",
    }

    binary_states = []
    for i in range(n_frames):
        t_bit = (
            1 if results_temporal[i].state in (AttractorState.ACCROCHE, AttractorState.SUIVI) else 0
        )
        s_bit = (
            1 if results_spatial[i].state in (AttractorState.ACCROCHE, AttractorState.SUIVI) else 0
        )
        binary_states.append((t_bit, s_bit))

    and_segments = []
    seg_start = 0
    current_bits = binary_states[0] if n_frames > 0 else (0, 0)

    for i in range(1, n_frames):
        if binary_states[i] != current_bits:
            code = f"{current_bits[0]}{current_bits[1]}"
            and_segments.append((seg_start, i - 1, current_bits[0], current_bits[1], code))
            seg_start = i
            current_bits = binary_states[i]

    if n_frames > 0:
        code = f"{current_bits[0]}{current_bits[1]}"
        and_segments.append((seg_start, n_frames - 1, current_bits[0], current_bits[1], code))

    try:
        plt.style.use("dark_background")

        fig = plt.figure(figsize=(24, 14), dpi=100)
        fig.set_facecolor("black")

        for frame_idx in range(n_frames):
            result_temp = results_temporal[frame_idx]
            result_spat = results_spatial[frame_idx]

            fig.clear()
            fig.set_facecolor("black")

            gs = fig.add_gridspec(
                3,
                6,
                height_ratios=[3, 1.5, 1],
                width_ratios=[1, 1, 0.35, 0.45, 0.45, 0.8],
                hspace=0.3,
                wspace=0.3,
            )

            ax_hist_temp = fig.add_subplot(gs[0, 0])
            ax_hist_spat = fig.add_subplot(gs[0, 1])
            ax_states = fig.add_subplot(gs[0, 2])
            ax_sig_temp = fig.add_subplot(gs[0, 3])
            ax_sig_spat = fig.add_subplot(gs[0, 4])
            ax_spectral = fig.add_subplot(gs[0, 5])
            ax_memo = fig.add_subplot(gs[1, :])
            ax_audio = fig.add_subplot(gs[2, :])

            time_seconds = frame_idx * decimation_factor / sample_rate

            both_active = result_temp.state in (
                AttractorState.ACCROCHE,
                AttractorState.SUIVI,
            ) and result_spat.state in (AttractorState.ACCROCHE, AttractorState.SUIVI)
            and_status = "✓ AND" if both_active else "✗ AND"
            and_color = "#00FF00" if both_active else "#FF4444"

            fig.suptitle(
                f"Frame {frame_idx + 1}/{n_frames} | t = {time_seconds:.3f}s | {and_status}",
                fontsize=14,
                fontweight="bold",
                color=and_color,
            )

            if result_temp.histogram is not None:
                hist = result_temp.histogram
                mean_bins = result_temp.mean_bins
                var_bins = result_temp.var_bins

                if mean_bins is not None and var_bins is not None and len(mean_bins) > 0:
                    extent = [
                        mean_bins[0] - 0.5,
                        mean_bins[-1] + 0.5,
                        var_bins[0] - 0.5,
                        var_bins[-1] + 0.5,
                    ]
                    ax_hist_temp.imshow(
                        hist,
                        aspect="auto",
                        origin="lower",
                        cmap="hot",
                        vmin=0,
                        vmax=max(hist.max(), 1),
                        extent=extent,
                    )

                    bounds_x = result_temp.bounds_x
                    bounds_y = result_temp.bounds_y
                    rect = plt.Rectangle(
                        (bounds_x[0], bounds_y[0]),
                        bounds_x[1] - bounds_x[0],
                        bounds_y[1] - bounds_y[0],
                        linewidth=2,
                        edgecolor="cyan",
                        facecolor="none",
                    )
                    ax_hist_temp.add_patch(rect)

            current_seg_temp = None
            for seg in segments_temporal:
                if seg.end_frame < frame_idx:
                    current_seg_temp = seg.class_id

            state_color_temp = state_colors[result_temp.state]
            seg_label_temp = f"T_{current_seg_temp}" if current_seg_temp is not None else "—"
            title_temp = f"TEMPORAL [{seg_label_temp}] | {result_temp.state.name}"
            ax_hist_temp.set_title(
                f"{title_temp} | NbPts={result_temp.nb_pts}",
                fontsize=11,
                color=state_color_temp,
            )
            ax_hist_temp.set_xlabel("Mean (temporal)", fontsize=9)
            ax_hist_temp.set_ylabel("Variation (temporal)", fontsize=9)
            ax_hist_temp.set_xlim(-0.5, 50.5)
            ax_hist_temp.set_ylim(-0.5, 30.5)

            if result_spat.histogram is not None:
                hist = result_spat.histogram
                mean_bins = result_spat.mean_bins
                var_bins = result_spat.var_bins

                if mean_bins is not None and var_bins is not None and len(mean_bins) > 0:
                    extent = [
                        mean_bins[0] - 0.5,
                        mean_bins[-1] + 0.5,
                        var_bins[0] - 0.5,
                        var_bins[-1] + 0.5,
                    ]
                    ax_hist_spat.imshow(
                        hist,
                        aspect="auto",
                        origin="lower",
                        cmap="hot",
                        vmin=0,
                        vmax=max(hist.max(), 1),
                        extent=extent,
                    )

                    bounds_x = result_spat.bounds_x
                    bounds_y = result_spat.bounds_y
                    rect = plt.Rectangle(
                        (bounds_x[0], bounds_y[0]),
                        bounds_x[1] - bounds_x[0],
                        bounds_y[1] - bounds_y[0],
                        linewidth=2,
                        edgecolor="lime",
                        facecolor="none",
                    )
                    ax_hist_spat.add_patch(rect)

            current_seg_spat = None
            for seg in segments_spatial:
                if seg.end_frame < frame_idx:
                    current_seg_spat = seg.class_id

            state_color_spat = state_colors[result_spat.state]
            seg_label_spat = f"S_{current_seg_spat}" if current_seg_spat is not None else "—"
            title_spat = f"SPATIAL [{seg_label_spat}] | {result_spat.state.name}"
            ax_hist_spat.set_title(
                f"{title_spat} | NbPts={result_spat.nb_pts}",
                fontsize=11,
                color=state_color_spat,
            )
            ax_hist_spat.set_xlabel("Mean (spatial)", fontsize=9)
            ax_hist_spat.set_ylabel("Variation (spatial)", fontsize=9)
            ax_hist_spat.set_xlim(-0.5, 50.5)
            ax_hist_spat.set_ylim(-0.5, 30.5)

            ax_states.set_xlim(0, 2)
            ax_states.set_ylim(0, 4.5)
            ax_states.axis("off")
            ax_states.set_title("States", fontsize=11, color="white")

            for state, y_pos, label in [
                (AttractorState.SUIVI, 2, "S"),
                (AttractorState.ACCROCHE, 1, "A"),
                (AttractorState.ATTENTE, 0, "W"),
            ]:
                is_active = result_temp.state == state
                color = state_colors[state] if is_active else "#333333"
                rect = plt.Rectangle(
                    (0.1, y_pos + 0.1),
                    0.8,
                    0.8,
                    facecolor=color if is_active else "none",
                    edgecolor=color,
                    linewidth=2 if is_active else 1,
                    alpha=1.0 if is_active else 0.3,
                )
                ax_states.add_patch(rect)
                ax_states.text(
                    0.5,
                    y_pos + 0.5,
                    label,
                    fontsize=10,
                    fontweight="bold" if is_active else "normal",
                    color="black" if is_active else "#666666",
                    ha="center",
                    va="center",
                )

            for state, y_pos, label in [
                (AttractorState.SUIVI, 2, "S"),
                (AttractorState.ACCROCHE, 1, "A"),
                (AttractorState.ATTENTE, 0, "W"),
            ]:
                is_active = result_spat.state == state
                color = state_colors[state] if is_active else "#333333"
                rect = plt.Rectangle(
                    (1.1, y_pos + 0.1),
                    0.8,
                    0.8,
                    facecolor=color if is_active else "none",
                    edgecolor=color,
                    linewidth=2 if is_active else 1,
                    alpha=1.0 if is_active else 0.3,
                )
                ax_states.add_patch(rect)
                ax_states.text(
                    1.5,
                    y_pos + 0.5,
                    label,
                    fontsize=10,
                    fontweight="bold" if is_active else "normal",
                    color="black" if is_active else "#666666",
                    ha="center",
                    va="center",
                )

            ax_states.text(0.5, -0.3, "TEMP", fontsize=9, color="cyan", ha="center")
            ax_states.text(1.5, -0.3, "SPAT", fontsize=9, color="lime", ha="center")

            pair_label = f"({seg_label_temp}, {seg_label_spat})"
            pair_color = "white" if both_active else "#666666"
            ax_states.text(
                1.0,
                3.7,
                pair_label,
                fontsize=12,
                fontweight="bold",
                color=pair_color,
                ha="center",
                va="center",
                bbox={"boxstyle": "round,pad=0.3", "facecolor": "#222222", "edgecolor": pair_color},
            )

            completed_segs_temp = [seg for seg in segments_temporal if seg.end_frame < frame_idx]
            n_completed_temp = len(completed_segs_temp)

            ax_sig_temp.set_facecolor("#1a1a1a")
            if n_completed_temp > 0:
                valid_sigs = [
                    seg.signature_histogram
                    for seg in completed_segs_temp
                    if seg.signature_histogram is not None
                ]
                if valid_sigs:
                    max_h = max(s.shape[0] for s in valid_sigs)
                    max_w = max(s.shape[1] for s in valid_sigs)
                    max_sigs = min(len(valid_sigs), 4)
                    stacked = np.zeros((max_sigs * (max_h + 2), max_w))

                    for i, sig_hist in enumerate(valid_sigs[-max_sigs:]):
                        h, w = sig_hist.shape
                        y_start = i * (max_h + 2)
                        stacked[y_start : y_start + h, :w] = sig_hist

                    ax_sig_temp.imshow(
                        stacked,
                        aspect="auto",
                        origin="lower",
                        cmap="hot",
                        interpolation="nearest",
                    )
                ax_sig_temp.set_title(
                    f"SIG T ({n_completed_temp} seg)",
                    fontsize=10,
                    color="cyan",
                    fontweight="bold",
                )
            else:
                ax_sig_temp.set_title("SIG T (0 seg)", fontsize=10, color="#666666")
            ax_sig_temp.set_xticks([])
            ax_sig_temp.set_yticks([])

            completed_segs_spat = [seg for seg in segments_spatial if seg.end_frame < frame_idx]
            n_completed_spat = len(completed_segs_spat)

            ax_sig_spat.set_facecolor("#1a1a1a")
            if n_completed_spat > 0:
                valid_sigs = [
                    seg.signature_histogram
                    for seg in completed_segs_spat
                    if seg.signature_histogram is not None
                ]
                if valid_sigs:
                    max_h = max(s.shape[0] for s in valid_sigs)
                    max_w = max(s.shape[1] for s in valid_sigs)
                    max_sigs = min(len(valid_sigs), 4)
                    stacked = np.zeros((max_sigs * (max_h + 2), max_w))

                    for i, sig_hist in enumerate(valid_sigs[-max_sigs:]):
                        h, w = sig_hist.shape
                        y_start = i * (max_h + 2)
                        stacked[y_start : y_start + h, :w] = sig_hist

                    ax_sig_spat.imshow(
                        stacked,
                        aspect="auto",
                        origin="lower",
                        cmap="hot",
                        interpolation="nearest",
                    )
                ax_sig_spat.set_title(
                    f"SIG S ({n_completed_spat} seg)",
                    fontsize=10,
                    color="lime",
                    fontweight="bold",
                )
            else:
                ax_sig_spat.set_title("SIG S (0 seg)", fontsize=10, color="#666666")
            ax_sig_spat.set_xticks([])
            ax_sig_spat.set_yticks([])

            last_and_idx = None
            for seg_idx, (_seg_start, seg_end, _t_bit, _s_bit, code) in enumerate(and_segments):
                if seg_end < frame_idx and code == "11":
                    last_and_idx = seg_idx

            analysis = None
            if last_and_idx is not None and and_segment_analyses is not None:
                for a in and_segment_analyses:
                    if a.segment_idx == last_and_idx:
                        analysis = a
                        break

            if analysis is not None and analysis.invariances is not None:
                invariances = analysis.invariances
                f0_channel = analysis.f0_channel

                n_ch = len(invariances)
                colors = ["lime" if i == f0_channel else "white" for i in range(n_ch)]
                ax_spectral.barh(
                    np.arange(n_ch),
                    invariances,
                    color=colors,
                    alpha=0.8,
                    height=0.8,
                )
                ax_spectral.axvline(0, color="yellow", linewidth=1, linestyle="--")
                ax_spectral.set_ylim(-0.5, n_ch - 0.5)
                inv_min = min(invariances.min() * 1.1, -1)
                inv_max = max(invariances.max() * 1.1, 1)
                ax_spectral.set_xlim(inv_min, inv_max)
                ax_spectral.set_ylabel("Channel", fontsize=9)
                ax_spectral.set_xlabel("Invariance (dB)", fontsize=9)
                ax_spectral.set_title(
                    f"AND_{last_and_idx} | F0≈ch{f0_channel}",
                    fontsize=10,
                    color="white",
                    fontweight="bold",
                )
            elif last_and_idx is not None:
                ax_spectral.set_facecolor("#1a1a1a")
                ax_spectral.set_title(f"AND_{last_and_idx} | No F0", fontsize=10, color="#666666")
                ax_spectral.set_xticks([])
                ax_spectral.set_yticks([])
            else:
                ax_spectral.set_facecolor("#1a1a1a")
                ax_spectral.set_title("AND_— | Invariances", fontsize=10, color="#666666")
                ax_spectral.set_xticks([])
                ax_spectral.set_yticks([])

            if memo_ma_int is not None:
                n_channels = memo_ma_int.shape[0]

                ax_memo.imshow(
                    memo_ma_int,
                    aspect="auto",
                    origin="lower",
                    cmap="hot",
                    interpolation="nearest",
                )

                segment_colors_temp = ["#00FFFF", "#00CCCC", "#009999", "#006666"]
                segment_colors_spat = ["#00FF00", "#00CC00", "#009900", "#006600"]

                for seg_idx, seg in enumerate(segments_temporal):
                    if seg.end_frame < frame_idx:
                        color = segment_colors_temp[seg_idx % len(segment_colors_temp)]
                        ax_memo.axvspan(
                            seg.start_frame,
                            seg.end_frame + 1,
                            ymin=0,
                            ymax=0.5,
                            alpha=0.25,
                            color=color,
                            zorder=1,
                        )

                for seg_idx, seg in enumerate(segments_spatial):
                    if seg.end_frame < frame_idx:
                        color = segment_colors_spat[seg_idx % len(segment_colors_spat)]
                        ax_memo.axvspan(
                            seg.start_frame,
                            seg.end_frame + 1,
                            ymin=0.5,
                            ymax=1.0,
                            alpha=0.25,
                            color=color,
                            zorder=1,
                        )

                code_colors = {
                    "00": "#666666",
                    "01": "#FF8800",
                    "10": "#00AAFF",
                    "11": "#00FF00",
                }
                for _seg_idx, (seg_start, seg_end, _t_bit, _s_bit, code) in enumerate(and_segments):
                    if seg_end < frame_idx:
                        edge_color = code_colors.get(code, "#FFFFFF")
                        line_width = 3 if code == "11" else 2
                        ax_memo.axvspan(
                            seg_start,
                            seg_end + 1,
                            alpha=0.0,
                            facecolor="none",
                            edgecolor=edge_color,
                            linewidth=line_width,
                            zorder=2,
                        )

                ax_memo.axvline(frame_idx, color="yellow", linewidth=2, label="Current")

                current_t = (
                    1 if result_temp.state in (AttractorState.ACCROCHE, AttractorState.SUIVI) else 0
                )
                current_s = (
                    1 if result_spat.state in (AttractorState.ACCROCHE, AttractorState.SUIVI) else 0
                )
                current_code = f"{current_t}{current_s}"
                bar_color = code_colors.get(current_code, "#FFFFFF")
                ax_memo.axhspan(n_channels - 3, n_channels, color=bar_color, alpha=0.7)

                ax_memo.set_xlabel("Frame (decimated)", fontsize=10)
                ax_memo.set_ylabel("Channel", fontsize=10)
                n_total_segs = sum(1 for _s, e, _t, _ss, _c in and_segments if e < frame_idx)
                n_11_segs = sum(
                    1 for _s, e, _t, _ss, c in and_segments if e < frame_idx and c == "11"
                )
                title = f"memo_ma_int | Code: {current_code} | Seg 11: {n_11_segs}/{n_total_segs}"
                ax_memo.set_title(title, fontsize=11)

            time_axis = np.linspace(0, audio_duration, len(audio_signal))
            ax_audio.plot(time_axis, audio_signal, color="#00BFFF", linewidth=0.5)

            code_colors = {
                "00": "#666666",
                "01": "#FF8800",
                "10": "#00AAFF",
                "11": "#00FF00",
            }
            for _seg_idx, (seg_start, seg_end, _t_bit, _s_bit, code) in enumerate(and_segments):
                if seg_end < frame_idx:
                    t_start = seg_start * decimation_factor / sample_rate
                    t_end = (seg_end + 1) * decimation_factor / sample_rate
                    color = code_colors.get(code, "#FFFFFF")
                    alpha = 0.3 if code == "11" else 0.15
                    ax_audio.axvspan(t_start, t_end, alpha=alpha, color=color, zorder=1)

            ax_audio.axvline(time_seconds, color="yellow", linewidth=2)
            ax_audio.set_xlim(0, audio_duration)
            ax_audio.set_xlabel("Time (s)", fontsize=10)
            ax_audio.set_ylabel("Amplitude", fontsize=10)
            ax_audio.set_title("Audio", fontsize=11)

            frame_path = frames_dir / f"frame_{frame_idx:06d}.png"
            fig.savefig(frame_path, dpi=100, facecolor="black", bbox_inches="tight")

            if (frame_idx + 1) % 20 == 0:
                logger.info("Frame %d/%d", frame_idx + 1, n_frames)

        plt.close(fig)

        logger.info("Creating video with ffmpeg...")
        temp_video = frames_dir.parent / "temp_video.mp4"

        cmd_video = [
            "ffmpeg",
            "-y",
            "-framerate",
            str(fps),
            "-i",
            str(frames_dir / "frame_%06d.png"),
            "-vf",
            "pad=ceil(iw/2)*2:ceil(ih/2)*2",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-preset",
            "medium",
            str(temp_video),
        ]

        result_ffmpeg = subprocess.run(cmd_video, capture_output=True, text=True, check=False)
        if result_ffmpeg.returncode != 0:
            logger.error("ffmpeg error: %s", result_ffmpeg.stderr)
            raise RuntimeError(f"ffmpeg failed: {result_ffmpeg.stderr}")

        logger.info("Adding audio track...")
        cmd_audio = [
            "ffmpeg",
            "-y",
            "-i",
            str(temp_video),
            "-i",
            audio_path,
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-shortest",
            output_path,
        ]

        result_ffmpeg = subprocess.run(cmd_audio, capture_output=True, text=True, check=False)
        if result_ffmpeg.returncode != 0:
            logger.error("ffmpeg audio error: %s", result_ffmpeg.stderr)
            raise RuntimeError(f"ffmpeg failed: {result_ffmpeg.stderr}")

        logger.info("Dual attractor video created: %s", output_path)

    finally:
        plt.style.use("default")

        if temp_dir is not None:
            shutil.rmtree(temp_dir)
            logger.info("Temporary files cleaned")
        else:
            logger.info("Frames kept in: %s", save_frames_dir)


def create_cascade_video(
    cascade: CascadeAttractorBank,
    cascade_results: list[CascadeFrameResult],
    histograms: np.ndarray,
    x_bins: np.ndarray,
    y_bins: np.ndarray,
    output_path: str | Path,
    memo_ma: np.ndarray | None = None,
    audio_signal: np.ndarray | None = None,
    sample_rate: int = 16000,
    decimation_factor: int = 100,
    fps: float | None = None,
    save_frames_dir: str | Path | None = None,
) -> None:
    """Create video for cascade attractor visualization.

    Shows:
    - Root attractor histogram and categorization
    - Segmentation on memo_ma and waveform (from root)
    - Cascade memory: last segment of each attractor at each level

    Args:
        cascade: CascadeAttractorBank instance.
        cascade_results: List of CascadeFrameResult from processing.
        histograms: Input histograms (n_frames, n_y, n_x).
        x_bins: X axis bin centers.
        y_bins: Y axis bin centers.
        output_path: Output video path.
        memo_ma: Amplitude memory for spectrogram (optional).
        audio_signal: Audio signal for waveform (optional).
        sample_rate: Audio sample rate.
        decimation_factor: Decimation factor for time alignment.
        fps: Frames per second (auto-calculated if None).
        save_frames_dir: Directory to save frames (optional).
    """
    output_path = Path(output_path)
    n_frames = len(cascade_results)

    if n_frames == 0:
        logger.warning("No cascade results to visualize")
        return

    if fps is None:
        duration_s = (n_frames * decimation_factor) / sample_rate
        fps = n_frames / duration_s if duration_s > 0 else 30.0

    num_levels = cascade.num_levels
    num_inputs = cascade.num_inputs

    root_segments = cascade.get_segments()

    temp_dir = None
    if save_frames_dir is not None:
        frames_dir = Path(save_frames_dir)
        frames_dir.mkdir(parents=True, exist_ok=True)
    else:
        temp_dir = tempfile.mkdtemp()
        frames_dir = Path(temp_dir)

    logger.info(
        "Creating cascade video: %d frames, %.2fs, %.1f fps",
        n_frames,
        n_frames / fps,
        fps,
    )
    logger.info("Cascade: %d inputs → %d levels", num_inputs, num_levels)
    logger.info("Frames saved in: %s", frames_dir)

    plt.style.use("dark_background")

    level_colors = [
        ["#00FF00", "#00FFFF", "#FF00FF", "#FFFF00", "#FF8800", "#00FF88", "#8800FF", "#FF0088"],
        ["#4488FF", "#FF8844"],
        ["#FFFFFF"],
    ]
    state_colors = {
        AttractorState.ATTENTE: "#444444",
        AttractorState.ACCROCHE: "#FFA500",
        AttractorState.SUIVI: "#00FF00",
    }

    try:
        for frame_idx in range(n_frames):
            cascade_result = cascade_results[frame_idx]
            root_result = cascade_result.final_result
            input_hist = histograms[frame_idx]

            time_s = (frame_idx * decimation_factor) / sample_rate

            fig = plt.figure(figsize=(18, 14))

            max_attractors_per_level = num_inputs
            cascade_rows = num_levels

            n_cols = max(6, max_attractors_per_level + 2)
            gs = GridSpec(
                3 + cascade_rows,
                n_cols,
                figure=fig,
                height_ratios=[2.5] + [1.2] * cascade_rows + [2, 1],
                hspace=0.35,
                wspace=0.25,
            )

            fig.suptitle(
                f"Cascade {num_inputs}→1 | Frame {frame_idx + 1}/{n_frames} | t = {time_s:.3f}s",
                fontsize=14,
                color="white",
            )

            ax_hist = fig.add_subplot(gs[0, :2])
            ax_cat = fig.add_subplot(gs[0, 2:4])

            if input_hist is not None and input_hist.size > 0:
                extent = [x_bins[0], x_bins[-1], y_bins[0], y_bins[-1]]
                ax_hist.imshow(
                    input_hist,
                    aspect="auto",
                    origin="lower",
                    cmap="hot",
                    extent=extent,
                )
                rmax = input_hist.max()
                ax_hist.set_title(f"Input Histogram (Rmax={rmax:.0f})", fontsize=10)
            ax_hist.set_xlabel("Mean (channel)")
            ax_hist.set_ylabel("Variation (amplitude)")

            if root_result is not None:
                ax_cat.imshow(
                    input_hist,
                    aspect="auto",
                    origin="lower",
                    cmap="gray",
                    extent=extent,
                    alpha=0.5,
                )
                bx, by = root_result.bounds_x, root_result.bounds_y
                rect = plt.Rectangle(
                    (bx[0], by[0]),
                    bx[1] - bx[0],
                    by[1] - by[0],
                    facecolor="none",
                    edgecolor=state_colors.get(root_result.state, "white"),
                    linewidth=2,
                )
                ax_cat.add_patch(rect)
                if root_result.med_x is not None and root_result.med_y is not None:
                    ax_cat.plot(root_result.med_x, root_result.med_y, "wo", markersize=8)
                state_name = root_result.state.name[0] if root_result.state else "?"
                ax_cat.set_title(
                    f"Root [{state_name}] | Med=({root_result.med_x:.1f}, {root_result.med_y:.1f})"
                    if root_result.med_x
                    else f"Root [{state_name}]",
                    fontsize=10,
                )
            ax_cat.set_xlabel("Mean")
            ax_cat.set_ylabel("Variation")

            ax_states = fig.add_subplot(gs[0, 4:])
            ax_states.set_facecolor("#0a0a0a")
            ax_states.set_title("Attractor States", fontsize=10, color="white")
            ax_states.set_xlim(0, 1)
            ax_states.set_ylim(0, 1)
            ax_states.axis("off")

            for level_idx in range(num_levels):
                level = cascade._levels[level_idx]
                n_attr = len(level.attractors)
                y_pos = 1 - (level_idx + 0.5) / num_levels

                for attr_idx in range(n_attr):
                    x_pos = (attr_idx + 0.5) / n_attr

                    if level_idx < len(cascade_result.level_results):
                        level_results = cascade_result.level_results[level_idx]
                        if attr_idx < len(level_results):
                            attr_result = level_results[attr_idx]
                            state = attr_result.state
                            state_char = state.name[0]
                            state_col = state_colors.get(state, "white")
                        else:
                            state_char = "?"
                            state_col = "gray"
                    else:
                        state_char = "?"
                        state_col = "gray"

                    box_size = 0.12
                    rect = plt.Rectangle(
                        (x_pos - box_size / 2, y_pos - box_size / 2),
                        box_size,
                        box_size,
                        facecolor=state_col,
                        edgecolor="white",
                        linewidth=1,
                    )
                    ax_states.add_patch(rect)
                    ax_states.text(
                        x_pos,
                        y_pos,
                        state_char,
                        fontsize=11,
                        color="black" if state_col != "#444444" else "white",
                        ha="center",
                        va="center",
                        fontweight="bold",
                    )

                ax_states.text(
                    0.02,
                    y_pos,
                    f"L{level_idx}",
                    fontsize=8,
                    color="gray",
                    ha="left",
                    va="center",
                )

            for level_idx in range(num_levels):
                level = cascade._levels[level_idx]
                n_attractors = len(level.attractors)
                row = 1 + level_idx

                start_col = (max_attractors_per_level - n_attractors) // 2

                for attr_idx, attractor in enumerate(level.attractors):
                    col = start_col + attr_idx
                    ax_mem = fig.add_subplot(gs[row, col])
                    ax_mem.set_facecolor("#1a1a1a")

                    if level_idx < len(level_colors) and attr_idx < len(level_colors[level_idx]):
                        color = level_colors[level_idx][attr_idx]
                    else:
                        color = "#FFFFFF"

                    segments = attractor.get_segments()
                    last_seg = None
                    for seg in reversed(segments):
                        if seg.end_frame < frame_idx:
                            last_seg = seg
                            break

                    if last_seg is not None:
                        if last_seg.signature_histogram is not None:
                            sig_hist = last_seg.signature_histogram
                            if (
                                last_seg.signature_mean_bins is not None
                                and last_seg.signature_var_bins is not None
                            ):
                                extent = [
                                    last_seg.signature_mean_bins[0],
                                    last_seg.signature_mean_bins[-1],
                                    last_seg.signature_var_bins[0],
                                    last_seg.signature_var_bins[-1],
                                ]
                            else:
                                extent = [0, sig_hist.shape[1], 0, sig_hist.shape[0]]
                            ax_mem.imshow(
                                sig_hist,
                                aspect="auto",
                                origin="lower",
                                cmap="hot",
                                extent=extent,
                                alpha=0.8,
                            )

                        bx = last_seg.median_bounds_x
                        by = last_seg.median_bounds_y
                        if bx and by:
                            margin_x = max(1, (bx[1] - bx[0]) * 0.3)
                            margin_y = max(1, (by[1] - by[0]) * 0.3)
                            ax_mem.set_xlim(bx[0] - margin_x, bx[1] + margin_x)
                            ax_mem.set_ylim(by[0] - margin_y, by[1] + margin_y)

                            rect = plt.Rectangle(
                                (bx[0], by[0]),
                                bx[1] - bx[0],
                                by[1] - by[0],
                                facecolor="none",
                                edgecolor=color,
                                linewidth=2,
                            )
                            ax_mem.add_patch(rect)

                        if last_seg.mean_med_x is not None and last_seg.mean_med_y is not None:
                            ax_mem.plot(
                                last_seg.mean_med_x,
                                last_seg.mean_med_y,
                                "o",
                                color="cyan",
                                markersize=4,
                            )
                            sigma_x = last_seg.hist_std_x or 1.0
                            sigma_y = last_seg.hist_std_y or 1.0
                            if sigma_x > 0 and sigma_y > 0:
                                ellipse = Ellipse(
                                    (last_seg.mean_med_x, last_seg.mean_med_y),
                                    width=2 * sigma_x,
                                    height=2 * sigma_y,
                                    facecolor="none",
                                    edgecolor="cyan",
                                    linewidth=1.5,
                                )
                                ax_mem.add_patch(ellipse)

                        title = f"L{level_idx}A{attr_idx} S{last_seg.class_id}"
                    else:
                        title = f"L{level_idx}A{attr_idx} ---"

                    ax_mem.set_title(title, fontsize=8, color=color)
                    ax_mem.tick_params(labelsize=6)
                    for spine in ax_mem.spines.values():
                        spine.set_color(color)

            row_spec = 1 + cascade_rows
            ax_spec = fig.add_subplot(gs[row_spec, :])
            if memo_ma is not None:
                ax_spec.imshow(
                    memo_ma,
                    aspect="auto",
                    origin="lower",
                    cmap="hot",
                    extent=[0, memo_ma.shape[1], 0, memo_ma.shape[0]],
                )
                sample_idx = frame_idx * decimation_factor
                ax_spec.axvline(sample_idx, color="cyan", linewidth=1, alpha=0.8)

                for seg in root_segments:
                    if seg.end_frame < frame_idx:
                        start_sample = seg.start_frame * decimation_factor
                        end_sample = seg.end_frame * decimation_factor
                        ax_spec.axvspan(
                            start_sample,
                            end_sample,
                            alpha=0.2,
                            color="#FFFFFF",
                        )
                        ax_spec.text(
                            (start_sample + end_sample) / 2,
                            memo_ma.shape[0] - 2,
                            f"S{seg.class_id}",
                            fontsize=7,
                            color="white",
                            ha="center",
                        )

            ax_spec.set_title("memo_ma (root segments)", fontsize=10)
            ax_spec.set_xlabel("Samples")
            ax_spec.set_ylabel("Channel")

            row_wave = 2 + cascade_rows
            ax_wave = fig.add_subplot(gs[row_wave, :])
            if audio_signal is not None:
                time_axis = np.arange(len(audio_signal)) / sample_rate
                ax_wave.plot(time_axis, audio_signal, color="deepskyblue", linewidth=0.5)
                ax_wave.axvline(time_s, color="red", linewidth=1)

                for seg in root_segments:
                    if seg.end_frame < frame_idx:
                        start_t = (seg.start_frame * decimation_factor) / sample_rate
                        end_t = (seg.end_frame * decimation_factor) / sample_rate
                        ax_wave.axvspan(start_t, end_t, alpha=0.2, color="#FFFFFF")

            ax_wave.set_title("Audio signal (root segments)", fontsize=10)
            ax_wave.set_xlabel("Time (s)")
            ax_wave.set_ylabel("Amplitude")
            ax_wave.set_xlim(0, len(audio_signal) / sample_rate if audio_signal is not None else 1)

            frame_path = frames_dir / f"frame_{frame_idx:06d}.png"
            plt.tight_layout()
            fig.savefig(frame_path, dpi=100, facecolor="black")
            plt.close(fig)

            if (frame_idx + 1) % 10 == 0 or frame_idx == 0:
                logger.info("Frame %d/%d generated", frame_idx + 1, n_frames)

        logger.info("Encoding video with ffmpeg...")
        frames_pattern = str(frames_dir / "frame_%06d.png")
        temp_video = str(frames_dir / "temp_video.mp4")

        cmd_video = [
            "ffmpeg",
            "-y",
            "-framerate",
            str(fps),
            "-i",
            frames_pattern,
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-crf",
            "23",
            temp_video,
        ]
        result = subprocess.run(cmd_video, capture_output=True, text=True, check=False)
        if result.returncode != 0:
            logger.error("ffmpeg error: %s", result.stderr)
            raise RuntimeError(f"ffmpeg failed: {result.stderr}")

        if audio_signal is not None:
            logger.info("Adding audio track...")
            audio_path = str(frames_dir / "audio.wav")
            sf.write(audio_path, audio_signal, sample_rate)

            cmd_audio = [
                "ffmpeg",
                "-y",
                "-i",
                temp_video,
                "-i",
                audio_path,
                "-c:v",
                "copy",
                "-c:a",
                "aac",
                "-b:a",
                "128k",
                "-shortest",
                str(output_path),
            ]
            result = subprocess.run(cmd_audio, capture_output=True, text=True, check=False)
            if result.returncode != 0:
                logger.error("ffmpeg audio error: %s", result.stderr)
                raise RuntimeError(f"ffmpeg failed: {result.stderr}")
        else:
            shutil.move(temp_video, str(output_path))

        logger.info("Cascade video created: %s", output_path)

    finally:
        plt.style.use("default")

        if temp_dir is not None:
            shutil.rmtree(temp_dir)
            logger.info("Temporary files cleaned")
        else:
            logger.info("Frames kept in: %s", frames_dir)
